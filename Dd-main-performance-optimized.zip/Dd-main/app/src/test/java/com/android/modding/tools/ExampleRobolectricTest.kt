package com.android.modding.tools

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.modding.tools.models.CornersModel
import com.android.modding.tools.models.GradientModel
import com.android.modding.tools.models.LayerModel
import com.android.modding.tools.models.StateModel
import com.android.modding.tools.models.StrokeModel
import com.android.modding.tools.generators.XmlGenerator
import com.android.modding.tools.generators.XmlFormatter
import com.android.modding.tools.generators.XmlValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.LinkedHashMap

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Morsalin XML Creator", appName)
  }

  @Test
  fun `verify shape xml generation and validation`() {
    val layer = LayerModel("TestLayer")
    layer.setSolidColor("#FF081A24")
    layer.corners.setCorners(8, 8, 8, 8, true)
    layer.stroke.widthDp = 2
    layer.stroke.color = "#FF00E5FF"

    val xml = XmlGenerator.generateShapeXml(layer)
    val formatted = XmlFormatter.formatXml(xml)
    val validation = XmlValidator.validateXml(formatted)

    assertTrue("Shape XML should be valid: ${validation.summary}", validation.isValid)
  }

  @Test
  fun `verify linear and radial gradient xml generation and validation`() {
    val layerLinear = LayerModel("Linear")
    layerLinear.isGradient = true
    layerLinear.gradient.type = GradientModel.TYPE_LINEAR
    layerLinear.gradient.startColor = "#FF00FFFF"
    layerLinear.gradient.endColor = "#FF052219"
    layerLinear.gradient.angle = 270

    val xmlLinear = XmlGenerator.generateShapeXml(layerLinear)
    val valLinear = XmlValidator.validateXml(xmlLinear)
    assertTrue("Linear gradient XML must be valid: ${valLinear.summary}", valLinear.isValid)

    val layerRadial = LayerModel("Radial")
    layerRadial.isGradient = true
    layerRadial.gradient.type = GradientModel.TYPE_RADIAL
    layerRadial.gradient.startColor = "#00FFFF"
    layerRadial.gradient.endColor = "#020B08"
    layerRadial.gradient.gradientRadiusDp = 50

    val xmlRadial = XmlGenerator.generateShapeXml(layerRadial)
    val valRadial = XmlValidator.validateXml(xmlRadial)
    assertTrue("Radial gradient XML must be valid: ${valRadial.summary}", valRadial.isValid)
    assertTrue("Radial XML must include positive gradientRadius", xmlRadial.contains("android:gradientRadius=\"50dp\""))
  }

  @Test
  fun `verify selector xml generation with states and fallback`() {
    val normal = StateModel(StateModel.STATE_NORMAL)
    normal.layers[0].setSolidColor("#FF00FFE6")

    val pressed = StateModel(StateModel.STATE_PRESSED)
    pressed.layers[0].setSolidColor("#FF005544")

    val checked = StateModel(StateModel.STATE_CHECKED)
    checked.layers[0].setSolidColor("#FF00B39E")

    val map = LinkedHashMap<String, StateModel>()
    map[StateModel.STATE_NORMAL] = normal
    map[StateModel.STATE_PRESSED] = pressed
    map[StateModel.STATE_CHECKED] = checked

    val selectorXml = XmlGenerator.generateSelectorXml(map)
    val validation = XmlValidator.validateXml(selectorXml)

    assertTrue("Generated selector XML must be strictly valid: ${validation.summary}", validation.isValid)
    assertTrue("Selector must have item", selectorXml.contains("<item"))
    assertTrue("Selector must have state_pressed", selectorXml.contains("android:state_pressed=\"true\""))
  }

  @Test
  fun `verify dash width and gap compliance in stroke`() {
    val layer = LayerModel("Dashed")
    layer.stroke.widthDp = 2
    layer.stroke.color = "#FF00E5FF"
    layer.stroke.dashWidthDp = 4
    layer.stroke.dashGapDp = 3

    val xml = XmlGenerator.generateShapeXml(layer)
    assertTrue(xml.contains("android:dashWidth=\"4dp\""))
    assertTrue(xml.contains("android:dashGap=\"3dp\""))
    val validation = XmlValidator.validateXml(xml)
    assertTrue(validation.isValid)
  }

  @Test
  fun `verify color sanitizer handles invalid colors safely`() {
    val safeColor = XmlGenerator.sanitizeColor("", "#00000000")
    assertEquals("#00000000", safeColor)

    val fixedHex = XmlGenerator.sanitizeColor("00FFE6", "#00000000")
    assertEquals("#00FFE6", fixedHex)

    val validHex = XmlGenerator.sanitizeColor("#FF00FFE6", "#00000000")
    assertEquals("#FF00FFE6", validHex)
  }

  @Test
  fun `verify typing helper styles and continuous loop configuration`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals(18, com.android.modding.tools.helpers.MorsalinTypingTextHelper.STYLE_NAMES.size)
    assertEquals(18, com.android.modding.tools.helpers.MorsalinTypingTextHelper.STYLE_DESCRIPTIONS.size)
    assertTrue(com.android.modding.tools.helpers.MorsalinTypingTextHelper.CURSOR_SYMBOLS.isNotEmpty())
    assertTrue(com.android.modding.tools.helpers.MorsalinTypingTextHelper.isLoopEnabled(context))
  }

  @Test
  fun `verify ClassToSmaliProcessor handles invalid data gracefully without crashing`() {
    val res1 = com.android.modding.tools.helpers.ClassToSmaliProcessor.convertClassToSmali(null, "Test.class")
    assertFalse(res1.success)
    assertNotNull(res1.errorMessage)

    val randomBytes = byteArrayOf(0x01, 0x02, 0x03, 0x04, 0x05, 0x06)
    val res2 = com.android.modding.tools.helpers.ClassToSmaliProcessor.convertClassToSmali(randomBytes, "Corrupt.class")
    assertFalse(res2.success)
    assertTrue(res2.errorMessage.contains("Invalid Class File"))
  }

  @Test
  fun `verify ClassToSmaliRecentManager storage operations`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.android.modding.tools.helpers.ClassToSmaliRecentManager.addRecent(
      context,
      "SampleTest.smali",
      "12.4 KB",
      ".class public LSampleTest;\n.super Ljava/lang/Object;",
      "SampleTest"
    )

    val recents = com.android.modding.tools.helpers.ClassToSmaliRecentManager.getRecents(context)
    assertTrue(recents.isNotEmpty())
    val top = recents[0]
    assertEquals("SampleTest.smali", top.fileName)
    assertEquals("12.4 KB", top.formattedSize)

    com.android.modding.tools.helpers.ClassToSmaliRecentManager.deleteRecent(context, top.id)
    val updated = com.android.modding.tools.helpers.ClassToSmaliRecentManager.getRecents(context)
    assertTrue(updated.none { it.id == top.id })
  }

  @Test
  fun `verify DialogConfig defaults and serialization`() {
    val simple = com.android.modding.tools.dialogmaker.DialogConfig.createSimpleSmaliDefault()
    assertNotNull(simple)
    assertEquals(com.android.modding.tools.dialogmaker.DialogConfig.TYPE_SIMPLE_SMALI, simple.dialogType)
    assertEquals(2, simple.buttonCount)

    val colorful = com.android.modding.tools.dialogmaker.DialogConfig.createColorfulDefault()
    assertEquals(com.android.modding.tools.dialogmaker.DialogConfig.TYPE_COLORFUL, colorful.dialogType)
    assertTrue(colorful.hasImage)
    assertEquals("ICON", colorful.imageKind)

    val profile = com.android.modding.tools.dialogmaker.DialogConfig.createProfileDefault()
    assertEquals(com.android.modding.tools.dialogmaker.DialogConfig.TYPE_PROFILE, profile.dialogType)
    assertTrue(profile.hasImage)
    assertEquals("AVATAR", profile.imageKind)

    val notice = com.android.modding.tools.dialogmaker.DialogConfig.createNoticeDefault()
    assertEquals(com.android.modding.tools.dialogmaker.DialogConfig.TYPE_NOTICE, notice.dialogType)
    assertTrue(notice.hasNoticeBadge)

    val custom = com.android.modding.tools.dialogmaker.DialogConfig.createCustomDefault()
    assertEquals(com.android.modding.tools.dialogmaker.DialogConfig.TYPE_CUSTOM, custom.dialogType)

    val json = custom.toJson()
    val restored = com.android.modding.tools.dialogmaker.DialogConfig.fromJson(json)
    assertNotNull(restored)
    assertEquals(custom.titleText, restored.titleText)
    assertEquals(custom.dialogType, restored.dialogType)
  }

  @Test
  fun `verify XmlMinimizer produces minimal valid XML without bloat`() {
    val config = com.android.modding.tools.dialogmaker.DialogConfig.createSimpleSmaliDefault()
    val bundle = com.android.modding.tools.dialogmaker.XmlMinimizer.generateRequiredXmls(config)
    assertTrue(bundle.isValid)
    assertNotNull(bundle.files)
    // Pure code dialog only generates dialog_bg.xml and minimal dialog_layout.xml
    assertTrue(bundle.files.containsKey("res/drawable/bg_morsalin_dialog.xml"))
    val bgXml = bundle.files["res/drawable/bg_morsalin_dialog.xml"]!!
    assertTrue(bgXml.contains("<shape"))
    assertTrue(bgXml.contains("android:shape=\"rectangle\""))
  }

  @Test
  fun `verify DexValidator rejects corrupt or invalid binaries`() {
    val emptyResult = com.android.modding.tools.dialogmaker.DexValidator.validate(ByteArray(0), null)
    assertFalse(emptyResult.isValid)
    assertTrue(emptyResult.errorMessage.lowercase().contains("empty"))

    val corruptBytes = byteArrayOf(0x00, 0x01, 0x02, 0x03, 0x04)
    val corruptResult = com.android.modding.tools.dialogmaker.DexValidator.validate(corruptBytes, null)
    assertFalse(corruptResult.isValid)
  }

  @Test
  fun `verify DialogPackageBuilder builds real DEX and clean package`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val config = com.android.modding.tools.dialogmaker.DialogConfig.createSimpleSmaliDefault()
    config.titleText = "Test Alert"
    config.messageText = "Testing Dex compilation pipeline"

    val result = com.android.modding.tools.dialogmaker.DialogPackageBuilder.buildDialogPackage(context, config)
    assertTrue("Dialog package build should succeed: ${result.errorMessage}", result.success)
    assertNotNull(result.dexBytes)
    assertTrue(result.dexBytes.size > 112)
    assertNotNull(result.dexValidation)
    assertTrue("DEX validation should pass", result.dexValidation.isValid)
    assertTrue(result.dexValidation.classCount > 0)
    assertNotNull(result.guideContent)
    assertTrue(result.guideContent.contains("REAL DALVIK SMALI HOOK FOR ONCREATE"))
    assertTrue(result.guideContent.contains("ডেভলপার বাই মোরসালিন খান"))
    assertNotNull(result.generatedPackage)

    // Ensure package contains strictly SINGLE classes.dex binary
    assertNotNull(result.generatedPackage.getDexBinary())
    assertTrue(result.generatedPackage.binaryFiles.containsKey("classes.dex"))
    assertFalse(result.generatedPackage.binaryFiles.containsKey("classes_rename.dex"))

    // Ensure package contains hook.smali and NO XML files
    assertTrue(result.generatedPackage.files.containsKey("hook.smali"))
    val smaliHook = result.generatedPackage.files["hook.smali"]!!
    assertTrue(smaliHook.contains("MorsalinCustomDialog;->show"))

    // Ensure package contains assets/ folder icon file and zero unnecessary text files
    assertTrue(result.generatedPackage.binaryFiles.containsKey("assets/dialog_icon.png"))
    assertFalse(result.generatedPackage.files.containsKey("assets/dialog_config.json"))

    // Verify ZIP bytes packaging succeeds with all entries
    val zipBytes = com.android.modding.tools.helpers.GeneratedPackageExporter.buildZipBytes(result.generatedPackage)
    assertNotNull(zipBytes)
    assertTrue(zipBytes.size > 200)
  }
}

