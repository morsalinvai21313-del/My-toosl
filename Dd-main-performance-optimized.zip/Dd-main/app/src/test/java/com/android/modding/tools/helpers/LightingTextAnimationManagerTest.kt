package com.android.modding.tools.helpers

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LightingTextAnimationManagerTest {

    @Test
    fun testTotalStylesCountAndMetadata() {
        assertEquals(10, LightingTextAnimationManager.TOTAL_STYLES)
        assertEquals(10, LightingTextAnimationManager.STYLE_NAMES.size)
        assertEquals(10, LightingTextAnimationManager.STYLE_DESCRIPTIONS.size)

        for (i in 0 until LightingTextAnimationManager.TOTAL_STYLES) {
            val name = LightingTextAnimationManager.getStyleName(i)
            val desc = LightingTextAnimationManager.getStyleDescription(i)
            val colors = LightingTextAnimationManager.getColorsForStyle(i)

            assertNotNull(name)
            assertTrue(name.isNotEmpty())
            assertNotNull(desc)
            assertTrue(desc.isNotEmpty())
            assertNotNull(colors)
            assertTrue(colors.size >= 2)
        }
    }

    @Test
    fun testListenerNotification() {
        var notifiedStyle = -1
        var notifiedEnabled = false

        val listener = LightingTextAnimationManager.OnLightingStyleChangeListener { newStyle, isEnabled ->
            notifiedStyle = newStyle
            notifiedEnabled = isEnabled
        }

        LightingTextAnimationManager.registerListener(listener)
        LightingTextAnimationManager.notifyListeners(LightingTextAnimationManager.STYLE_SYNTHWAVE, true)
        assertEquals(LightingTextAnimationManager.STYLE_SYNTHWAVE, notifiedStyle)
        assertTrue(notifiedEnabled)

        LightingTextAnimationManager.unregisterListener(listener)
        LightingTextAnimationManager.notifyListeners(LightingTextAnimationManager.STYLE_SUPERNOVA, false)
        // Should remain unchanged after unregistering
        assertEquals(LightingTextAnimationManager.STYLE_SYNTHWAVE, notifiedStyle)
    }
}
