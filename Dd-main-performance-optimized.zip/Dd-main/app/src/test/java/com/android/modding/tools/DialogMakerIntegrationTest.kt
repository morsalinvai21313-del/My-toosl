package com.android.modding.tools

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.modding.tools.dialogmaker.DexValidator
import com.android.modding.tools.dialogmaker.DialogConfig
import com.android.modding.tools.dialogmaker.DialogPackageBuilder
import com.android.modding.tools.dialogmaker.GuideGenerator
import com.android.modding.tools.dialogmaker.ProgrammaticDialogSourceGenerator
import com.android.modding.tools.dialogmaker.XmlMinimizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DialogMakerIntegrationTest {

    @Test
    fun `verify all 5 dialog presets configuration and json roundtrip`() {
        val simple = DialogConfig.createSimpleSmaliDefault()
        assertEquals(DialogConfig.TYPE_SIMPLE_SMALI, simple.dialogType)
        val jsonSimple = simple.toJson()
        val parsedSimple = DialogConfig.fromJson(jsonSimple)
        assertEquals(simple.titleText, parsedSimple.titleText)
        assertEquals(simple.buttonCount, parsedSimple.buttonCount)

        val colorful = DialogConfig.createColorfulDefault()
        assertEquals(DialogConfig.TYPE_COLORFUL, colorful.dialogType)
        assertTrue(colorful.hasImage)
        assertTrue(colorful.isGradient)

        val profile = DialogConfig.createProfileDefault()
        assertEquals(DialogConfig.TYPE_PROFILE, profile.dialogType)
        assertEquals("AVATAR", profile.imageKind)
        assertTrue(profile.hasNoticeBadge)

        val notice = DialogConfig.createNoticeDefault()
        assertEquals(DialogConfig.TYPE_NOTICE, notice.dialogType)
        assertTrue(notice.hasNoticeBadge)

        val custom = DialogConfig.createCustomDefault()
        assertEquals(DialogConfig.TYPE_CUSTOM, custom.dialogType)
    }

    @Test
    fun `verify programmatic dialog generator creates zero xml pure java code`() {
        val config = DialogConfig.createCustomDefault()
        val javaCode = ProgrammaticDialogSourceGenerator.generateJavaCode(config)

        assertNotNull(javaCode)
        assertTrue(javaCode.contains("package com.morsalin.dialog;"))
        assertTrue(javaCode.contains("public class MorsalinCustomDialog"))
        assertTrue(javaCode.contains("public static void show(final Context context)"))
        assertTrue(javaCode.contains("new Dialog(context)"))
        assertTrue(javaCode.contains("new GradientDrawable()"))
        assertTrue(javaCode.contains("new TextView(context)"))
        assertTrue(javaCode.contains("new Button(context)"))
        // Verifies zero XML layout inflation
        assertFalse(javaCode.contains("R.layout."))
        assertFalse(javaCode.contains("R.drawable."))
    }

    @Test
    fun `verify dialog package builder compiles real dex and outputs strictly single classes_dex, GUIDE_smali, and zero xml`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val config = DialogConfig.createSimpleSmaliDefault()

        val buildResult = DialogPackageBuilder.buildDialogPackage(context, config)

        assertTrue("Build must succeed: ${buildResult.errorMessage}", buildResult.success)
        assertNotNull(buildResult.dexBytes)
        assertTrue("DEX size must be greater than 112 bytes", buildResult.dexBytes.size > 112)

        // Verify DEX validation results
        val dexVal = buildResult.dexValidation
        assertNotNull(dexVal)
        assertTrue("Dex validator must pass: ${dexVal.errorMessage}", dexVal.isValid)
        assertTrue(dexVal.classCount > 0)
        assertNotNull(dexVal.checksumHex)
        assertNotNull(dexVal.sha1Hex)

        // Verify hook.smali file
        assertNotNull(buildResult.guideContent)
        assertTrue(buildResult.guideContent.contains("REAL DALVIK SMALI HOOK FOR ONCREATE"))
        assertTrue(buildResult.guideContent.contains("Lcom/morsalin/dialog/MorsalinCustomDialog;->show"))
        assertTrue(buildResult.guideContent.contains("ডেভলপার বাই মোরসালিন খান"))

        // Verify package contains strictly SINGLE classes.dex, single hook.smali, NO classes_rename.dex, and ZERO XML
        val pkg = buildResult.generatedPackage
        assertNotNull(pkg)
        assertNotNull(pkg.getDexBinary())
        assertTrue("Must contain classes.dex", pkg.binaryFiles.containsKey("classes.dex"))
        assertFalse("Must NOT contain classes_rename.dex", pkg.binaryFiles.containsKey("classes_rename.dex"))
        val dexFileCount = pkg.binaryFiles.keys.count { it.endsWith(".dex") }
        assertEquals("Must contain strictly 1 classes.dex file", 1, dexFileCount)

        assertTrue("Must contain hook.smali", pkg.files.containsKey("hook.smali"))
        assertFalse("Must NOT contain GUIDE.txt", pkg.files.containsKey("GUIDE.txt"))
        assertFalse("Must NOT contain ReadMe.smali", pkg.files.containsKey("ReadMe.smali"))
        val smaliFileCount = pkg.files.keys.count { it.endsWith(".smali") }
        assertEquals("Must contain strictly 1 hook.smali file", 1, smaliFileCount)

        // ZERO XML check
        assertFalse("Must NOT contain layout XML", pkg.files.containsKey("res/layout/dialog_morsalin_custom.xml"))
        assertFalse("Must NOT contain drawable XML", pkg.files.containsKey("res/drawable/bg_morsalin_dialog.xml"))
        for (key in pkg.files.keys) {
            assertFalse("Package must contain NO XML files: $key", key.endsWith(".xml"))
        }
    }

    @Test
    fun `verify guide generator includes all required smali hook sections`() {
        val config = DialogConfig.createProfileDefault()
        val dexResult = DexValidator.ValidationResult(
            true, 5000, "12345678",
            "abcdef1234567890abcdef1234567890abcdef12", 1, 6,
            "Lcom/morsalin/dialog/MorsalinCustomDialog;", null
        )
        val guide = GuideGenerator.generateSmaliGuide(config, dexResult)

        assertTrue(guide.contains("REAL DALVIK SMALI HOOK FOR ONCREATE"))
        assertTrue(guide.contains("invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V"))
        assertTrue(guide.contains(GuideGenerator.STYLISH_BORDER))
        assertTrue(guide.contains("ডেভলপার বাই মোরসালিন খান"))
    }

    @Test
    fun `verify separate dedicated asset files are generated for all dialog options`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Simple Smali Dialog
        val simple = DialogConfig.createSimpleSmaliDefault()
        val simpleBundle = com.android.modding.tools.dialogmaker.DialogAssetGenerator.generateAssets(simple, context)
        assertTrue("Simple Smali must generate assets/dialog_icon.png",
            simpleBundle.binaryAssets.containsKey("assets/dialog_icon.png"))
        assertTrue(simpleBundle.binaryAssets["assets/dialog_icon.png"]!!.isNotEmpty())

        // 2. Colorful Neon Dialog
        val colorful = DialogConfig.createColorfulDefault()
        val colorfulBundle = com.android.modding.tools.dialogmaker.DialogAssetGenerator.generateAssets(colorful, context)
        assertTrue("Colorful Neon must generate assets/neon_dialog_icon.png",
            colorfulBundle.binaryAssets.containsKey("assets/neon_dialog_icon.png"))

        // 3. Profile Dialog
        val profile = DialogConfig.createProfileDefault()
        val profileBundle = com.android.modding.tools.dialogmaker.DialogAssetGenerator.generateAssets(profile, context)
        assertTrue("Profile must generate assets/morsalin_avatar.png",
            profileBundle.binaryAssets.containsKey("assets/morsalin_avatar.png"))
        assertTrue("Profile must generate assets/profile_badge.png",
            profileBundle.binaryAssets.containsKey("assets/profile_badge.png"))

        // 4. Notice Alert Dialog
        val notice = DialogConfig.createNoticeDefault()
        val noticeBundle = com.android.modding.tools.dialogmaker.DialogAssetGenerator.generateAssets(notice, context)
        assertTrue("Notice must generate assets/notice_alert_icon.png",
            noticeBundle.binaryAssets.containsKey("assets/notice_alert_icon.png"))
        assertTrue("Notice must generate assets/notice_badge.png",
            noticeBundle.binaryAssets.containsKey("assets/notice_badge.png"))

        // 5. Verify no unnecessary text/json files in assets
        assertTrue(simpleBundle.textAssets.isEmpty())

        // 6. Custom Gallery Avatar Asset
        profile.hasCustomAvatar = true
        profile.customAvatarBytes = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) // PNG header mock
        val customBundle = com.android.modding.tools.dialogmaker.DialogAssetGenerator.generateAssets(profile, context)
        assertEquals(8, customBundle.binaryAssets["assets/morsalin_avatar.png"]!!.size)
    }

    @Test
    fun `verify dont show again checkbox generation and vertical proportion in java code`() {
        val config = DialogConfig.createNoticeDefault()
        config.hasDontShowAgain = true
        config.dontShowAgainText = "Don't show this again"
        val code = ProgrammaticDialogSourceGenerator.generateJavaCode(config)

        assertTrue("Must contain CheckBox creation", code.contains("CheckBox cbDontShow = new android.widget.CheckBox(context);"))
        assertTrue("Must contain CheckBox text", code.contains("Don't show this again"))
        assertTrue("Must check SharedPreferences before showing", code.contains("morsalin_dialog_prefs"))
        assertTrue("Must contain setMinimumHeight for vertical elegance", code.contains("root.setMinimumHeight("))
    }
}
