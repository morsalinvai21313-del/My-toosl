package com.android.modding.tools.helpers

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LightingTextHelperTest {

    private fun matchesCodeRule(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("code_output") ||
                lower.contains("xml_output") ||
                lower.contains("generated_code") ||
                lower.contains("generated_xml") ||
                lower.contains("code_preview") ||
                lower.contains("preview_code") ||
                lower.contains("editor_code") ||
                lower.contains("code_content") ||
                lower.contains("xml_content") ||
                lower.contains("tv_code") ||
                lower.contains("et_code") ||
                lower.contains("syntax")
    }

    @Test
    fun testCodeViewExclusionRules() {
        val codeNames = listOf(
            "tv_code_output",
            "tv_generated_xml",
            "et_code_input",
            "editor_code",
            "code_preview_box",
            "preview_code_syntax",
            "syntax_highlighter_output",
            "tv_code",
            "et_code"
        )

        for (name in codeNames) {
            assertTrue("Expected $name to match code exclusion rule", matchesCodeRule(name))
        }

        // Test normal UI element names that should NOT be excluded
        val uiNames = listOf(
            "btn_pick_color",
            "tv_app_title",
            "btn_back",
            "tv_category_title",
            "btn_copy",
            "btn_save_history",
            "btn_download_xml",
            "btn_share_export",
            "tv_setting_item"
        )

        for (name in uiNames) {
            assertFalse("Expected $name to NOT match code exclusion rule", matchesCodeRule(name))
        }
    }
}
