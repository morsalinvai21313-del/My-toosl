package com.android.modding.tools.helpers

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AnimatedDividerManagerTest {

    @Test
    fun testStylesCountAndMetadata() {
        assertEquals(13, AnimatedDividerManager.TOTAL_STYLES)
        assertEquals(13, AnimatedDividerManager.STYLE_NAMES.size)
        assertEquals(13, AnimatedDividerManager.STYLE_DESCRIPTIONS.size)

        for (i in 0 until AnimatedDividerManager.TOTAL_STYLES) {
            val name = AnimatedDividerManager.getStyleName(i)
            val desc = AnimatedDividerManager.getStyleDescription(i)
            val shortName = AnimatedDividerManager.getStyleShortName(i)

            assertNotNull(name)
            assertTrue(name.isNotEmpty())
            assertNotNull(desc)
            assertTrue(desc.isNotEmpty())
            assertNotNull(shortName)
            assertTrue(shortName.isNotEmpty())
        }
    }

    @Test
    fun testListenerNotification() {
        var notifiedStyle = -1
        val listener = AnimatedDividerManager.OnDividerStyleChangeListener { newStyle ->
            notifiedStyle = newStyle
        }

        AnimatedDividerManager.registerListener(listener)
        AnimatedDividerManager.notifyListeners(AnimatedDividerManager.STYLE_PLASMA_COMET)
        assertEquals(AnimatedDividerManager.STYLE_PLASMA_COMET, notifiedStyle)

        AnimatedDividerManager.unregisterListener(listener)
        AnimatedDividerManager.notifyListeners(AnimatedDividerManager.STYLE_SUPERNOVA_LASER)
        // Should remain unchanged after unregistering
        assertEquals(AnimatedDividerManager.STYLE_PLASMA_COMET, notifiedStyle)
    }
}
