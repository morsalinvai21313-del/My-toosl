package com.android.modding.tools.helpers

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.modding.tools.activities.AnimationMakerActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MorsalinDexGeneratorTest {

    private fun assertValidDex(dexBytes: ByteArray?, minSize: Int) {
        assertNotNull("DEX binary must not be null", dexBytes)
        assertTrue("DEX binary must be at least $minSize bytes, got ${dexBytes!!.size}", dexBytes.size >= minSize)
        // Verify Dalvik magic bytes: dex\n035\0
        assertEquals(0x64.toByte(), dexBytes[0]) // 'd'
        assertEquals(0x65.toByte(), dexBytes[1]) // 'e'
        assertEquals(0x78.toByte(), dexBytes[2]) // 'x'
        assertEquals(0x0a.toByte(), dexBytes[3]) // '\n'
        assertEquals(0x30.toByte(), dexBytes[4]) // '0'
        assertEquals(0x33.toByte(), dexBytes[5]) // '3'
        assertEquals(0x35.toByte(), dexBytes[6]) // '5'
        assertEquals(0x00.toByte(), dexBytes[7]) // '\0'
    }

    @Test
    fun testAnimationHelperDexGeneration() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val step = AnimationMakerActivity.AnimStep("Bounce", 500, 50, 100, 0, 1, 0, false)
        val dex = MorsalinDexGenerator.buildAnimationHelperDex(context, listOf(step))
        assertValidDex(dex, 3000)
    }

    @Test
    fun testTextAnimationDexGeneration() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dex = MorsalinDexGenerator.buildTextAnimationDex(
            context,
            "Morsalin Hacker Mod",
            "Neon Glow",
            24,
            "#00E5FF",
            "#7C4DFF",
            "#00FF88",
            12,
            1,
            600
        )
        assertValidDex(dex, 5000)
    }

    @Test
    fun testCustomDialogDexGeneration() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dex = MorsalinDexGenerator.buildCustomDialogDex(
            context,
            "VIP Mod Alert",
            "Subtitle Notice",
            "Welcome to Morsalin Mod Tools!",
            3,
            "CONFIRM",
            "CANCEL",
            "MORE",
            "https://t.me/morsalin",
            "",
            "https://google.com",
            "#0A0E1A",
            "#00E5FF",
            "#00FF88",
            "#FFFFFF",
            "#A0AEC0",
            16,
            2,
            16,
            85,
            "Zoom Bounce"
        )
        assertValidDex(dex, 7000)
    }

    @Test
    fun testNotificationHelperDexGeneration() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dex = MorsalinDexGenerator.buildNotificationHelperDex(
            context,
            "Big Text",
            "Update Available",
            "New VIP Features Unlocked",
            "#00E5FF",
            75,
            3,
            "Download",
            "Changelog",
            "Dismiss",
            "https://t.me/morsalin",
            "https://t.me/morsalin",
            "https://github.com",
            ""
        )
        assertValidDex(dex, 5000)
    }
}
