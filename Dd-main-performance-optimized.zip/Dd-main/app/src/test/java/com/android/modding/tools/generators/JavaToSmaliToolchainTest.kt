package com.android.modding.tools.generators

import org.junit.Test
import org.junit.Assert.*

class JavaToSmaliToolchainTest {

    @Test
    fun test1_simpleHelloWorld() {
        val src = """
            package com.test;
            public class HelloWorld {
                public static void main(String[] args) {
                    System.out.println("Hello, World!");
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "HelloWorld.java", null)
        assertTrue("Compilation should succeed", res.success)
        assertTrue("Should contain class descriptor", res.primarySmaliContent.contains(".class public Lcom/test/HelloWorld;"))
        assertTrue("Should contain print call", res.primarySmaliContent.contains("invoke-virtual"))
        assertNotNull("DEX bytes generated", res.dexBytes)
        assertTrue("DEX bytes non-empty", res.dexBytes.isNotEmpty())
        assertTrue("Round-trip valid", res.roundTripValid)
    }

    @Test
    fun test2_fieldsAndConstructor() {
        val src = """
            package com.test;
            public class Person {
                public String name;
                private int age;
                public static final double PI = 3.14159;

                public Person(String name, int age) {
                    this.name = name;
                    this.age = age;
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "Person.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(".field public name:Ljava/lang/String;"))
        assertTrue(res.primarySmaliContent.contains(".field private age:I"))
        assertTrue(res.primarySmaliContent.contains(".method public constructor <init>(Ljava/lang/String;I)V"))
        assertTrue(res.primarySmaliContent.contains("iput-object"))
        assertTrue(res.primarySmaliContent.contains("iput"))
    }

    @Test
    fun test3_multipleMethods() {
        val src = """
            package com.test;
            public class MathOps {
                public int add(int a, int b) { return a + b; }
                public static long multiply(long x, long y) { return x * y; }
                public double divide(double a, double b) { return a / b; }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "MathOps.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(".method public add(II)I"))
        assertTrue(res.primarySmaliContent.contains(".method public static multiply(JJ)J"))
        assertTrue(res.primarySmaliContent.contains(".method public divide(DD)D"))
    }

    @Test
    fun test4_ifElseControlFlow() {
        val src = """
            package com.test;
            public class LogicCheck {
                public String checkScore(int score) {
                    if (score >= 90) {
                        return "A";
                    } else if (score >= 80) {
                        return "B";
                    } else {
                        return "F";
                    }
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "LogicCheck.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains("if-"))
        assertTrue(res.primarySmaliContent.contains("return-object"))
    }

    @Test
    fun test5_loops() {
        val src = """
            package com.test;
            public class LoopRunner {
                public int sum(int n) {
                    int total = 0;
                    for (int i = 0; i < n; i++) {
                        total += i;
                    }
                    while (n > 0) {
                        n--;
                    }
                    return total;
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "LoopRunner.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains("goto"))
        assertTrue(res.primarySmaliContent.contains("if-"))
    }

    @Test
    fun test6_arrays() {
        val src = """
            package com.test;
            public class ArrayHandler {
                public int[] createArray(int size) {
                    int[] arr = new int[size];
                    arr[0] = 42;
                    return arr;
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "ArrayHandler.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains("new-array"))
        assertTrue(res.primarySmaliContent.contains("aput"))
    }

    @Test
    fun test7_stringOperations() {
        val src = """
            package com.test;
            public class StringHelper {
                public String greet(String first, String last) {
                    return "Hello " + first + " " + last.toUpperCase();
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "StringHelper.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains("Ljava/lang/String;"))
    }

    @Test
    fun test8_inheritance() {
        val src = """
            package com.test;
            public class Dog extends Animal {
                public Dog(String name) { super(name); }
                public void bark() {}
            }
            class Animal {
                protected String name;
                public Animal(String name) { this.name = name; }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "Dog.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(".super Lcom/test/Animal;"))
        assertEquals(2, res.allSmaliFiles.size)
    }

    @Test
    fun test9_interface() {
        val src = """
            package com.test;
            public class MyService implements Runnable, java.io.Serializable {
                @Override
                public void run() {}
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "MyService.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(".implements Ljava/lang/Runnable;"))
        assertTrue(res.primarySmaliContent.contains(".implements Ljava/io/Serializable;"))
    }

    @Test
    fun test10_tryCatchThrow() {
        val src = """
            package com.test;
            public class SafeWorker {
                public int parse(String s) {
                    try {
                        return Integer.parseInt(s);
                    } catch (NumberFormatException e) {
                        return -1;
                    } finally {
                        System.out.println("done");
                    }
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "SafeWorker.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(":try_start"))
        assertTrue(res.primarySmaliContent.contains(".catch"))
    }

    @Test
    fun test11_androidActivity() {
        val src = """
            package com.example.app;
            import android.app.Activity;
            import android.os.Bundle;

            public class MainActivity extends Activity {
                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "MainActivity.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains(".super Landroid/app/Activity;"))
        assertTrue(res.primarySmaliContent.contains("invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V"))
    }

    @Test
    fun test12_textViewAndButton() {
        val src = """
            package com.example.ui;
            import android.content.Context;
            import android.widget.TextView;
            import android.widget.Button;

            public class UiBuilder {
                public static TextView create(Context ctx) {
                    TextView tv = new TextView(ctx);
                    tv.setText("Sample");
                    Button btn = new Button(ctx);
                    btn.setText("Click");
                    return tv;
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "UiBuilder.java", null)
        assertTrue(res.success)
        assertTrue(res.primarySmaliContent.contains("Landroid/widget/TextView;"))
        assertTrue(res.primarySmaliContent.contains("Landroid/widget/Button;"))
    }

    @Test
    fun test13_innerClass() {
        val src = """
            package com.test;
            public class Outer {
                private int secret = 100;
                public class Inner {
                    public int getSecret() { return secret; }
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "Outer.java", null)
        assertTrue(res.success)
        assertEquals(2, res.allSmaliFiles.size)
        assertTrue(res.allSmaliFiles.keys.any { it.contains("Outer$") })
    }

    @Test
    fun test14_anonymousClass() {
        val src = """
            package com.test;
            public class TaskDispatcher {
                public void dispatch() {
                    Runnable r = new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("Running");
                        }
                    };
                    r.run();
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "TaskDispatcher.java", null)
        assertTrue(res.success)
        assertEquals(2, res.allSmaliFiles.size)
        assertTrue(res.allSmaliFiles.keys.any { it.contains("TaskDispatcher$1") })
    }

    @Test
    fun test15_largeJavaSource() {
        val sb = StringBuilder()
        sb.append("package com.test.large;\n")
        sb.append("public class BigClass {\n")
        for (i in 0 until 50) {
            sb.append("    private int field$i = $i;\n")
            sb.append("    public int getField$i() { return field$i; }\n")
            sb.append("    public void setField$i(int val) { this.field$i = val; }\n")
        }
        sb.append("}\n")

        val res = JavaToSmaliToolchain.compile(null, sb.toString(), "BigClass.java", null)
        assertTrue(res.success)
        assertTrue(res.fieldsCount >= 50)
        assertTrue(res.methodsCount >= 100)
    }

    @Test
    fun test16_multipleClasses() {
        val src = """
            package com.test.multi;
            public class Alpha {
                public void hello() {}
            }
            class Beta {
                public void world() {}
            }
            class Gamma {
                public void done() {}
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "Alpha.java", null)
        assertTrue(res.success)
        assertEquals(3, res.allSmaliFiles.size)
    }

    @Test
    fun test17_invalidJavaSource() {
        val src = """
            package com.test.bad;
            public class Broken {
                public void oops() {
                    int x = "incompatible";
                    NonExistentClass nec = new NonExistentClass();
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "Broken.java", null)
        assertFalse("Should fail on invalid code", res.success)
        assertFalse("Primary smali must be empty on failure", res.primarySmaliContent.isNotEmpty())
        assertTrue("Error message should mention compilation failure", res.errorMessage.contains("Compilation Failed"))
        assertTrue("Error details should contain diagnostics", res.errorDetails.contains("incompatible") || res.errorDetails.contains("cannot convert") || res.errorDetails.contains("Line"))
        assertTrue("Diagnostic errors list should not be empty", res.diagnosticErrors.isNotEmpty())
    }

    @Test
    fun test18_userPromptConverterTest() {
        val src = """
            package com.test.javatosmali;

            public class ConverterTest {

                private String name;
                private int age;
                private static int counter = 0;

                public ConverterTest(String name, int age) {
                    this.name = name;
                    this.age = age;
                    counter++;
                }

                public String getName() {
                    return name;
                }

                public int getAge() {
                    return age;
                }

                public int calculate(int a, int b) {
                    int result = 0;

                    if (a > b) {
                        result = a * b;
                    } else if (a == b) {
                        result = a + b;
                    } else {
                        result = b - a;
                    }

                    return result;
                }

                public int calculateSum(int[] numbers) {
                    int sum = 0;

                    for (int i = 0; i < numbers.length; i++) {
                        sum += numbers[i];
                    }

                    return sum;
                }

                public String getStatus() {
                    if (age < 13) {
                        return "Child";
                    } else if (age < 20) {
                        return "Teenager";
                    } else if (age < 60) {
                        return "Adult";
                    } else {
                        return "Senior";
                    }
                }

                public String safeDivide(int a, int b) {
                    try {
                        int result = a / b;
                        return "Result: " + result;
                    } catch (ArithmeticException e) {
                        return "Cannot divide by zero";
                    }
                }

                public void printNumbers() {
                    for (int i = 1; i <= 10; i++) {
                        if (i % 2 == 0) {
                            System.out.println("Even: " + i);
                        } else {
                            System.out.println("Odd: " + i);
                        }
                    }
                }

                public static String createMessage(String name) {
                    return "Hello, " + name + "! Counter = " + counter;
                }

                public static void main(String[] args) {

                    ConverterTest test =
                            new ConverterTest("Morsalin", 22);

                    int[] numbers = {
                            10, 20, 30, 40, 50
                    };

                    int sum = test.calculateSum(numbers);

                    System.out.println("Name: " + test.getName());
                    System.out.println("Age: " + test.getAge());
                    System.out.println("Status: " + test.getStatus());
                    System.out.println("Calculate: " + test.calculate(10, 5));
                    System.out.println("Sum: " + sum);
                    System.out.println(test.safeDivide(100, 5));
                    System.out.println(test.safeDivide(100, 0));

                    test.printNumbers();

                    System.out.println(
                            createMessage("Morsalin")
                    );
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "ConverterTest.java", null)
        assertTrue("Compilation of user prompt ConverterTest must succeed", res.success)
        assertTrue("Contains class header", res.primarySmaliContent.contains(".class public Lcom/test/javatosmali/ConverterTest;"))
        assertTrue("Contains constructor", res.primarySmaliContent.contains(".method public constructor <init>(Ljava/lang/String;I)V"))
        assertTrue("Contains field name", res.primarySmaliContent.contains(".field private name:Ljava/lang/String;"))
        assertTrue("Contains field age", res.primarySmaliContent.contains(".field private age:I"))
        assertTrue("Contains static counter", res.primarySmaliContent.contains(".field private static counter:I"))
        assertTrue("Contains iput-object", res.primarySmaliContent.contains("iput-object"))
        assertTrue("Contains if-", res.primarySmaliContent.contains("if-"))
        assertTrue("Contains :try_start", res.primarySmaliContent.contains(":try_start"))
        assertTrue("Contains new-array", res.primarySmaliContent.contains("new-array"))
        assertNotNull("DEX bytes exist", res.dexBytes)
        assertTrue("DEX bytes non-empty", res.dexBytes.isNotEmpty())
        assertTrue("Smali round-trip valid", res.roundTripValid)
    }

    @Test
    fun test19_userPromptMainActivity() {
        val src = """
            package com.test.javatosmali;

            import android.app.Activity;
            import android.os.Bundle;
            import android.widget.TextView;

            public class MainActivity extends Activity {

                private TextView textView;

                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);

                    textView = new TextView(this);
                    textView.setText("Hello Morsalin");
                    setContentView(textView);
                }
            }
        """.trimIndent()

        val res = JavaToSmaliToolchain.compile(null, src, "MainActivity.java", null)
        assertTrue("Android API compilation must succeed", res.success)
        assertTrue("Super class is Activity", res.primarySmaliContent.contains(".super Landroid/app/Activity;"))
        assertTrue("Field textView exists", res.primarySmaliContent.contains(".field private textView:Landroid/widget/TextView;"))
        assertTrue("onCreate overrides Activity", res.primarySmaliContent.contains("invoke-super"))
        assertTrue("Round-trip valid", res.roundTripValid)
    }
}
