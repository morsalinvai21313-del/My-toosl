package com.android.modding.tools

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.modding.tools.dialogmaker.DexValidator
import com.android.modding.tools.toastmaker.ProgrammaticToastSourceGenerator
import com.android.modding.tools.toastmaker.ToastConfig
import com.android.modding.tools.toastmaker.ToastGuideGenerator
import com.android.modding.tools.toastmaker.ToastPackageBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ToastMakerIntegrationTest {

    @Test
    fun verifyToastConfigPresetsAndJsonRoundtrip() {
        // 1. Simple
        val simple = ToastConfig.createSimpleDefault()
        assertEquals(ToastConfig.TYPE_SIMPLE, simple.toastType)
        val jsonSimple = simple.toJson()
        val parsedSimple = ToastConfig.fromJson(jsonSimple)
        assertEquals(simple.messageText, parsedSimple.messageText)
        assertEquals(simple.isLongDuration, parsedSimple.isLongDuration)

        // 2. Base64
        val b64 = ToastConfig.createBase64Default()
        assertEquals(ToastConfig.TYPE_BASE64, b64.toastType)
        assertTrue(b64.isBase64Encoded)

        // 3. Colorful
        val colorful = ToastConfig.createColorfulDefault()
        assertEquals(ToastConfig.TYPE_COLORFUL, colorful.toastType)
        assertEquals(28, colorful.cornerRadiusDp)
        assertEquals("#FF1744", colorful.bgHex)

        // 4. Animated
        val animated = ToastConfig.createAnimatedDefault()
        assertEquals(ToastConfig.TYPE_ANIMATED, animated.toastType)
        assertEquals("Zoom", animated.animMode)

        // 5. Image / Badge
        val image = ToastConfig.createImageDefault()
        assertEquals(ToastConfig.TYPE_IMAGE, image.toastType)
        assertEquals("👑", image.symbolIcon)
        assertTrue(image.hasBadge)
    }

    @Test
    fun verifyProgrammaticToastGeneratorCreatesZeroXmlPureJavaCode() {
        val config = ToastConfig.createColorfulDefault()
        val javaCode = ProgrammaticToastSourceGenerator.generateJavaCode(config)

        assertNotNull(javaCode)
        assertTrue(javaCode.contains("package com.morsalin.toast;"))
        assertTrue(javaCode.contains("public class MorsalinCustomToast"))
        assertTrue(javaCode.contains("public static void show(final Context context)"))
        assertTrue(javaCode.contains("displayToast(context"))
        assertTrue(javaCode.contains("GradientDrawable"))
    }

    @Test
    fun verifyToastGuideGeneratorContainsSmaliHookAndBengaliInstructions() {
        val config = ToastConfig.createSimpleDefault()
        val guide = ToastGuideGenerator.generateSmaliGuide(config, null, "const-string v0, \"Test\"")

        assertNotNull(guide)
        assertTrue(guide.contains("REAL DALVIK SMALI HOOK FOR ONCREATE"))
        assertTrue(guide.contains("invoke-static {p0}, Lcom/morsalin/toast/MorsalinCustomToast;->show(Landroid/content/Context;)V"))
        assertTrue(guide.contains(ToastGuideGenerator.STYLISH_BORDER))
        assertTrue(guide.contains("ডেভলপার বাই মোরসালিন খান"))
    }

    @Test
    fun verifyToastPackageBuilderCompilesAndBundlesZeroXmlPackage() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val config = ToastConfig.createSimpleDefault()
        val buildResult = ToastPackageBuilder.buildToastPackage(context, config)

        assertNotNull(buildResult)
        assertTrue("Compilation should succeed: " + buildResult.errorMessage, buildResult.success)
        assertNotNull(buildResult.dexBytes)
        assertTrue("Dex size must be >= 112 bytes", buildResult.dexBytes.size >= 112)
        assertNotNull(buildResult.generatedPackage)
        assertNotNull(buildResult.generatedPackage.getDexBinary())
        assertTrue(buildResult.generatedPackage.files.containsKey("hook.smali"))
        assertEquals("Must contain strictly 1 file (hook.smali) when no custom image is set", 1, buildResult.generatedPackage.files.size)
        val guide = buildResult.guideContent
        org.junit.Assert.assertFalse("Must NOT contain duplicate inline smali hook", guide.contains("ALTERNATIVE IN-LINE SMALI HOOK"))
    }
}
