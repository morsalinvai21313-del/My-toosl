package com.android.modding.tools.generators;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class JavaKotlinConverterEngineTest {

    private static final String MORSALIN_JAVA_INPUT =
            "package com.morsalin.convertertest;\n" +
            "\n" +
            "import android.content.Intent;\n" +
            "import android.os.Bundle;\n" +
            "import android.util.Log;\n" +
            "import android.view.View;\n" +
            "import android.widget.Button;\n" +
            "import android.widget.TextView;\n" +
            "import android.widget.Toast;\n" +
            "import androidx.appcompat.app.AppCompatActivity;\n" +
            "import java.util.ArrayList;\n" +
            "import java.util.HashMap;\n" +
            "import java.util.List;\n" +
            "import java.util.Map;\n" +
            "\n" +
            "public class MainActivity extends AppCompatActivity {\n" +
            "\n" +
            "    private static final String TAG = \"MorsalinTest\";\n" +
            "    private int counter = 0;\n" +
            "    private TextView titleText;\n" +
            "    private Button actionButton;\n" +
            "    private final List<String> languages = new ArrayList<>();\n" +
            "    private final Map<String, Integer> scores = new HashMap<>();\n" +
            "\n" +
            "    @Override\n" +
            "    protected void onCreate(Bundle savedInstanceState) {\n" +
            "        super.onCreate(savedInstanceState);\n" +
            "        setContentView(R.layout.activity_main);\n" +
            "\n" +
            "        titleText = findViewById(R.id.titleText);\n" +
            "        actionButton = findViewById(R.id.actionButton);\n" +
            "\n" +
            "        languages.add(\"Java\");\n" +
            "        languages.add(\"Kotlin\");\n" +
            "        scores.put(\"Java\", 95);\n" +
            "        scores.put(\"Kotlin\", 98);\n" +
            "\n" +
            "        final User user = new User(\"Morsalin\", 20);\n" +
            "\n" +
            "        actionButton.setOnClickListener(new View.OnClickListener() {\n" +
            "            @Override\n" +
            "            public void onClick(View view) {\n" +
            "                counter++;\n" +
            "                String message = getMessage(user.getName());\n" +
            "                titleText.setText(message + \" | Click: \" + counter);\n" +
            "                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();\n" +
            "                if (counter >= 3) {\n" +
            "                    openSecondScreen(user);\n" +
            "                }\n" +
            "            }\n" +
            "        });\n" +
            "\n" +
            "        printLanguages();\n" +
            "        calculateTotal();\n" +
            "    }\n" +
            "\n" +
            "    private String getMessage(String name) {\n" +
            "        if (name == null || name.isEmpty()) {\n" +
            "            return \"Unknown User\";\n" +
            "        }\n" +
            "        return \"Welcome, \" + name;\n" +
            "    }\n" +
            "\n" +
            "    private void printLanguages() {\n" +
            "        for (int i = 0; i < languages.size(); i++) {\n" +
            "            String item = languages.get(i);\n" +
            "            Log.d(TAG, \"Language: \" + item);\n" +
            "        }\n" +
            "\n" +
            "        for (Map.Entry<String, Integer> entry : scores.entrySet()) {\n" +
            "            String key = entry.getKey();\n" +
            "            Integer score = entry.getValue();\n" +
            "            if (score != null && score > 90) {\n" +
            "                Log.d(TAG, key + \" = \" + score);\n" +
            "            }\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    private void calculateTotal() {\n" +
            "        int[] numbers = new int[] {\n" +
            "            10, 20, 30, 40, 50\n" +
            "        };\n" +
            "        int total = 0;\n" +
            "        for (int number : numbers) {\n" +
            "            total += number;\n" +
            "        }\n" +
            "        try {\n" +
            "            int average = total / numbers.length;\n" +
            "            Log.d(TAG, \"Average: \" + average);\n" +
            "        } catch (Exception e) {\n" +
            "            Log.e(TAG, \"Error: \" + e.getMessage());\n" +
            "        }\n" +
            "    }\n" +
            "\n" +
            "    private void openSecondScreen(User user) {\n" +
            "        Intent intent = new Intent(MainActivity.this, SecondActivity.class);\n" +
            "        intent.putExtra(\"username\", user.getName());\n" +
            "        intent.putExtra(\"age\", user.getAge());\n" +
            "        startActivity(intent);\n" +
            "    }\n" +
            "\n" +
            "    public static class User {\n" +
            "        private String name;\n" +
            "        private int age;\n" +
            "\n" +
            "        public User(String name, int age) {\n" +
            "            this.name = name;\n" +
            "            this.age = age;\n" +
            "        }\n" +
            "\n" +
            "        public String getName() {\n" +
            "            return name;\n" +
            "        }\n" +
            "\n" +
            "        public void setName(String name) {\n" +
            "            this.name = name;\n" +
            "        }\n" +
            "\n" +
            "        public int getAge() {\n" +
            "            return age;\n" +
            "        }\n" +
            "\n" +
            "        public void setAge(int age) {\n" +
            "            this.age = age;\n" +
            "        }\n" +
            "    }\n" +
            "}\n";

    @Test
    public void testJavaToKotlinAndReverseValidation() {
        JavaKotlinConverterEngine.ConversionResult ktRes = JavaKotlinConverterEngine.convert(
                MORSALIN_JAVA_INPUT,
                JavaKotlinConverterEngine.Direction.JAVA_TO_KOTLIN
        );

        String kt = ktRes.convertedCode;
        System.out.println("=== GENERATED KOTLIN ===\n" + kt);

        assertTrue("Conversion should succeed", ktRes.success);
        assertFalse("Should not need review", ktRes.needsReview);

        // Rule A: Declaration parser
        assertFalse("Never generate var : int", kt.contains("var :"));
        assertFalse("Never generate val : int", kt.contains("val :"));
        assertTrue("Counter declaration must be valid Kotlin", kt.contains("private var counter: Int = 0") || kt.contains("private var counter = 0"));

        // Rule B & M: Modifier separation & Collection types
        assertFalse("Never put modifiers inside Kotlin type", kt.contains(": private") || kt.contains(": final"));
        assertTrue("MutableList generated cleanly", kt.contains("private val languages: MutableList<String> = ArrayList()"));
        assertTrue("MutableMap generated cleanly", kt.contains("private val scores: MutableMap<String, Int> = HashMap()"));

        // Rule C & D: Statement parser & Lambda conversion
        assertFalse("No anonymous View.OnClickListener in Kotlin", kt.contains("View.OnClickListener"));
        assertFalse("No Java String message inside lambda", kt.contains("String message ="));
        assertTrue("Uses idiomatic setOnClickListener { ... }", kt.contains("actionButton.setOnClickListener {"));
        assertTrue("Inside lambda converts to val message", kt.contains("val message = getMessage(user.name)"));

        // Rule E & J: Constructor parser & Getter/Setter analysis
        assertFalse("Never generate fun User(...)", kt.contains("fun User("));
        assertTrue("User class has primary constructor", kt.contains("class User("));

        // Rule F: Array parser
        assertFalse("Never output new int[]", kt.contains("new int["));
        assertTrue("Uses intArrayOf", kt.contains("intArrayOf("));
        assertTrue("Array length becomes .size in Kotlin", kt.contains("numbers.size"));

        // Rule G: Nullability analyzer
        assertTrue("getMessage parameter is nullable String?", kt.contains("private fun getMessage(name: String?): String"));
        assertTrue("Uses isNullOrEmpty()", kt.contains("name.isNullOrEmpty()"));

        // Rule H: Android context
        assertFalse("Never leave MainActivity.this", kt.contains("MainActivity.this"));
        assertTrue("Uses this@MainActivity", kt.contains("this@MainActivity"));

        // Rule I: Companion object at class scope
        assertTrue("Contains companion object with const val TAG", kt.contains("companion object {\n        private const val TAG = \"MorsalinTest\"\n    }"));

        // Rule L: Type system
        assertFalse("Never output : int", kt.contains(": int"));
        assertFalse("Never output : boolean", kt.contains(": boolean"));

        // Now test reverse conversion: Kotlin -> Java
        JavaKotlinConverterEngine.ConversionResult javaRes = JavaKotlinConverterEngine.convert(
                kt,
                JavaKotlinConverterEngine.Direction.KOTLIN_TO_JAVA
        );
        String javaOut = javaRes.convertedCode;
        System.out.println("=== GENERATED JAVA FROM KOTLIN ===\n" + javaOut);

        assertTrue("Kotlin to Java conversion should succeed", javaRes.success);
        assertFalse("Java output should not contain val/var keywords as Kotlin declarations", javaOut.contains("val "));
        assertFalse("Java output should not contain fun keyword", javaOut.contains("fun "));
        assertFalse("Java output should not contain companion object", javaOut.contains("companion object"));
        assertFalse("Java output should not contain ::class.java", javaOut.contains("::class.java"));
        assertFalse("Java output should not contain this@MainActivity", javaOut.contains("this@MainActivity"));
        assertTrue("Java output should restore MainActivity.this", javaOut.contains("MainActivity.this"));
        assertTrue("Java output should restore SecondActivity.class", javaOut.contains("SecondActivity.class"));
        assertTrue("Java output should infer User type for new User", javaOut.contains("final User user = new User("));
        assertTrue("Java output should separate counter++; onto its own statement", javaOut.contains("counter++;"));
        assertTrue("Java output should use languages.size()", javaOut.contains("languages.size()"));
        assertTrue("Java output should use languages.get(i)", javaOut.contains("languages.get(i)"));
        assertTrue("Java output should use scores.entrySet()", javaOut.contains("scores.entrySet()"));
        assertTrue("Java output should use e.getMessage()", javaOut.contains("e.getMessage()"));
        assertTrue("Java output should use user.getName()", javaOut.contains("user.getName()"));
        assertTrue("Java output should use user.getAge()", javaOut.contains("user.getAge()"));
        assertTrue("Java output should infer String for languages.get(i)", javaOut.contains("String item = languages.get(i)"));
        assertTrue("Java output should infer Map.Entry<String, Integer>", javaOut.contains("Map.Entry<String, Integer> entry : scores.entrySet()"));
        assertTrue("Java output should infer int for numbers array loop", javaOut.contains("for (int number : numbers)"));
        assertTrue("Java output should restore numbers.length", javaOut.contains("numbers.length"));
        assertTrue("Java output should generate public static class User", javaOut.contains("public static class User"));
    }
}
