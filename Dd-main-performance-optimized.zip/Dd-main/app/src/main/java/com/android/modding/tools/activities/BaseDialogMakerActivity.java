package com.android.modding.tools.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogmaker.DexValidator;
import com.android.modding.tools.dialogmaker.DialogConfig;
import com.android.modding.tools.dialogmaker.DialogPackageBuilder;
import com.android.modding.tools.dialogmaker.DialogPreviewHelper;
import com.android.modding.tools.dialogmaker.FullScreenGenerationOverlayHelper;
import com.android.modding.tools.dialogs.ColorPickerDialog;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.HistoryManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.PackageGenerationRunner;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.XmlProject;

/**
 * Universal Base Dialog Maker Activity.
 * Provides the unified, complete 12-section builder system:
 * Real-time Live Preview, Programmatic UI configuration,
 * Real D8 classes.dex compilation, GUIDE.smali hook output, and zero XML generation.
 */
public abstract class BaseDialogMakerActivity extends AppCompatActivity {

    protected static final String[] ANIM_MODES = {
            "Zoom", "Bounce", "Fade", "Slide", "Flip 3D",
            "Cyber Glitch", "Boomerang", "Matrix Drop", "Hologram",
            "Origami", "Vortex", "Warp"
    };
    protected static final String[] ICON_NAMES = {"SHIELD", "CODE", "SAVE", "REFRESH", "NONE"};
    protected static final String[] FONT_NAMES = {"DEFAULT", "MONOSPACE", "SANS_SERIF", "SERIF", "COMIC_NEUE"};
    protected static final String[] ALIGN_NAMES = {"CENTER", "LEFT", "RIGHT"};
    protected static final String[] ACTION_TYPES = {
            DialogConfig.ACTION_DISMISS,
            DialogConfig.ACTION_OPEN_URL,
            DialogConfig.ACTION_OPEN_ACTIVITY,
            DialogConfig.ACTION_CUSTOM
    };

    protected DialogConfig config;
    protected DialogPackageBuilder.BuildResult lastBuildResult;
    protected HistoryManager historyManager;

    private int animIdx = 0;
    private int iconIdx = 0;
    private int titleFontIdx = 0;
    private int msgFontIdx = 0;
    private int titleAlignIdx = 0;
    private int msgAlignIdx = 0;

    // Quick Presets & Smali Hook Header Views
    protected View layoutQuickPresetsCard;
    protected TextView tvPresetsCardTitle;
    protected Button btnPreset1, btnPreset2, btnPreset3, btnPreset4;
    protected View layoutSmaliHookInfoCard;
    protected TextView tvQuickSmaliHook;
    protected Button btnCopyQuickHook;
    protected Button btnTestAnimPreview;

    // Live Preview Views
    protected LinearLayout cardPreview;
    protected TextView tvPreviewBadge;
    protected ImageView ivPreviewIcon;
    protected TextView tvPreviewTitle, tvPreviewSubtitle, tvPreviewMessage, tvPreviewCountdown;
    protected CheckBox cbPreviewDontShow;
    protected Button btnPrev1, btnPrev2, btnPrevConfirm;

    // Controls
    protected TextView tvScreenTitle;
    protected TextView tvWidthVal, tvHeightVal, tvRadiusVal;
    protected SeekBar seekWidth, seekHeight, seekRadius;
    protected Button btnDimCompact, btnDimStandard, btnDimTall;
    protected Button btnBgColor, btnGradientToggle, btnGradientEndColor, btnBorderColor;
    protected Button btnPosCenter, btnPosTop, btnPosBottom;

    protected EditText etTitle;
    protected Button btnTitleColor, btnTitleFont, btnTitleAlign;

    protected EditText etMessage;
    protected Button btnMessageColor, btnMessageFont, btnMessageAlign;

    // Section 4: Separated Profile Photo & Vector Emblem Sections
    protected View layoutProfilePhotoSection, layoutVectorIconSection;
    protected TextView tvEmblemSectionTitle;
    protected Button btnToggleIcon, btnIconColor;
    protected Button btnPickGallery, btnAvatarPreset, btnAvatarShape;
    protected TextView tvAvatarSizeLabel;
    protected SeekBar seekAvatarSize;
    protected Button btnAvatarSizeMinus, btnAvatarSizePlus;
    protected Button btnSizePresetSmall, btnSizePresetMedium, btnSizePresetLarge;
    protected Button btnAvatarBorderWidth, btnAvatarBorderColor, btnAvatarBorderStyle;

    // Notice & Mandatory Update Controls
    protected View layoutNoticeUpdateSection;
    protected Button btnToggleForceUpdate, btnToggleCountdown;
    protected Button btnTimer5s, btnTimer10s, btnTimer15s, btnTimer30s, btnTimer60s;

    protected Button btnCount1, btnCount2, btnCount3;
    protected LinearLayout layoutBtn1, layoutBtn2, layoutBtnConfirm;
    protected EditText etBtn1Text, etBtn1Url, etBtn2Text, etBtn2Url, etBtnConfirmText, etBtnConfirmUrl;
    protected Button btnBtn1ActionType, btnBtn2ActionType, btnBtn3ActionType;
    protected Button btnBtn1BgColor, btnBtn1TextColor;
    protected Button btnBtn2BgColor, btnBtn2TextColor;
    protected Button btnConfirmBgColor, btnConfirmTextColor;

    // Don't Show Again Section
    protected Button btnToggleDontShow, btnDontShowColor;
    protected EditText etDontShowText;

    protected Button btnAnimOpen, btnAnimDuration;

    // Build & Export Panels
    protected ScrollView scrollView;
    protected View layoutAnimPanel, layoutReadyPanel;
    protected ConversionAnimationView animView;
    protected TextView tvAnimBadge, tvAnimStatus, tvDexReport;

    private final ActivityResultLauncher<String> galleryPickerLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    try {
                        java.io.InputStream is = getContentResolver().openInputStream(uri);
                        Bitmap bitmap = BitmapFactory.decodeStream(is);
                        if (is != null) is.close();
                        if (bitmap != null) {
                            int maxDim = Math.max(bitmap.getWidth(), bitmap.getHeight());
                            if (maxDim > 512) {
                                float scale = 512f / maxDim;
                                bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * scale), Math.round(bitmap.getHeight() * scale), true);
                            }
                            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                            config.customAvatarBytes = baos.toByteArray();
                            config.hasCustomAvatar = true;
                            config.hasImage = true;
                            config.imageKind = "AVATAR";
                            config.avatarPreset = "Custom Gallery";
                            refreshPreview();
                            MorsalinToast.show(this, R.drawable.ic_about_dev, "Photo Selected", "Custom image loaded from gallery!");
                        }
                    } catch (Throwable t) {
                        MorsalinToast.show(this, R.drawable.ic_refresh, "Load Failed", "Could not load photo: " + t.getMessage());
                    }
                }
            });

    protected abstract DialogConfig getInitialConfig();
    protected abstract String getScreenTitle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_dialog_maker);

        GlobalTouchParticleManager.attach(this);
        historyManager = new HistoryManager(this);
        config = getInitialConfig();

        initViews();
        updateInputsFromConfig();
        refreshPreview();
    }

    protected void initViews() {
        tvScreenTitle = findViewById(R.id.tv_screen_title);
        if (tvScreenTitle != null) {
            tvScreenTitle.setText(getScreenTitle());
        }

        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            config = getInitialConfig();
            updateInputsFromConfig();
            refreshPreview();
            MorsalinToast.show(this, R.drawable.ic_refresh, "Reset", "Default configuration restored.");
        });

        findViewById(R.id.btn_test_dialog).setOnClickListener(v -> {
            DialogPreviewHelper.showInteractiveTestDialog(this, config);
        });

        // Quick Presets & 1-Line Smali Hook Header
        layoutQuickPresetsCard = findViewById(R.id.layout_quick_presets_card);
        tvPresetsCardTitle = findViewById(R.id.tv_presets_card_title);
        btnPreset1 = findViewById(R.id.btn_preset_1);
        btnPreset2 = findViewById(R.id.btn_preset_2);
        btnPreset3 = findViewById(R.id.btn_preset_3);
        btnPreset4 = findViewById(R.id.btn_preset_4);
        setupPresets();

        layoutSmaliHookInfoCard = findViewById(R.id.layout_smali_hook_info_card);
        tvQuickSmaliHook = findViewById(R.id.tv_quick_smali_hook);
        btnCopyQuickHook = findViewById(R.id.btn_copy_quick_hook);
        if (btnCopyQuickHook != null) {
            btnCopyQuickHook.setOnClickListener(v -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) {
                    String hook = "invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V";
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("SmaliHook", hook));
                    MorsalinToast.show(this, R.drawable.ic_content_copy, "Hook Copied", "1-line Smali Hook copied to clipboard!");
                }
            });
        }

        // Live Preview Views
        cardPreview = findViewById(R.id.card_live_dialog_preview);
        tvPreviewBadge = findViewById(R.id.tv_preview_badge);
        ivPreviewIcon = findViewById(R.id.iv_preview_icon);
        tvPreviewTitle = findViewById(R.id.tv_preview_title);
        tvPreviewSubtitle = findViewById(R.id.tv_preview_subtitle);
        tvPreviewMessage = findViewById(R.id.tv_preview_message);
        tvPreviewCountdown = findViewById(R.id.tv_preview_countdown);
        cbPreviewDontShow = findViewById(R.id.cb_preview_dont_show);
        btnPrev1 = findViewById(R.id.btn_prev_1);
        btnPrev2 = findViewById(R.id.btn_prev_2);
        btnPrevConfirm = findViewById(R.id.btn_prev_confirm);

        // Section 1: Dialog Basic
        tvWidthVal = findViewById(R.id.tv_width_val);
        seekWidth = findViewById(R.id.seek_dialog_width);
        if (seekWidth != null) {
            seekWidth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        config.widthPct = 65 + progress; // 65%..100%
                        if (tvWidthVal != null) tvWidthVal.setText(config.widthPct + "%");
                        refreshPreview();
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        tvHeightVal = findViewById(R.id.tv_height_val);
        seekHeight = findViewById(R.id.seek_dialog_height);
        if (seekHeight != null) {
            seekHeight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        config.heightDp = 200 + progress * 10; // 200dp..500dp
                        updateHeightLabel();
                        refreshPreview();
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        btnDimCompact = findViewById(R.id.btn_dim_compact);
        if (btnDimCompact != null) {
            btnDimCompact.setOnClickListener(v -> {
                config.heightDp = 240;
                config.widthPct = 80;
                updateInputsFromConfig();
                refreshPreview();
            });
        }

        btnDimStandard = findViewById(R.id.btn_dim_standard);
        if (btnDimStandard != null) {
            btnDimStandard.setOnClickListener(v -> {
                config.heightDp = 320;
                config.widthPct = 90;
                updateInputsFromConfig();
                refreshPreview();
            });
        }

        btnDimTall = findViewById(R.id.btn_dim_tall);
        if (btnDimTall != null) {
            btnDimTall.setOnClickListener(v -> {
                config.heightDp = 440;
                config.widthPct = 94;
                updateInputsFromConfig();
                refreshPreview();
            });
        }

        btnBgColor = findViewById(R.id.btn_bg_color);
        if (btnBgColor != null) {
            btnBgColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.bgHex, colorHex -> {
                    config.bgHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnGradientToggle = findViewById(R.id.btn_gradient_toggle);
        if (btnGradientToggle != null) {
            btnGradientToggle.setOnClickListener(v -> {
                config.isGradient = !config.isGradient;
                btnGradientToggle.setText(config.isGradient ? "Gradient: ON" : "Gradient: OFF");
                refreshPreview();
            });
        }

        btnGradientEndColor = findViewById(R.id.btn_gradient_end_color);
        if (btnGradientEndColor != null) {
            btnGradientEndColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.bgGradientEndHex, colorHex -> {
                    config.bgGradientEndHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnBorderColor = findViewById(R.id.btn_border_color);
        if (btnBorderColor != null) {
            btnBorderColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.borderHex, colorHex -> {
                    config.borderHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        tvRadiusVal = findViewById(R.id.tv_radius_val);
        seekRadius = findViewById(R.id.seek_corner_radius);
        if (seekRadius != null) {
            seekRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        config.cornerRadiusDp = progress;
                        if (tvRadiusVal != null) tvRadiusVal.setText("Corner Radius: " + progress + "dp");
                        refreshPreview();
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        btnPosCenter = findViewById(R.id.btn_pos_center);
        btnPosTop = findViewById(R.id.btn_pos_top);
        btnPosBottom = findViewById(R.id.btn_pos_bottom);

        if (btnPosCenter != null) btnPosCenter.setOnClickListener(v -> { config.dialogPosition = "CENTER"; refreshPreview(); });
        if (btnPosTop != null) btnPosTop.setOnClickListener(v -> { config.dialogPosition = "TOP"; refreshPreview(); });
        if (btnPosBottom != null) btnPosBottom.setOnClickListener(v -> { config.dialogPosition = "BOTTOM"; refreshPreview(); });

        // Section 2: Title
        etTitle = findViewById(R.id.et_title);
        if (etTitle != null) {
            etTitle.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.titleText = s.toString();
                    refreshPreview();
                }
            });
        }

        btnTitleColor = findViewById(R.id.btn_title_color);
        if (btnTitleColor != null) {
            btnTitleColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.titleColorHex, colorHex -> {
                    config.titleColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnTitleFont = findViewById(R.id.btn_title_font);
        if (btnTitleFont != null) {
            btnTitleFont.setOnClickListener(v -> {
                titleFontIdx = (titleFontIdx + 1) % FONT_NAMES.length;
                config.titleFont = FONT_NAMES[titleFontIdx];
                btnTitleFont.setText("Font: " + config.titleFont);
                refreshPreview();
            });
        }

        btnTitleAlign = findViewById(R.id.btn_title_align);
        if (btnTitleAlign != null) {
            btnTitleAlign.setOnClickListener(v -> {
                titleAlignIdx = (titleAlignIdx + 1) % ALIGN_NAMES.length;
                config.titleAlignment = ALIGN_NAMES[titleAlignIdx];
                btnTitleAlign.setText("Align: " + config.titleAlignment);
                refreshPreview();
            });
        }

        // Section 3: Message
        etMessage = findViewById(R.id.et_message);
        if (etMessage != null) {
            etMessage.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.messageText = s.toString();
                    refreshPreview();
                }
            });
        }

        btnMessageColor = findViewById(R.id.btn_message_color);
        if (btnMessageColor != null) {
            btnMessageColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.messageColorHex, colorHex -> {
                    config.messageColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnMessageFont = findViewById(R.id.btn_message_font);
        if (btnMessageFont != null) {
            btnMessageFont.setOnClickListener(v -> {
                msgFontIdx = (msgFontIdx + 1) % FONT_NAMES.length;
                config.messageFont = FONT_NAMES[msgFontIdx];
                btnMessageFont.setText("Font: " + config.messageFont);
                refreshPreview();
            });
        }

        btnMessageAlign = findViewById(R.id.btn_message_align);
        if (btnMessageAlign != null) {
            btnMessageAlign.setOnClickListener(v -> {
                msgAlignIdx = (msgAlignIdx + 1) % ALIGN_NAMES.length;
                config.messageAlignment = ALIGN_NAMES[msgAlignIdx];
                btnMessageAlign.setText("Align: " + config.messageAlignment);
                refreshPreview();
            });
        }

        // Section 4: Separated Profile Avatar & Vector Emblem Sections
        layoutProfilePhotoSection = findViewById(R.id.layout_profile_photo_section);
        layoutVectorIconSection = findViewById(R.id.layout_vector_icon_section);
        tvEmblemSectionTitle = findViewById(R.id.tv_emblem_section_title);

        btnPickGallery = findViewById(R.id.btn_pick_gallery);
        if (btnPickGallery != null) {
            btnPickGallery.setOnClickListener(v -> galleryPickerLauncher.launch("image/*"));
        }

        btnAvatarPreset = findViewById(R.id.btn_avatar_preset);
        if (btnAvatarPreset != null) {
            btnAvatarPreset.setOnClickListener(v -> {
                String[] presets = {"Morsalin Cyber", "Morsalin Neon", "Sanny DJ", "Sanny Modder"};
                int cur = 0;
                for (int i = 0; i < presets.length; i++) {
                    if (presets[i].equalsIgnoreCase(config.avatarPreset)) {
                        cur = (i + 1) % presets.length;
                        break;
                    }
                }
                config.avatarPreset = presets[cur];
                config.hasCustomAvatar = false;
                btnAvatarPreset.setText("Preset: " + config.avatarPreset);
                refreshPreview();
            });
        }

        btnAvatarShape = findViewById(R.id.btn_avatar_shape);
        if (btnAvatarShape != null) {
            btnAvatarShape.setOnClickListener(v -> {
                if ("CIRCLE".equalsIgnoreCase(config.avatarShape)) {
                    config.avatarShape = "ROUNDED";
                } else if ("ROUNDED".equalsIgnoreCase(config.avatarShape)) {
                    config.avatarShape = "SQUARE";
                } else {
                    config.avatarShape = "CIRCLE";
                }
                btnAvatarShape.setText("Shape: " + config.avatarShape);
                refreshPreview();
            });
        }

        // Photo Size & Border Controls (ছবি সাইজ বাড়ানো/কমানো, বর্ডার, ডট চিহ্ন)
        tvAvatarSizeLabel = findViewById(R.id.tv_avatar_size_label);
        btnAvatarSizeMinus = findViewById(R.id.btn_avatar_size_minus);
        btnAvatarSizePlus = findViewById(R.id.btn_avatar_size_plus);
        btnSizePresetSmall = findViewById(R.id.btn_size_preset_small);
        btnSizePresetMedium = findViewById(R.id.btn_size_preset_medium);
        btnSizePresetLarge = findViewById(R.id.btn_size_preset_large);
        btnAvatarBorderWidth = findViewById(R.id.btn_avatar_border_width);
        btnAvatarBorderColor = findViewById(R.id.btn_avatar_border_color);
        btnAvatarBorderStyle = findViewById(R.id.btn_avatar_border_style);

        seekAvatarSize = findViewById(R.id.seek_avatar_size);
        if (seekAvatarSize != null) {
            seekAvatarSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser) {
                        config.avatarSizeDp = 36 + progress; // 36dp..156dp
                        if (tvAvatarSizeLabel != null) {
                            tvAvatarSizeLabel.setText("📐 Photo Size: " + config.avatarSizeDp + "dp");
                        }
                        refreshPreview();
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
        }

        if (btnAvatarSizeMinus != null) {
            btnAvatarSizeMinus.setOnClickListener(v -> {
                config.avatarSizeDp = Math.max(36, config.avatarSizeDp - 8);
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnAvatarSizePlus != null) {
            btnAvatarSizePlus.setOnClickListener(v -> {
                config.avatarSizeDp = Math.min(160, config.avatarSizeDp + 8);
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnSizePresetSmall != null) {
            btnSizePresetSmall.setOnClickListener(v -> {
                config.avatarSizeDp = 56;
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnSizePresetMedium != null) {
            btnSizePresetMedium.setOnClickListener(v -> {
                config.avatarSizeDp = 76;
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnSizePresetLarge != null) {
            btnSizePresetLarge.setOnClickListener(v -> {
                config.avatarSizeDp = 104;
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnAvatarBorderWidth != null) {
            btnAvatarBorderWidth.setOnClickListener(v -> {
                int[] widths = {0, 2, 3, 5, 8};
                int idx = 0;
                for (int i = 0; i < widths.length; i++) {
                    if (widths[i] == config.avatarBorderWidthDp) {
                        idx = (i + 1) % widths.length;
                        break;
                    }
                }
                config.avatarBorderWidthDp = widths[idx];
                updateAvatarControls();
                refreshPreview();
            });
        }
        if (btnAvatarBorderColor != null) {
            btnAvatarBorderColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.avatarBorderHex, colorHex -> {
                    config.avatarBorderHex = colorHex;
                    updateAvatarControls();
                    refreshPreview();
                }).show();
            });
        }
        if (btnAvatarBorderStyle != null) {
            btnAvatarBorderStyle.setOnClickListener(v -> {
                String[] styles = {"SOLID", "DOTTED", "DASHED", "GLOW"};
                int cur = 0;
                for (int i = 0; i < styles.length; i++) {
                    if (styles[i].equalsIgnoreCase(config.avatarBorderStyle)) {
                        cur = (i + 1) % styles.length;
                        break;
                    }
                }
                config.avatarBorderStyle = styles[cur];
                updateAvatarControls();
                refreshPreview();
            });
        }

        // Section 4C: Mandatory Update & Timer (বাধ্যতামূলক আপডেট ও টাইমার)
        layoutNoticeUpdateSection = findViewById(R.id.layout_notice_update_section);
        btnToggleForceUpdate = findViewById(R.id.btn_toggle_force_update);
        btnToggleCountdown = findViewById(R.id.btn_toggle_countdown);
        btnTimer5s = findViewById(R.id.btn_timer_5s);
        btnTimer10s = findViewById(R.id.btn_timer_10s);
        btnTimer15s = findViewById(R.id.btn_timer_15s);
        btnTimer30s = findViewById(R.id.btn_timer_30s);
        btnTimer60s = findViewById(R.id.btn_timer_60s);

        if (btnToggleForceUpdate != null) {
            btnToggleForceUpdate.setOnClickListener(v -> {
                config.isForceUpdate = !config.isForceUpdate;
                if (config.isForceUpdate) {
                    config.cancelable = false;
                    config.buttonCount = 1;
                    setButtonCount(1);
                }
                updateNoticeControls();
                refreshPreview();
            });
        }
        if (btnToggleCountdown != null) {
            btnToggleCountdown.setOnClickListener(v -> {
                config.hasCountdownTimer = !config.hasCountdownTimer;
                if (config.hasCountdownTimer && config.countdownSeconds <= 0) {
                    config.countdownSeconds = 15;
                }
                updateNoticeControls();
                refreshPreview();
            });
        }
        View.OnClickListener timerClick = v -> {
            Button b = (Button) v;
            String text = b.getText().toString().replace("s", "").trim();
            try {
                config.countdownSeconds = Integer.parseInt(text);
                config.hasCountdownTimer = true;
            } catch (Exception ignored) {}
            updateNoticeControls();
            refreshPreview();
        };
        if (btnTimer5s != null) btnTimer5s.setOnClickListener(timerClick);
        if (btnTimer10s != null) btnTimer10s.setOnClickListener(timerClick);
        if (btnTimer15s != null) btnTimer15s.setOnClickListener(timerClick);
        if (btnTimer30s != null) btnTimer30s.setOnClickListener(timerClick);
        if (btnTimer60s != null) btnTimer60s.setOnClickListener(timerClick);

        btnToggleIcon = findViewById(R.id.btn_toggle_icon);
        if (btnToggleIcon != null) {
            btnToggleIcon.setOnClickListener(v -> {
                iconIdx = (iconIdx + 1) % ICON_NAMES.length;
                String name = ICON_NAMES[iconIdx];
                config.iconName = name;
                config.hasImage = !"NONE".equals(name);
                config.iconResIndex = iconIdx;
                btnToggleIcon.setText("Emblem: " + name);
                refreshPreview();
            });
        }

        btnIconColor = findViewById(R.id.btn_icon_color);
        if (btnIconColor != null) {
            btnIconColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.borderHex, colorHex -> {
                    config.borderHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        configureSpecificSections();

        // Section 5: Buttons
        btnCount1 = findViewById(R.id.btn_count_1);
        btnCount2 = findViewById(R.id.btn_count_2);
        btnCount3 = findViewById(R.id.btn_count_3);

        if (btnCount1 != null) btnCount1.setOnClickListener(v -> setButtonCount(1));
        if (btnCount2 != null) btnCount2.setOnClickListener(v -> setButtonCount(2));
        if (btnCount3 != null) btnCount3.setOnClickListener(v -> setButtonCount(3));

        layoutBtn1 = findViewById(R.id.layout_btn1);
        layoutBtn2 = findViewById(R.id.layout_btn2);
        layoutBtnConfirm = findViewById(R.id.layout_btn_confirm);

        etBtn1Text = findViewById(R.id.et_btn1_text);
        if (etBtn1Text != null) {
            etBtn1Text.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn1Text = s.toString();
                    refreshPreview();
                }
            });
        }

        btnBtn1BgColor = findViewById(R.id.btn_btn1_bg_color);
        if (btnBtn1BgColor != null) {
            btnBtn1BgColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn1BgHex, colorHex -> {
                    config.btn1BgHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnBtn1TextColor = findViewById(R.id.btn_btn1_text_color);
        if (btnBtn1TextColor != null) {
            btnBtn1TextColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn1ColorHex, colorHex -> {
                    config.btn1ColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        etBtn1Url = findViewById(R.id.et_btn1_url);
        if (etBtn1Url != null) {
            etBtn1Url.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn1Url = s.toString();
                }
            });
        }

        btnBtn1ActionType = findViewById(R.id.btn_btn1_action_type);
        if (btnBtn1ActionType != null) {
            btnBtn1ActionType.setOnClickListener(v -> cycleActionType(1));
        }

        etBtn2Text = findViewById(R.id.et_btn2_text);
        if (etBtn2Text != null) {
            etBtn2Text.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn2Text = s.toString();
                    refreshPreview();
                }
            });
        }

        btnBtn2BgColor = findViewById(R.id.btn_btn2_bg_color);
        if (btnBtn2BgColor != null) {
            btnBtn2BgColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn2BgHex, colorHex -> {
                    config.btn2BgHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnBtn2TextColor = findViewById(R.id.btn_btn2_text_color);
        if (btnBtn2TextColor != null) {
            btnBtn2TextColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn2ColorHex, colorHex -> {
                    config.btn2ColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        etBtn2Url = findViewById(R.id.et_btn2_url);
        if (etBtn2Url != null) {
            etBtn2Url.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn2Url = s.toString();
                }
            });
        }

        btnBtn2ActionType = findViewById(R.id.btn_btn2_action_type);
        if (btnBtn2ActionType != null) {
            btnBtn2ActionType.setOnClickListener(v -> cycleActionType(2));
        }

        etBtnConfirmText = findViewById(R.id.et_btn_confirm_text);
        if (etBtnConfirmText != null) {
            etBtnConfirmText.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn3Text = s.toString();
                    refreshPreview();
                }
            });
        }

        btnConfirmBgColor = findViewById(R.id.btn_confirm_bg_color);
        if (btnConfirmBgColor != null) {
            btnConfirmBgColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn3BgHex, colorHex -> {
                    config.btn3BgHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        btnConfirmTextColor = findViewById(R.id.btn_confirm_text_color);
        if (btnConfirmTextColor != null) {
            btnConfirmTextColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.btn3ColorHex, colorHex -> {
                    config.btn3ColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        etBtnConfirmUrl = findViewById(R.id.et_btn_confirm_url);
        if (etBtnConfirmUrl != null) {
            etBtnConfirmUrl.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.btn3Url = s.toString();
                }
            });
        }

        btnBtn3ActionType = findViewById(R.id.btn_btn3_action_type);
        if (btnBtn3ActionType != null) {
            btnBtn3ActionType.setOnClickListener(v -> cycleActionType(3));
        }

        // Section 6: Don't Show Again Checkbox (টিক চিহ্ন)
        btnToggleDontShow = findViewById(R.id.btn_toggle_dont_show);
        if (btnToggleDontShow != null) {
            btnToggleDontShow.setOnClickListener(v -> {
                config.hasDontShowAgain = !config.hasDontShowAgain;
                btnToggleDontShow.setText(config.hasDontShowAgain ? "Checkbox: ON" : "Checkbox: OFF");
                btnToggleDontShow.setTextColor(config.hasDontShowAgain ? Color.CYAN : Color.WHITE);
                refreshPreview();
            });
        }

        btnDontShowColor = findViewById(R.id.btn_dont_show_color);
        if (btnDontShowColor != null) {
            btnDontShowColor.setOnClickListener(v -> {
                new ColorPickerDialog(this, config.dontShowAgainColorHex, colorHex -> {
                    config.dontShowAgainColorHex = colorHex;
                    refreshPreview();
                }).show();
            });
        }

        etDontShowText = findViewById(R.id.et_dont_show_text);
        if (etDontShowText != null) {
            etDontShowText.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) {
                    config.dontShowAgainText = s.toString();
                    refreshPreview();
                }
            });
        }

        // Section 7: Animation
        btnAnimOpen = findViewById(R.id.btn_anim_open);
        if (btnAnimOpen != null) {
            btnAnimOpen.setOnClickListener(v -> {
                animIdx = (animIdx + 1) % ANIM_MODES.length;
                config.openAnimMode = ANIM_MODES[animIdx];
                btnAnimOpen.setText("Enter: " + config.openAnimMode);
                DialogPreviewHelper.playOpeningAnimation(cardPreview, config.openAnimMode, config.animDurationMs);
            });
        }

        btnAnimDuration = findViewById(R.id.btn_anim_duration);
        if (btnAnimDuration != null) {
            btnAnimDuration.setOnClickListener(v -> {
                if (config.animDurationMs == 350) config.animDurationMs = 500;
                else if (config.animDurationMs == 500) config.animDurationMs = 700;
                else config.animDurationMs = 350;
                btnAnimDuration.setText("Duration: " + config.animDurationMs + "ms");
            });
        }

        btnTestAnimPreview = findViewById(R.id.btn_test_anim_preview);
        if (btnTestAnimPreview != null) {
            btnTestAnimPreview.setOnClickListener(v -> {
                DialogPreviewHelper.playOpeningAnimation(cardPreview, config.openAnimMode, config.animDurationMs);
                MorsalinToast.show(this, R.drawable.ic_about_dev, "Animation Preview", "Testing: " + config.openAnimMode);
            });
        }

        // Section 8: Build & Download Panels
        scrollView = findViewById(R.id.scroll_custom);
        layoutAnimPanel = findViewById(R.id.layout_anim_panel);
        layoutReadyPanel = findViewById(R.id.layout_ready_panel);
        animView = findViewById(R.id.conversion_anim_view);
        tvAnimBadge = findViewById(R.id.tv_anim_badge);
        tvAnimStatus = findViewById(R.id.tv_anim_status);
        tvDexReport = findViewById(R.id.tv_dex_report);

        Button btnBuild = findViewById(R.id.btn_build_pipeline);
        if (btnBuild != null) {
            btnBuild.setOnClickListener(v -> executeBuildPipeline());
        }

        Button btnDlFolder = findViewById(R.id.btn_download_folder);
        if (btnDlFolder != null) {
            btnDlFolder.setOnClickListener(v -> downloadAllFiles());
        }

        Button btnDlAll = findViewById(R.id.btn_download_all);
        if (btnDlAll != null) {
            btnDlAll.setOnClickListener(v -> downloadAllZip());
        }

        Button btnDlDex = findViewById(R.id.btn_download_dex);
        if (btnDlDex != null) {
            btnDlDex.setOnClickListener(v -> downloadDex());
        }

        Button btnDlGuide = findViewById(R.id.btn_download_guide);
        if (btnDlGuide != null) {
            btnDlGuide.setOnClickListener(v -> downloadGuide());
        }

        Button btnSave = findViewById(R.id.btn_save_history);
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> saveToHistory());
        }

        Button btnShare = findViewById(R.id.btn_share_export);
        if (btnShare != null) {
            btnShare.setOnClickListener(v -> shareHook());
        }
    }

    protected void setButtonCount(int count) {
        config.buttonCount = count;
        if (btnCount1 != null) btnCount1.setTextColor(count == 1 ? Color.CYAN : Color.WHITE);
        if (btnCount2 != null) btnCount2.setTextColor(count == 2 ? Color.CYAN : Color.WHITE);
        if (btnCount3 != null) btnCount3.setTextColor(count == 3 ? Color.CYAN : Color.WHITE);

        if (layoutBtn1 != null) layoutBtn1.setVisibility(count >= 2 ? View.VISIBLE : View.GONE);
        if (layoutBtn2 != null) layoutBtn2.setVisibility(count == 3 ? View.VISIBLE : View.GONE);

        refreshPreview();
    }

    protected void cycleActionType(int buttonNum) {
        String current = (buttonNum == 1) ? config.btn1Action : (buttonNum == 2) ? config.btn2Action : config.btn3Action;
        int idx = 0;
        for (int i = 0; i < ACTION_TYPES.length; i++) {
            if (ACTION_TYPES[i].equalsIgnoreCase(current)) {
                idx = (i + 1) % ACTION_TYPES.length;
                break;
            }
        }
        String next = ACTION_TYPES[idx];

        if (buttonNum == 1) {
            config.btn1Action = next;
            if (btnBtn1ActionType != null) btnBtn1ActionType.setText("Action: " + getShortActionName(next));
            if (etBtn1Url != null) etBtn1Url.setVisibility(DialogConfig.ACTION_DISMISS.equals(next) ? View.GONE : View.VISIBLE);
        } else if (buttonNum == 2) {
            config.btn2Action = next;
            if (btnBtn2ActionType != null) btnBtn2ActionType.setText("Action: " + getShortActionName(next));
            if (etBtn2Url != null) etBtn2Url.setVisibility(DialogConfig.ACTION_DISMISS.equals(next) ? View.GONE : View.VISIBLE);
        } else {
            config.btn3Action = next;
            if (btnBtn3ActionType != null) btnBtn3ActionType.setText("Action: " + getShortActionName(next));
            if (etBtnConfirmUrl != null) etBtnConfirmUrl.setVisibility(DialogConfig.ACTION_DISMISS.equals(next) ? View.GONE : View.VISIBLE);
        }
    }

    private String getShortActionName(String action) {
        if (DialogConfig.ACTION_DISMISS.equalsIgnoreCase(action)) return "Dismiss";
        if (DialogConfig.ACTION_OPEN_URL.equalsIgnoreCase(action)) return "URL";
        if (DialogConfig.ACTION_OPEN_ACTIVITY.equalsIgnoreCase(action)) return "Activity";
        return "Custom";
    }

    protected void updateHeightLabel() {
        if (tvHeightVal != null) {
            String tag = config.heightDp >= 440 ? " (Tall)" :
                         config.heightDp <= 240 ? " (Compact)" : " (Standard)";
            tvHeightVal.setText(config.heightDp + "dp" + tag);
        }
    }

    protected void configureSpecificSections() {
        boolean isProfile = isProfileDialog();
        if (layoutProfilePhotoSection != null) {
            layoutProfilePhotoSection.setVisibility(isProfile ? View.VISIBLE : View.GONE);
        }
        if (layoutVectorIconSection != null) {
            layoutVectorIconSection.setVisibility(isProfile ? View.GONE : View.VISIBLE);
            if (tvEmblemSectionTitle != null) {
                tvEmblemSectionTitle.setText(getEmblemSectionTitle());
            }
        }
        if (layoutNoticeUpdateSection != null) {
            boolean isNotice = DialogConfig.TYPE_NOTICE.equalsIgnoreCase(config.dialogType)
                    || config.isForceUpdate || config.hasCountdownTimer;
            layoutNoticeUpdateSection.setVisibility(isNotice ? View.VISIBLE : View.GONE);
        }
        setupCustomMakerOptions();
    }

    protected boolean isProfileDialog() {
        return DialogConfig.TYPE_PROFILE.equalsIgnoreCase(config.dialogType);
    }

    protected String getEmblemSectionTitle() {
        if (DialogConfig.TYPE_NOTICE.equalsIgnoreCase(config.dialogType)) {
            return "4. NOTICE BADGE & ALERT EMBLEM (NO PHOTO)";
        } else if (DialogConfig.TYPE_COLORFUL.equalsIgnoreCase(config.dialogType)) {
            return "4. NEON GRAPHIC & VECTOR EMBLEM (NO PHOTO)";
        } else if (DialogConfig.TYPE_SIMPLE_SMALI.equalsIgnoreCase(config.dialogType)) {
            return "4. MINIMAL VECTOR EMBLEM (NO PHOTO)";
        }
        return "4. GRAPHIC & VECTOR EMBLEM (NO PHOTO)";
    }

    protected void setupCustomMakerOptions() {
        // Subclasses can customize buttons or extra options
    }

    protected void updateAvatarControls() {
        if (tvAvatarSizeLabel != null) {
            tvAvatarSizeLabel.setText("📐 Photo Size: " + config.avatarSizeDp + "dp");
        }
        if (seekAvatarSize != null) {
            seekAvatarSize.setProgress(Math.max(0, Math.min(120, config.avatarSizeDp - 36)));
        }
        if (btnAvatarBorderWidth != null) {
            btnAvatarBorderWidth.setText("Border: " + config.avatarBorderWidthDp + "dp");
        }
        if (btnAvatarBorderStyle != null) {
            String styleText = "SOLID".equalsIgnoreCase(config.avatarBorderStyle) ? "⚪ Solid" :
                    "DOTTED".equalsIgnoreCase(config.avatarBorderStyle) ? "⁝⁝ Dotted" :
                    "DASHED".equalsIgnoreCase(config.avatarBorderStyle) ? "╌╌ Dashed" : "✨ Neon Glow";
            btnAvatarBorderStyle.setText("Border Style: " + styleText);
            btnAvatarBorderStyle.setTextColor(
                    "DOTTED".equalsIgnoreCase(config.avatarBorderStyle) ? Color.CYAN :
                    "GLOW".equalsIgnoreCase(config.avatarBorderStyle) ? Color.MAGENTA : Color.GREEN);
        }
        if (btnAvatarPreset != null) {
            btnAvatarPreset.setText("Preset: " + config.avatarPreset);
        }
        if (btnAvatarShape != null) {
            btnAvatarShape.setText("Shape: " + config.avatarShape);
        }
    }

    protected void updateNoticeControls() {
        if (btnToggleForceUpdate != null) {
            btnToggleForceUpdate.setText(config.isForceUpdate
                    ? "🔒 Force Update: ON (No Exit)"
                    : "🔒 Force Update: OFF (Allows Exit)");
            btnToggleForceUpdate.setTextColor(config.isForceUpdate ? Color.RED : Color.WHITE);
        }
        if (btnToggleCountdown != null) {
            btnToggleCountdown.setText(config.hasCountdownTimer
                    ? "⏱️ Countdown Timer: " + config.countdownSeconds + "s"
                    : "⏱️ Countdown Timer: OFF");
            btnToggleCountdown.setTextColor(config.hasCountdownTimer ? Color.CYAN : Color.WHITE);
        }
    }

    public void applyPreset(DialogConfig newPreset, String presetName) {
        if (newPreset == null) return;
        this.config = newPreset;
        updateInputsFromConfig();
        refreshPreview();
        if (cardPreview != null) {
            DialogPreviewHelper.playOpeningAnimation(cardPreview, config.openAnimMode, 300);
        }
        MorsalinToast.show(this, R.drawable.ic_save, "Preset Loaded", presetName + " applied!");
    }

    protected void setupPresets() {
        // Overridden by subclasses to provide 4 dedicated presets
    }

    protected void updateInputsFromConfig() {
        if (etTitle != null) etTitle.setText(config.titleText);
        if (etMessage != null) etMessage.setText(config.messageText);
        if (seekRadius != null) seekRadius.setProgress(config.cornerRadiusDp);
        if (tvRadiusVal != null) tvRadiusVal.setText("Corner Radius: " + config.cornerRadiusDp + "dp");
        if (seekWidth != null) seekWidth.setProgress(Math.max(0, config.widthPct - 70));
        if (tvWidthVal != null) {
            String widthTag = config.widthPct >= 94 ? " (Wide)" :
                              config.widthPct <= 75 ? " (Slim)" : " (Standard)";
            tvWidthVal.setText(config.widthPct + "%" + widthTag);
        }
        if (seekHeight != null) seekHeight.setProgress(Math.max(0, (config.heightDp - 200) / 10));
        updateHeightLabel();

        if (btnGradientToggle != null) {
            btnGradientToggle.setText(config.isGradient ? "Gradient: ON" : "Gradient: OFF");
        }

        if (btnToggleDontShow != null) {
            btnToggleDontShow.setText(config.hasDontShowAgain ? "Checkbox: ON" : "Checkbox: OFF");
            btnToggleDontShow.setTextColor(config.hasDontShowAgain ? Color.CYAN : Color.WHITE);
        }
        if (etDontShowText != null) {
            etDontShowText.setText(config.dontShowAgainText);
        }

        updateAvatarControls();
        updateNoticeControls();
        configureSpecificSections();

        setButtonCount(config.buttonCount);

        if (etBtn1Text != null) etBtn1Text.setText(config.btn1Text);
        if (etBtn1Url != null) etBtn1Url.setText(config.btn1Url);
        if (etBtn2Text != null) etBtn2Text.setText(config.btn2Text);
        if (etBtn2Url != null) etBtn2Url.setText(config.btn2Url);
        if (etBtnConfirmText != null) etBtnConfirmText.setText(config.btn3Text);
        if (etBtnConfirmUrl != null) etBtnConfirmUrl.setText(config.btn3Url);

        if (btnAnimOpen != null) btnAnimOpen.setText("Enter: " + config.openAnimMode);
        if (btnAnimDuration != null) btnAnimDuration.setText("Duration: " + config.animDurationMs + "ms");
    }

    protected void refreshPreview() {
        if (cardPreview == null) return;

        // Card container background and dynamic height/width sizing
        cardPreview.setBackground(DialogPreviewHelper.buildDialogDrawable(config, this));
        int padPx = DialogPreviewHelper.dpToPx(this, Math.max(10, config.paddingDp));
        cardPreview.setPadding(padPx, padPx, padPx, padPx);
        int previewMinH = DialogPreviewHelper.dpToPx(this, Math.max(180, Math.round(config.heightDp * 0.72f)));
        cardPreview.setMinimumHeight(previewMinH);

        ViewGroup.LayoutParams cardLp = cardPreview.getLayoutParams();
        if (cardLp != null) {
            int screenW = getResources().getDisplayMetrics().widthPixels - DialogPreviewHelper.dpToPx(this, 36);
            int targetW = (int) (screenW * (config.widthPct / 100f));
            cardLp.width = Math.max(DialogPreviewHelper.dpToPx(this, 220), targetW);
            cardPreview.setLayoutParams(cardLp);
        }

        // Notice Badge
        if (tvPreviewBadge != null) {
            if (config.hasNoticeBadge) {
                tvPreviewBadge.setVisibility(View.VISIBLE);
                tvPreviewBadge.setText(config.noticeBadgeText);
                tvPreviewBadge.setTextColor(DialogPreviewHelper.parseColorSafe(config.noticeBadgeTextHex, Color.WHITE));
            } else {
                tvPreviewBadge.setVisibility(View.GONE);
            }
        }

        // Icon / Image / Avatar
        boolean isAvatarType = isProfileDialog() || config.hasCustomAvatar || "AVATAR".equalsIgnoreCase(config.imageKind);
        if (ivPreviewIcon != null) {
            if (config.hasImage || isAvatarType) {
                ivPreviewIcon.setVisibility(View.VISIBLE);

                int sizePx = DialogPreviewHelper.dpToPx(this, isAvatarType ? Math.max(36, config.avatarSizeDp) : config.imageSizeDp);
                ViewGroup.LayoutParams lp = ivPreviewIcon.getLayoutParams();
                if (lp != null) {
                    lp.width = sizePx;
                    lp.height = sizePx;
                    ivPreviewIcon.setLayoutParams(lp);
                }

                if (isAvatarType) {
                    Bitmap rawBmp = null;
                    if (config.hasCustomAvatar && config.customAvatarBytes != null && config.customAvatarBytes.length > 0) {
                        try {
                            rawBmp = BitmapFactory.decodeByteArray(config.customAvatarBytes, 0, config.customAvatarBytes.length);
                        } catch (Throwable ignored) {}
                    }
                    if (rawBmp == null) {
                        int avatarRes = R.drawable.avatar_morsalin_cyber_1790834216696;
                        if ("Morsalin Neon".equalsIgnoreCase(config.avatarPreset)) {
                            avatarRes = R.drawable.avatar_morsalin_neon_1790834232712;
                        } else if ("Sanny DJ".equalsIgnoreCase(config.avatarPreset)) {
                            avatarRes = R.drawable.avatar_sanny_dj_1790834248190;
                        } else if ("Sanny Modder".equalsIgnoreCase(config.avatarPreset)) {
                            avatarRes = R.drawable.avatar_sanny_modder_1790834263619;
                        }
                        rawBmp = BitmapFactory.decodeResource(getResources(), avatarRes);
                    }
                    if (rawBmp != null) {
                        Bitmap framed = DialogPreviewHelper.createFramedAvatarBitmap(
                                this, rawBmp, config.avatarSizeDp, config.avatarShape,
                                config.avatarBorderWidthDp, config.avatarBorderHex, config.avatarBorderStyle);
                        ivPreviewIcon.setImageTintList(null);
                        ivPreviewIcon.clearColorFilter();
                        ivPreviewIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        ivPreviewIcon.setImageBitmap(framed != null ? framed : rawBmp);
                    }
                } else {
                    int res = DialogPreviewHelper.ICON_RES[Math.min(config.iconResIndex, DialogPreviewHelper.ICON_RES.length - 1)];
                    if (res != 0) {
                        ivPreviewIcon.setImageResource(res);
                        ivPreviewIcon.setColorFilter(DialogPreviewHelper.parseColorSafe(config.borderHex, Color.CYAN));
                    }
                }
            } else {
                ivPreviewIcon.setVisibility(View.GONE);
            }
        }

        // Title
        if (tvPreviewTitle != null) {
            tvPreviewTitle.setText(config.titleText);
            tvPreviewTitle.setTextColor(DialogPreviewHelper.parseColorSafe(config.titleColorHex, Color.CYAN));
            tvPreviewTitle.setTypeface(DialogPreviewHelper.resolveFontTypeface(config.titleFont), config.titleBold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            tvPreviewTitle.setGravity(DialogPreviewHelper.resolveGravity(config.titleAlignment));
        }

        // Subtitle
        if (tvPreviewSubtitle != null) {
            if (config.subtitleVisible && config.subtitleText != null && !config.subtitleText.isEmpty()) {
                tvPreviewSubtitle.setVisibility(View.VISIBLE);
                tvPreviewSubtitle.setText(config.subtitleText);
                tvPreviewSubtitle.setTextColor(DialogPreviewHelper.parseColorSafe(config.subtitleColorHex, 0xFF00FF88));
            } else {
                tvPreviewSubtitle.setVisibility(View.GONE);
            }
        }

        // Message
        if (tvPreviewMessage != null) {
            if (config.messageVisible && config.messageText != null && !config.messageText.isEmpty()) {
                tvPreviewMessage.setVisibility(View.VISIBLE);
                tvPreviewMessage.setText(config.messageText);
                tvPreviewMessage.setTextColor(DialogPreviewHelper.parseColorSafe(config.messageColorHex, Color.WHITE));
                tvPreviewMessage.setTypeface(DialogPreviewHelper.resolveFontTypeface(config.messageFont));
                tvPreviewMessage.setGravity(DialogPreviewHelper.resolveGravity(config.messageAlignment));
            } else {
                tvPreviewMessage.setVisibility(View.GONE);
            }
        }

        // Live Countdown Timer Badge Preview
        if (tvPreviewCountdown != null) {
            if (config.hasCountdownTimer) {
                tvPreviewCountdown.setVisibility(View.VISIBLE);
                tvPreviewCountdown.setText("⏱️ Mandatory Update in: " + config.countdownSeconds + "s");
            } else {
                tvPreviewCountdown.setVisibility(View.GONE);
            }
        }

        // Don't show again Checkbox
        if (cbPreviewDontShow != null) {
            if (config.hasDontShowAgain && !config.isForceUpdate) {
                cbPreviewDontShow.setVisibility(View.VISIBLE);
                cbPreviewDontShow.setText(config.dontShowAgainText != null && !config.dontShowAgainText.isEmpty()
                        ? config.dontShowAgainText : "Don't show this again");
                cbPreviewDontShow.setTextColor(DialogPreviewHelper.parseColorSafe(config.dontShowAgainColorHex, 0xFF94A3B8));
            } else {
                cbPreviewDontShow.setVisibility(View.GONE);
            }
        }

        // Responsive Action Buttons Layout
        LinearLayout layoutButtons = findViewById(R.id.layout_preview_buttons);
        boolean isNarrow = config.widthPct < 84 || (config.buttonCount == 3 && config.widthPct < 90);
        boolean isVertical = "VERTICAL".equalsIgnoreCase(config.btnOrientation) || isNarrow;
        if (layoutButtons != null) {
            layoutButtons.setOrientation(isVertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        }

        float responsiveSp = Math.max(10.5f, Math.min(13.5f, 12f * (config.widthPct / 92f)));
        int btnHeightPx = DialogPreviewHelper.dpToPx(this, Math.max(34, Math.min(44, (int) (38 * (config.widthPct / 90f)))));

        // Buttons
        if (btnPrev1 != null) {
            btnPrev1.setVisibility((!config.isForceUpdate && config.buttonCount >= 2) ? View.VISIBLE : View.GONE);
            btnPrev1.setText(config.btn1Text);
            btnPrev1.setSingleLine(true);
            btnPrev1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            btnPrev1.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, responsiveSp);
            btnPrev1.setTextColor(DialogPreviewHelper.parseColorSafe(config.btn1ColorHex, Color.WHITE));
            btnPrev1.setBackground(DialogPreviewHelper.buildButtonDrawable(config, config.btn1BgHex, config.btn1BorderHex, config.btn1BorderWidthDp, this));
            btnPrev1.setPadding(DialogPreviewHelper.dpToPx(this, 6), 0, DialogPreviewHelper.dpToPx(this, 6), 0);
            if (isVertical) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnHeightPx);
                lp.bottomMargin = DialogPreviewHelper.dpToPx(this, 4);
                btnPrev1.setLayoutParams(lp);
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
                lp.rightMargin = DialogPreviewHelper.dpToPx(this, 3);
                btnPrev1.setLayoutParams(lp);
            }
        }

        if (btnPrev2 != null) {
            btnPrev2.setVisibility((!config.isForceUpdate && config.buttonCount == 3) ? View.VISIBLE : View.GONE);
            btnPrev2.setText(config.btn2Text);
            btnPrev2.setSingleLine(true);
            btnPrev2.setEllipsize(android.text.TextUtils.TruncateAt.END);
            btnPrev2.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, responsiveSp);
            btnPrev2.setTextColor(DialogPreviewHelper.parseColorSafe(config.btn2ColorHex, Color.WHITE));
            btnPrev2.setBackground(DialogPreviewHelper.buildButtonDrawable(config, config.btn2BgHex, config.btn2BorderHex, config.btn2BorderWidthDp, this));
            btnPrev2.setPadding(DialogPreviewHelper.dpToPx(this, 6), 0, DialogPreviewHelper.dpToPx(this, 6), 0);
            if (isVertical) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnHeightPx);
                lp.bottomMargin = DialogPreviewHelper.dpToPx(this, 4);
                btnPrev2.setLayoutParams(lp);
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
                lp.leftMargin = DialogPreviewHelper.dpToPx(this, 2);
                lp.rightMargin = DialogPreviewHelper.dpToPx(this, 2);
                btnPrev2.setLayoutParams(lp);
            }
        }

        if (btnPrevConfirm != null) {
            boolean forceMode = config.isForceUpdate;
            btnPrevConfirm.setText(forceMode
                    ? (config.btn3Text != null && !config.btn3Text.isEmpty() ? config.btn3Text : "UPDATE APP NOW")
                    : config.btn3Text);
            btnPrevConfirm.setSingleLine(true);
            btnPrevConfirm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            btnPrevConfirm.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, responsiveSp);
            btnPrevConfirm.setBackground(DialogPreviewHelper.buildButtonDrawable(config,
                    forceMode ? (config.borderHex != null ? config.borderHex : "#FF1744") : config.btn3BgHex,
                    config.btn3BorderHex, config.btn3BorderWidthDp, this));
            btnPrevConfirm.setTextColor(DialogPreviewHelper.parseColorSafe(forceMode ? "#FFFFFF" : config.btn3ColorHex, Color.CYAN));
            btnPrevConfirm.setPadding(DialogPreviewHelper.dpToPx(this, 6), 0, DialogPreviewHelper.dpToPx(this, 6), 0);
            if (forceMode || config.buttonCount == 1 || isVertical) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, forceMode ? DialogPreviewHelper.dpToPx(this, 42) : btnHeightPx);
                lp.leftMargin = 0;
                lp.rightMargin = 0;
                btnPrevConfirm.setLayoutParams(lp);
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
                lp.leftMargin = DialogPreviewHelper.dpToPx(this, 3);
                btnPrevConfirm.setLayoutParams(lp);
            }
        }
    }

    protected String getExportFolderName() {
        if (config != null && config.dialogName != null && !config.dialogName.trim().isEmpty()) {
            return config.dialogName.trim().replaceAll("\\s+", "_");
        }
        return (config != null && config.dialogType != null)
                ? config.dialogType.trim().replaceAll("\\s+", "_") : "Dialog_Output";
    }

    protected void refreshReadyButtonLabels() {
        Button btnDlAll = findViewById(R.id.btn_download_all);
        if (btnDlAll != null) {
            btnDlAll.setText("📦 Download Clean ZIP (classes.dex + hook.smali)");
        }
        Button btnDlDex = findViewById(R.id.btn_download_dex);
        if (btnDlDex != null) {
            btnDlDex.setText("⚡ classes.dex");
        }
        Button btnDlGuide = findViewById(R.id.btn_download_guide);
        if (btnDlGuide != null) {
            btnDlGuide.setText("📜 hook.smali");
        }
        Button btnDlFolder = findViewById(R.id.btn_download_folder);
        if (btnDlFolder != null) {
            btnDlFolder.setText("📥 Save Clean Files");
        }
    }

    protected void executeBuildPipeline() {
        String optionTitle = config.dialogName != null ? config.dialogName.replaceAll("_", " ") : config.dialogType;
        FullScreenGenerationOverlayHelper.showAndExecute(
                this,
                optionTitle,
                config,
                () -> DialogPackageBuilder.buildDialogPackage(this, config),
                result -> {
                    lastBuildResult = result;
                    runOnUiThread(() -> {
                        if (lastBuildResult != null && lastBuildResult.success) {
                            DexValidator.ValidationResult vr = lastBuildResult.dexValidation;
                            String folder = getExportFolderName();
                            String report = "⚡ DALVIK EXECUTABLE: classes.dex (100% VERIFIED)\n"
                                    + "• Dialog Mode : " + config.dialogType + "\n"
                                    + "• Package ZIP : " + folder + ".zip\n"
                                    + "• DEX Size    : " + vr.sizeBytes + " bytes | Adler32: 0x" + vr.checksumHex + "\n"
                                    + "• SHA-1 Hash  : " + vr.sha1Hex.substring(0, Math.min(16, vr.sha1Hex.length())) + "...\n"
                                    + "• Smali Hook  : invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V\n"
                                    + "• Output Files: classes.dex + hook.smali + assets (ZERO XML)";
                            if (tvDexReport != null) tvDexReport.setText(report);

                            if (layoutReadyPanel != null) {
                                layoutReadyPanel.setVisibility(View.VISIBLE);
                                layoutReadyPanel.setAlpha(0f);
                                layoutReadyPanel.animate().alpha(1f).setDuration(280).start();
                            }
                            if (scrollView != null && layoutReadyPanel != null) {
                                scrollView.post(() -> scrollView.smoothScrollTo(0, layoutReadyPanel.getTop()));
                            }
                            refreshReadyButtonLabels();
                            MorsalinToast.show(this, R.drawable.ic_download, "Build Succeeded",
                                    folder + " classes.dex and hook.smali ready!");
                        } else {
                            String err = (lastBuildResult != null && lastBuildResult.errorMessage != null)
                                    ? lastBuildResult.errorMessage : "Unknown compilation error";
                            if (tvDexReport != null) tvDexReport.setText("❌ BUILD ERROR: " + err);
                            MorsalinToast.show(this, R.drawable.ic_refresh, "Build Failed", err);
                        }
                    });
                }
        );
    }

    protected void downloadDex() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.dexBytes != null) {
            String folder = getExportFolderName();
            // Save strictly a SINGLE classes.dex file ready for direct APK copying without duplicate files
            FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                    this, "MorsalinXML/" + folder, "classes.dex", "application/octet-stream", lastBuildResult.dexBytes);
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "classes.dex Downloaded" : "Download Failed",
                    res.success ? "Saved to Downloads/MorsalinXML/" + folder + "/classes.dex" : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadGuide() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.guideContent != null) {
            String folder = getExportFolderName();
            String guideFile = "hook.smali";
            FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                    this, "MorsalinXML/" + folder, guideFile, "text/plain", lastBuildResult.guideContent.getBytes());
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? guideFile + " Downloaded" : "Download Failed",
                    res.success ? "Saved to Downloads/MorsalinXML/" + folder + "/" + guideFile : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadAllFiles() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.generatedPackage != null) {
            FileExporter.ExportResult res = GeneratedPackageExporter.exportAllPackageFiles(
                    this, lastBuildResult.generatedPackage);
            String folder = getExportFolderName();
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "Files Exported" : "Export Failed",
                    res.success ? "All " + folder + " files saved to Downloads/MorsalinXML/" + folder : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadAllZip() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.generatedPackage != null) {
            FileExporter.ExportResult res = GeneratedPackageExporter.exportPackageAsZip(
                    this, lastBuildResult.generatedPackage);
            String folder = getExportFolderName();
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "ZIP Exported" : "Export Failed",
                    res.success ? folder + ".zip saved to Downloads folder!" : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void saveToHistory() {
        String name = config.dialogName.replaceAll("\\s+", "_");
        XmlProject proj = new XmlProject(name, XmlProject.TYPE_DIALOG, "", config.toJson());
        historyManager.saveProject(proj);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Dialog saved to History!");
    }

    protected void shareHook() {
        String hook = "invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V";
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Morsalin Dialog Smali Hook (GUIDE.smali)");
        send.putExtra(Intent.EXTRA_TEXT, hook);
        startActivity(Intent.createChooser(send, "Share Smali Hook"));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private static abstract class SimpleWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}
