package com.android.modding.tools.toastmaker;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.ConverterAnimationManager;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Full-Screen High-Tech Animated Compilation Overlay for Toast Maker.
 * Shows a 60fps Stark HUD holographic animation and 5 compilation stages.
 */
public class ToastGenerationOverlayHelper {

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public interface BuildTask {
        ToastPackageBuilder.BuildResult execute();
    }

    public interface OnBuildCompleteListener {
        void onComplete(ToastPackageBuilder.BuildResult result);
    }

    public static void showAndExecute(
            Activity activity,
            String optionName,
            ToastConfig config,
            BuildTask buildTask,
            OnBuildCompleteListener listener
    ) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_fullscreen_generation);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.argb(250, 3, 11, 18)));
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        }

        TextView tvBadge = dialog.findViewById(R.id.tv_gen_badge);
        TextView tvTitle = dialog.findViewById(R.id.tv_gen_target_title);
        TextView tvSubtitle = dialog.findViewById(R.id.tv_gen_subtitle);
        ConversionAnimationView animView = dialog.findViewById(R.id.gen_anim_view);
        TextView tvStageCounter = dialog.findViewById(R.id.tv_gen_stage_counter);
        TextView tvPercentage = dialog.findViewById(R.id.tv_gen_percentage);
        ProgressBar progressBar = dialog.findViewById(R.id.progress_bar_gen);
        TextView tvStatus = dialog.findViewById(R.id.tv_gen_status);
        View layoutSuccess = dialog.findViewById(R.id.layout_gen_success);
        TextView tvSpecs = dialog.findViewById(R.id.tv_gen_specs);

        String cleanTitle = optionName != null && !optionName.trim().isEmpty() ? optionName : "Toast Package";
        if (tvBadge != null) tvBadge.setText("⚡ DALVIK COMPILER");
        if (tvTitle != null) tvTitle.setText("⚡ " + cleanTitle.toUpperCase());
        if (tvSubtitle != null) {
            tvSubtitle.setText("Compiling Standalone Dalvik classes.dex • ZERO-XML Architecture");
        }

        if (animView != null) {
            ConverterAnimationManager.ConverterAnimItem animItem = new ConverterAnimationManager.ConverterAnimItem(
                    "toast_hud", "Holo-UI Toast Assembler", "Assembling dynamic toast framework",
                    ConverterAnimationManager.CAT_CINEMATIC, "⚡ STARK TOAST ASSEMBLER ⚡",
                    ConverterAnimationManager.ENGINE_JARVIS_HUD, ConverterAnimationManager.PALETTE_CYBER_NEON, false, false);
            animView.applyAnimationConfig(animItem);
            animView.setLanguages(config != null && config.toastType != null ? config.toastType.toUpperCase() : "TOAST", "CLASSES.DEX");
            animView.updateState(12, "Initializing Dalvik Compiler...");
            animView.startAnimationLoop();
        }

        dialog.show();

        final String[] stages = new String[]{
                "Stage 1/5 • Analyzing View Tree, Colors & Corner Radii...",
                "Stage 2/5 • Generating Pure Java Bytecode & Dynamic Views...",
                "Stage 3/5 • Compiling Dalvik classes.dex via D8 Engine...",
                "Stage 4/5 • Verifying Adler32, SHA-1 Checksums & Magic Header...",
                "Stage 5/5 • Generating hook.smali & Packaging Zero-XML Bundle..."
        };

        final AtomicBoolean taskDone = new AtomicBoolean(false);
        final ToastPackageBuilder.BuildResult[] resultHolder = new ToastPackageBuilder.BuildResult[1];

        // Background worker thread for DEX compilation
        new Thread(() -> {
            try {
                resultHolder[0] = buildTask.execute();
            } catch (Throwable t) {
                resultHolder[0] = ToastPackageBuilder.BuildResult.failure(t.getMessage());
            } finally {
                taskDone.set(true);
            }
        }).start();

        // 60fps Animation driver
        final int[] progress = {5};
        final int[] currentStage = {0};

        final Runnable updater = new Runnable() {
            @Override
            public void run() {
                if (activity.isFinishing()) return;

                if (!taskDone.get()) {
                    if (progress[0] < 88) {
                        progress[0] += (progress[0] < 45) ? 4 : 2;
                    }
                } else {
                    progress[0] += 6;
                }

                if (progress[0] > 100) progress[0] = 100;

                int stageIdx = Math.min(stages.length - 1, progress[0] / 20);
                if (stageIdx != currentStage[0]) {
                    currentStage[0] = stageIdx;
                    if (tvStageCounter != null) {
                        tvStageCounter.setText("STAGE " + (stageIdx + 1) + " OF 5");
                    }
                    if (tvStatus != null) {
                        tvStatus.setText(stages[stageIdx]);
                    }
                    if (animView != null) {
                        animView.updateState(progress[0], stages[stageIdx]);
                    }
                }

                if (progressBar != null) progressBar.setProgress(progress[0]);
                if (tvPercentage != null) tvPercentage.setText(progress[0] + "%");

                if (progress[0] >= 100 && taskDone.get()) {
                    if (layoutSuccess != null) layoutSuccess.setVisibility(View.VISIBLE);
                    if (tvSpecs != null && resultHolder[0] != null && resultHolder[0].dexValidation != null) {
                        tvSpecs.setText("classes.dex: " + resultHolder[0].dexValidation.sizeBytes + " bytes | Adler32: 0x"
                                + resultHolder[0].dexValidation.checksumHex);
                    }
                    if (animView != null) {
                        animView.stopAnimationLoop();
                    }

                    MAIN_HANDLER.postDelayed(() -> {
                        try {
                            if (dialog.isShowing()) dialog.dismiss();
                        } catch (Throwable ignored) {}
                        if (listener != null) {
                            listener.onComplete(resultHolder[0]);
                        }
                    }, 450);
                } else {
                    MAIN_HANDLER.postDelayed(this, 35);
                }
            }
        };

        MAIN_HANDLER.post(updater);
    }
}
