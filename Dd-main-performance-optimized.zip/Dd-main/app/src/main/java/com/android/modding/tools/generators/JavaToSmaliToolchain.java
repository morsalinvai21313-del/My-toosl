package com.android.modding.tools.generators;

import android.content.Context;
import android.util.Log;

import com.android.tools.r8.D8;
import com.android.tools.r8.D8Command;
import com.android.tools.r8.OutputMode;
import com.android.tools.smali.baksmali.Baksmali;
import com.android.tools.smali.baksmali.BaksmaliOptions;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.smali.Smali;
import com.android.tools.smali.smali.SmaliOptions;

import org.eclipse.jdt.internal.compiler.batch.Main;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Authoritative, Production-Grade Java → Bytecode → DEX → Smali Compilation Pipeline.
 *
 * Android Runtime Compatibility:
 * 1. Uses Android-compatible Eclipse JDT (ECJ 3.18.0) which eliminates any static dependency
 *    on javax.lang.model.SourceVersion (which was introduced in ECJ 3.19.0+ FileSystem.<clinit>).
 * 2. Overrides initializeAnnotationProcessorManager() in AndroidEcjBatchCompiler to guarantee
 *    that Annotation Processing (APT) is never initialized on Android ART/Dalvik, avoiding
 *    NoClassDefFoundError for javax.annotation.processing or javax.lang.model.
 * 3. Compiles Java source → JVM bytecode (.class) using ECJ.
 * 4. Desugars and compiles .class → classes.dex using embedded Android D8.
 * 5. Disassembles classes.dex → authentic .smali files using Baksmali.
 * 6. Performs round-trip validation using Smali assembler (.smali → .dex).
 */
public class JavaToSmaliToolchain {

    private static final String TAG = "JavaToSmaliToolchain";
    private static final String ASSET_ANDROID_JAR = "android_stubs/android_apis.jar";
    private static final String CACHED_ANDROID_JAR = "android_apis.jar";

    public interface ProgressListener {
        void onProgress(int percentage, String stageDescription);
    }

    /**
     * Custom Android-compatible ECJ Batch Compiler.
     * Prevents APT (Annotation Processing Tool) initialization on Android ART/Dalvik runtime.
     */
    public static class AndroidEcjBatchCompiler extends Main {
        public AndroidEcjBatchCompiler(PrintWriter outWriter, PrintWriter errWriter, boolean systemExitWhenFinished) {
            super(outWriter, errWriter, systemExitWhenFinished, null, null);
        }

        @Override
        protected void initializeAnnotationProcessorManager() {
            // Disabled on Android runtime:
            // Standard Java -> Bytecode compilation does not require annotation processors.
            // Overriding this ensures that on ART/Dalvik it never attempts to load
            // javax.annotation.processing or javax.lang.model classes.
        }
    }

    public static class CompilationResult {
        public final boolean success;
        public final String primarySmaliContent;
        public final String primarySmaliFileName;
        public final String primaryClassName;
        public final String packageName;
        public final Map<String, String> allSmaliFiles; // relativePath -> content
        public final byte[] dexBytes;
        public final byte[] zipBytes;
        public final boolean roundTripValid;
        public final int classesCount;
        public final int methodsCount;
        public final int fieldsCount;
        public final String errorMessage;
        public final String errorDetails;
        public final List<DiagnosticError> diagnosticErrors;

        public CompilationResult(boolean success,
                                 String primarySmaliContent,
                                 String primarySmaliFileName,
                                 String primaryClassName,
                                 String packageName,
                                 Map<String, String> allSmaliFiles,
                                 byte[] dexBytes,
                                 byte[] zipBytes,
                                 boolean roundTripValid,
                                 int classesCount,
                                 int methodsCount,
                                 int fieldsCount,
                                 String errorMessage,
                                 String errorDetails,
                                 List<DiagnosticError> diagnosticErrors) {
            this.success = success;
            this.primarySmaliContent = primarySmaliContent != null ? primarySmaliContent : "";
            this.primarySmaliFileName = primarySmaliFileName != null ? primarySmaliFileName : "Unknown.smali";
            this.primaryClassName = primaryClassName != null ? primaryClassName : "Unknown";
            this.packageName = packageName != null ? packageName : "";
            this.allSmaliFiles = allSmaliFiles != null ? allSmaliFiles : Collections.emptyMap();
            this.dexBytes = dexBytes;
            this.zipBytes = zipBytes;
            this.roundTripValid = roundTripValid;
            this.classesCount = classesCount;
            this.methodsCount = methodsCount;
            this.fieldsCount = fieldsCount;
            this.errorMessage = errorMessage != null ? errorMessage : "";
            this.errorDetails = errorDetails != null ? errorDetails : "";
            this.diagnosticErrors = diagnosticErrors != null ? diagnosticErrors : Collections.emptyList();
        }

        public static CompilationResult failure(String message, String details, List<DiagnosticError> errors) {
            return new CompilationResult(
                    false, "", "", "", "",
                    Collections.emptyMap(), null, null, false,
                    0, 0, 0,
                    message, details, errors
            );
        }
    }

    public static class DiagnosticError {
        public final String file;
        public final int line;
        public final int column;
        public final String message;
        public final String snippet;

        public DiagnosticError(String file, int line, int column, String message, String snippet) {
            this.file = file;
            this.line = line;
            this.column = column;
            this.message = message;
            this.snippet = snippet;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            if (line > 0) {
                sb.append("Line ").append(line);
                if (column > 0) sb.append(", Column ").append(column);
                sb.append(": ");
            }
            sb.append(message);
            if (snippet != null && !snippet.isEmpty()) {
                sb.append("\n  ").append(snippet);
            }
            return sb.toString();
        }
    }

    /**
     * Executes the authoritative Java → Smali compilation pipeline.
     */
    public static CompilationResult compile(Context context, String javaSource, String preferredFileName, ProgressListener listener) {
        if (javaSource == null || javaSource.trim().isEmpty()) {
            return CompilationResult.failure("Java Source Empty", "Please provide Java source code to compile.", null);
        }

        File workDir = null;
        try {
            reportProgress(listener, 5, "Preparing compiler environment...");

            // 1. Resolve Android API classpath
            File androidJar = ensureAndroidClasspath(context);
            if (androidJar == null || !androidJar.exists()) {
                return CompilationResult.failure("Compiler Environment Error",
                        "Could not prepare Android API classpath for compiler. Ensure assets are intact.", null);
            }

            // 2. Setup workspace directory
            File cacheBase = context != null ? context.getCacheDir() : new File(System.getProperty("java.io.tmpdir", "/tmp"));
            workDir = new File(cacheBase, "j2s_work_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 1000));
            File srcDir = new File(workDir, "src");
            File classesDir = new File(workDir, "classes");
            File dexDir = new File(workDir, "dex");
            File smaliDir = new File(workDir, "smali");

            if (!srcDir.mkdirs() || !classesDir.mkdirs() || !dexDir.mkdirs() || !smaliDir.mkdirs()) {
                return CompilationResult.failure("Workspace Initialization Failed",
                        "Unable to create temporary directories in app storage.", null);
            }

            // 3. Extract package & class name
            String normalizedCode = javaSource.replace("\r\n", "\n").replace("\r", "\n");
            String packageName = extractPackageName(normalizedCode);
            String primaryClassName = extractClassName(normalizedCode, preferredFileName);

            // 4. Handle multiple top-level classes if present
            List<File> sourceFiles = writeSourceFiles(srcDir, packageName, primaryClassName, normalizedCode);

            // 5. STEP: Java Compilation with AndroidEcjBatchCompiler
            reportProgress(listener, 25, "Compiling Java with Android-compatible compiler...");
            StringWriter outWriter = new StringWriter();
            StringWriter errWriter = new StringWriter();
            PrintWriter out = new PrintWriter(outWriter);
            PrintWriter err = new PrintWriter(errWriter);

            List<String> ecjArgs = new ArrayList<>();
            ecjArgs.add("-1.8");
            ecjArgs.add("-source");
            ecjArgs.add("1.8");
            ecjArgs.add("-target");
            ecjArgs.add("1.8");
            ecjArgs.add("-nowarn");
            ecjArgs.add("-proc:none");
            ecjArgs.add("-cp");
            ecjArgs.add(androidJar.getAbsolutePath());
            ecjArgs.add("-d");
            ecjArgs.add(classesDir.getAbsolutePath());
            for (File sf : sourceFiles) {
                ecjArgs.add(sf.getAbsolutePath());
            }

            AndroidEcjBatchCompiler ecjMain = new AndroidEcjBatchCompiler(out, err, false);
            boolean compiled = ecjMain.compile(ecjArgs.toArray(new String[0]));

            if (!compiled) {
                String errorRaw = errWriter.toString().trim();
                List<DiagnosticError> diagnostics = parseEcjDiagnostics(errorRaw, primaryClassName + ".java");
                String formattedMessage = buildUserFriendlyErrorMessage(diagnostics, errorRaw);
                return CompilationResult.failure("Compilation Failed", formattedMessage, diagnostics);
            }

            // 6. Collect compiled .class files
            List<File> classFiles = new ArrayList<>();
            collectFilesRecursively(classesDir, ".class", classFiles);
            if (classFiles.isEmpty()) {
                return CompilationResult.failure("Bytecode Generation Failed",
                        "Java compiler succeeded but no .class files were produced.", null);
            }

            // 7. STEP: DEX Conversion with Android D8
            reportProgress(listener, 55, "Converting bytecode to DEX using D8...");
            List<Path> classFilePaths = new ArrayList<>();
            for (File cf : classFiles) {
                classFilePaths.add(cf.toPath());
            }

            D8Command.Builder d8Builder = D8Command.builder()
                    .addProgramFiles(classFilePaths)
                    .setOutput(dexDir.toPath(), OutputMode.DexIndexed)
                    .setMinApiLevel(21)
                    .addLibraryFiles(Collections.singletonList(androidJar.toPath()));

            try {
                D8.run(d8Builder.build());
            } catch (Exception d8Ex) {
                return CompilationResult.failure("DEX Conversion Failed",
                        "D8 dexing error: " + d8Ex.getMessage(), null);
            }

            List<File> dexFiles = new ArrayList<>();
            collectFilesRecursively(dexDir, ".dex", dexFiles);
            if (dexFiles.isEmpty()) {
                return CompilationResult.failure("DEX Generation Failed",
                        "D8 completed without generating classes.dex.", null);
            }

            File primaryDexFile = new File(dexDir, "classes.dex");
            if (!primaryDexFile.exists() && !dexFiles.isEmpty()) {
                primaryDexFile = dexFiles.get(0);
            }
            byte[] dexBytes = readFileBytes(primaryDexFile);

            // 8. STEP: Disassemble DEX to Smali using Baksmali
            reportProgress(listener, 80, "Disassembling DEX to Smali using Baksmali...");
            for (File df : dexFiles) {
                try {
                    DexFile loadedDex = DexFileFactory.loadDexFile(df, Opcodes.forApi(21));
                    BaksmaliOptions options = new BaksmaliOptions();
                    options.apiLevel = 21;
                    Baksmali.disassembleDexFile(loadedDex, smaliDir, 1, options);
                } catch (Exception bsmEx) {
                    return CompilationResult.failure("Smali Disassembly Failed",
                            "Baksmali disassembly error: " + bsmEx.getMessage(), null);
                }
            }

            // 9. Collect generated .smali files
            List<File> smaliFiles = new ArrayList<>();
            collectFilesRecursively(smaliDir, ".smali", smaliFiles);
            if (smaliFiles.isEmpty()) {
                return CompilationResult.failure("Smali Extraction Failed",
                        "No .smali files were generated by disassembler.", null);
            }

            Map<String, String> allSmaliMap = new LinkedHashMap<>();
            int totalMethods = 0;
            int totalFields = 0;

            String primarySmaliKey = null;
            String primarySmaliCode = null;

            for (File sf : smaliFiles) {
                String relPath = sf.getAbsolutePath().substring(smaliDir.getAbsolutePath().length() + 1)
                        .replace(File.separatorChar, '/');
                String content = new String(readFileBytes(sf), StandardCharsets.UTF_8);
                allSmaliMap.put(relPath, content);

                // Count methods and fields in smali
                totalMethods += countOccurrences(content, ".method ");
                totalFields += countOccurrences(content, ".field ");

                // Identify primary file: matches primaryClassName.smali
                if (sf.getName().equals(primaryClassName + ".smali")) {
                    primarySmaliKey = relPath;
                    primarySmaliCode = content;
                }
            }

            // If primary not matched exactly, take first non-inner class or first file
            if (primarySmaliCode == null) {
                for (Map.Entry<String, String> entry : allSmaliMap.entrySet()) {
                    if (!entry.getKey().contains("$")) {
                        primarySmaliKey = entry.getKey();
                        primarySmaliCode = entry.getValue();
                        break;
                    }
                }
                if (primarySmaliCode == null && !allSmaliMap.isEmpty()) {
                    Map.Entry<String, String> first = allSmaliMap.entrySet().iterator().next();
                    primarySmaliKey = first.getKey();
                    primarySmaliCode = first.getValue();
                }
            }

            String primarySmaliFileName = primarySmaliKey != null
                    ? primarySmaliKey.substring(primarySmaliKey.lastIndexOf('/') + 1)
                    : primaryClassName + ".smali";

            // 10. STEP: Round-Trip Smali Assembler Validation
            reportProgress(listener, 92, "Validating Smali round-trip assembly...");
            boolean roundTripValid = false;
            try {
                File roundTripDex = new File(workDir, "roundtrip_verify.dex");
                SmaliOptions smaliOpt = new SmaliOptions();
                smaliOpt.outputDexFile = roundTripDex.getAbsolutePath();
                smaliOpt.apiLevel = 21;
                List<String> smaliPaths = new ArrayList<>();
                for (File sf : smaliFiles) {
                    smaliPaths.add(sf.getAbsolutePath());
                }
                roundTripValid = Smali.assemble(smaliOpt, smaliPaths) && roundTripDex.exists() && roundTripDex.length() > 0;
            } catch (Exception asmEx) {
                Log.w(TAG, "Smali assemble validation warning: " + asmEx.getMessage());
            }

            // 11. Create ZIP package of all .smali files
            reportProgress(listener, 97, "Creating Smali export archive...");
            byte[] zipBytes = createZipArchive(allSmaliMap, primaryClassName);

            reportProgress(listener, 100, "Compilation successful!");

            return new CompilationResult(
                    true,
                    primarySmaliCode,
                    primarySmaliFileName,
                    primaryClassName,
                    packageName,
                    allSmaliMap,
                    dexBytes,
                    zipBytes,
                    roundTripValid,
                    allSmaliMap.size(),
                    totalMethods,
                    totalFields,
                    null,
                    null,
                    Collections.emptyList()
            );

        } catch (Throwable t) {
            Log.e(TAG, "Uncaught compilation pipeline error", t);
            return CompilationResult.failure("Conversion Engine Error",
                    "Unexpected processing exception: " + t.getClass().getSimpleName() + " - " + t.getMessage(), null);
        } finally {
            // Clean up temporary workspace
            if (workDir != null) {
                deleteDirRecursively(workDir);
            }
        }
    }

    /**
     * Converts a pre-compiled Java .class file or .dex file directly.
     */
    public static CompilationResult convertBinary(Context context, byte[] binaryBytes, String fileName, ProgressListener listener) {
        if (binaryBytes == null || binaryBytes.length == 0) {
            return CompilationResult.failure("Empty Binary Data", "No binary data was provided.", null);
        }

        File workDir = null;
        try {
            reportProgress(listener, 10, "Preparing binary conversion...");
            File cacheBase = context != null ? context.getCacheDir() : new File(System.getProperty("java.io.tmpdir", "/tmp"));
            workDir = new File(cacheBase, "j2s_bin_" + System.currentTimeMillis());
            File dexDir = new File(workDir, "dex");
            File smaliDir = new File(workDir, "smali");
            dexDir.mkdirs();
            smaliDir.mkdirs();

            boolean isDex = fileName.endsWith(".dex") || (binaryBytes.length >= 8 && binaryBytes[0] == 'd' && binaryBytes[1] == 'e' && binaryBytes[2] == 'x');
            File targetDexFile;

            if (isDex) {
                targetDexFile = new File(dexDir, "classes.dex");
                try (FileOutputStream fos = new FileOutputStream(targetDexFile)) {
                    fos.write(binaryBytes);
                }
            } else {
                // Must be .class bytecode
                reportProgress(listener, 30, "Converting .class bytecode to DEX using D8...");
                File classDir = new File(workDir, "classes");
                classDir.mkdirs();
                File classFile = new File(classDir, fileName.endsWith(".class") ? fileName : fileName + ".class");
                try (FileOutputStream fos = new FileOutputStream(classFile)) {
                    fos.write(binaryBytes);
                }

                File androidJar = ensureAndroidClasspath(context);
                D8Command.Builder d8Builder = D8Command.builder()
                        .addProgramFiles(Collections.singletonList(classFile.toPath()))
                        .setOutput(dexDir.toPath(), OutputMode.DexIndexed)
                        .setMinApiLevel(21);
                if (androidJar != null && androidJar.exists()) {
                    d8Builder.addLibraryFiles(Collections.singletonList(androidJar.toPath()));
                }
                D8.run(d8Builder.build());

                targetDexFile = new File(dexDir, "classes.dex");
                if (!targetDexFile.exists()) {
                    return CompilationResult.failure("DEX Generation Failed", "D8 could not convert .class to classes.dex", null);
                }
            }

            reportProgress(listener, 70, "Disassembling DEX with Baksmali...");
            DexFile loadedDex = DexFileFactory.loadDexFile(targetDexFile, Opcodes.forApi(21));
            BaksmaliOptions options = new BaksmaliOptions();
            options.apiLevel = 21;
            Baksmali.disassembleDexFile(loadedDex, smaliDir, 1, options);

            List<File> smaliFiles = new ArrayList<>();
            collectFilesRecursively(smaliDir, ".smali", smaliFiles);
            if (smaliFiles.isEmpty()) {
                return CompilationResult.failure("Smali Extraction Failed", "Baksmali produced no smali files.", null);
            }

            Map<String, String> allSmaliMap = new LinkedHashMap<>();
            int totalMethods = 0;
            int totalFields = 0;
            for (File sf : smaliFiles) {
                String relPath = sf.getAbsolutePath().substring(smaliDir.getAbsolutePath().length() + 1).replace(File.separatorChar, '/');
                String content = new String(readFileBytes(sf), StandardCharsets.UTF_8);
                allSmaliMap.put(relPath, content);
                totalMethods += countOccurrences(content, ".method ");
                totalFields += countOccurrences(content, ".field ");
            }

            Map.Entry<String, String> first = allSmaliMap.entrySet().iterator().next();
            byte[] dexBytes = readFileBytes(targetDexFile);
            byte[] zipBytes = createZipArchive(allSmaliMap, fileName.replace(".class", "").replace(".dex", ""));

            reportProgress(listener, 100, "Completed successfully!");

            return new CompilationResult(
                    true,
                    first.getValue(),
                    first.getKey().substring(first.getKey().lastIndexOf('/') + 1),
                    fileName.replace(".class", "").replace(".dex", ""),
                    "",
                    allSmaliMap,
                    dexBytes,
                    zipBytes,
                    true,
                    allSmaliMap.size(),
                    totalMethods,
                    totalFields,
                    null,
                    null,
                    Collections.emptyList()
            );

        } catch (Throwable t) {
            return CompilationResult.failure("Binary Conversion Failed", t.getMessage(), null);
        } finally {
            if (workDir != null) deleteDirRecursively(workDir);
        }
    }

    /**
     * Ensures android_apis.jar exists in local app files directory for compilation classpath.
     */
    public static synchronized File ensureAndroidClasspath(Context context) {
        if (context != null) {
            File target = new File(context.getFilesDir(), CACHED_ANDROID_JAR);
            if (target.exists() && target.length() > 1000000) {
                return target;
            }
            try (InputStream is = context.getAssets().open(ASSET_ANDROID_JAR);
                 FileOutputStream fos = new FileOutputStream(target)) {
                byte[] buf = new byte[65536];
                int len;
                while ((len = is.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                }
                fos.flush();
                return target;
            } catch (Exception e) {
                Log.e(TAG, "Failed extracting android_apis.jar from assets: " + e.getMessage());
            }
        }

        // JVM unit test fallback
        File localAsset = new File("app/src/main/assets/" + ASSET_ANDROID_JAR);
        if (localAsset.exists()) return localAsset;

        String sdkRoot = System.getenv("ANDROID_SDK_ROOT");
        if (sdkRoot != null) {
            File platformJar = new File(sdkRoot, "platforms/android-36/android.jar");
            if (platformJar.exists()) return platformJar;
        }

        return null;
    }

    private static List<File> writeSourceFiles(File srcDir, String packageName, String primaryClassName, String code) throws IOException {
        List<File> files = new ArrayList<>();
        File targetDir = srcDir;
        if (!packageName.isEmpty()) {
            targetDir = new File(srcDir, packageName.replace('.', File.separatorChar));
            targetDir.mkdirs();
        }

        // Check if there are multiple public classes that need separate files
        Matcher pubClassMatcher = Pattern.compile("public\\s+(?:final\\s+|abstract\\s+)?class\\s+([a-zA-Z0-9_]+)").matcher(code);
        List<String> publicClassNames = new ArrayList<>();
        while (pubClassMatcher.find()) {
            publicClassNames.add(pubClassMatcher.group(1));
        }

        if (publicClassNames.size() > 1) {
            // Write primary class file as-is, or if multiple public classes, convert secondary to package-private to avoid compiler clash
            String sanitizedCode = code;
            for (int i = 1; i < publicClassNames.size(); i++) {
                String cName = publicClassNames.get(i);
                sanitizedCode = sanitizedCode.replaceAll("public\\s+class\\s+" + cName, "class " + cName);
            }
            File mainFile = new File(targetDir, primaryClassName + ".java");
            try (FileOutputStream fos = new FileOutputStream(mainFile)) {
                fos.write(sanitizedCode.getBytes(StandardCharsets.UTF_8));
            }
            files.add(mainFile);
        } else {
            File mainFile = new File(targetDir, primaryClassName + ".java");
            try (FileOutputStream fos = new FileOutputStream(mainFile)) {
                fos.write(code.getBytes(StandardCharsets.UTF_8));
            }
            files.add(mainFile);
        }

        return files;
    }

    private static String extractPackageName(String code) {
        Matcher m = Pattern.compile("package\\s+([a-zA-Z0-9_.]+)\\s*;").matcher(code);
        if (m.find()) {
            return m.group(1).trim();
        }
        return "";
    }

    private static String extractClassName(String code, String preferredFileName) {
        if (preferredFileName != null && preferredFileName.endsWith(".java")) {
            String name = preferredFileName.replace(".java", "").trim();
            if (!name.isEmpty() && !name.equals("CustomCode")) return name;
        }

        Matcher publicClass = Pattern.compile("public\\s+(?:final\\s+|abstract\\s+)?class\\s+([a-zA-Z0-9_]+)").matcher(code);
        if (publicClass.find()) {
            return publicClass.group(1).trim();
        }

        Matcher anyClass = Pattern.compile("(?:class|interface|enum)\\s+([a-zA-Z0-9_]+)").matcher(code);
        if (anyClass.find()) {
            return anyClass.group(1).trim();
        }

        return "MainClass";
    }

    private static List<DiagnosticError> parseEcjDiagnostics(String rawError, String defaultFileName) {
        List<DiagnosticError> list = new ArrayList<>();
        if (rawError == null || rawError.isEmpty()) return list;

        String[] problems = rawError.split("----------");
        for (String p : problems) {
            String clean = p.trim();
            if (clean.isEmpty() || clean.matches("\\d+\\s+problems?.*")) continue;

            Matcher lineMatch = Pattern.compile("ERROR in .*?\\(at line (\\d+)\\)").matcher(clean);
            int line = -1;
            if (lineMatch.find()) {
                try {
                    line = Integer.parseInt(lineMatch.group(1));
                } catch (Exception ignored) {}
            }

            String[] lines = clean.split("\n");
            StringBuilder snippet = new StringBuilder();
            String msg = "";
            for (int i = 0; i < lines.length; i++) {
                String l = lines[i].trim();
                if (l.contains("ERROR in")) continue;
                if (l.contains("^^^")) {
                    if (i > 0) snippet.append(lines[i - 1].trim());
                    if (i + 1 < lines.length) {
                        msg = lines[i + 1].trim();
                    }
                    break;
                }
            }

            if (msg.isEmpty() && lines.length > 1) {
                msg = lines[lines.length - 1].trim();
            }

            // Detect missing external library dependencies
            if (msg.contains("cannot be resolved to a type")) {
                Matcher typeMatcher = Pattern.compile("([a-zA-Z0-9_]+) cannot be resolved to a type").matcher(msg);
                if (typeMatcher.find()) {
                    String missingType = typeMatcher.group(1);
                    if (isCommonExternalLibrary(missingType)) {
                        msg = "Missing dependency: '" + missingType + "' is an external library not present in the standard Android classpath.";
                    }
                }
            }

            if (!msg.isEmpty() || line > 0) {
                list.add(new DiagnosticError(defaultFileName, line, -1, msg, snippet.toString()));
            }
        }
        return list;
    }

    private static boolean isCommonExternalLibrary(String typeName) {
        return typeName.contains("Retrofit") || typeName.contains("OkHttp") ||
                typeName.contains("Firebase") || typeName.contains("Gson") ||
                typeName.contains("Glide") || typeName.contains("Picasso") ||
                typeName.startsWith("NavController") || typeName.startsWith("Room");
    }

    private static String buildUserFriendlyErrorMessage(List<DiagnosticError> diagnostics, String raw) {
        if (diagnostics == null || diagnostics.isEmpty()) {
            return raw.isEmpty() ? "Compilation syntax or reference error occurred." : raw;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Java compilation failed with ").append(diagnostics.size()).append(" diagnostic error(s):\n\n");
        for (int i = 0; i < diagnostics.size(); i++) {
            DiagnosticError d = diagnostics.get(i);
            sb.append("[").append(i + 1).append("] ");
            if (d.line > 0) {
                sb.append("Line ").append(d.line).append(": ");
            }
            sb.append(d.message).append("\n");
            if (!d.snippet.isEmpty()) {
                sb.append("    > ").append(d.snippet).append("\n");
            }
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    private static byte[] createZipArchive(Map<String, String> smaliFiles, String baseName) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);

            for (Map.Entry<String, String> entry : smaliFiles.entrySet()) {
                ZipEntry ze = new ZipEntry("smali/" + entry.getKey());
                zos.putNextEntry(ze);
                zos.write(entry.getValue().getBytes(StandardCharsets.UTF_8));
                zos.closeEntry();
            }

            String readme = "# Morsalin XML Creator — Dalvik Smali Export\n" +
                    "# Primary Class : " + baseName + "\n" +
                    "# Total Classes : " + smaliFiles.size() + "\n" +
                    "# Toolchain     : ECJ + Android D8 + Baksmali\n" +
                    "# Specification : 100% Dalvik/ART Compliant\n";
            ZipEntry rme = new ZipEntry("README.txt");
            zos.putNextEntry(rme);
            zos.write(readme.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            zos.finish();
            zos.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private static void collectFilesRecursively(File dir, String suffix, List<File> list) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                collectFilesRecursively(f, suffix, list);
            } else if (f.getName().endsWith(suffix)) {
                list.add(f);
            }
        }
    }

    private static byte[] readFileBytes(File file) {
        if (file == null || !file.exists()) return new byte[0];
        try (FileInputStream fis = new FileInputStream(file);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) != -1) {
                baos.write(buf, 0, n);
            }
            return baos.toByteArray();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private static void deleteDirRecursively(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] children = dir.listFiles();
        if (children != null) {
            for (File c : children) {
                if (c.isDirectory()) deleteDirRecursively(c);
                else c.delete();
            }
        }
        dir.delete();
    }

    private static int countOccurrences(String str, String substr) {
        if (str == null || substr == null || str.isEmpty() || substr.isEmpty()) return 0;
        int count = 0;
        int idx = 0;
        while ((idx = str.indexOf(substr, idx)) != -1) {
            count++;
            idx += substr.length();
        }
        return count;
    }

    private static void reportProgress(ProgressListener listener, int percent, String stage) {
        if (listener != null) {
            listener.onProgress(percent, stage);
        }
    }
}
