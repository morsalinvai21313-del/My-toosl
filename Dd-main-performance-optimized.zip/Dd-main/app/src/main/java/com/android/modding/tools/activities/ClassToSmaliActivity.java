package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;
import com.android.modding.tools.helpers.ClassToSmaliProcessor;
import com.android.modding.tools.helpers.ClassToSmaliRecentManager;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.ConverterAnimationManager;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.generators.JavaToSmaliConverterEngine;
import com.android.modding.tools.generators.JavaToSmaliToolchain;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ClassToSmaliActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private ScrollView scrollMain;
    private Button btnSelectClassFile;
    private View cardSelectedFileInfo;

    // Code input & output
    private EditText etJavaCodeInput;
    private TextView tvSmaliPreviewCode;

    // File info TextViews
    private TextView tvFileStatusBadge;
    private TextView tvInfoFilename;
    private TextView tvInfoFilesize;
    private TextView tvInfoFormat;
    private TextView tvInfoVersion;
    private TextView tvInfoSuperclass;
    private TextView tvInfoAccessFlags;
    private TextView tvInfoMethodsFields;
    private TextView tvInfoInterfaces;

    private Button btnConvertToSmali;

    // Processing animation panel (Reuses existing app's ConversionAnimationView)
    private View layoutPkgAnimPanel;
    private TextView tvPkgAnimBadge;
    private TextView tvPkgAnimStatus;
    private ConversionAnimationView viewPkgConversionAnim;

    // Success card
    private View layoutSuccessCard;
    private TextView tvResultFilename;
    private TextView tvResultSize;
    private TextView tvResultStatus;
    private Button btnResultPreview;
    private Button btnResultCopy;
    private Button btnResultSaveSmali;
    private Button btnResultSaveZip;
    private Button btnResultSaveDex;
    private Button btnResultShare;

    // Error card
    private View layoutErrorCard;
    private TextView tvErrorTitle;
    private TextView tvErrorMessage;
    private TextView tvErrorDetails;
    private Button btnErrorTryAgain;
    private Button btnErrorViewDetails;

    // Recent exports
    private TextView tvRecentCount;
    private LinearLayout containerRecentExports;

    // State
    private byte[] selectedClassBytes = null;
    private String selectedFileName = "";
    private String activeSelectedSmaliClass = null;
    private ClassToSmaliProcessor.ClassMetadata selectedMetadata = null;
    private ClassToSmaliProcessor.ConversionResult latestConversionResult = null;

    // Activity Result Launchers
    private ActivityResultLauncher<String> getContentClassFileLauncher;
    private ActivityResultLauncher<String[]> openClassFileLauncher;
    private ActivityResultLauncher<String> createSmaliDocumentLauncher;
    private ActivityResultLauncher<String> createZipDocumentLauncher;
    private ActivityResultLauncher<String> createDexDocumentLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_to_smali);

        GlobalTouchParticleManager.attach(this);

        initLaunchers();
        initViews();
        refreshRecentExports();
    }

    private void initLaunchers() {
        getContentClassFileLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        handlePickedClassUri(uri);
                    }
                }
        );

        openClassFileLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null) {
                        handlePickedClassUri(uri);
                    }
                }
        );

        createSmaliDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("text/plain"),
                uri -> {
                    if (uri != null && latestConversionResult != null) {
                        writeSmaliToUri(uri, latestConversionResult.smaliContent);
                    }
                }
        );

        createZipDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("application/zip"),
                uri -> {
                    if (uri != null && latestConversionResult != null) {
                        writeZipToUri(uri, latestConversionResult.smaliFileName, latestConversionResult.smaliContent);
                    }
                }
        );

        createDexDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("application/octet-stream"),
                uri -> {
                    if (uri != null && latestConversionResult != null && latestConversionResult.dexBytes != null) {
                        writeDexToUri(uri, latestConversionResult.dexBytes);
                    }
                }
        );
    }

    private void initViews() {
        scrollMain = findViewById(R.id.scroll_cts_main);

        findViewById(R.id.btn_cts_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_cts_reset).setOnClickListener(v -> {
            MorsalinDialogHelper.showResetDialog(this, "Reset Tool",
                    "Clear the currently loaded class file and conversion output?", this::resetAllState);
        });

        etJavaCodeInput = findViewById(R.id.et_java_code_input);
        tvSmaliPreviewCode = findViewById(R.id.tv_smali_preview_code);

        Button btnPaste = findViewById(R.id.btn_cts_paste_code);
        if (btnPaste != null) {
            btnPaste.setOnClickListener(v -> pasteJavaCodeFromClipboard());
        }

        btnSelectClassFile = findViewById(R.id.btn_select_class_file);
        btnSelectClassFile.setOnClickListener(v -> launchClassFilePicker());

        Button btnLoadSample = findViewById(R.id.btn_load_sample_class);
        if (btnLoadSample != null) {
            btnLoadSample.setOnClickListener(v -> loadSampleClassFile());
        }

        if (etJavaCodeInput != null) {
            etJavaCodeInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    boolean hasCode = s != null && !s.toString().trim().isEmpty();
                    if (hasCode || selectedClassBytes != null) {
                        btnConvertToSmali.setEnabled(true);
                        btnConvertToSmali.setAlpha(1.0f);
                    } else {
                        btnConvertToSmali.setEnabled(false);
                        btnConvertToSmali.setAlpha(0.6f);
                    }
                }
            });
        }

        cardSelectedFileInfo = findViewById(R.id.card_selected_file_info);
        tvFileStatusBadge = findViewById(R.id.tv_file_status_badge);
        tvInfoFilename = findViewById(R.id.tv_info_filename);
        tvInfoFilesize = findViewById(R.id.tv_info_filesize);
        tvInfoFormat = findViewById(R.id.tv_info_format);
        tvInfoVersion = findViewById(R.id.tv_info_version);
        tvInfoSuperclass = findViewById(R.id.tv_info_superclass);
        tvInfoAccessFlags = findViewById(R.id.tv_info_access_flags);
        tvInfoMethodsFields = findViewById(R.id.tv_info_methods_fields);
        tvInfoInterfaces = findViewById(R.id.tv_info_interfaces);

        btnConvertToSmali = findViewById(R.id.btn_convert_to_smali);
        btnConvertToSmali.setEnabled(false);
        btnConvertToSmali.setAlpha(0.6f);
        btnConvertToSmali.setOnClickListener(v -> startConversionPipeline());

        // Processing Panel
        layoutPkgAnimPanel = findViewById(R.id.layout_pkg_anim_panel);
        tvPkgAnimBadge = findViewById(R.id.tv_pkg_anim_badge);
        tvPkgAnimStatus = findViewById(R.id.tv_pkg_anim_status);
        viewPkgConversionAnim = findViewById(R.id.view_pkg_conversion_anim);

        // Success Card
        layoutSuccessCard = findViewById(R.id.layout_cts_success_card);
        tvResultFilename = findViewById(R.id.tv_result_filename);
        tvResultSize = findViewById(R.id.tv_result_size);
        tvResultStatus = findViewById(R.id.tv_result_status);
        btnResultPreview = findViewById(R.id.btn_result_preview);
        btnResultCopy = findViewById(R.id.btn_result_copy);
        btnResultSaveSmali = findViewById(R.id.btn_result_save_smali);
        btnResultSaveZip = findViewById(R.id.btn_result_save_zip);
        btnResultSaveDex = findViewById(R.id.btn_result_save_dex);
        btnResultShare = findViewById(R.id.btn_result_share);

        tvResultFilename.setOnClickListener(v -> showClassSwitchDialog());
        btnResultPreview.setOnClickListener(v -> openSmaliPreview());
        btnResultCopy.setOnClickListener(v -> copySmaliResult());
        btnResultSaveSmali.setOnClickListener(v -> saveSmaliFile());
        btnResultSaveZip.setOnClickListener(v -> saveZipFile());
        if (btnResultSaveDex != null) {
            btnResultSaveDex.setOnClickListener(v -> saveDexFile());
        }
        btnResultShare.setOnClickListener(v -> shareSmaliResult());

        // Error Card
        layoutErrorCard = findViewById(R.id.layout_cts_error_card);
        tvErrorTitle = findViewById(R.id.tv_error_title);
        tvErrorMessage = findViewById(R.id.tv_error_message);
        tvErrorDetails = findViewById(R.id.tv_error_details);
        btnErrorTryAgain = findViewById(R.id.btn_error_try_again);
        btnErrorViewDetails = findViewById(R.id.btn_error_view_details);

        btnErrorTryAgain.setOnClickListener(v -> launchClassFilePicker());
        btnErrorViewDetails.setOnClickListener(v -> showErrorDetailsDialog());

        // Recent Exports
        tvRecentCount = findViewById(R.id.tv_recent_count);
        containerRecentExports = findViewById(R.id.container_recent_exports);
    }

    private void pasteJavaCodeFromClipboard() {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) {
                ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                if (item != null && item.getText() != null) {
                    String text = item.getText().toString();
                    if (!text.isEmpty()) {
                        if (etJavaCodeInput != null) {
                            etJavaCodeInput.setText(text);
                            selectedClassBytes = text.getBytes(StandardCharsets.UTF_8);
                            selectedFileName = "CustomCode.java";
                            try {
                                selectedMetadata = ClassToSmaliProcessor.parseMetadata(selectedClassBytes, selectedFileName);
                            } catch (Exception ignored) {}
                            displaySelectedFileInfo();
                        }
                        MorsalinToast.show(this, R.drawable.ic_content_copy, "Code Pasted", "Java code pasted from clipboard.");
                        return;
                    }
                }
            }
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Clipboard Empty", "No text found in clipboard.");
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Error", "Could not paste: " + e.getMessage());
        }
    }

    private void launchClassFilePicker() {
        try {
            getContentClassFileLauncher.launch("*/*");
        } catch (Exception e) {
            try {
                openClassFileLauncher.launch(new String[]{"*/*"});
            } catch (Exception ex) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select .class file"), 1001);
                } catch (Exception ex2) {
                    MorsalinToast.show(this, R.drawable.ic_download, "Error", "File picker not available: " + ex2.getMessage());
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            handlePickedClassUri(data.getData());
        }
    }

    private void loadSampleClassFile() {
        String[] templates = new String[]{
                "anim_helper.dex (MorsalinAnimationHelper)",
                "custom_dialog.dex (MorsalinCustomDialog)",
                "notif_helper.dex (MorsalinNotificationHelper)",
                "text_anim_view.dex (MorsalinAnimatedTextView)",
                "MainActivity.class (Sample Java Bytecode)"
        };

        new AlertDialog.Builder(this)
                .setTitle("Select Sample / DEX Template")
                .setItems(templates, (dialog, which) -> {
                    if (which == 4) {
                        byte[] bytes = ClassToSmaliProcessor.createSampleClassBytes();
                        selectedClassBytes = bytes;
                        selectedFileName = "MainActivity.class";
                        try {
                            selectedMetadata = ClassToSmaliProcessor.parseMetadata(bytes, selectedFileName);
                        } catch (Exception e) {
                            selectedMetadata = new ClassToSmaliProcessor.ClassMetadata();
                            selectedMetadata.simpleName = "MainActivity";
                            selectedMetadata.fileSizeBytes = bytes.length;
                        }
                        displaySelectedFileInfo();
                        MorsalinToast.show(this, R.drawable.ic_code_convert, "Sample Class Loaded",
                                "MainActivity.class (Sample) is loaded and ready to convert!");
                    } else {
                        String[] assetNames = {"anim_helper.dex", "custom_dialog.dex", "notif_helper.dex", "text_anim_view.dex"};
                        String assetName = assetNames[which];
                        loadDexFromAssets(assetName);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadDexFromAssets(String assetName) {
        try (InputStream is = getAssets().open("dex_templates/" + assetName);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) != -1) {
                baos.write(buf, 0, r);
            }
            byte[] bytes = baos.toByteArray();
            selectedClassBytes = bytes;
            selectedFileName = assetName;
            selectedMetadata = ClassToSmaliProcessor.parseMetadata(bytes, assetName);
            displaySelectedFileInfo();
            MorsalinToast.show(this, R.drawable.ic_code_convert, "DEX Loaded",
                    selectedMetadata.simpleName + " (" + selectedMetadata.getFormattedSize() + ") detected from " + assetName + "!");
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Error", "Could not load template DEX: " + e.getMessage());
        }
    }

    private void handlePickedClassUri(Uri uri) {
        try {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}

            String fileName = queryFileName(uri);
            if (fileName == null || fileName.isEmpty()) {
                fileName = "SelectedClass.class";
            }

            byte[] bytes = readUriBytes(uri);
            if (bytes == null || bytes.length == 0) {
                new AlertDialog.Builder(this)
                        .setTitle("Unable to Read File")
                        .setMessage("Could not read data from the selected file. Would you like to load a sample class (MainActivity.class) to test the converter?")
                        .setPositiveButton("Load Sample Class", (d, w) -> loadSampleClassFile())
                        .setNegativeButton("Choose Other File", (d, w) -> launchClassFilePicker())
                        .show();
                return;
            }

            selectedClassBytes = bytes;
            selectedFileName = fileName;

            // Parse metadata safely (handles Java Class .class, Dalvik .dex, or Java text)
            try {
                selectedMetadata = ClassToSmaliProcessor.parseMetadata(bytes, fileName);
            } catch (Exception metaEx) {
                selectedMetadata = new ClassToSmaliProcessor.ClassMetadata();
                selectedMetadata.fileSizeBytes = bytes.length;
                selectedMetadata.simpleName = fileName.replace(".class", "").replace(".dex", "").replace(".java", "");
                selectedMetadata.className = selectedMetadata.simpleName;
                selectedMetadata.superClassName = "Ljava/lang/Object;";
            }

            displaySelectedFileInfo();

            if (fileName.endsWith(".java") || fileName.endsWith(".txt")) {
                try {
                    String javaSource = new String(bytes, StandardCharsets.UTF_8);
                    if (etJavaCodeInput != null) {
                        etJavaCodeInput.setText(javaSource);
                    }
                } catch (Exception ignored) {}
            }

            MorsalinToast.show(this, R.drawable.ic_code_convert, "File Loaded",
                    fileName + " (" + selectedMetadata.getFormattedSize() + ") is ready to convert!");

        } catch (Exception e) {
            new AlertDialog.Builder(this)
                    .setTitle("Cannot Open File")
                    .setMessage("Error loading file: " + e.getMessage() + "\n\nWould you like to load the sample class file instead?")
                    .setPositiveButton("Load Sample", (d, w) -> loadSampleClassFile())
                    .setNegativeButton("Try Again", (d, w) -> launchClassFilePicker())
                    .show();
        }
    }

    private void showInvalidFileDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Invalid File")
                .setMessage(message)
                .setPositiveButton("Select Again", (dialog, which) -> launchClassFilePicker())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void displaySelectedFileInfo() {
        if (selectedMetadata == null) return;

        cardSelectedFileInfo.setVisibility(View.VISIBLE);
        cardSelectedFileInfo.setAlpha(0f);
        cardSelectedFileInfo.animate().alpha(1f).setDuration(250).start();

        tvFileStatusBadge.setText("Status: Ready");
        tvInfoFilename.setText(selectedFileName);
        tvInfoFilesize.setText(selectedMetadata.getFormattedSize());
        tvInfoFormat.setText("Java Class (.class)");
        tvInfoVersion.setText(selectedMetadata.javaVersion);
        tvInfoSuperclass.setText(!selectedMetadata.superClassName.isEmpty() ? selectedMetadata.superClassName : "None");
        tvInfoAccessFlags.setText(!selectedMetadata.accessFlagsString.isEmpty() ? selectedMetadata.accessFlagsString : "package-private");
        tvInfoMethodsFields.setText(selectedMetadata.methodsCount + " Methods • " + selectedMetadata.fieldsCount + " Fields");

        if (selectedMetadata.interfaces.isEmpty()) {
            tvInfoInterfaces.setText("None");
        } else {
            tvInfoInterfaces.setText(String.join(", ", selectedMetadata.interfaces));
        }

        btnConvertToSmali.setEnabled(true);
        btnConvertToSmali.setAlpha(1.0f);

        // Hide success & error cards from previous runs
        layoutSuccessCard.setVisibility(View.GONE);
        layoutErrorCard.setVisibility(View.GONE);

        scrollMain.post(() -> scrollMain.smoothScrollTo(0, cardSelectedFileInfo.getTop() - 20));
    }

    private void startConversionPipeline() {
        String enteredJava = etJavaCodeInput != null ? etJavaCodeInput.getText().toString().trim() : "";
        if (!enteredJava.isEmpty()) {
            selectedClassBytes = enteredJava.getBytes(StandardCharsets.UTF_8);
            if (selectedFileName == null || selectedFileName.isEmpty() || !selectedFileName.endsWith(".java")) {
                selectedFileName = "CustomCode.java";
            }
        }

        if (selectedClassBytes == null) {
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Select File or Paste Code", "Please type/paste Java code or choose a file from storage.");
            return;
        }

        btnConvertToSmali.setEnabled(false);
        btnConvertToSmali.setAlpha(0.5f);
        btnSelectClassFile.setEnabled(false);

        layoutSuccessCard.setVisibility(View.GONE);
        layoutErrorCard.setVisibility(View.GONE);

        // Display Full-Screen High-Tech Compilation Matrix front and center
        com.android.modding.tools.dialogmaker.FullScreenGenerationOverlayHelper.showAndExecuteClassToSmali(
                ClassToSmaliActivity.this,
                selectedFileName,
                progressListener -> {
                    ClassToSmaliProcessor.ConversionResult result;
                    try {
                        String asText = new String(selectedClassBytes, StandardCharsets.UTF_8);
                        boolean isSource = asText.contains("class ") || asText.contains("interface ") ||
                                asText.contains("package ") || asText.contains("import ") ||
                                asText.contains("public ") || asText.contains("void ") ||
                                selectedFileName.endsWith(".java") || selectedFileName.endsWith(".txt");

                        if (isSource) {
                            JavaToSmaliToolchain.CompilationResult comp = JavaToSmaliToolchain.compile(
                                    ClassToSmaliActivity.this, asText, selectedFileName, progressListener);

                            if (comp.success) {
                                ClassToSmaliProcessor.ClassMetadata meta = new ClassToSmaliProcessor.ClassMetadata();
                                meta.className = comp.packageName.isEmpty() ? comp.primaryClassName : comp.packageName.replace('.', '/') + "/" + comp.primaryClassName;
                                meta.simpleName = comp.primaryClassName;
                                meta.packageName = comp.packageName;
                                meta.fieldsCount = comp.fieldsCount;
                                meta.methodsCount = comp.methodsCount;
                                meta.fileSizeBytes = selectedClassBytes.length;
                                meta.sourceFile = comp.primaryClassName + ".java";

                                result = ClassToSmaliProcessor.ConversionResult.success(comp.primarySmaliContent, meta);
                                result.dexBytes = comp.dexBytes;
                                result.allSmaliFiles = comp.allSmaliFiles;
                                result.zipBytes = comp.zipBytes;
                                result.roundTripValid = comp.roundTripValid;
                            } else {
                                result = ClassToSmaliProcessor.ConversionResult.failure(
                                        comp.errorMessage != null && !comp.errorMessage.isEmpty() ? comp.errorMessage : "Compilation Failed",
                                        comp.errorDetails != null ? comp.errorDetails : "Syntax or type resolution errors.",
                                        null
                                );
                            }
                        } else {
                            // Binary .class or .dex file
                            JavaToSmaliToolchain.CompilationResult comp = JavaToSmaliToolchain.convertBinary(
                                    ClassToSmaliActivity.this, selectedClassBytes, selectedFileName, progressListener);
                            if (comp.success) {
                                ClassToSmaliProcessor.ClassMetadata meta = new ClassToSmaliProcessor.ClassMetadata();
                                meta.className = comp.primaryClassName;
                                meta.simpleName = comp.primaryClassName;
                                meta.fieldsCount = comp.fieldsCount;
                                meta.methodsCount = comp.methodsCount;
                                meta.fileSizeBytes = selectedClassBytes.length;

                                result = ClassToSmaliProcessor.ConversionResult.success(comp.primarySmaliContent, meta);
                                result.dexBytes = comp.dexBytes;
                                result.allSmaliFiles = comp.allSmaliFiles;
                                result.zipBytes = comp.zipBytes;
                                result.roundTripValid = comp.roundTripValid;
                            } else {
                                result = ClassToSmaliProcessor.convertClassToSmali(selectedClassBytes, selectedFileName);
                            }
                        }
                    } catch (Exception e) {
                        result = ClassToSmaliProcessor.ConversionResult.failure(
                                "Conversion Failed", "Processing exception: " + e.getMessage(), null);
                    }
                    return result;
                },
                result -> {
                    onConversionFinished(result);
                }
        );
    }

    private void onConversionFinished(ClassToSmaliProcessor.ConversionResult result) {
        latestConversionResult = result;

        btnConvertToSmali.setEnabled(true);
        btnConvertToSmali.setAlpha(1.0f);
        btnSelectClassFile.setEnabled(true);

        layoutPkgAnimPanel.setVisibility(View.GONE);

        if (result.success) {
            layoutSuccessCard.setVisibility(View.VISIBLE);
            layoutSuccessCard.setAlpha(0f);
            layoutSuccessCard.setScaleX(0.96f);
            layoutSuccessCard.setScaleY(0.96f);
            layoutSuccessCard.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(280)
                    .start();

            activeSelectedSmaliClass = result.smaliFileName;

            if (result.allSmaliFiles != null && result.allSmaliFiles.size() > 1) {
                tvResultFilename.setText(result.smaliFileName + " (" + result.allSmaliFiles.size() + " classes) ▼");
            } else {
                tvResultFilename.setText(result.smaliFileName);
            }

            tvResultSize.setText("Size: " + formatSize(result.smaliContent.length()));
            if (result.roundTripValid) {
                tvResultStatus.setText("✓ 100% READY (DEX & Smali Verified)");
            } else {
                tvResultStatus.setText("✓ 100% READY");
            }

            if (tvSmaliPreviewCode != null) {
                tvSmaliPreviewCode.setText(result.smaliContent);
            }

            if (btnResultSaveZip != null) {
                btnResultSaveZip.setVisibility(View.VISIBLE);
            }
            if (btnResultSaveDex != null) {
                btnResultSaveDex.setVisibility(result.dexBytes != null ? View.VISIBLE : View.GONE);
            }

            // Save to recent exports
            ClassToSmaliRecentManager.addRecent(
                    this,
                    result.smaliFileName,
                    formatSize(result.smaliContent.length()),
                    result.smaliContent,
                    result.metadata != null ? result.metadata.className : "UnknownClass"
            );
            refreshRecentExports();

            MorsalinToast.show(this, R.drawable.ic_code_convert, "Smali Generated!",
                    result.smaliFileName + " generated successfully!");

            scrollMain.post(() -> scrollMain.smoothScrollTo(0, layoutSuccessCard.getTop() - 20));

        } else {
            layoutErrorCard.setVisibility(View.VISIBLE);
            layoutErrorCard.setAlpha(0f);
            layoutErrorCard.animate().alpha(1f).setDuration(250).start();

            tvErrorTitle.setText(result.errorMessage != null ? result.errorMessage : "Compilation Failed");
            tvErrorMessage.setText("Java source could not be compiled. Please check syntax & references below:");
            if (result.errorDetails != null && !result.errorDetails.isEmpty()) {
                tvErrorDetails.setText(result.errorDetails);
                tvErrorDetails.setVisibility(View.VISIBLE);
                tvErrorDetails.setTextIsSelectable(true);
            } else {
                tvErrorDetails.setVisibility(View.GONE);
            }

            scrollMain.post(() -> scrollMain.smoothScrollTo(0, layoutErrorCard.getTop() - 20));
        }
    }

    private void showClassSwitchDialog() {
        if (latestConversionResult == null || latestConversionResult.allSmaliFiles == null || latestConversionResult.allSmaliFiles.size() <= 1) {
            return;
        }

        List<String> keys = new ArrayList<>(latestConversionResult.allSmaliFiles.keySet());
        String[] items = new String[keys.size()];
        for (int i = 0; i < keys.size(); i++) {
            String k = keys.get(i);
            int len = latestConversionResult.allSmaliFiles.get(k).length();
            items[i] = k + " (" + formatSize(len) + ")";
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Generated Class (" + keys.size() + " total)")
                .setItems(items, (dialog, which) -> {
                    String selectedKey = keys.get(which);
                    String content = latestConversionResult.allSmaliFiles.get(selectedKey);
                    String simpleFileName = selectedKey.substring(selectedKey.lastIndexOf('/') + 1);

                    activeSelectedSmaliClass = simpleFileName;
                    tvResultFilename.setText(simpleFileName + " (" + (which + 1) + " of " + keys.size() + ") ▼");
                    tvResultSize.setText("Size: " + formatSize(content.length()));
                    if (tvSmaliPreviewCode != null) {
                        tvSmaliPreviewCode.setText(content);
                    }
                    MorsalinToast.show(this, R.drawable.ic_code_convert, "Switched Class", "Viewing " + simpleFileName);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openSmaliPreview() {
        if (latestConversionResult == null) {
            MorsalinToast.show(this, R.drawable.ic_code_convert, "No Output", "Please convert a class file first.");
            return;
        }

        String contentToPreview = tvSmaliPreviewCode != null ? tvSmaliPreviewCode.getText().toString() : latestConversionResult.smaliContent;
        String fileNameToPreview = activeSelectedSmaliClass != null ? activeSelectedSmaliClass : latestConversionResult.smaliFileName;

        if (contentToPreview.isEmpty()) {
            MorsalinToast.show(this, R.drawable.ic_code_convert, "No Output", "Please convert a class file first.");
            return;
        }

        Intent intent = new Intent(this, SmaliPreviewActivity.class);
        intent.putExtra(SmaliPreviewActivity.EXTRA_SMALI_CONTENT, contentToPreview);
        intent.putExtra(SmaliPreviewActivity.EXTRA_SMALI_FILE_NAME, fileNameToPreview);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    private void copySmaliResult() {
        if (latestConversionResult == null) return;
        String contentToCopy = tvSmaliPreviewCode != null ? tvSmaliPreviewCode.getText().toString() : latestConversionResult.smaliContent;
        String nameToCopy = activeSelectedSmaliClass != null ? activeSelectedSmaliClass : latestConversionResult.smaliFileName;

        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("smali", contentToCopy));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied to Clipboard",
                    nameToCopy + " copied successfully!");
        }
    }

    private void saveSmaliFile() {
        if (latestConversionResult == null) return;
        String contentToSave = tvSmaliPreviewCode != null ? tvSmaliPreviewCode.getText().toString() : latestConversionResult.smaliContent;
        String nameToSave = activeSelectedSmaliClass != null ? activeSelectedSmaliClass : latestConversionResult.smaliFileName;

        byte[] bytes = contentToSave.getBytes(StandardCharsets.UTF_8);
        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/ClassToSmali/Exports",
                nameToSave, "text/plain", bytes);

        try {
            createSmaliDocumentLauncher.launch(nameToSave);
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "Saved to Downloads" : "Export Error", res.message);
        }
    }

    private void saveZipFile() {
        if (latestConversionResult == null) return;

        byte[] zipBytes = latestConversionResult.zipBytes;
        if (zipBytes == null || zipBytes.length == 0) {
            zipBytes = createZipBytes(latestConversionResult.smaliFileName, latestConversionResult.smaliContent);
        }
        if (zipBytes == null) {
            MorsalinToast.show(this, R.drawable.ic_download, "Error", "Failed to create ZIP package.");
            return;
        }

        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/ClassToSmali/Exports",
                latestConversionResult.zipFileName, "application/zip", zipBytes);

        try {
            createZipDocumentLauncher.launch(latestConversionResult.zipFileName);
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "ZIP Saved to Downloads" : "Export Error", res.message);
        }
    }

    private void saveDexFile() {
        if (latestConversionResult == null || latestConversionResult.dexBytes == null) {
            MorsalinToast.show(this, R.drawable.ic_download, "No DEX Available", "Please compile Java code first to generate classes.dex.");
            return;
        }

        String dexFileName = "classes.dex";

        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/ClassToSmali/Exports",
                dexFileName, "application/octet-stream", latestConversionResult.dexBytes);

        try {
            createDexDocumentLauncher.launch(dexFileName);
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "DEX Saved to Downloads" : "Export Error", res.message);
        }
    }

    private void writeDexToUri(Uri uri, byte[] bytes) {
        if (bytes == null || bytes.length == 0) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os != null) {
                os.write(bytes);
                os.flush();
                MorsalinToast.show(this, R.drawable.ic_download, "DEX Saved", "classes.dex saved successfully!");
            }
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Save Failed", "Could not save classes.dex: " + e.getMessage());
        }
    }

    private byte[] createZipBytes(String smaliFileName, String smaliContent) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);

            String folderPrefix = smaliFileName.replace(".smali", "") + "_Smali/";

            // Entry 1: Smali file inside folder
            ZipEntry smaliEntry = new ZipEntry(folderPrefix + smaliFileName);
            zos.putNextEntry(smaliEntry);
            zos.write(smaliContent.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            // Entry 2: Info README.txt
            String readme = "# Morsalin XML Creator — Class → Smali Exporter\n" +
                    "# Generated : " + smaliFileName + "\n" +
                    "# Tool      : ⚡ Class → Smali Exporter\n" +
                    "# Runtime   : MT Manager / APKTool M / Baksmali Compatible\n";
            ZipEntry readmeEntry = new ZipEntry(folderPrefix + "README.txt");
            zos.putNextEntry(readmeEntry);
            zos.write(readme.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();

            zos.finish();
            zos.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean verifyZipContent(byte[] zipBytes, String expectedFileName) {
        if (zipBytes == null || zipBytes.length == 0) return false;
        try (ZipInputStream zis = new ZipInputStream(new java.io.ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.getName().endsWith(expectedFileName)) {
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void writeSmaliToUri(Uri uri, String content) {
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os != null) {
                os.write(content.getBytes(StandardCharsets.UTF_8));
                os.flush();
                MorsalinToast.show(this, R.drawable.ic_download, "File Saved", "Smali file saved successfully!");
            }
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Save Failed", "Could not save file: " + e.getMessage());
        }
    }

    private void writeZipToUri(Uri uri, String smaliFileName, String smaliContent) {
        byte[] zipBytes = createZipBytes(smaliFileName, smaliContent);
        if (zipBytes == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os != null) {
                os.write(zipBytes);
                os.flush();
                MorsalinToast.show(this, R.drawable.ic_download, "ZIP Saved", "Smali ZIP saved successfully!");
            }
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Save Failed", "Could not save ZIP: " + e.getMessage());
        }
    }

    private void shareSmaliResult() {
        if (latestConversionResult == null) return;
        try {
            // Write temporary file in cacheDir
            File cacheFile = new File(getCacheDir(), latestConversionResult.smaliFileName);
            try (FileOutputStream fos = new FileOutputStream(cacheFile)) {
                fos.write(latestConversionResult.smaliContent.getBytes(StandardCharsets.UTF_8));
            }

            Uri fileUri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", cacheFile);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, latestConversionResult.smaliFileName);
            shareIntent.putExtra(Intent.EXTRA_TEXT, latestConversionResult.smaliContent);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Share Smali via"));

        } catch (Exception e) {
            // Fallback to text sharing
            Intent textIntent = new Intent(Intent.ACTION_SEND);
            textIntent.setType("text/plain");
            textIntent.putExtra(Intent.EXTRA_TEXT, latestConversionResult.smaliContent);
            startActivity(Intent.createChooser(textIntent, "Share Smali via"));
        }
    }

    private void showErrorDetailsDialog() {
        if (latestConversionResult == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Conversion Details")
                .setMessage("Error:\n" + latestConversionResult.errorMessage +
                        "\n\nDetails:\n" + latestConversionResult.errorDetails +
                        (latestConversionResult.missingDependency != null ? "\n\nMissing:\n" + latestConversionResult.missingDependency : ""))
                .setPositiveButton("Close", null)
                .show();
    }

    private void refreshRecentExports() {
        if (containerRecentExports == null) return;
        containerRecentExports.removeAllViews();

        List<ClassToSmaliRecentManager.RecentSmaliItem> list = ClassToSmaliRecentManager.getRecents(this);
        tvRecentCount.setText(list.size() + (list.size() == 1 ? " file" : " files"));

        if (list.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setText("No recent Smali exports yet. Converted files will appear here.");
            emptyTv.setTextColor(Color.parseColor("#78909C"));
            emptyTv.setTextSize(12f);
            emptyTv.setPadding(0, 10, 0, 10);
            containerRecentExports.addView(emptyTv);
            return;
        }

        for (ClassToSmaliRecentManager.RecentSmaliItem item : list) {
            View itemView = buildRecentItemView(item);
            containerRecentExports.addView(itemView);
        }
    }

    private View buildRecentItemView(ClassToSmaliRecentManager.RecentSmaliItem item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.morsalin_button_bg);
        card.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dpToPx(8));
        card.setLayoutParams(lp);

        // Header Row: Title & Size
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView tvName = new TextView(this);
        tvName.setText(item.fileName);
        tvName.setTextColor(Color.WHITE);
        tvName.setTextSize(13.5f);
        tvName.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvName.setLayoutParams(nameLp);
        row1.addView(tvName);

        TextView tvSize = new TextView(this);
        tvSize.setText(item.formattedSize);
        tvSize.setTextColor(Color.parseColor("#00E5FF"));
        tvSize.setTextSize(11.5f);
        tvSize.setTypeface(null, android.graphics.Typeface.BOLD);
        row1.addView(tvSize);

        card.addView(row1);

        // Subtitle: Timestamp
        TextView tvTime = new TextView(this);
        tvTime.setText(item.timestamp);
        tvTime.setTextColor(Color.parseColor("#90A4AE"));
        tvTime.setTextSize(11f);
        tvTime.setPadding(0, dpToPx(2), 0, dpToPx(6));
        card.addView(tvTime);

        // Buttons Row: OPEN, SHARE, DELETE
        LinearLayout rowBtns = new LinearLayout(this);
        rowBtns.setOrientation(LinearLayout.HORIZONTAL);
        rowBtns.setGravity(android.view.Gravity.CENTER_VERTICAL);

        Button btnOpen = createSmallButton("OPEN", Color.parseColor("#00E5FF"), () -> {
            Intent intent = new Intent(this, SmaliPreviewActivity.class);
            intent.putExtra(SmaliPreviewActivity.EXTRA_SMALI_CONTENT, item.smaliContent);
            intent.putExtra(SmaliPreviewActivity.EXTRA_SMALI_FILE_NAME, item.fileName);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });

        Button btnShare = createSmallButton("SHARE", Color.WHITE, () -> {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, item.fileName);
            sendIntent.putExtra(Intent.EXTRA_TEXT, item.smaliContent);
            startActivity(Intent.createChooser(sendIntent, "Share Smali via"));
        });

        Button btnDelete = createSmallButton("DELETE", Color.parseColor("#FF5252"), () -> {
            ClassToSmaliRecentManager.deleteRecent(this, item.id);
            refreshRecentExports();
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Deleted", item.fileName + " removed.");
        });

        rowBtns.addView(btnOpen);
        rowBtns.addView(btnShare);
        rowBtns.addView(btnDelete);

        card.addView(rowBtns);
        return card;
    }

    private Button createSmallButton(String text, int textColor, Runnable onClick) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(11f);
        btn.setTypeface(null, android.graphics.Typeface.BOLD);
        btn.setBackgroundResource(R.drawable.dialog_step_button_bg);
        btn.setPadding(dpToPx(10), dpToPx(2), dpToPx(10), dpToPx(2));
        btn.setMinHeight(dpToPx(30));
        btn.setMinWidth(0);
        btn.setAllCaps(false);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(30));
        lp.setMargins(0, 0, dpToPx(8), 0);
        btn.setLayoutParams(lp);

        btn.setOnClickListener(v -> onClick.run());
        return btn;
    }

    private void resetAllState() {
        selectedClassBytes = null;
        selectedFileName = "";
        selectedMetadata = null;
        latestConversionResult = null;

        cardSelectedFileInfo.setVisibility(View.GONE);
        layoutSuccessCard.setVisibility(View.GONE);
        layoutErrorCard.setVisibility(View.GONE);
        layoutPkgAnimPanel.setVisibility(View.GONE);

        btnConvertToSmali.setEnabled(false);
        btnConvertToSmali.setAlpha(0.6f);

        // Clean up temp files
        cleanUpTempFiles();

        MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Reset", "Tool state cleared.");
    }

    private void cleanUpTempFiles() {
        try {
            File[] files = getCacheDir().listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.getName().endsWith(".smali") || f.getName().endsWith(".class") || f.getName().endsWith(".dex")) {
                        f.delete();
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cleanUpTempFiles();
        executor.shutdown();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private byte[] readUriBytes(Uri uri) throws Exception {
        // Stage 1: Standard ContentResolver InputStream
        try (InputStream is = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            if (is != null) {
                byte[] buf = new byte[8192];
                int read;
                while ((read = is.read(buf)) != -1) {
                    baos.write(buf, 0, read);
                }
                byte[] data = baos.toByteArray();
                if (data.length > 0) return data;
            }
        } catch (Exception ignored) {}

        // Stage 2: ParcelFileDescriptor
        try (android.os.ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r")) {
            if (pfd != null) {
                try (FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int read;
                    while ((read = fis.read(buf)) != -1) {
                        baos.write(buf, 0, read);
                    }
                    byte[] data = baos.toByteArray();
                    if (data.length > 0) return data;
                }
            }
        } catch (Exception ignored) {}

        // Stage 3: Direct File path
        if (uri.getPath() != null) {
            File f = new File(uri.getPath());
            if (f.exists() && f.canRead()) {
                try (FileInputStream fis = new FileInputStream(f);
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int read;
                    while ((read = fis.read(buf)) != -1) {
                        baos.write(buf, 0, read);
                    }
                    byte[] data = baos.toByteArray();
                    if (data.length > 0) return data;
                }
            }
        }

        return null;
    }

    private String queryFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        result = cursor.getString(idx);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            String path = uri.getPath();
            if (path != null) {
                int cut = path.lastIndexOf('/');
                if (cut != -1) {
                    result = path.substring(cut + 1);
                }
            }
        }
        return result;
    }

    private String formatSize(long bytes) {
        if (bytes <= 0) return "0 B";
        if (bytes < 1024) return bytes + " B";
        return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
