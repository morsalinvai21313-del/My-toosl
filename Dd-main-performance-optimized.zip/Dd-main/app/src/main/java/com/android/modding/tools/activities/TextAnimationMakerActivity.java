package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.ColorPickerDialog;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.HistoryManager;
import com.android.modding.tools.helpers.LiveTextAnimationView;
import com.android.modding.tools.helpers.MorsalinDexGenerator;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.PackageGenerationRunner;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.XmlProject;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TextAnimationMakerActivity extends AppCompatActivity {

    private static final String[] EFFECTS = {
            "Typing", "Letter-by-letter", "Fade", "Wave",
            "Bounce", "Shake", "Flicker", "Glow",
            "Neon", "RGB", "Gradient", "Zoom",
            "Rotate", "Slide", "Character Reveal", "Word Reveal"
    };

    private static final int[] STYLE_VALUES = {
            Typeface.BOLD, Typeface.ITALIC, Typeface.BOLD_ITALIC, Typeface.NORMAL
    };
    private static final String[] STYLE_LABELS = {
            "STYLE: BOLD", "STYLE: ITALIC", "STYLE: BOLD+ITALIC", "STYLE: NORMAL"
    };

    private String customText = "MORSALIN XML CREATOR";
    private String currentEffect = "Typing";
    private int textSizeSp = 22;
    private int cycleDurationMs = 1600;
    private int strokeWidthPx = 0;
    private int glowRadiusPx = 12;
    private String primaryHex = "#00E5FF";
    private String secondaryHex = "#FF007F";
    private String strokeHex = "#FFFFFF";
    private String glowHex = "#00FF88";
    private boolean useGradient = true;
    private int styleIdx = 0;

    private LiveTextAnimationView liveTextView;
    private EditText etCustomText;
    private SeekBar seekSize, seekSpeed, seekStroke, seekGlow;
    private TextView tvSizeVal, tvSpeedVal, tvStrokeVal, tvGlowVal;
    private Button btnStyleCycle, btnToggleGradient;
    private Button tabJava, tabXml, tabColors, tabGuide;
    private TextView tvGeneratedCode;
    private final List<Button> effectButtons = new ArrayList<>();

    private int activeCodeTab = 0;
    private GeneratedPackageExporter.GeneratedPackage latestPackage;
    private HistoryManager historyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_animation_maker);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);
        initViews();

        String jsonConfig = getIntent().getStringExtra("EXTRA_JSON_CONFIG");
        if (jsonConfig != null && !jsonConfig.isEmpty()) {
            loadFromJsonConfig(jsonConfig);
        }

        updateEffectButtonsUI();
        refreshPreviewAndPackage();
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            MorsalinDialogHelper.showResetDialog(this, "Reset Text Animation",
                    "Reset text effect, colors, and styling to default?", () -> {
                        customText = "MORSALIN XML CREATOR";
                        currentEffect = "Typing";
                        textSizeSp = 22;
                        cycleDurationMs = 1600;
                        strokeWidthPx = 0;
                        glowRadiusPx = 12;
                        primaryHex = "#00E5FF";
                        secondaryHex = "#FF007F";
                        strokeHex = "#FFFFFF";
                        glowHex = "#00FF88";
                        useGradient = true;
                        styleIdx = 0;
                        etCustomText.setText(customText);
                        seekSize.setProgress(10);
                        seekSpeed.setProgress(1200);
                        seekStroke.setProgress(0);
                        seekGlow.setProgress(12);
                        updateEffectButtonsUI();
                        refreshPreviewAndPackage();
                    });
        });

        liveTextView = findViewById(R.id.view_live_text_anim);
        etCustomText = findViewById(R.id.et_custom_text);
        btnStyleCycle = findViewById(R.id.btn_text_style_cycle);
        btnToggleGradient = findViewById(R.id.btn_tx_toggle_gradient);

        findViewById(R.id.btn_text_replay).setOnClickListener(v -> liveTextView.startAnimationLoop());
        findViewById(R.id.btn_text_pause).setOnClickListener(v -> liveTextView.pauseOrResume());

        btnStyleCycle.setOnClickListener(v -> {
            styleIdx = (styleIdx + 1) % STYLE_VALUES.length;
            btnStyleCycle.setText(STYLE_LABELS[styleIdx]);
            refreshPreviewAndPackage();
        });

        etCustomText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                customText = s.toString();
                refreshPreviewAndPackage();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        int[] btnIds = {
                R.id.btn_tx_typing, R.id.btn_tx_letter, R.id.btn_tx_fade, R.id.btn_tx_wave,
                R.id.btn_tx_bounce, R.id.btn_tx_shake, R.id.btn_tx_flicker, R.id.btn_tx_glow,
                R.id.btn_tx_neon, R.id.btn_tx_rgb, R.id.btn_tx_gradient, R.id.btn_tx_zoom,
                R.id.btn_tx_rotate, R.id.btn_tx_slide, R.id.btn_tx_char_reveal, R.id.btn_tx_word_reveal
        };

        for (int i = 0; i < btnIds.length; i++) {
            final String eff = EFFECTS[i];
            Button b = findViewById(btnIds[i]);
            effectButtons.add(b);
            b.setOnClickListener(v -> {
                currentEffect = eff;
                updateEffectButtonsUI();
                refreshPreviewAndPackage();
                liveTextView.startAnimationLoop();
            });
        }

        seekSize = findViewById(R.id.seek_tx_size);
        seekSpeed = findViewById(R.id.seek_tx_speed);
        seekStroke = findViewById(R.id.seek_tx_stroke);
        seekGlow = findViewById(R.id.seek_tx_glow);

        tvSizeVal = findViewById(R.id.tv_tx_size_val);
        tvSpeedVal = findViewById(R.id.tv_tx_speed_val);
        tvStrokeVal = findViewById(R.id.tv_tx_stroke_val);
        tvGlowVal = findViewById(R.id.tv_tx_glow_val);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textSizeSp = 12 + seekSize.getProgress();
                cycleDurationMs = 400 + seekSpeed.getProgress();
                strokeWidthPx = seekStroke.getProgress();
                glowRadiusPx = seekGlow.getProgress();

                tvSizeVal.setText(textSizeSp + " sp");
                tvSpeedVal.setText(cycleDurationMs + " ms");
                tvStrokeVal.setText(strokeWidthPx + " px");
                tvGlowVal.setText(glowRadiusPx + " px");
                if (fromUser) {
                    refreshPreviewAndPackage();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seekSize.setOnSeekBarChangeListener(listener);
        seekSpeed.setOnSeekBarChangeListener(listener);
        seekStroke.setOnSeekBarChangeListener(listener);
        seekGlow.setOnSeekBarChangeListener(listener);

        findViewById(R.id.btn_tx_primary_color).setOnClickListener(v -> {
            new ColorPickerDialog(this, primaryHex, hex -> {
                primaryHex = hex;
                refreshPreviewAndPackage();
            }, hex -> {
                primaryHex = hex;
                refreshPreviewAndPackage();
            }).show();
        });

        findViewById(R.id.btn_tx_secondary_color).setOnClickListener(v -> {
            new ColorPickerDialog(this, secondaryHex, hex -> {
                secondaryHex = hex;
                refreshPreviewAndPackage();
            }, hex -> {
                secondaryHex = hex;
                refreshPreviewAndPackage();
            }).show();
        });

        findViewById(R.id.btn_tx_stroke_color).setOnClickListener(v -> {
            new ColorPickerDialog(this, strokeHex, hex -> {
                strokeHex = hex;
                if (strokeWidthPx == 0) {
                    strokeWidthPx = 2;
                    seekStroke.setProgress(2);
                }
                refreshPreviewAndPackage();
            }, hex -> {
                strokeHex = hex;
                refreshPreviewAndPackage();
            }).show();
        });

        findViewById(R.id.btn_tx_glow_color).setOnClickListener(v -> {
            new ColorPickerDialog(this, glowHex, hex -> {
                glowHex = hex;
                refreshPreviewAndPackage();
            }, hex -> {
                glowHex = hex;
                refreshPreviewAndPackage();
            }).show();
        });

        btnToggleGradient.setOnClickListener(v -> {
            useGradient = !useGradient;
            btnToggleGradient.setText(useGradient ? "GRADIENT SHADER: ON" : "GRADIENT SHADER: OFF");
            refreshPreviewAndPackage();
        });

        android.widget.ScrollView scrollMain = findViewById(R.id.scroll_text_anim_maker);
        View animPanel = findViewById(R.id.layout_pkg_anim_panel);
        ConversionAnimationView convAnimView = findViewById(R.id.view_pkg_conversion_anim);
        TextView tvAnimBadge = findViewById(R.id.tv_pkg_anim_badge);
        TextView tvAnimStatus = findViewById(R.id.tv_pkg_anim_status);
        View readyPanel = findViewById(R.id.layout_pkg_ready_panel);
        Button btnGenerate = findViewById(R.id.btn_generate_package);
        Button btnDownloadDex = findViewById(R.id.btn_download_dex);
        Button btnDownloadZip = findViewById(R.id.btn_download_xml);

        if (btnGenerate != null) {
            btnGenerate.setOnClickListener(v -> {
                PackageGenerationRunner.runGeneratePipeline(
                        scrollMain,
                        animPanel,
                        convAnimView,
                        tvAnimBadge,
                        tvAnimStatus,
                        readyPanel,
                        "TEXT FX",
                        "CLASSES.DEX",
                        () -> {
                            refreshPreviewAndPackage();
                            MorsalinToast.show(this, R.drawable.ic_download, "Package Ready",
                                    "classes.dex and ZIP ready to download!");
                        }
                );
            });
        }

        if (btnDownloadDex != null) {
            btnDownloadDex.setOnClickListener(v -> {
                if (latestPackage != null && latestPackage.getDexBinary() != null) {
                    byte[] dexBytes = latestPackage.getDexBinary();
                    FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                            this, "MorsalinXML/" + latestPackage.projectFolderName,
                            "classes.dex", "application/octet-stream", dexBytes);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "classes.dex Downloaded" : "Export Error", res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        if (btnDownloadZip != null) {
            btnDownloadZip.setOnClickListener(v -> {
                if (latestPackage != null) {
                    FileExporter.ExportResult res = GeneratedPackageExporter.exportPackageAsZip(this, latestPackage);
                    GeneratedPackageExporter.exportAllPackageFiles(this, latestPackage);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "ZIP Package Downloaded" : "Export Error",
                            res.success ? "Saved to Downloads/MorsalinXML/" + latestPackage.projectFolderName + ".zip" : res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        findViewById(R.id.btn_save_history).setOnClickListener(v -> {
            String title = "TextAnim_" + currentEffect.replace(" ", "_");
            XmlProject proj = new XmlProject(title, XmlProject.TYPE_TEXT_ANIM,
                    latestPackage != null ? latestPackage.files.get("res/layout/layout_animated_text.xml") : "", buildJsonConfig());
            historyManager.saveProject(proj);
            MorsalinToast.show(this, R.drawable.ic_save, "Saved to History",
                    "Text Animation saved to History!");
        });

        findViewById(R.id.btn_share_export).setOnClickListener(v -> {
            if (latestPackage != null) {
                GeneratedPackageExporter.showShareDialog(
                        this, latestPackage, "classes.dex", getCurrentTabContent());
            }
        });
    }

    private void updateEffectButtonsUI() {
        int cyan = getResources().getColor(R.color.morsalin_cyan);
        int white = Color.WHITE;
        for (int i = 0; i < effectButtons.size(); i++) {
            Button b = effectButtons.get(i);
            boolean active = EFFECTS[i].equals(currentEffect);
            b.setTextColor(active ? cyan : white);
        }
    }

    private int parseSafeColor(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    private void refreshPreviewAndPackage() {
        liveTextView.configure(
                customText,
                currentEffect,
                textSizeSp,
                parseSafeColor(primaryHex, Color.CYAN),
                parseSafeColor(secondaryHex, Color.MAGENTA),
                parseSafeColor(strokeHex, Color.WHITE),
                parseSafeColor(glowHex, Color.GREEN),
                strokeWidthPx,
                glowRadiusPx,
                useGradient,
                STYLE_VALUES[styleIdx],
                cycleDurationMs
        );

        byte[] dexBytes = MorsalinDexGenerator.buildTextAnimationDex(
                this,
                customText,
                currentEffect,
                textSizeSp,
                primaryHex,
                secondaryHex,
                glowHex,
                glowRadiusPx,
                STYLE_VALUES[styleIdx],
                cycleDurationMs
        );
        String layoutXml = generateLayoutXml();
        String colorsXml = generateColorsXml();
        String guide = GeneratedPackageExporter.buildTextAnimationMakerGuide(
                customText, currentEffect, textSizeSp, primaryHex, glowHex
        );

        GeneratedPackageExporter.GeneratedPackage pkg =
                new GeneratedPackageExporter.GeneratedPackage("Morsalin_TextAnimation_Package", "Text Animation Maker");
        pkg.addDexBinary(dexBytes);
        pkg.addFile("java/com/morsalin/xmlcreator/MorsalinAnimatedTextView.java", generateCustomTextViewJava());
        pkg.addFile("smali/com/morsalin/xmlcreator/MorsalinAnimatedTextView.smali", generateCustomTextViewSmali());
        pkg.addFile("res/layout/layout_animated_text.xml", layoutXml);
        pkg.addFile("res/values/colors_text_anim.xml", colorsXml);
        pkg.setGuideContent("TEXT_ANIMATION_GUIDE.txt", guide);
        latestPackage = pkg;
        displayActiveTabCode();
    }

    private void switchCodeTab(int idx) {
        activeCodeTab = idx;
    }

    private void displayActiveTabCode() {
        // Files are prepared in package for direct download
    }

    private String getCurrentTabFileName() {
        if (activeCodeTab == 0) return "classes.dex";
        if (activeCodeTab == 1) return "layout_animated_text.xml";
        if (activeCodeTab == 2) return "colors_text_anim.xml";
        return "TEXT_ANIMATION_GUIDE.txt";
    }

    private String getCurrentTabContent() {
        if (latestPackage == null) return "";
        if (activeCodeTab == 0) {
            byte[] dex = latestPackage.getDexBinary();
            return MorsalinDexGenerator.getDexBinaryReport(
                    dex,
                    "MorsalinAnimatedTextView",
                    "<com.morsalin.xmlcreator.MorsalinAnimatedTextView android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\" android:text=\"" + customText + "\" />",
                    "Effect: " + currentEffect + " | Size: " + textSizeSp + "sp | Primary: " + primaryHex
            );
        }
        if (activeCodeTab == 1) return latestPackage.files.get("res/layout/layout_animated_text.xml");
        if (activeCodeTab == 2) return latestPackage.files.get("res/values/colors_text_anim.xml");
        return latestPackage.guideContent;
    }

    private String generateLayoutXml() {
        String safeText = customText.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<!-- Generated by Morsalin XML Creator - Text Animation Maker -->\n"
                + "<FrameLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                + "    android:layout_width=\"match_parent\"\n"
                + "    android:layout_height=\"wrap_content\"\n"
                + "    android:padding=\"16dp\">\n\n"
                + "    <com.morsalin.xmlcreator.MorsalinAnimatedTextView\n"
                + "        android:id=\"@+id/tv_morsalin_animated\"\n"
                + "        android:layout_width=\"match_parent\"\n"
                + "        android:layout_height=\"96dp\"\n"
                + "        android:gravity=\"center\"\n"
                + "        android:text=\"" + safeText + "\"\n"
                + "        android:textColor=\"" + primaryHex + "\"\n"
                + "        android:textSize=\"" + textSizeSp + "sp\"\n"
                + "        android:textStyle=\"bold\" />\n\n"
                + "</FrameLayout>";
    }

    private String generateColorsXml() {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<resources>\n"
                + "    <color name=\"morsalin_text_primary\">" + primaryHex + "</color>\n"
                + "    <color name=\"morsalin_text_secondary\">" + secondaryHex + "</color>\n"
                + "    <color name=\"morsalin_text_stroke\">" + strokeHex + "</color>\n"
                + "    <color name=\"morsalin_text_glow\">" + glowHex + "</color>\n"
                + "</resources>";
    }

    private String generateCustomTextViewSmali() {
        String safeText = customText.replace("\\", "\\\\").replace("\"", "\\\"");
        String sizeHex = String.format(java.util.Locale.US, "0x%08x", Float.floatToRawIntBits((float) textSizeSp));
        String glowHexBits = String.format(java.util.Locale.US, "0x%08x", Float.floatToRawIntBits((float) glowRadiusPx));

        StringBuilder sb = new StringBuilder();
        sb.append(".class public Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;\n");
        sb.append(".super Landroid/widget/TextView;\n");
        sb.append(".source \"MorsalinAnimatedTextView.java\"\n\n");
        sb.append("# interfaces\n");
        sb.append(".implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;\n\n");
        sb.append("# ====================================================================\n");
        sb.append("# Generated by Morsalin XML Creator — Text Animation Maker\n");
        sb.append("# Package : com.morsalin.xmlcreator\n");
        sb.append("# Effect  : ").append(currentEffect).append("\n");
        sb.append("#\n");
        sb.append("# HOW TO CALL IN MainActivity.smali (inside onCreate before return-void):\n");
        sb.append("# invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->attachToActivity(Landroid/app/Activity;)Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;\n");
        sb.append("#\n");
        sb.append("# OR USE IN ANY LAYOUT XML:\n");
        sb.append("# <com.morsalin.xmlcreator.MorsalinAnimatedTextView\n");
        sb.append("#     android:layout_width=\"match_parent\"\n");
        sb.append("#     android:layout_height=\"wrap_content\" />\n");
        sb.append("# ====================================================================\n\n");

        sb.append("# instance fields\n");
        sb.append(".field private animator:Landroid/animation/ValueAnimator;\n");
        sb.append(".field private effectType:Ljava/lang/String;\n");
        sb.append(".field private fullText:Ljava/lang/String;\n");
        sb.append(".field private glowColor:I\n");
        sb.append(".field private primaryColor:I\n");
        sb.append(".field private progress:F\n");
        sb.append(".field private secondaryColor:I\n\n");

        sb.append(".method public constructor <init>(Landroid/content/Context;)V\n");
        sb.append("    .locals 0\n\n");
        sb.append("    invoke-direct {p0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V\n");
        sb.append("    invoke-direct {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->initAnim()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V\n");
        sb.append("    .locals 0\n\n");
        sb.append("    invoke-direct {p0, p1, p2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V\n");
        sb.append("    invoke-direct {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->initAnim()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public static attachToActivity(Landroid/app/Activity;)Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;\n");
        sb.append("    .locals 4\n\n");
        sb.append("    if-nez p0, :cond_ok\n");
        sb.append("    const/4 v0, 0x0\n");
        sb.append("    return-object v0\n\n");
        sb.append("    :cond_ok\n");
        sb.append("    new-instance v0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;\n");
        sb.append("    invoke-direct {v0, p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;-><init>(Landroid/content/Context;)V\n");
        sb.append("    const v1, 0x1020002\n");
        sb.append("    invoke-virtual {p0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;\n");
        sb.append("    move-result-object v1\n");
        sb.append("    instance-of v2, v1, Landroid/view/ViewGroup;\n");
        sb.append("    if-eqz v2, :cond_done\n");
        sb.append("    check-cast v1, Landroid/view/ViewGroup;\n");
        sb.append("    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;\n");
        sb.append("    const/4 v3, -0x1\n");
        sb.append("    const/4 p0, -0x2\n");
        sb.append("    invoke-direct {v2, v3, p0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V\n");
        sb.append("    invoke-virtual {v1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V\n\n");
        sb.append("    :cond_done\n");
        sb.append("    return-object v0\n");
        sb.append(".end method\n\n");

        sb.append(".method private initAnim()V\n");
        sb.append("    .locals 4\n\n");
        sb.append("    const-string v0, \"").append(safeText).append("\"\n");
        sb.append("    iput-object v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->fullText:Ljava/lang/String;\n");
        sb.append("    invoke-virtual {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setText(Ljava/lang/CharSequence;)V\n\n");
        sb.append("    const-string v0, \"").append(currentEffect).append("\"\n");
        sb.append("    iput-object v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->effectType:Ljava/lang/String;\n\n");
        sb.append("    const-string v0, \"").append(primaryHex).append("\"\n");
        sb.append("    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I\n");
        sb.append("    move-result v0\n");
        sb.append("    iput v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->primaryColor:I\n");
        sb.append("    invoke-virtual {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setTextColor(I)V\n\n");
        sb.append("    const-string v0, \"").append(secondaryHex).append("\"\n");
        sb.append("    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I\n");
        sb.append("    move-result v0\n");
        sb.append("    iput v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->secondaryColor:I\n\n");
        sb.append("    const-string v0, \"").append(glowHex).append("\"\n");
        sb.append("    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I\n");
        sb.append("    move-result v0\n");
        sb.append("    iput v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->glowColor:I\n\n");
        sb.append("    const v1, ").append(glowHexBits).append("\n");
        sb.append("    const/4 v2, 0x0\n");
        sb.append("    invoke-virtual {p0, v1, v2, v2, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setShadowLayer(FFFI)V\n\n");
        sb.append("    const v0, ").append(sizeHex).append("\n");
        sb.append("    invoke-virtual {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setTextSize(F)V\n");
        sb.append("    const/16 v0, 0x11\n");
        sb.append("    invoke-virtual {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setGravity(I)V\n");
        sb.append("    invoke-virtual {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->startTextAnimation()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public startTextAnimation()V\n");
        sb.append("    .locals 3\n\n");
        sb.append("    iget-object v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->animator:Landroid/animation/ValueAnimator;\n");
        sb.append("    if-eqz v0, :cond_new\n");
        sb.append("    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V\n\n");
        sb.append("    :cond_new\n");
        sb.append("    const/4 v0, 0x2\n");
        sb.append("    new-array v0, v0, [F\n");
        sb.append("    const/4 v1, 0x0\n");
        sb.append("    const/4 v2, 0x0\n");
        sb.append("    aput v2, v0, v1\n");
        sb.append("    const/4 v1, 0x1\n");
        sb.append("    const/high16 v2, 0x3f800000\n");
        sb.append("    aput v2, v0, v1\n");
        sb.append("    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;\n");
        sb.append("    move-result-object v0\n");
        sb.append("    iput-object v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->animator:Landroid/animation/ValueAnimator;\n");
        sb.append("    const-wide/16 v1, 0x").append(Integer.toHexString(cycleDurationMs)).append("\n");
        sb.append("    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;\n");
        sb.append("    const/4 v1, -0x1\n");
        sb.append("    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V\n");
        sb.append("    const/4 v1, 0x2\n");
        sb.append("    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setRepeatMode(I)V\n");
        sb.append("    invoke-virtual {v0, p0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V\n");
        sb.append("    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V\n");
        sb.append("    .locals 4\n\n");
        sb.append("    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;\n");
        sb.append("    move-result-object v0\n");
        sb.append("    check-cast v0, Ljava/lang/Float;\n");
        sb.append("    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F\n");
        sb.append("    move-result v0\n");
        sb.append("    iput v0, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->progress:F\n\n");

        if ("Typing".equals(currentEffect) || "Letter-by-letter".equals(currentEffect)
                || "Character Reveal".equals(currentEffect) || "Word Reveal".equals(currentEffect)) {
            sb.append("    iget-object v1, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->fullText:Ljava/lang/String;\n");
            sb.append("    if-eqz v1, :cond_end\n");
            sb.append("    invoke-virtual {v1}, Ljava/lang/String;->length()I\n");
            sb.append("    move-result v2\n");
            sb.append("    int-to-float v2, v2\n");
            sb.append("    mul-float/2addr v2, v0\n");
            sb.append("    float-to-int v2, v2\n");
            sb.append("    const/4 v3, 0x0\n");
            sb.append("    invoke-virtual {v1, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;\n");
            sb.append("    move-result-object v1\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setText(Ljava/lang/CharSequence;)V\n");
        } else if ("Fade".equals(currentEffect) || "Flicker".equals(currentEffect)) {
            sb.append("    invoke-virtual {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setAlpha(F)V\n");
        } else if ("Zoom".equals(currentEffect)) {
            sb.append("    const v1, 0x3f4ccccd\n");
            sb.append("    const v2, 0x3e99999a\n");
            sb.append("    mul-float/2addr v2, v0\n");
            sb.append("    add-float/2addr v1, v2\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setScaleX(F)V\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setScaleY(F)V\n");
        } else if ("Slide".equals(currentEffect) || "Shake".equals(currentEffect)) {
            sb.append("    const/high16 v1, 0x3f000000\n");
            sb.append("    sub-float v1, v0, v1\n");
            sb.append("    const/high16 v2, 0x42200000\n");
            sb.append("    mul-float/2addr v1, v2\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setTranslationX(F)V\n");
        } else if ("Bounce".equals(currentEffect) || "Wave".equals(currentEffect)) {
            sb.append("    const/high16 v1, 0x3f000000\n");
            sb.append("    sub-float v1, v0, v1\n");
            sb.append("    const/high16 v2, -0x3e600000\n");
            sb.append("    mul-float/2addr v1, v2\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setTranslationY(F)V\n");
        } else if ("Rotate".equals(currentEffect)) {
            sb.append("    const/high16 v1, 0x3f000000\n");
            sb.append("    sub-float v1, v0, v1\n");
            sb.append("    const/high16 v2, 0x41800000\n");
            sb.append("    mul-float/2addr v1, v2\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setRotation(F)V\n");
        } else {
            sb.append("    const/high16 v1, 0x3f000000\n");
            sb.append("    cmpg-float v1, v0, v1\n");
            sb.append("    if-gez v1, :cond_sec\n");
            sb.append("    iget v1, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->primaryColor:I\n");
            sb.append("    goto :goto_col\n");
            sb.append("    :cond_sec\n");
            sb.append("    iget v1, p0, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->secondaryColor:I\n");
            sb.append("    :goto_col\n");
            sb.append("    invoke-virtual {p0, v1}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->setTextColor(I)V\n");
        }

        sb.append("    :cond_end\n");
        sb.append("    invoke-virtual {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->invalidate()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n");
        return sb.toString();
    }

    private String generateCustomTextViewJava() {
        String safeText = customText.replace("\\", "\\\\").replace("\"", "\\\"");
        return "package com.morsalin.xmlcreator;\n\n"
                + "import android.animation.ValueAnimator;\n"
                + "import android.content.Context;\n"
                + "import android.graphics.Canvas;\n"
                + "import android.graphics.Color;\n"
                + "import android.graphics.LinearGradient;\n"
                + "import android.graphics.Matrix;\n"
                + "import android.graphics.Paint;\n"
                + "import android.graphics.Shader;\n"
                + "import android.graphics.Typeface;\n"
                + "import android.text.TextPaint;\n"
                + "import android.util.AttributeSet;\n"
                + "import android.view.animation.LinearInterpolator;\n"
                + "import androidx.appcompat.widget.AppCompatTextView;\n\n"
                + "/**\n"
                + " * Generated by Morsalin XML Creator — Text Animation Maker\n"
                + " * Configured Effect: " + currentEffect + "\n"
                + " */\n"
                + "public class MorsalinAnimatedTextView extends AppCompatTextView {\n\n"
                + "    private String effectType = \"" + currentEffect + "\";\n"
                + "    private int primaryColor = Color.parseColor(\"" + primaryHex + "\");\n"
                + "    private int secondaryColor = Color.parseColor(\"" + secondaryHex + "\");\n"
                + "    private int strokeColor = Color.parseColor(\"" + strokeHex + "\");\n"
                + "    private int glowColor = Color.parseColor(\"" + glowHex + "\");\n"
                + "    private float strokeWidthPx = " + strokeWidthPx + "f;\n"
                + "    private float glowRadiusPx = " + glowRadiusPx + "f;\n"
                + "    private boolean useGradient = " + useGradient + ";\n"
                + "    private int durationMs = " + cycleDurationMs + ";\n\n"
                + "    private final TextPaint strokePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);\n"
                + "    private final Matrix gradientMatrix = new Matrix();\n"
                + "    private LinearGradient gradientShader;\n"
                + "    private ValueAnimator animator;\n"
                + "    private float progress = 0f;\n\n"
                + "    public MorsalinAnimatedTextView(Context context) {\n"
                + "        super(context);\n"
                + "        initAnim();\n"
                + "    }\n\n"
                + "    public MorsalinAnimatedTextView(Context context, AttributeSet attrs) {\n"
                + "        super(context, attrs);\n"
                + "        initAnim();\n"
                + "    }\n\n"
                + "    private void initAnim() {\n"
                + "        if (getText() == null || getText().length() == 0) {\n"
                + "            setText(\"" + safeText + "\");\n"
                + "        }\n"
                + "        setTextSize(" + textSizeSp + "f);\n"
                + "        setTypeface(getTypeface(), " + STYLE_VALUES[styleIdx] + ");\n"
                + "        startTextAnimation();\n"
                + "    }\n\n"
                + "    public void setTextEffect(String effect) {\n"
                + "        this.effectType = effect;\n"
                + "        invalidate();\n"
                + "    }\n\n"
                + "    public void startTextAnimation() {\n"
                + "        if (animator != null) animator.cancel();\n"
                + "        animator = ValueAnimator.ofFloat(0f, 1f);\n"
                + "        animator.setDuration(durationMs);\n"
                + "        animator.setRepeatCount(ValueAnimator.INFINITE);\n"
                + "        animator.setInterpolator(new LinearInterpolator());\n"
                + "        animator.addUpdateListener(a -> {\n"
                + "            progress = (float) a.getAnimatedValue();\n"
                + "            invalidate();\n"
                + "        });\n"
                + "        animator.start();\n"
                + "    }\n\n"
                + "    @Override\n"
                + "    protected void onDraw(Canvas canvas) {\n"
                + "        int w = getWidth(), h = getHeight();\n"
                + "        if (w <= 0 || h <= 0) return;\n"
                + "        TextPaint paint = getPaint();\n"
                + "        paint.setStyle(Paint.Style.FILL);\n"
                + "        if (\"RGB\".equals(effectType)) {\n"
                + "            paint.setShader(null);\n"
                + "            paint.setColor(Color.HSVToColor(new float[]{(progress * 360f) % 360f, 0.9f, 1f}));\n"
                + "        } else if (useGradient || \"Gradient\".equals(effectType)) {\n"
                + "            if (gradientShader == null) {\n"
                + "                gradientShader = new LinearGradient(0, 0, w * 0.6f, 0,\n"
                + "                        new int[]{primaryColor, secondaryColor, primaryColor}, null, Shader.TileMode.MIRROR);\n"
                + "            }\n"
                + "            gradientMatrix.setTranslate(w * progress * 1.5f, 0);\n"
                + "            gradientShader.setLocalMatrix(gradientMatrix);\n"
                + "            paint.setShader(gradientShader);\n"
                + "        } else {\n"
                + "            paint.setShader(null);\n"
                + "            paint.setColor(primaryColor);\n"
                + "        }\n"
                + "        if (glowRadiusPx > 0) {\n"
                + "            paint.setShadowLayer(glowRadiusPx, 0, 0, glowColor);\n"
                + "        }\n"
                + "        String full = getText().toString();\n"
                + "        String drawStr = full;\n"
                + "        if (\"Typing\".equals(effectType)) {\n"
                + "            int count = Math.max(1, Math.round(full.length() * Math.min(1f, progress * 1.15f)));\n"
                + "            drawStr = full.substring(0, Math.min(full.length(), count));\n"
                + "        }\n"
                + "        Paint.FontMetrics fm = paint.getFontMetrics();\n"
                + "        float y = (h / 2f) - ((fm.descent + fm.ascent) / 2f);\n"
                + "        float x = (w - paint.measureText(drawStr)) / 2f;\n"
                + "        if (strokeWidthPx > 0) {\n"
                + "            strokePaint.set(paint);\n"
                + "            strokePaint.setShader(null);\n"
                + "            strokePaint.setStyle(Paint.Style.STROKE);\n"
                + "            strokePaint.setStrokeWidth(strokeWidthPx);\n"
                + "            strokePaint.setColor(strokeColor);\n"
                + "            canvas.drawText(drawStr, x, y, strokePaint);\n"
                + "        }\n"
                + "        canvas.drawText(drawStr, x, y, paint);\n"
                + "    }\n"
                + "}\n";
    }

    private String buildJsonConfig() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("customText", customText);
            obj.put("currentEffect", currentEffect);
            obj.put("textSizeSp", textSizeSp);
            obj.put("cycleDurationMs", cycleDurationMs);
            obj.put("strokeWidthPx", strokeWidthPx);
            obj.put("glowRadiusPx", glowRadiusPx);
            obj.put("primaryHex", primaryHex);
            obj.put("secondaryHex", secondaryHex);
            obj.put("strokeHex", strokeHex);
            obj.put("glowHex", glowHex);
            obj.put("useGradient", useGradient);
            obj.put("styleIdx", styleIdx);
            return obj.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void loadFromJsonConfig(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            customText = obj.optString("customText", "MORSALIN XML CREATOR");
            currentEffect = obj.optString("currentEffect", "Typing");
            textSizeSp = obj.optInt("textSizeSp", 22);
            cycleDurationMs = obj.optInt("cycleDurationMs", 1600);
            strokeWidthPx = obj.optInt("strokeWidthPx", 0);
            glowRadiusPx = obj.optInt("glowRadiusPx", 12);
            primaryHex = obj.optString("primaryHex", "#00E5FF");
            secondaryHex = obj.optString("secondaryHex", "#FF007F");
            strokeHex = obj.optString("strokeHex", "#FFFFFF");
            glowHex = obj.optString("glowHex", "#00FF88");
            useGradient = obj.optBoolean("useGradient", true);
            styleIdx = obj.optInt("styleIdx", 0);

            etCustomText.setText(customText);
            seekSize.setProgress(Math.max(0, textSizeSp - 12));
            seekSpeed.setProgress(Math.max(0, cycleDurationMs - 400));
            seekStroke.setProgress(Math.max(0, strokeWidthPx));
            seekGlow.setProgress(Math.max(0, glowRadiusPx));
            btnStyleCycle.setText(STYLE_LABELS[styleIdx % STYLE_LABELS.length]);
            btnToggleGradient.setText(useGradient ? "GRADIENT SHADER: ON" : "GRADIENT SHADER: OFF");
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
