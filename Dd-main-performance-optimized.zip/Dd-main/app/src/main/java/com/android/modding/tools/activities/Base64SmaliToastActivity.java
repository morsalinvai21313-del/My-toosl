package com.android.modding.tools.activities;

import com.android.modding.tools.toastmaker.ToastConfig;

/**
 * Base64 Smali Toast Maker.
 * Focused on string-obfuscated Dalvik Toast executables (classes.dex) that runtime-decode
 * secret messages without exposing plaintext strings in decompiled Smali/Java code.
 */
public class Base64SmaliToastActivity extends BaseToastMakerActivity {

    @Override
    protected ToastConfig getInitialConfig() {
        return ToastConfig.createBase64Default();
    }

    @Override
    protected String getScreenTitle() {
        return "Base64 Smali Toast Maker";
    }

    @Override
    protected boolean showBase64Section() {
        return true;
    }

    @Override
    protected boolean showAnimationSection() {
        return false;
    }

    @Override
    protected boolean showGalleryPickerSection() {
        return false;
    }

    @Override
    protected boolean showEmblemSection() {
        return false;
    }

    @Override
    protected boolean showTitleInput() {
        return false;
    }

    @Override
    protected boolean showGradientSection() {
        return true;
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("🔒 BASE64 ENCRYPTED QUICK PRESETS");
        }

        if (btnPreset1 != null) {
            btnPreset1.setText("VIP Encrypted");
            btnPreset1.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createBase64Default();
                p.toastName = "Base64_VIP_Toast";
                p.messageText = "Modded by Morsalin • VIP Active";
                p.isBase64 = true;
                p.bgHex = "#131722";
                p.isGradient = true;
                p.bgGradientEndHex = "#00E5FF";
                p.borderHex = "#00E5FF";
                p.animMode = "Cyber Glitch";
                applyPreset(p, "VIP Encrypted");
            });
        }

        if (btnPreset2 != null) {
            btnPreset2.setText("Anti-Ban Shield");
            btnPreset2.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createBase64Default();
                p.toastName = "Base64_AntiBan_Toast";
                p.messageText = "Security Bypass Engine 100% Active";
                p.isBase64 = true;
                p.bgHex = "#1B1026";
                p.isGradient = true;
                p.bgGradientEndHex = "#D500F9";
                p.borderHex = "#E040FB";
                p.animMode = "Matrix Drop";
                applyPreset(p, "Anti-Ban Shield");
            });
        }

        if (btnPreset3 != null) {
            btnPreset3.setText("License Verified");
            btnPreset3.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createBase64Default();
                p.toastName = "Base64_License_Toast";
                p.messageText = "Key Verified: LIFETIME ACCESS GRANTED";
                p.isBase64 = true;
                p.bgHex = "#081C15";
                p.isGradient = true;
                p.bgGradientEndHex = "#1B4332";
                p.borderHex = "#52B788";
                p.animMode = "Bounce";
                applyPreset(p, "License Verified");
            });
        }

        if (btnPreset4 != null) {
            btnPreset4.setText("Modder Signature");
            btnPreset4.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createBase64Default();
                p.toastName = "Base64_Signature_Toast";
                p.messageText = "Protected by Sanny & Morsalin Modding Tools";
                p.isBase64 = true;
                p.bgHex = "#211A00";
                p.isGradient = true;
                p.bgGradientEndHex = "#4A3B00";
                p.borderHex = "#FFD700";
                p.animMode = "Hologram";
                applyPreset(p, "Modder Signature");
            });
        }
    }
}
