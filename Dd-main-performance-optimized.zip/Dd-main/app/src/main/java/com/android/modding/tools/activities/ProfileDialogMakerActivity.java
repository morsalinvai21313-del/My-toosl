package com.android.modding.tools.activities;

import android.view.View;
import com.android.modding.tools.dialogmaker.DialogConfig;

/**
 * Profile Card Dialog Maker.
 * Dedicated to developer profiles, VIP user cards, avatars, and social community links.
 */
public class ProfileDialogMakerActivity extends BaseDialogMakerActivity {

    @Override
    protected DialogConfig getInitialConfig() {
        return DialogConfig.createProfileDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Profile Card Dialog Maker";
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("⚡ PROFILE CARD PRESETS");
        }
        if (btnPreset1 != null) {
            btnPreset1.setText("VIP Dev Card");
            btnPreset1.setOnClickListener(v -> applyPreset(createVipDevPreset(), "VIP Developer Card"));
        }
        if (btnPreset2 != null) {
            btnPreset2.setText("Neon Hacker");
            btnPreset2.setOnClickListener(v -> applyPreset(createNeonHackerPreset(), "Neon Hacker"));
        }
        if (btnPreset3 != null) {
            btnPreset3.setText("24/7 Support");
            btnPreset3.setOnClickListener(v -> applyPreset(createSupportPreset(), "Support Card"));
        }
        if (btnPreset4 != null) {
            btnPreset4.setText("Social Connect");
            btnPreset4.setOnClickListener(v -> applyPreset(createSocialConnectPreset(), "Social Connect"));
        }
    }

    @Override
    protected void setupCustomMakerOptions() {
        if (layoutProfilePhotoSection != null) layoutProfilePhotoSection.setVisibility(View.VISIBLE);
        if (layoutVectorIconSection != null) layoutVectorIconSection.setVisibility(View.GONE);
    }

    private DialogConfig createVipDevPreset() {
        DialogConfig c = DialogConfig.createProfileDefault();
        c.avatarPreset = "Morsalin Cyber";
        c.avatarShape = "CIRCLE";
        c.avatarSizeDp = 84;
        c.avatarBorderWidthDp = 4;
        c.avatarBorderStyle = "DOTTED";
        c.avatarBorderHex = "#00FFB2";
        c.borderHex = "#00FFB2";
        c.noticeBadgeText = "👑 VIP MODDER";
        c.noticeBadgeBgHex = "#00FFB2";
        c.noticeBadgeTextHex = "#0A1926";
        c.titleText = "Anonymous Modder";
        c.titleColorHex = "#FFFFFF";
        c.subtitleText = "Android Security & Reverse Engineer";
        c.subtitleColorHex = "#00FFB2";
        c.messageText = "Follow official Telegram and Facebook channels for the latest APK modding tools and XML creators.";
        c.buttonCount = 3;
        c.btn1Text = "Close";
        c.btn2Text = "Facebook";
        c.btn2Url = "https://www.facebook.com/share/19bhVG8oJF/";
        c.btn3Text = "Telegram";
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Zoom";
        return c;
    }

    private DialogConfig createNeonHackerPreset() {
        DialogConfig c = DialogConfig.createProfileDefault();
        c.avatarPreset = "Morsalin Neon";
        c.avatarShape = "ROUNDED";
        c.avatarSizeDp = 92;
        c.avatarBorderWidthDp = 5;
        c.avatarBorderStyle = "GLOW";
        c.avatarBorderHex = "#00E5FF";
        c.borderHex = "#00E5FF";
        c.noticeBadgeText = "⚡ CYBER SEC";
        c.noticeBadgeBgHex = "#00E5FF";
        c.noticeBadgeTextHex = "#040E17";
        c.titleText = "Cyber Phantom";
        c.titleColorHex = "#00E5FF";
        c.subtitleText = "Binary Patching & DEX Analyst";
        c.subtitleColorHex = "#80EAFF";
        c.messageText = "Dedicated to reverse engineering, Dalvik bytecode modding, and zero-XML dialog creation.";
        c.buttonCount = 2;
        c.btn1Text = "Dismiss";
        c.btn3Text = "Channel";
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Flip 3D";
        return c;
    }

    private DialogConfig createSupportPreset() {
        DialogConfig c = DialogConfig.createProfileDefault();
        c.avatarPreset = "Sanny DJ";
        c.avatarShape = "CIRCLE";
        c.avatarSizeDp = 76;
        c.avatarBorderWidthDp = 3;
        c.avatarBorderStyle = "DASHED";
        c.avatarBorderHex = "#FFB703";
        c.borderHex = "#FFB703";
        c.noticeBadgeText = "🛡️ 24/7 SUPPORT";
        c.noticeBadgeBgHex = "#FFB703";
        c.noticeBadgeTextHex = "#0A1926";
        c.titleText = "Help & Support Desk";
        c.titleColorHex = "#FFB703";
        c.subtitleText = "Customer Care & Modding Help";
        c.subtitleColorHex = "#FFD166";
        c.messageText = "Need assistance configuring your modded APK or troubleshooting DEX errors? Connect with us directly.";
        c.buttonCount = 2;
        c.btn1Text = "Cancel";
        c.btn3Text = "Contact Support";
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Slide";
        return c;
    }

    private DialogConfig createSocialConnectPreset() {
        DialogConfig c = DialogConfig.createProfileDefault();
        c.avatarPreset = "Sanny Modder";
        c.avatarShape = "ROUNDED";
        c.avatarSizeDp = 80;
        c.avatarBorderWidthDp = 3;
        c.avatarBorderStyle = "SOLID";
        c.avatarBorderHex = "#FF007F";
        c.borderHex = "#FF007F";
        c.noticeBadgeText = "⭐ CREATOR HUB";
        c.noticeBadgeBgHex = "#FF007F";
        c.noticeBadgeTextHex = "#FFFFFF";
        c.titleText = "Morsalin Media";
        c.titleColorHex = "#FF007F";
        c.subtitleText = "YouTube, Telegram & GitHub";
        c.subtitleColorHex = "#FFAAD4";
        c.messageText = "Join our developer community to access exclusive tools, tutorials, and smali modding templates.";
        c.buttonCount = 3;
        c.btn1Text = "Close";
        c.btn2Text = "Facebook";
        c.btn2Url = "https://www.facebook.com/share/19bhVG8oJF/";
        c.btn3Text = "Telegram";
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Bounce";
        return c;
    }
}
