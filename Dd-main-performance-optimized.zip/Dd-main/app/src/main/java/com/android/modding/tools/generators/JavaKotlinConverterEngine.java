package com.android.modding.tools.generators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * High-Precision AST & Structural Java <-> Kotlin Converter Engine.
 *
 * Capabilities:
 * - Multi-line declaration & signature normalization
 * - Literal & Comment Vault (protects strings, raw strings, chars, block/line comments,
 *   and performs accurate Kotlin "$var" / "${expr}" string template interpolation)
 * - Full class hierarchy parsing (classes, data classes, interfaces, enums, object,
 *   companion object, nested/inner classes, primary & secondary constructors)
 * - Generics & variance conversion (? extends T <-> out T, ? super T <-> in T, <?> <-> <*>)
 * - Switch / When (including multi-case, arrow syntax, subjectless when, smart-cast is/in)
 * - Loops (fori, downTo, until, step, enhanced for-each, map destructuring, complex while fallback)
 * - Try-with-resources, multi-catch, lambdas, SAM interfaces (OnClickListener, Runnable),
 *   Java Streams -> Kotlin collection pipelines, bitwise operators, ternary parser, arrays
 */
public class JavaKotlinConverterEngine {

    public enum Direction {
        JAVA_TO_KOTLIN,
        KOTLIN_TO_JAVA
    }

    public static class ValidationResult {
        public final boolean isValid;
        public final String errorMessage;
        public final Direction detectedDirection;

        public ValidationResult(boolean isValid, String errorMessage, Direction detectedDirection) {
            this.isValid = isValid;
            this.errorMessage = errorMessage;
            this.detectedDirection = detectedDirection;
        }
    }

    public static class ConversionResult {
        public final boolean success;
        public final boolean needsReview;
        public final String convertedCode;
        public final String errorTitle;
        public final String errorReason;
        public final String errorDetails;
        public final List<String> warnings;
        public final int linesProcessed;
        public final int linesGenerated;
        public final long conversionTimeMs;

        public ConversionResult(
                boolean success,
                String convertedCode,
                String errorTitle,
                String errorReason,
                String errorDetails,
                List<String> warnings,
                int linesProcessed,
                int linesGenerated,
                long conversionTimeMs) {
            this(success, false, convertedCode, errorTitle, errorReason, errorDetails,
                    warnings, linesProcessed, linesGenerated, conversionTimeMs);
        }

        public ConversionResult(
                boolean success,
                boolean needsReview,
                String convertedCode,
                String errorTitle,
                String errorReason,
                String errorDetails,
                List<String> warnings,
                int linesProcessed,
                int linesGenerated,
                long conversionTimeMs) {
            this.success = success;
            this.needsReview = needsReview;
            this.convertedCode = convertedCode;
            this.errorTitle = errorTitle;
            this.errorReason = errorReason;
            this.errorDetails = errorDetails;
            this.warnings = warnings != null ? warnings : new ArrayList<>();
            this.linesProcessed = linesProcessed;
            this.linesGenerated = linesGenerated;
            this.conversionTimeMs = conversionTimeMs;
        }
    }

    public static Direction detectDirection(String fileName, String code) {
        if (fileName != null) {
            String lower = fileName.trim().toLowerCase();
            if (lower.endsWith(".kt") || lower.endsWith(".kts")) {
                return Direction.KOTLIN_TO_JAVA;
            }
            if (lower.endsWith(".java") && (code == null || code.trim().isEmpty())) {
                return Direction.JAVA_TO_KOTLIN;
            }
        }
        return detectLanguage(code);
    }

    public static String getSampleJavaCode() {
        return "package com.example.app;\n\n"
                + "import android.os.Bundle;\n"
                + "import android.view.View;\n"
                + "import android.widget.Button;\n"
                + "import android.widget.TextView;\n"
                + "import android.widget.Toast;\n"
                + "import androidx.appcompat.app.AppCompatActivity;\n"
                + "import java.util.ArrayList;\n"
                + "import java.util.List;\n\n"
                + "public class MyActivity extends AppCompatActivity {\n\n"
                + "    private static final String TAG = \"MyActivity\";\n"
                + "    private TextView tvCounter;\n"
                + "    private Button btnAction;\n"
                + "    private int clickCount = 0;\n\n"
                + "    @Override\n"
                + "    protected void onCreate(Bundle savedInstanceState) {\n"
                + "        super.onCreate(savedInstanceState);\n"
                + "        setContentView(R.layout.activity_main);\n\n"
                + "        tvCounter = findViewById(R.id.tv_counter);\n"
                + "        btnAction = findViewById(R.id.btn_action);\n\n"
                + "        final List<String> logs = new ArrayList<>();\n"
                + "        for (int i = 0; i < 5; i++) {\n"
                + "            logs.add(\"Step #\" + i);\n"
                + "        }\n\n"
                + "        btnAction.setOnClickListener(new View.OnClickListener() {\n"
                + "            @Override\n"
                + "            public void onClick(View v) {\n"
                + "                clickCount++;\n"
                + "                String status = clickCount > 3 ? \"High Activity\" : \"Normal\";\n"
                + "                tvCounter.setText(\"Clicked: \" + clickCount + \" (\" + status + \")\");\n"
                + "                Toast.makeText(MyActivity.this, status, Toast.LENGTH_SHORT).show();\n"
                + "            }\n"
                + "        });\n"
                + "    }\n"
                + "}\n";
    }

    public static String getSampleKotlinCode() {
        return "package com.example.app\n\n"
                + "import android.os.Bundle\n"
                + "import android.widget.Button\n"
                + "import android.widget.TextView\n"
                + "import android.widget.Toast\n"
                + "import androidx.appcompat.app.AppCompatActivity\n\n"
                + "class MainActivity : AppCompatActivity() {\n\n"
                + "    private var tvCounter: TextView? = null\n"
                + "    private var clickCount: Int = 0\n\n"
                + "    override fun onCreate(savedInstanceState: Bundle?) {\n"
                + "        super.onCreate(savedInstanceState)\n"
                + "        setContentView(R.layout.activity_main)\n\n"
                + "        tvCounter = findViewById(R.id.tv_counter)\n"
                + "        val btnAction: Button = findViewById(R.id.btn_action)\n\n"
                + "        for (i in 0 until 5) {\n"
                + "            println(\"Initializing step $i\")\n"
                + "        }\n\n"
                + "        btnAction.setOnClickListener { v ->\n"
                + "            clickCount++\n"
                + "            val label = if (clickCount >= 5) \"Master\" else \"Starter\"\n"
                + "            tvCounter?.setText(\"Score: $clickCount - $label\")\n"
                + "            Toast.makeText(this, \"Level: $label\", Toast.LENGTH_SHORT).show()\n"
                + "        }\n"
                + "    }\n\n"
                + "    companion object {\n"
                + "        const val TAG: String = \"MainActivity\"\n"
                + "    }\n"
                + "}\n";
    }

    private static final Map<String, String> JAVA_TO_KT_TYPES = new LinkedHashMap<>();
    private static final Map<String, String> KT_TO_JAVA_PRIMITIVES = new LinkedHashMap<>();
    private static final Map<String, String> KT_TO_JAVA_BOXED = new LinkedHashMap<>();

    static {
        JAVA_TO_KT_TYPES.put("boolean", "Boolean");
        JAVA_TO_KT_TYPES.put("byte", "Byte");
        JAVA_TO_KT_TYPES.put("short", "Short");
        JAVA_TO_KT_TYPES.put("int", "Int");
        JAVA_TO_KT_TYPES.put("long", "Long");
        JAVA_TO_KT_TYPES.put("float", "Float");
        JAVA_TO_KT_TYPES.put("double", "Double");
        JAVA_TO_KT_TYPES.put("char", "Char");
        JAVA_TO_KT_TYPES.put("void", "Unit");
        JAVA_TO_KT_TYPES.put("java.lang.String", "String");
        JAVA_TO_KT_TYPES.put("String", "String");
        JAVA_TO_KT_TYPES.put("Integer", "Int");
        JAVA_TO_KT_TYPES.put("Boolean", "Boolean");
        JAVA_TO_KT_TYPES.put("Long", "Long");
        JAVA_TO_KT_TYPES.put("Float", "Float");
        JAVA_TO_KT_TYPES.put("Double", "Double");
        JAVA_TO_KT_TYPES.put("Short", "Short");
        JAVA_TO_KT_TYPES.put("Byte", "Byte");
        JAVA_TO_KT_TYPES.put("Character", "Char");
        JAVA_TO_KT_TYPES.put("Object", "Any");
        JAVA_TO_KT_TYPES.put("CharSequence", "CharSequence");

        KT_TO_JAVA_PRIMITIVES.put("Boolean", "boolean");
        KT_TO_JAVA_PRIMITIVES.put("Byte", "byte");
        KT_TO_JAVA_PRIMITIVES.put("Short", "short");
        KT_TO_JAVA_PRIMITIVES.put("Int", "int");
        KT_TO_JAVA_PRIMITIVES.put("Long", "long");
        KT_TO_JAVA_PRIMITIVES.put("Float", "float");
        KT_TO_JAVA_PRIMITIVES.put("Double", "double");
        KT_TO_JAVA_PRIMITIVES.put("Char", "char");
        KT_TO_JAVA_PRIMITIVES.put("Unit", "void");
        KT_TO_JAVA_PRIMITIVES.put("Any", "Object");
        KT_TO_JAVA_PRIMITIVES.put("String", "String");

        KT_TO_JAVA_BOXED.put("Boolean", "Boolean");
        KT_TO_JAVA_BOXED.put("Byte", "Byte");
        KT_TO_JAVA_BOXED.put("Short", "Short");
        KT_TO_JAVA_BOXED.put("Int", "Integer");
        KT_TO_JAVA_BOXED.put("Long", "Long");
        KT_TO_JAVA_BOXED.put("Float", "Float");
        KT_TO_JAVA_BOXED.put("Double", "Double");
        KT_TO_JAVA_BOXED.put("Char", "Character");
        KT_TO_JAVA_BOXED.put("Any", "Object");
        KT_TO_JAVA_BOXED.put("String", "String");
    }

    /**
     * Automatically detects whether source code is Java or Kotlin using weighted syntax heuristics.
     */
    public static Direction detectLanguage(String code) {
        if (code == null || code.trim().isEmpty()) {
            return Direction.JAVA_TO_KOTLIN;
        }
        int kotlinScore = 0;
        int javaScore = 0;

        if (Pattern.compile("\\bfun\\s+[A-Za-z0-9_<>.]+\\s*\\(").matcher(code).find()) kotlinScore += 6;
        if (Pattern.compile("\\b(val|var)\\s+[A-Za-z0-9_]+\\s*[:=]").matcher(code).find()) kotlinScore += 5;
        if (code.contains("companion object") || code.contains("data class ") || code.contains("sealed class ")) kotlinScore += 6;
        if (code.contains("override fun ") || code.contains("suspend fun ") || code.contains("lateinit var ")) kotlinScore += 6;
        if (code.contains("?.") || code.contains("?:") || code.contains("!!")) kotlinScore += 4;
        if (Pattern.compile("\\bwhen\\s*[({]").matcher(code).find()) kotlinScore += 4;
        if (code.contains("listOf(") || code.contains("mutableListOf(") || code.contains("mapOf(")) kotlinScore += 3;

        if (Pattern.compile("\\bpublic\\s+(static\\s+)?(final\\s+)?(class|interface|enum|void|int|String|boolean)\\b").matcher(code).find()) javaScore += 6;
        if (code.contains("System.out.println") || code.contains("@Override")) javaScore += 4;
        if (code.contains("implements ") || code.contains("extends ")) javaScore += 5;
        if (Pattern.compile("\\bnew\\s+[A-Z][A-Za-z0-9_<>]*\\s*\\(").matcher(code).find()) javaScore += 4;
        if (Pattern.compile(";\\s*$", Pattern.MULTILINE).matcher(code).find()) javaScore += 3;

        return kotlinScore > javaScore ? Direction.KOTLIN_TO_JAVA : Direction.JAVA_TO_KOTLIN;
    }

    /**
     * Validates code structure and balanced delimiters while ignoring delimiters inside strings/comments.
     */
    public static ValidationResult validateSource(String code, Direction selectedDirection) {
        if (code == null || code.trim().isEmpty()) {
            return new ValidationResult(false, "Please enter or import source code first.", selectedDirection);
        }
        String trimmed = code.trim();
        if (trimmed.length() < 3) {
            return new ValidationResult(false, "Source code is too short to convert.", selectedDirection);
        }

        LiteralVault vault = new LiteralVault();
        String masked = vault.maskLiteralsAndComments(trimmed);

        int braceBalance = 0;
        int parenBalance = 0;
        for (int i = 0; i < masked.length(); i++) {
            char c = masked.charAt(i);
            if (c == '{') braceBalance++;
            else if (c == '}') braceBalance--;
            else if (c == '(') parenBalance++;
            else if (c == ')') parenBalance--;
        }

        if (braceBalance != 0) {
            return new ValidationResult(
                    false,
                    "Syntax error: Unbalanced curly braces '{ }' (" + (braceBalance > 0 ? "missing '}'" : "extra '}'") + ").",
                    selectedDirection
            );
        }
        if (parenBalance != 0) {
            return new ValidationResult(
                    false,
                    "Syntax error: Unbalanced parentheses '( )' (" + (parenBalance > 0 ? "missing ')'" : "extra ')'") + ").",
                    selectedDirection
            );
        }

        Direction detected = detectLanguage(trimmed);
        return new ValidationResult(true, "Valid source code", detected);
    }

    /**
     * Main entry point for converting source code in the given direction.
     */
    public static ConversionResult convert(String sourceCode, Direction direction) {
        return convert(sourceCode, direction, ConversionPostProcessor.QualityMode.BALANCED);
    }

    public static ConversionResult convert(String sourceCode, Direction direction, ConversionPostProcessor.QualityMode mode) {
        long startNs = System.nanoTime();
        if (sourceCode == null || sourceCode.trim().isEmpty()) {
            return new ConversionResult(
                    false,
                    false,
                    "",
                    "Empty Source Code",
                    "No source code was provided to convert.",
                    "Paste code or import a .java / .kt file before converting.",
                    new ArrayList<>(),
                    0,
                    0,
                    1L
            );
        }

        ValidationResult validation = validateSource(sourceCode, direction);
        int inputLines = sourceCode.split("\n", -1).length;
        if (!validation.isValid) {
            long elapsedMs = Math.max(1L, (System.nanoTime() - startNs) / 1_000_000L);
            return new ConversionResult(
                    false,
                    false,
                    "",
                    "Syntax Validation Error",
                    validation.errorMessage,
                    "Please verify all curly braces '{ }', parentheses '( )', and string quotes are balanced.",
                    new ArrayList<>(),
                    inputLines,
                    0,
                    elapsedMs
            );
        }

        List<String> warnings = new ArrayList<>();
        if (validation.detectedDirection != direction) {
            warnings.add("Auto-detected " + (validation.detectedDirection == Direction.JAVA_TO_KOTLIN ? "Java" : "Kotlin")
                    + " syntax; applied smart AST normalization.");
        }

        String normalized = sourceCode.replace("\r\n", "\n").replace("\r", "\n");
        String converted;
        boolean needsReview = false;
        try {
            if (direction == Direction.JAVA_TO_KOTLIN) {
                ConversionPostProcessor.PreprocessedJavaResult prep =
                        ConversionPostProcessor.preprocessJavaSourceDetailed(normalized, mode);
                String rawKt = convertJavaToKotlin(prep.code, prep.collapsedGetters, prep.collapsedSetters);
                String refinedKt = ConversionPostProcessor.refineGeneratedKotlin(rawKt, mode);
                refinedKt = formatIndentation(refinedKt);
                ConversionPostProcessor.RepairAndValidationReport report =
                        ConversionPostProcessor.validateAndRepairKotlin(refinedKt, mode);
                converted = formatIndentation(report.repairedCode);
                warnings.addAll(report.structuredWarnings);
                needsReview = report.hasUnresolvedCriticalErrors;
            } else {
                String rawJava = convertKotlinToJava(normalized);
                ConversionPostProcessor.RepairAndValidationReport report =
                        ConversionPostProcessor.validateAndRepairJava(rawJava, mode);
                converted = formatIndentation(report.repairedCode);
                warnings.addAll(report.structuredWarnings);
                needsReview = report.hasUnresolvedCriticalErrors;
            }
        } catch (Exception e) {
            long elapsedMs = Math.max(1L, (System.nanoTime() - startNs) / 1_000_000L);
            return new ConversionResult(
                    false,
                    true,
                    "",
                    "Conversion Engine Exception",
                    e.getMessage() != null ? e.getMessage() : "Unexpected syntax construct encountered.",
                    "Please check your code structure and try again.",
                    warnings,
                    inputLines,
                    0,
                    elapsedMs
            );
        }

        int outputLines = converted.trim().isEmpty() ? 0 : converted.split("\n", -1).length;
        long elapsedMs = Math.max(1L, (System.nanoTime() - startNs) / 1_000_000L);
        return new ConversionResult(
                true,
                needsReview,
                converted,
                null,
                null,
                null,
                warnings,
                inputLines,
                outputLines,
                elapsedMs
        );
    }

    // =========================================================================================
    // LITERAL & COMMENT VAULT (Protects Strings, Raw Strings, Chars, and Comments)
    // =========================================================================================
    private static class LiteralVault {
        private final List<String> strings = new ArrayList<>();
        private final List<String> comments = new ArrayList<>();

        String maskLiteralsAndComments(String input) {
            StringBuilder out = new StringBuilder(input.length());
            int n = input.length();
            int i = 0;

            while (i < n) {
                char c = input.charAt(i);

                // 1. Block comment /* ... */
                if (c == '/' && i + 1 < n && input.charAt(i + 1) == '*') {
                    int start = i;
                    i += 2;
                    while (i + 1 < n && !(input.charAt(i) == '*' && input.charAt(i + 1) == '/')) {
                        i++;
                    }
                    i = Math.min(n, i + 2);
                    int idx = comments.size();
                    comments.add(input.substring(start, i));
                    out.append("__CMT_TOKEN_").append(idx).append("__");
                    continue;
                }

                // 2. Line comment // ...
                if (c == '/' && i + 1 < n && input.charAt(i + 1) == '/') {
                    int start = i;
                    while (i < n && input.charAt(i) != '\n') {
                        i++;
                    }
                    int idx = comments.size();
                    comments.add(input.substring(start, i));
                    out.append("__CMT_TOKEN_").append(idx).append("__");
                    continue;
                }

                // 3. Triple-quoted raw string """ ... """
                if (c == '"' && i + 2 < n && input.charAt(i + 1) == '"' && input.charAt(i + 2) == '"') {
                    int start = i;
                    i += 3;
                    while (i + 2 < n && !(input.charAt(i) == '"' && input.charAt(i + 1) == '"' && input.charAt(i + 2) == '"')) {
                        i++;
                    }
                    i = Math.min(n, i + 3);
                    int idx = strings.size();
                    strings.add(input.substring(start, i));
                    out.append("__STR_TOKEN_").append(idx).append("__");
                    continue;
                }

                // 4. Standard string literal "..." or char literal '...'
                if (c == '"' || c == '\'') {
                    char quote = c;
                    int start = i;
                    i++;
                    while (i < n) {
                        char cur = input.charAt(i);
                        if (cur == '\\') {
                            i += 2;
                            continue;
                        }
                        if (cur == quote) {
                            i++;
                            break;
                        }
                        if (cur == '\n' && quote == '\'') {
                            break;
                        }
                        i++;
                    }
                    int idx = strings.size();
                    strings.add(input.substring(start, Math.min(n, i)));
                    out.append("__STR_TOKEN_").append(idx).append("__");
                    continue;
                }

                out.append(c);
                i++;
            }
            return out.toString();
        }

        String restoreForKotlin(String code) {
            String result = code;
            for (int i = strings.size() - 1; i >= 0; i--) {
                result = result.replace("__STR_TOKEN_" + i + "__", strings.get(i));
            }
            for (int i = comments.size() - 1; i >= 0; i--) {
                result = result.replace("__CMT_TOKEN_" + i + "__", comments.get(i));
            }
            return result;
        }

        String restoreForJavaWithTemplateExpansion(String code) {
            String result = code;
            for (int i = strings.size() - 1; i >= 0; i--) {
                String rawLiteral = strings.get(i);
                String expanded = expandKotlinStringTemplatesToJava(rawLiteral);
                result = result.replace("__STR_TOKEN_" + i + "__", expanded);
            }
            for (int i = comments.size() - 1; i >= 0; i--) {
                result = result.replace("__CMT_TOKEN_" + i + "__", comments.get(i));
            }
            return result;
        }

        private String expandKotlinStringTemplatesToJava(String literal) {
            if (literal == null || literal.length() < 2) return literal;
            // Handle triple-quoted raw strings """..."""
            if (literal.startsWith("\"\"\"") && literal.endsWith("\"\"\"") && literal.length() >= 6) {
                String inner = literal.substring(3, literal.length() - 3)
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n");
                literal = "\"" + inner + "\"";
            }
            if (!literal.startsWith("\"") || !literal.endsWith("\"") || !literal.contains("$")) {
                return literal;
            }
            String body = literal.substring(1, literal.length() - 1);
            StringBuilder sb = new StringBuilder();
            List<String> parts = new ArrayList<>();
            int i = 0;
            int n = body.length();

            while (i < n) {
                char c = body.charAt(i);
                if (c == '\\' && i + 1 < n) {
                    sb.append(c).append(body.charAt(i + 1));
                    i += 2;
                    continue;
                }
                if (c == '$' && i + 1 < n) {
                    if (body.charAt(i + 1) == '{') {
                        int close = body.indexOf('}', i + 2);
                        if (close > i + 2) {
                            if (sb.length() > 0) {
                                parts.add("\"" + sb.toString() + "\"");
                                sb.setLength(0);
                            }
                            String expr = body.substring(i + 2, close).trim();
                            expr = expr.replace(".size", ".size()")
                                    .replace(".message", ".getMessage()");
                            if (expr.matches("^[A-Za-z0-9_.()]+$")) {
                                parts.add(expr);
                            } else {
                                parts.add("(" + expr + ")");
                            }
                            i = close + 1;
                            continue;
                        }
                    } else if (Character.isJavaIdentifierStart(body.charAt(i + 1))) {
                        int j = i + 1;
                        while (j < n && Character.isJavaIdentifierPart(body.charAt(j))) {
                            j++;
                        }
                        if (sb.length() > 0) {
                            parts.add("\"" + sb.toString() + "\"");
                            sb.setLength(0);
                        }
                        String varName = body.substring(i + 1, j);
                        parts.add(varName);
                        i = j;
                        continue;
                    }
                }
                sb.append(c);
                i++;
            }

            if (parts.isEmpty()) {
                return literal;
            }
            if (sb.length() > 0) {
                parts.add("\"" + sb.toString() + "\"");
            }
            StringBuilder joined = new StringBuilder();
            for (int k = 0; k < parts.size(); k++) {
                if (k > 0) joined.append(" + ");
                joined.append(parts.get(k));
            }
            return joined.toString();
        }
    }

    /**
     * Pre-normalizes multi-line array initializers and joins multi-line headers/expressions
     * without ever merging across `{` or `}` block boundaries.
     */
    private static List<String> normalizeMultilineStatements(String maskedCode) {
        String pre = maskedCode;
        // Normalize multi-line array allocations before line splitting so `new int[] {\n 10, 20 \n}` stays intact
        pre = Pattern.compile("\\bnew\\s+int\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("intArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+long\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("longArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+double\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("doubleArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+float\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("floatArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+boolean\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("booleanArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+byte\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("byteArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+short\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("shortArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+char\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("charArrayOf($1)");
        pre = Pattern.compile("\\bnew\\s+[A-Za-z0-9_<>]+\\s*\\[\\s*\\]\\s*\\{([^;{}]*)\\}", Pattern.DOTALL)
                .matcher(pre).replaceAll("arrayOf($1)");

        String[] rawLines = pre.split("\n", -1);
        List<String> normalized = new ArrayList<>();
        StringBuilder pending = new StringBuilder();
        int openParen = 0;

        for (String raw : rawLines) {
            String trimmed = raw.trim();
            if (pending.length() == 0) {
                if (trimmed.isEmpty() || isStandaloneCommentToken(trimmed)) {
                    normalized.add(raw);
                    continue;
                }
                // Never start multi-line paren joining if the line opens a `{` block (e.g. lambda/listener)
                if (trimmed.endsWith("{") || trimmed.endsWith("}")) {
                    normalized.add(raw);
                    continue;
                }
                openParen = countNetChars(trimmed, '(', ')');
                boolean trailingContinuation = trimmed.endsWith(",")
                        || trimmed.endsWith("&&")
                        || trimmed.endsWith("||")
                        || (trimmed.endsWith("+") && !trimmed.endsWith("++"))
                        || (trimmed.endsWith("-") && !trimmed.endsWith("--"))
                        || trimmed.endsWith("extends")
                        || trimmed.endsWith("implements");
                if (openParen > 0 || trailingContinuation) {
                    pending.append(trimmed);
                } else {
                    normalized.add(raw);
                }
            } else {
                if (isStandaloneCommentToken(trimmed)) {
                    normalized.add(trimmed);
                    continue;
                }
                pending.append(" ").append(trimmed);
                openParen = countNetChars(pending.toString(), '(', ')');
                String current = pending.toString().trim();
                boolean trailingContinuation = current.endsWith(",")
                        || current.endsWith("&&")
                        || current.endsWith("||")
                        || (current.endsWith("+") && !current.endsWith("++"))
                        || (current.endsWith("-") && !current.endsWith("--"))
                        || current.endsWith("extends")
                        || current.endsWith("implements");
                if (openParen <= 0 && !trailingContinuation || current.endsWith("{") || current.endsWith(";")) {
                    normalized.add(current);
                    pending.setLength(0);
                    openParen = 0;
                }
            }
        }
        if (pending.length() > 0) {
            normalized.add(pending.toString());
        }
        return normalized;
    }

    private static boolean isStandaloneCommentToken(String trimmed) {
        return trimmed.matches("^__CMT_TOKEN_\\d+__$");
    }

    private static int countNetChars(String s, char open, char close) {
        int net = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == open) net++;
            else if (c == close) net--;
        }
        return net;
    }

    private static class ClassScopeInfo {
        final String className;
        final int braceDepth;
        final List<String> staticMembers = new ArrayList<>();

        ClassScopeInfo(String className, int braceDepth) {
            this.className = className;
            this.braceDepth = braceDepth;
        }
    }

    // =========================================================================================
    // 1. JAVA -> KOTLIN CONVERTER ENGINE
    // =========================================================================================
    private static String convertJavaToKotlin(String javaCode, Set<String> knownGetters, Set<String> knownSetters) {
        LiteralVault vault = new LiteralVault();
        String masked = vault.maskLiteralsAndComments(javaCode);

        // Pre-transform anonymous inner listeners and Runnables with exact brace balancing
        masked = transformJavaAnonymousListeners(masked);

        List<String> lines = normalizeMultilineStatements(masked);
        List<String> outputLines = new ArrayList<>();
        List<ClassScopeInfo> classStack = new ArrayList<>();

        boolean insideSwitch = false;
        int switchBraceDepth = 0;
        List<String> pendingCaseLabels = new ArrayList<>();
        boolean caseBlockOpen = false;
        int currentBraceDepth = 0;
        Set<String> nullableVars = new LinkedHashSet<>();
        Set<String> reassignedVars = scanReassignedVariables(lines);

        for (int i = 0; i < lines.size(); i++) {
            String rawLine = lines.get(i);
            String trimmed = rawLine.trim();

            if (trimmed.isEmpty()) {
                outputLines.add("");
                continue;
            }

            if (isStandaloneCommentToken(trimmed)) {
                outputLines.add(trimmed);
                continue;
            }

            if (trimmed.startsWith("package ")) {
                outputLines.add(stripTrailingSemicolon(trimmed));
                continue;
            }

            if (trimmed.startsWith("import ")) {
                String imp = stripTrailingSemicolon(trimmed);
                if (imp.contains("java.util.Arrays") || imp.contains("java.util.Collectors")
                        || imp.contains("java.util.Map") || imp.contains("java.util.List")
                        || imp.contains("java.util.Set")
                        || imp.contains("androidx.annotation.NonNull")
                        || imp.contains("androidx.annotation.Nullable")) {
                    continue;
                }
                outputLines.add(imp);
                continue;
            }

            if (trimmed.startsWith("@")) {
                if (trimmed.equals("@Override") || trimmed.equals("@NonNull") || trimmed.equals("@Nullable")) {
                    continue;
                }
                outputLines.add(trimmed);
                continue;
            }

            int netBraces = countNetChars(trimmed, '{', '}');
            ClassScopeInfo currentClass = classStack.isEmpty() ? null : classStack.get(classStack.size() - 1);

            // Handle active switch -> when block
            if (insideSwitch) {
                if (trimmed.startsWith("case ") && trimmed.endsWith(":")) {
                    String caseVal = trimmed.substring(5, trimmed.length() - 1).trim();
                    pendingCaseLabels.add(convertJavaExpressionToKotlin(caseVal, nullableVars, knownGetters, knownSetters));
                    continue;
                }
                if (trimmed.startsWith("case ") && trimmed.contains("->")) {
                    if (caseBlockOpen) {
                        outputLines.add("}");
                        caseBlockOpen = false;
                    }
                    String rest = stripTrailingSemicolon(trimmed.substring(5).trim());
                    outputLines.add(convertJavaExpressionToKotlin(rest, nullableVars, knownGetters, knownSetters));
                    pendingCaseLabels.clear();
                    continue;
                }
                if (trimmed.startsWith("case ") && trimmed.contains(":")) {
                    int colonIdx = trimmed.indexOf(':');
                    String caseVal = trimmed.substring(5, colonIdx).trim();
                    pendingCaseLabels.add(convertJavaExpressionToKotlin(caseVal, nullableVars, knownGetters, knownSetters));
                    String afterColon = stripTrailingSemicolon(trimmed.substring(colonIdx + 1).trim());
                    if (caseBlockOpen) {
                        outputLines.add("}");
                        caseBlockOpen = false;
                    }
                    String joinedCases = joinList(pendingCaseLabels, ", ");
                    pendingCaseLabels.clear();
                    if (!afterColon.isEmpty() && !afterColon.equals("break")) {
                        outputLines.add(joinedCases + " -> " + convertJavaStatementToKotlin(afterColon, nullableVars, reassignedVars, knownGetters, knownSetters));
                    } else {
                        outputLines.add(joinedCases + " -> {");
                        caseBlockOpen = true;
                    }
                    continue;
                }
                if (trimmed.startsWith("default:")) {
                    if (caseBlockOpen) {
                        outputLines.add("}");
                        caseBlockOpen = false;
                    }
                    pendingCaseLabels.clear();
                    String afterColon = stripTrailingSemicolon(trimmed.substring(8).trim());
                    if (!afterColon.isEmpty() && !afterColon.equals("break")) {
                        outputLines.add("else -> " + convertJavaStatementToKotlin(afterColon, nullableVars, reassignedVars, knownGetters, knownSetters));
                    } else {
                        outputLines.add("else -> {");
                        caseBlockOpen = true;
                    }
                    continue;
                }
                if (trimmed.equals("break;")) {
                    if (caseBlockOpen) {
                        outputLines.add("}");
                        caseBlockOpen = false;
                    }
                    continue;
                }
                if (!pendingCaseLabels.isEmpty()) {
                    if (caseBlockOpen) {
                        outputLines.add("}");
                    }
                    String joinedCases = joinList(pendingCaseLabels, ", ");
                    pendingCaseLabels.clear();
                    outputLines.add(joinedCases + " -> {");
                    caseBlockOpen = true;
                }
                if (currentBraceDepth + netBraces < switchBraceDepth) {
                    if (caseBlockOpen) {
                        outputLines.add("}");
                        caseBlockOpen = false;
                    }
                    insideSwitch = false;
                    outputLines.add("}");
                    currentBraceDepth += netBraces;
                    continue;
                }
            }

            // Detect switch (expr) {
            Matcher switchMatcher = Pattern.compile("^switch\\s*\\((.+)\\)\\s*\\{$").matcher(trimmed);
            if (switchMatcher.find()) {
                insideSwitch = true;
                pendingCaseLabels.clear();
                caseBlockOpen = false;
                currentBraceDepth += netBraces;
                switchBraceDepth = currentBraceDepth;
                String expr = convertJavaExpressionToKotlin(switchMatcher.group(1).trim(), nullableVars, knownGetters, knownSetters);
                outputLines.add("when (" + expr + ") {");
                continue;
            }

            // Detect Class / Interface / Enum declaration
            Matcher classMatcher = Pattern.compile(
                    "^(?:(public|private|protected)\\s+)?((?:(?:static|final|abstract)\\s+)*)(class|interface|enum)\\s+([A-Za-z0-9_<>]+)(?:\\s+extends\\s+([A-Za-z0-9_<>.]+))?(?:\\s+implements\\s+([^{]+))?\\s*\\{?$"
            ).matcher(trimmed);
            if (classMatcher.find()) {
                String vis = classMatcher.group(1);
                String mods = classMatcher.group(2) != null ? classMatcher.group(2) : "";
                String kind = classMatcher.group(3);
                String name = classMatcher.group(4);
                String ext = classMatcher.group(5);
                String impl = classMatcher.group(6);

                String simpleName = name.replaceAll("<.*>", "").trim();
                int targetDepth = currentBraceDepth + netBraces;
                classStack.add(new ClassScopeInfo(simpleName, targetDepth));

                StringBuilder ktHeader = new StringBuilder();
                if ("private".equals(vis) || "protected".equals(vis)) {
                    ktHeader.append(vis).append(" ");
                }
                if (mods.contains("abstract") && !"interface".equals(kind)) {
                    ktHeader.append("abstract ");
                }
                if ("enum".equals(kind)) {
                    ktHeader.append("enum class ").append(name);
                } else {
                    ktHeader.append(kind).append(" ").append(name);
                }

                List<String> parents = new ArrayList<>();
                boolean hasSecondarySuperConstructor = hasConstructorWithSuperCall(lines, i + 1, simpleName);
                if (ext != null && !ext.trim().isEmpty()) {
                    String ktExt = mapJavaTypeToKotlin(ext.trim());
                    if (hasSecondarySuperConstructor) {
                        parents.add(ktExt);
                    } else {
                        parents.add(ktExt + "()");
                    }
                }
                if (impl != null && !impl.trim().isEmpty()) {
                    for (String p : splitTopLevel(impl, ',')) {
                        if (!p.trim().isEmpty()) {
                            parents.add(mapJavaTypeToKotlin(p.trim()));
                        }
                    }
                }
                if (!parents.isEmpty()) {
                    ktHeader.append(" : ").append(joinList(parents, ", "));
                }
                if (trimmed.endsWith("{")) {
                    ktHeader.append(" {");
                }
                outputLines.add(ktHeader.toString());
                currentBraceDepth = targetDepth;
                continue;
            }

            // Detect Constructor declaration (matches current enclosing class OR any `[vis] ClassName(params) {` without return type)
            Matcher ctorMatcher = Pattern.compile(
                    "^(?:(public|private|protected)\\s+)?([A-Z][A-Za-z0-9_]*)\\s*\\(([^)]*)\\)\\s*\\{$"
            ).matcher(trimmed);
            if (ctorMatcher.find()) {
                String vis = ctorMatcher.group(1);
                String ctorName = ctorMatcher.group(2).trim();
                if (currentClass != null && ctorName.equals(currentClass.className)) {
                    String params = convertJavaParamsToKotlin(ctorMatcher.group(3).trim(), nullableVars);
                    String visPrefix = ("private".equals(vis) || "protected".equals(vis)) ? vis + " " : "";

                    String delegation = "";
                    if (i + 1 < lines.size()) {
                        String nextTrim = lines.get(i + 1).trim();
                        Matcher superMatcher = Pattern.compile("^(super|this)\\s*\\((.*)\\);$").matcher(nextTrim);
                        if (superMatcher.find()) {
                            String callType = superMatcher.group(1);
                            String args = convertJavaExpressionToKotlin(superMatcher.group(2).trim(), nullableVars, knownGetters, knownSetters);
                            delegation = " : " + callType + "(" + args + ")";
                            i++;
                        }
                    }
                    outputLines.add(visPrefix + "constructor(" + params + ")" + delegation + " {");
                    currentBraceDepth += netBraces;
                    continue;
                }
            }

            // Detect Method declaration (ensure returnTypeRaw is NOT a visibility modifier like `public`)
            boolean hasOverrideBefore = hasPreviousAnnotation(lines, i, "@Override");
            Matcher methodMatcher = Pattern.compile(
                    "^(?:(@[A-Za-z0-9_]+(?:\\([^)]*\\))?)\\s+)*(?:(public|private|protected)\\s+)?((?:(?:static|final|abstract|synchronized)\\s+)*)(?:<([^>]+)>\\s+)?([A-Za-z0-9_<>\\[\\]., ?]+)\\s+([A-Za-z0-9_]+)\\s*\\(([^)]*)\\)(?:\\s*throws\\s+[A-Za-z0-9_., ]+)?\\s*(\\{|;)$"
            ).matcher(trimmed);

            if (methodMatcher.find()
                    && !isControlKeyword(methodMatcher.group(5))
                    && !isJavaModifierWord(methodMatcher.group(5))
                    && !isControlKeyword(methodMatcher.group(6))) {
                String inlineAnno = methodMatcher.group(1);
                String vis = methodMatcher.group(2);
                String mods = methodMatcher.group(3) != null ? methodMatcher.group(3) : "";
                String typeParam = methodMatcher.group(4);
                String returnTypeRaw = methodMatcher.group(5).trim();
                String methodName = methodMatcher.group(6).trim();
                String paramsRaw = methodMatcher.group(7).trim();
                String ending = methodMatcher.group(8);

                boolean isStatic = mods.contains("static");
                boolean isAbstract = mods.contains("abstract");
                boolean isOverride = hasOverrideBefore || "@Override".equals(inlineAnno) || isKnownAndroidLifecycleMethod(methodName);

                if (isStatic && "main".equals(methodName) && paramsRaw.contains("String")) {
                    outputLines.add("fun main(args: Array<String>) {");
                    currentBraceDepth += netBraces;
                    continue;
                }

                // Pre-scan method body for null checks on parameters so parameters are marked nullable immediately
                Set<String> methodNullCheckedParams = scanMethodNullCheckedParams(lines, i, paramsRaw);
                String ktParams = convertJavaParamsToKotlinWithNullCheck(paramsRaw, nullableVars, methodNullCheckedParams);
                String ktReturnType = mapJavaTypeToKotlin(returnTypeRaw);

                StringBuilder fnHeader = new StringBuilder();
                if ("private".equals(vis)) {
                    fnHeader.append("private ");
                } else if ("protected".equals(vis) && !isOverride) {
                    fnHeader.append("protected ");
                }
                if (isOverride) {
                    fnHeader.append("override ");
                }
                if (isAbstract) {
                    fnHeader.append("abstract ");
                }
                fnHeader.append("fun ");
                if (typeParam != null && !typeParam.trim().isEmpty()) {
                    fnHeader.append("<").append(typeParam.replace(" extends ", " : ")).append("> ");
                }
                fnHeader.append(methodName).append("(").append(ktParams).append(")");
                if (!"Unit".equals(ktReturnType)) {
                    fnHeader.append(": ").append(ktReturnType);
                }
                if ("{".equals(ending)) {
                    fnHeader.append(" {");
                }

                if (isStatic && currentClass != null) {
                    List<String> staticMethodLines = new ArrayList<>();
                    staticMethodLines.add(fnHeader.toString());
                    if ("{".equals(ending)) {
                        int depth = 1;
                        while (i + 1 < lines.size() && depth > 0) {
                            i++;
                            String sLine = lines.get(i).trim();
                            depth += countNetChars(sLine, '{', '}');
                            if (depth == 0 && sLine.equals("}")) {
                                staticMethodLines.add("}");
                            } else {
                                staticMethodLines.add(convertJavaControlOrStatement(sLine, nullableVars, reassignedVars, knownGetters, knownSetters));
                            }
                        }
                    }
                    currentClass.staticMembers.addAll(staticMethodLines);
                    continue;
                }

                outputLines.add(fnHeader.toString());
                currentBraceDepth += netBraces;
                continue;
            }

            // Detect Class Field / Constant declaration (at current class scope, including initializers with `(` like `new ArrayList<>()`)
            if (currentClass != null && currentBraceDepth == currentClass.braceDepth
                    && trimmed.endsWith(";") && !trimmed.startsWith("return ") && !trimmed.startsWith("throw ")) {
                List<String> fieldOut = tryParseJavaDeclaration(
                        stripTrailingSemicolon(trimmed),
                        true,
                        nullableVars,
                        reassignedVars,
                        knownGetters,
                        knownSetters,
                        currentClass.staticMembers
                );
                if (fieldOut != null) {
                    outputLines.addAll(fieldOut);
                    continue;
                }
            }

            // Detect closing brace of current class -> inject companion object at class scope
            if (trimmed.equals("}") && currentClass != null && currentBraceDepth == currentClass.braceDepth) {
                if (!currentClass.staticMembers.isEmpty()) {
                    outputLines.add("");
                    outputLines.add("companion object {");
                    outputLines.addAll(currentClass.staticMembers);
                    outputLines.add("}");
                    currentClass.staticMembers.clear();
                }
                classStack.remove(classStack.size() - 1);
                outputLines.add("}");
                currentBraceDepth += netBraces;
                continue;
            }

            // General statement / control structure conversion
            String convertedLine = convertJavaControlOrStatement(trimmed, nullableVars, reassignedVars, knownGetters, knownSetters);
            outputLines.add(convertedLine);
            currentBraceDepth += netBraces;
        }

        while (!classStack.isEmpty()) {
            ClassScopeInfo leftover = classStack.remove(classStack.size() - 1);
            if (!leftover.staticMembers.isEmpty()) {
                outputLines.add("");
                outputLines.add("companion object {");
                outputLines.addAll(leftover.staticMembers);
                outputLines.add("}");
            }
        }

        String joined = joinList(outputLines, "\n");
        String restored = vault.restoreForKotlin(joined);
        return formatIndentation(restored);
    }

    private static boolean hasConstructorWithSuperCall(List<String> lines, int startIdx, String className) {
        for (int i = startIdx; i < lines.size(); i++) {
            String t = lines.get(i).trim();
            if (t.matches("^(?:(public|private|protected)\\s+)?" + Pattern.quote(className) + "\\s*\\(.*\\)\\s*\\{$")) {
                if (i + 1 < lines.size() && lines.get(i + 1).trim().startsWith("super(")) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean hasPreviousAnnotation(List<String> lines, int index, String anno) {
        for (int k = index - 1; k >= 0; k--) {
            String prev = lines.get(k).trim();
            if (prev.isEmpty() || isStandaloneCommentToken(prev)) continue;
            if (prev.equals(anno) || prev.startsWith(anno + "(")) return true;
            if (!prev.startsWith("@")) return false;
        }
        return false;
    }

    private static boolean isKnownAndroidLifecycleMethod(String name) {
        return "onCreate".equals(name) || "onStart".equals(name) || "onResume".equals(name)
                || "onPause".equals(name) || "onStop".equals(name) || "onDestroy".equals(name)
                || "onCreateView".equals(name) || "onViewCreated".equals(name)
                || "onBindViewHolder".equals(name) || "onCreateViewHolder".equals(name)
                || "getItemCount".equals(name) || "onDraw".equals(name)
                || "onMeasure".equals(name) || "onBackPressed".equals(name)
                || "toString".equals(name) || "hashCode".equals(name) || "equals".equals(name);
    }

    /**
     * Brace-balanced anonymous SAM listener transformer.
     * Converts `.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { ... } });`
     * into `.setOnClickListener { ... }` with balanced single `{` and `}`, preserving all inner statements on separate lines.
     */
    private static String transformJavaAnonymousListeners(String code) {
        String result = code;
        Pattern samHeader = Pattern.compile(
                "(\\.[A-Za-z0-9_]+|runOnUiThread)\\s*\\(\\s*new\\s+(?:[A-Za-z0-9_.]*\\.)?(?:OnClickListener|OnLongClickListener|OnCheckedChangeListener|Runnable)\\s*\\(\\s*\\)\\s*\\{\\s*(?:@Override\\s*)?public\\s+(?:void|boolean)\\s+[A-Za-z0-9_]+\\s*\\(([^)]*)\\)\\s*\\{",
                Pattern.DOTALL
        );

        int safety = 0;
        while (safety++ < 30) {
            Matcher m = samHeader.matcher(result);
            if (!m.find()) break;

            String callPrefix = m.group(1);
            String paramsRaw = m.group(2).trim();
            int methodBodyStart = m.end(); // right after method's opening `{`

            // Find matching `}` of the inner callback method (`onClick` / `run`)
            int depth = 1;
            int idx = methodBodyStart;
            while (idx < result.length() && depth > 0) {
                char c = result.charAt(idx);
                if (c == '{') depth++;
                else if (c == '}') depth--;
                idx++;
            }
            if (depth != 0) break;
            int methodCloseBraceIdx = idx - 1;

            // After method's `}`, expect whitespace + `}` (of anonymous class) + `)` (of method call) + optional `;`
            Matcher closeTail = Pattern.compile("^\\s*\\}\\s*\\)\\s*;?").matcher(result.substring(idx));
            if (!closeTail.find()) break;
            int fullEndIdx = idx + closeTail.end();

            String bodyContent = result.substring(methodBodyStart, methodCloseBraceIdx);
            String lambdaParamHeader = "";
            if (!paramsRaw.isEmpty()) {
                List<String> pList = splitTopLevel(paramsRaw, ',');
                List<String> pNames = new ArrayList<>();
                for (String p : pList) {
                    String[] tokens = p.replace("final ", "").trim().split("\\s+");
                    if (tokens.length > 0) {
                        pNames.add(tokens[tokens.length - 1]);
                    }
                }
                boolean anyUsed = false;
                for (String pn : pNames) {
                    if (Pattern.compile("\\b" + Pattern.quote(pn) + "\\b").matcher(bodyContent).find()) {
                        anyUsed = true;
                        break;
                    }
                }
                if (anyUsed) {
                    lambdaParamHeader = " " + joinList(pNames, ", ") + " ->";
                }
            }

            String replacement = callPrefix + " {" + lambdaParamHeader + bodyContent + "}";
            result = result.substring(0, m.start()) + replacement + result.substring(fullEndIdx);
        }
        return result;
    }

    private static Set<String> scanReassignedVariables(List<String> lines) {
        Set<String> reassigned = new LinkedHashSet<>();
        Pattern assignP = Pattern.compile("(?:^|[;{\\s(])(?:this\\.)?([a-zA-Z_][a-zA-Z0-9_]*)\\s*(?:\\+\\+|--|\\+=|-=|\\*=|/=|%=|=(?!=))");
        Map<String, Integer> eqCount = new HashMap<>();
        for (String line : lines) {
            String t = line.trim();
            Matcher incDec = Pattern.compile("\\b([a-zA-Z_][a-zA-Z0-9_]*)\\s*(?:\\+\\+|--|\\+=|-=|\\*=|/=|%=)").matcher(t);
            while (incDec.find()) {
                reassigned.add(incDec.group(1));
            }
            Matcher m = assignP.matcher(t);
            while (m.find()) {
                String v = m.group(1);
                int c = eqCount.getOrDefault(v, 0) + 1;
                eqCount.put(v, c);
                if (c > 1 || t.startsWith(v + " =") || t.startsWith("this." + v + " =")) {
                    reassigned.add(v);
                }
            }
        }
        return reassigned;
    }

    private static Set<String> scanMethodNullCheckedParams(List<String> lines, int methodStartIndex, String paramsRaw) {
        Set<String> result = new LinkedHashSet<>();
        if (paramsRaw == null || paramsRaw.trim().isEmpty()) return result;

        StringBuilder bodySb = new StringBuilder();
        int depth = countNetChars(lines.get(methodStartIndex), '{', '}');
        for (int j = methodStartIndex + 1; j < lines.size() && depth > 0; j++) {
            String bl = lines.get(j);
            depth += countNetChars(bl, '{', '}');
            bodySb.append(bl).append("\n");
        }
        String body = bodySb.toString();

        for (String part : splitTopLevel(paramsRaw, ',')) {
            String p = part.replaceAll("@[A-Za-z0-9_]+(?:\\([^)]*\\))?\\s*", "").replace("final ", "").replace("...", " ").trim();
            int sp = p.lastIndexOf(' ');
            if (sp > 0) {
                String pName = p.substring(sp + 1).replace("[]", "").trim();
                if (Pattern.compile("\\b" + Pattern.quote(pName) + "\\s*(?:==|!=)\\s*null\\b").matcher(body).find()
                        || Pattern.compile("\\bnull\\s*(?:==|!=)\\s*" + Pattern.quote(pName) + "\\b").matcher(body).find()
                        || body.contains("TextUtils.isEmpty(" + pName + ")")) {
                    result.add(pName);
                }
            }
        }
        return result;
    }

    private static boolean isJavaModifierWord(String word) {
        if (word == null) return false;
        String w = word.trim();
        return "public".equals(w) || "private".equals(w) || "protected".equals(w)
                || "static".equals(w) || "final".equals(w) || "abstract".equals(w)
                || "synchronized".equals(w) || "volatile".equals(w) || "transient".equals(w);
    }

    /**
     * Structured Java Declaration Parser (Requirements A & B):
     * Separates MODIFIERS, TYPE, VARIABLE NAME, and INITIALIZER so modifiers never leak into types
     * and variable names are never omitted before `:`.
     */
    private static List<String> tryParseJavaDeclaration(
            String stmtWithoutSemi,
            boolean isClassScope,
            Set<String> nullableVars,
            Set<String> reassignedVars,
            Set<String> knownGetters,
            Set<String> knownSetters,
            List<String> staticMembersCollector) {

        String rest = stmtWithoutSemi.trim();
        if (rest.isEmpty() || rest.endsWith("{") || rest.endsWith("}")) return null;

        boolean hasNullableAnno = rest.contains("@Nullable");
        rest = rest.replaceAll("@[A-Za-z0-9_]+(?:\\([^)]*\\))?\\s*", "").trim();

        String visibility = "";
        boolean isStatic = false;
        boolean isFinal = false;

        // 1. Strip all leading Java modifiers in any order
        while (true) {
            Matcher modM = Pattern.compile("^(public|private|protected|internal|static|final|volatile|transient)\\b\\s*").matcher(rest);
            if (!modM.find()) break;
            String mod = modM.group(1);
            if ("private".equals(mod) || "protected".equals(mod) || "internal".equals(mod)) {
                visibility = mod;
            } else if ("public".equals(mod)) {
                visibility = "public";
            } else if ("static".equals(mod)) {
                isStatic = true;
            } else if ("final".equals(mod)) {
                isFinal = true;
            }
            rest = rest.substring(modM.end()).trim();
        }

        if (rest.isEmpty()) return null;

        // 2. Scan Java Type (including generics `<...>` and array brackets `[]`)
        int n = rest.length();
        int i = 0;
        if (!Character.isJavaIdentifierStart(rest.charAt(0))) return null;

        int angleDepth = 0;
        while (i < n) {
            char c = rest.charAt(i);
            if (c == '<') {
                angleDepth++;
                i++;
            } else if (c == '>') {
                angleDepth--;
                i++;
                if (angleDepth == 0) {
                    while (i < n && (rest.charAt(i) == ' ' || rest.charAt(i) == '[' || rest.charAt(i) == ']')) {
                        if (rest.charAt(i) == ' ') {
                            // Only consume space if followed by `[`
                            int look = i;
                            while (look < n && rest.charAt(look) == ' ') look++;
                            if (look < n && rest.charAt(look) == '[') {
                                i = look;
                            } else {
                                break;
                            }
                        } else {
                            i++;
                        }
                    }
                    break;
                }
            } else if (angleDepth > 0) {
                i++;
            } else if (Character.isJavaIdentifierPart(c) || c == '.' || c == '[' || c == ']') {
                i++;
            } else {
                break;
            }
        }

        if (angleDepth != 0 || i == 0 || i >= n) return null;
        String rawType = rest.substring(0, i).trim();
        String declsPart = rest.substring(i).trim();

        if (rawType.isEmpty() || declsPart.isEmpty()
                || isControlKeyword(rawType) || isJavaModifierWord(rawType)
                || rawType.contains("(") || rawType.contains(")")) {
            return null;
        }

        // Verify declsPart starts with a valid variable name followed by `$`, `=`, `,`, or `[]`
        List<String> declarators = splitTopLevel(declsPart, ',');
        if (declarators.isEmpty()) return null;

        for (String d : declarators) {
            String dt = d.trim();
            Matcher dm = Pattern.compile("^([A-Za-z_$][A-Za-z0-9_$]*)(\\s*\\[\\s*\\])?(?:\\s*=\\s*(.+))?$").matcher(dt);
            if (!dm.find()) return null;
            String vName = dm.group(1);
            if (isControlKeyword(vName) || isJavaModifierWord(vName)) return null;
        }

        boolean isBoxedJavaType = "Integer".equals(rawType) || "Long".equals(rawType)
                || "Double".equals(rawType) || "Float".equals(rawType)
                || "Boolean".equals(rawType) || "Short".equals(rawType)
                || "Byte".equals(rawType) || "Character".equals(rawType);

        String ktType = mapJavaTypeToKotlin(rawType);
        String visPrefix = ("private".equals(visibility) || "protected".equals(visibility) || "internal".equals(visibility))
                ? visibility + " " : "";

        List<String> out = new ArrayList<>();
        for (String d : declarators) {
            String dt = d.trim();
            Matcher dm = Pattern.compile("^([A-Za-z_$][A-Za-z0-9_$]*)(\\s*\\[\\s*\\])?(?:\\s*=\\s*(.+))?$").matcher(dt);
            if (!dm.find()) continue;
            String vName = dm.group(1).trim();
            boolean cStyleArray = dm.group(2) != null;
            String initRaw = dm.group(3) != null ? dm.group(3).trim() : null;

            String effectiveKtType = cStyleArray ? mapJavaTypeToKotlin(rawType + "[]") : ktType;
            boolean isImmutable = isFinal || (!isClassScope && !reassignedVars.contains(vName));
            String valOrVar = isImmutable ? "val " : "var ";

            if (initRaw != null) {
                // Handle shorthand array initializer `{ 1, 2, 3 }`
                if (initRaw.startsWith("{") && initRaw.endsWith("}")) {
                    String innerArr = initRaw.substring(1, initRaw.length() - 1).trim();
                    if ("IntArray".equals(effectiveKtType)) initRaw = "intArrayOf(" + innerArr + ")";
                    else if ("LongArray".equals(effectiveKtType)) initRaw = "longArrayOf(" + innerArr + ")";
                    else if ("DoubleArray".equals(effectiveKtType)) initRaw = "doubleArrayOf(" + innerArr + ")";
                    else if ("FloatArray".equals(effectiveKtType)) initRaw = "floatArrayOf(" + innerArr + ")";
                    else if ("BooleanArray".equals(effectiveKtType)) initRaw = "booleanArrayOf(" + innerArr + ")";
                    else initRaw = "arrayOf(" + innerArr + ")";
                }

                String ktInit = convertJavaExpressionToKotlin(initRaw, nullableVars, knownGetters, knownSetters);
                boolean rhsIsNullable = "null".equals(ktInit) || hasNullableAnno
                        || (isBoxedJavaType && (ktInit.contains(".value") || ktInit.contains("[") || ktInit.contains(".get(")));
                String finalType = (rhsIsNullable && !effectiveKtType.endsWith("?"))
                        ? effectiveKtType + "?" : effectiveKtType;
                if (finalType.endsWith("?")) {
                    nullableVars.add(vName);
                }

                if (isClassScope && isStatic && staticMembersCollector != null) {
                    boolean canConst = isFinal && isPrimitiveOrStringKotlinType(effectiveKtType) && !ktInit.contains("(");
                    if (canConst) {
                        staticMembersCollector.add(visPrefix + "const val " + vName + " = " + ktInit);
                    } else {
                        staticMembersCollector.add(visPrefix + valOrVar + vName + ": " + finalType + " = " + ktInit);
                    }
                } else if (isClassScope) {
                    out.add(visPrefix + valOrVar + vName + ": " + finalType + " = " + ktInit);
                } else {
                    // Local variable scope: omit redundant explicit type when idiomatic, keep for nullables / boxed / collections
                    boolean keepExplicitType = "null".equals(ktInit) || finalType.endsWith("?")
                            || finalType.startsWith("Mutable");
                    if (keepExplicitType) {
                        out.add(valOrVar + vName + ": " + finalType + " = " + ktInit);
                    } else {
                        out.add(valOrVar + vName + " = " + ktInit);
                    }
                }
            } else {
                String defaultInit = getDefaultKotlinInitializer(effectiveKtType);
                if (isClassScope && !isStatic && !hasNullableAnno && "null".equals(defaultInit)
                        && reassignedVars != null && reassignedVars.contains(vName)) {
                    out.add(visPrefix + "lateinit var " + vName + ": " + effectiveKtType);
                } else {
                    nullableVars.add(vName);
                    String nullableType = defaultInit.equals("null") && !effectiveKtType.endsWith("?")
                            ? effectiveKtType + "?" : effectiveKtType;
                    String lineOut = visPrefix + "var " + vName + ": " + nullableType + " = " + defaultInit;
                    if (isClassScope && isStatic && staticMembersCollector != null) {
                        staticMembersCollector.add(lineOut);
                    } else {
                        out.add(lineOut);
                    }
                }
            }
        }
        return out;
    }

    private static String convertJavaControlOrStatement(
            String line,
            Set<String> nullableVars,
            Set<String> reassignedVars,
            Set<String> knownGetters,
            Set<String> knownSetters) {
        // 1. try-with-resources: try (Type res = expr) {
        Matcher tryResMatcher = Pattern.compile("^try\\s*\\(([^=]+)=([^)]+)\\)\\s*\\{$").matcher(line);
        if (tryResMatcher.find()) {
            String left = tryResMatcher.group(1).replace("final ", "").trim();
            String right = convertJavaExpressionToKotlin(tryResMatcher.group(2).trim(), nullableVars, knownGetters, knownSetters);
            String[] parts = left.split("\\s+");
            String varName = parts[parts.length - 1];
            return "val " + varName + " = " + right + "\ntry {";
        }

        // 2. catch (Ex1 | Ex2 e) { or catch (Exception e) {
        Matcher catchMatcher = Pattern.compile("^(\\}?\\s*)catch\\s*\\(([^)]+)\\)\\s*\\{$").matcher(line);
        if (catchMatcher.find()) {
            String prefix = catchMatcher.group(1).trim();
            String inside = catchMatcher.group(2).replace("final ", "").trim();
            int lastSpace = inside.lastIndexOf(' ');
            if (lastSpace > 0) {
                String exTypeRaw = inside.substring(0, lastSpace).trim();
                String exVar = inside.substring(lastSpace + 1).trim();
                String ktExType = exTypeRaw.contains("|") ? "Exception" : mapJavaTypeToKotlin(exTypeRaw);
                return (prefix.isEmpty() ? "" : prefix + " ") + "catch (" + exVar + ": " + ktExType + ") {";
            }
        }

        // 3. Classic for-loop: for (int i = 0; i < n; i++) {
        Matcher forClassic = Pattern.compile(
                "^for\\s*\\(\\s*(?:int|long|var)?\\s*([A-Za-z0-9_]+)\\s*=\\s*([^;]+);\\s*\\1\\s*(<|<=|>|>=)\\s*([^;]+);\\s*([^)]+)\\)\\s*\\{$"
        ).matcher(line);
        if (forClassic.find()) {
            String var = forClassic.group(1).trim();
            String start = convertJavaExpressionToKotlin(forClassic.group(2).trim(), nullableVars, knownGetters, knownSetters);
            String op = forClassic.group(3).trim();
            String end = convertJavaExpressionToKotlin(forClassic.group(4).trim(), nullableVars, knownGetters, knownSetters);
            String stepExpr = forClassic.group(5).trim();

            String stepSuffix = "";
            Matcher plusStep = Pattern.compile("^" + Pattern.quote(var) + "\\s*\\+=\\s*(.+)$").matcher(stepExpr);
            Matcher minusStep = Pattern.compile("^" + Pattern.quote(var) + "\\s*-=\\s*(.+)$").matcher(stepExpr);
            if (plusStep.find() && !"1".equals(plusStep.group(1).trim())) {
                stepSuffix = " step " + convertJavaExpressionToKotlin(plusStep.group(1).trim(), nullableVars, knownGetters, knownSetters);
            } else if (minusStep.find() && !"1".equals(minusStep.group(1).trim())) {
                stepSuffix = " step " + convertJavaExpressionToKotlin(minusStep.group(1).trim(), nullableVars, knownGetters, knownSetters);
            }

            if ("<".equals(op)) {
                return "for (" + var + " in " + start + " until " + end + stepSuffix + ") {";
            } else if ("<=".equals(op)) {
                return "for (" + var + " in " + start + ".." + end + stepSuffix + ") {";
            } else if (">=".equals(op)) {
                return "for (" + var + " in " + start + " downTo " + end + stepSuffix + ") {";
            } else if (">".equals(op)) {
                return "for (" + var + " in " + start + " downTo (" + end + " + 1)" + stepSuffix + ") {";
            }
        }

        // 4. Enhanced for-each over Map.Entry: for (Map.Entry<K, V> entry : map.entrySet()) {
        Matcher mapForEach = Pattern.compile(
                "^for\\s*\\(\\s*(?:final\\s+)?(?:Map\\.)?Entry<[^>]+>\\s+([A-Za-z0-9_]+)\\s*:\\s*([A-Za-z0-9_.()]+)\\.entrySet\\(\\)\\s*\\)\\s*\\{$"
        ).matcher(line);
        if (mapForEach.find()) {
            String entryVar = mapForEach.group(1).trim();
            String mapExpr = convertJavaExpressionToKotlin(mapForEach.group(2).trim(), nullableVars, knownGetters, knownSetters);
            return "for (" + entryVar + " in " + mapExpr + ".entries) {";
        }

        // 5. Enhanced for-each: for (Type item : collection) {
        Matcher forEach = Pattern.compile(
                "^for\\s*\\(\\s*(?:final\\s+)?([A-Za-z0-9_<>\\[\\].?]+)\\s+([A-Za-z0-9_]+)\\s*:\\s*(.+)\\)\\s*\\{$"
        ).matcher(line);
        if (forEach.find()) {
            String itemVar = forEach.group(2).trim();
            String iterable = convertJavaExpressionToKotlin(forEach.group(3).trim(), nullableVars, knownGetters, knownSetters);
            return "for (" + itemVar + " in " + iterable + ") {";
        }

        // 6. If / else if / while
        Matcher condMatcher = Pattern.compile("^(\\}?\\s*(?:else\\s+if|if|while))\\s*\\((.+)\\)\\s*(\\{?)$").matcher(line);
        if (condMatcher.find()) {
            String kw = condMatcher.group(1).trim();
            String cond = convertJavaExpressionToKotlin(condMatcher.group(2).trim(), nullableVars, knownGetters, knownSetters);
            String brace = condMatcher.group(3).trim();
            return kw + " (" + cond + ")" + (brace.isEmpty() ? "" : " {");
        }

        // 7. Standard statement
        String noSemi = stripTrailingSemicolon(line);
        return convertJavaStatementToKotlin(noSemi, nullableVars, reassignedVars, knownGetters, knownSetters);
    }

    private static String convertJavaStatementToKotlin(
            String stmt,
            Set<String> nullableVars,
            Set<String> reassignedVars,
            Set<String> knownGetters,
            Set<String> knownSetters) {
        String trimmed = stmt.trim();
        if (trimmed.isEmpty() || trimmed.equals("{") || trimmed.equals("}")) {
            return trimmed;
        }

        if (trimmed.startsWith("System.out.println(") && trimmed.endsWith(")")) {
            String inner = trimmed.substring("System.out.println(".length(), trimmed.length() - 1);
            return "println(" + convertJavaExpressionToKotlin(inner, nullableVars, knownGetters, knownSetters) + ")";
        }
        if (trimmed.startsWith("System.out.print(") && trimmed.endsWith(")")) {
            String inner = trimmed.substring("System.out.print(".length(), trimmed.length() - 1);
            return "print(" + convertJavaExpressionToKotlin(inner, nullableVars, knownGetters, knownSetters) + ")";
        }

        if (trimmed.equals("return")) return "return";
        if (trimmed.startsWith("return ")) {
            return "return " + convertJavaExpressionToKotlin(trimmed.substring(7).trim(), nullableVars, knownGetters, knownSetters);
        }

        if (trimmed.startsWith("throw ")) {
            return "throw " + convertJavaExpressionToKotlin(trimmed.substring(6).trim(), nullableVars, knownGetters, knownSetters);
        }

        // Structured local variable declaration parser
        List<String> localDecl = tryParseJavaDeclaration(
                trimmed, false, nullableVars, reassignedVars, knownGetters, knownSetters, null
        );
        if (localDecl != null && !localDecl.isEmpty()) {
            return joinList(localDecl, "\n");
        }

        return convertJavaExpressionToKotlin(trimmed, nullableVars, knownGetters, knownSetters);
    }

    private static String convertJavaExpressionToKotlin(
            String expr,
            Set<String> nullableVars,
            Set<String> knownGetters,
            Set<String> knownSetters) {
        if (expr == null || expr.trim().isEmpty()) return "";
        String res = expr.trim();

        // 1. Array allocations
        res = Pattern.compile("\\bnew\\s+int\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("intArrayOf($1)");
        res = Pattern.compile("\\bnew\\s+long\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("longArrayOf($1)");
        res = Pattern.compile("\\bnew\\s+float\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("floatArrayOf($1)");
        res = Pattern.compile("\\bnew\\s+double\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("doubleArrayOf($1)");
        res = Pattern.compile("\\bnew\\s+boolean\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("booleanArrayOf($1)");
        res = Pattern.compile("\\bnew\\s+[A-Za-z0-9_<>]+\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL).matcher(res).replaceAll("arrayOf($1)");

        res = res.replaceAll("new\\s+int\\s*\\[([^\\]]+)\\]", "IntArray($1)");
        res = res.replaceAll("new\\s+byte\\s*\\[([^\\]]+)\\]", "ByteArray($1)");
        res = res.replaceAll("new\\s+long\\s*\\[([^\\]]+)\\]", "LongArray($1)");
        res = res.replaceAll("new\\s+float\\s*\\[([^\\]]+)\\]", "FloatArray($1)");
        res = res.replaceAll("new\\s+double\\s*\\[([^\\]]+)\\]", "DoubleArray($1)");
        res = res.replaceAll("new\\s+boolean\\s*\\[([^\\]]+)\\]", "BooleanArray($1)");
        res = res.replaceAll("new\\s+([A-Za-z0-9_]+)\\s*\\[([^\\]]+)\\]", "arrayOfNulls<$1>($2)");

        // 2. Collection & Stream Idioms
        res = res.replaceAll("Arrays\\.asList\\s*\\(([^)]*)\\)", "mutableListOf($1)");
        res = res.replaceAll("Collections\\.singletonList\\s*\\(([^)]*)\\)", "listOf($1)");
        res = res.replaceAll("Collections\\.emptyList\\s*\\(\\s*\\)", "emptyList()");
        res = res.replaceAll("Collections\\.emptyMap\\s*\\(\\s*\\)", "emptyMap()");
        res = res.replace(".stream()", "");
        res = res.replace(".collect(Collectors.toList())", ".toList()");
        res = res.replace(".collect(Collectors.toSet())", ".toSet()");

        // 3. Constructor instantiations: new ArrayList<>() -> ArrayList()
        res = res.replaceAll("\\bnew\\s+([A-Za-z0-9_.]+)\\s*<\\s*>\\s*\\(", "$1(");
        res = res.replaceAll("\\bnew\\s+([A-Za-z0-9_.<>]+)\\s*\\(", "$1(");

        // 4. Class literals: MainActivity.class -> MainActivity::class.java
        res = res.replaceAll("\\b([A-Za-z0-9_]+)\\.class\\b", "$1::class.java");
        res = res.replaceAll("\\b([A-Z][A-Za-z0-9_]*)\\.this\\b", "this@$1");

        // 5. instanceof
        res = res.replaceAll("!\\s*\\(\\s*([A-Za-z0-9_.()]+)\\s+instanceof\\s+([A-Za-z0-9_<>]+)\\s*\\)", "$1 !is $2");
        res = res.replaceAll("\\b([A-Za-z0-9_.()]+)\\s+instanceof\\s+([A-Za-z0-9_<>]+)\\b", "$1 is $2");

        // 6. .equals(...) -> ==
        res = res.replaceAll("!([A-Za-z0-9_.()]+)\\.equals\\(([^)]+)\\)", "$1 != $2");
        res = res.replaceAll("([A-Za-z0-9_.()]+)\\.equals\\(([^)]+)\\)", "$1 == $2");

        // 7. Java casts: (Type) expr -> (expr as Type)
        res = res.replaceAll("\\(\\s*([A-Z][A-Za-z0-9_<>]*)\\s*\\)\\s*([A-Za-z0-9_.]+\\([^)]*\\)|[A-Za-z0-9_.]+)", "($2 as $1)");

        // 8. Bitwise operators
        res = res.replaceAll("(?<![&|])\\s+&\\s+(?![&])", " and ");
        res = res.replaceAll("(?<![&|])\\s+\\|\\s+(?![|])", " or ");
        res = res.replaceAll("\\s+\\^\\s+", " xor ");
        res = res.replaceAll("\\s+<<\\s+", " shl ");
        res = res.replaceAll("\\s+>>>\\s+", " ushr ");
        res = res.replaceAll("\\s+>>\\s+", " shr ");

        // 9. Property access for Map.Entry & standard getters + known class properties (Requirements N & O)
        res = res.replaceAll("\\.length\\b(?!\\s*\\()", ".size");
        res = res.replaceAll("\\.length\\(\\)", ".length");
        res = res.replaceAll("\\.size\\(\\)", ".size");
        res = res.replaceAll("\\.getKey\\(\\s*\\)", ".key");
        res = res.replaceAll("\\.getValue\\(\\s*\\)", ".value");
        res = res.replaceAll("\\.getMessage\\(\\s*\\)", ".message");
        res = res.replaceAll("([A-Za-z0-9_]+)\\.setText\\(([^)]+)\\)", "$1.text = $2");
        res = res.replaceAll("([A-Za-z0-9_]+)\\.get\\(([A-Za-z0-9_]+)\\)", "$1[$2]");

        if (knownGetters != null) {
            for (String prop : knownGetters) {
                if (prop.isEmpty()) continue;
                String cap = Character.toUpperCase(prop.charAt(0)) + prop.substring(1);
                res = res.replaceAll("\\.get" + Pattern.quote(cap) + "\\(\\s*\\)", "." + prop);
            }
        }
        if (knownSetters != null) {
            for (String prop : knownSetters) {
                if (prop.isEmpty()) continue;
                String cap = Character.toUpperCase(prop.charAt(0)) + prop.substring(1);
                res = res.replaceAll("([A-Za-z0-9_]+)\\.set" + Pattern.quote(cap) + "\\(([^)]+)\\)", "$1." + prop + " = $2");
            }
        }

        // 10. Safe-call operator for known nullable variables
        if (nullableVars != null) {
            for (String nv : nullableVars) {
                res = res.replaceAll("\\b" + Pattern.quote(nv) + "\\.(?!isNullOrEmpty\\b|isNullOrBlank\\b)", nv + "?.");
            }
        }

        // 11. Ternary operator: cond ? trueVal : falseVal -> if (cond) trueVal else falseVal
        res = convertTopLevelTernaryToKotlin(res);

        return res;
    }

    private static String convertTopLevelTernaryToKotlin(String expr) {
        int qIndex = findTopLevelChar(expr, '?');
        if (qIndex <= 0) return expr;
        if (qIndex + 1 < expr.length() && (expr.charAt(qIndex + 1) == '.' || expr.charAt(qIndex + 1) == ':')) {
            return expr;
        }
        String afterQ = expr.substring(qIndex + 1);
        int colonOffset = findMatchingTernaryColon(afterQ);
        if (colonOffset <= 0) return expr;

        String cond = expr.substring(0, qIndex).trim();
        String trueBranch = convertTopLevelTernaryToKotlin(afterQ.substring(0, colonOffset).trim());
        String falseBranch = convertTopLevelTernaryToKotlin(afterQ.substring(colonOffset + 1).trim());

        if (cond.startsWith("(") && cond.endsWith(")") && isBalancedParens(cond.substring(1, cond.length() - 1))) {
            cond = cond.substring(1, cond.length() - 1).trim();
        }
        return "if (" + cond + ") " + trueBranch + " else " + falseBranch;
    }

    private static int findTopLevelChar(String s, char target) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') depth++;
            else if (c == ')' || c == ']' || c == '}') depth--;
            else if (c == target && depth == 0) return i;
        }
        return -1;
    }

    private static int findMatchingTernaryColon(String s) {
        int parenDepth = 0;
        int nestedTernary = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') parenDepth++;
            else if (c == ')' || c == ']' || c == '}') parenDepth--;
            else if (parenDepth == 0) {
                if (c == '?') nestedTernary++;
                else if (c == ':') {
                    if (nestedTernary == 0) return i;
                    nestedTernary--;
                }
            }
        }
        return -1;
    }

    private static boolean isBalancedParens(String s) {
        int d = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') d++;
            else if (c == ')') {
                d--;
                if (d < 0) return false;
            }
        }
        return d == 0;
    }

    private static String convertJavaParamsToKotlin(String paramsRaw, Set<String> nullableVars) {
        return convertJavaParamsToKotlinWithNullCheck(paramsRaw, nullableVars, null);
    }

    private static String convertJavaParamsToKotlinWithNullCheck(
            String paramsRaw,
            Set<String> nullableVars,
            Set<String> nullCheckedParams) {
        if (paramsRaw == null || paramsRaw.trim().isEmpty()) return "";
        List<String> parts = splitTopLevel(paramsRaw, ',');
        List<String> ktParams = new ArrayList<>();

        for (String part : parts) {
            String p = part.trim();
            boolean isNullable = p.contains("@Nullable") || p.contains("savedInstanceState");
            p = p.replaceAll("@[A-Za-z0-9_]+(?:\\([^)]*\\))?\\s*", "").replace("final ", "").trim();
            if (p.isEmpty()) continue;

            boolean isVarargs = p.contains("...");
            p = p.replace("...", " ");

            int lastSpace = p.lastIndexOf(' ');
            if (lastSpace > 0) {
                String typePart = p.substring(0, lastSpace).trim();
                String namePart = p.substring(lastSpace + 1).trim();
                if (namePart.endsWith("[]")) {
                    namePart = namePart.substring(0, namePart.length() - 2).trim();
                    typePart = typePart + "[]";
                }
                if (nullCheckedParams != null && nullCheckedParams.contains(namePart)) {
                    isNullable = true;
                }
                String ktType = mapJavaTypeToKotlin(typePart);
                if (isNullable && !ktType.endsWith("?")) {
                    ktType = ktType + "?";
                }
                if (isVarargs) {
                    ktParams.add("vararg " + namePart + ": " + ktType);
                } else {
                    ktParams.add(namePart + ": " + ktType);
                }
            } else {
                ktParams.add(p);
            }
        }
        return joinList(ktParams, ", ");
    }

    private static String mapJavaTypeToKotlin(String javaType) {
        if (javaType == null || javaType.isEmpty()) return "Unit";
        // Strip any stray Java modifiers so modifiers never appear in a Kotlin type
        String t = javaType.replaceAll("\\b(public|private|protected|final|static|volatile|transient)\\b", "").trim();
        if (t.isEmpty()) return "Any";

        // Handle arrays
        if (t.endsWith("[]")) {
            String base = t.substring(0, t.length() - 2).trim();
            switch (base) {
                case "int": return "IntArray";
                case "long": return "LongArray";
                case "byte": return "ByteArray";
                case "short": return "ShortArray";
                case "float": return "FloatArray";
                case "double": return "DoubleArray";
                case "boolean": return "BooleanArray";
                case "char": return "CharArray";
                default: return "Array<" + mapJavaTypeToKotlin(base) + ">";
            }
        }

        // Handle Generics & Wildcards
        if (t.contains("<") && t.endsWith(">")) {
            int lt = t.indexOf('<');
            String outer = t.substring(0, lt).trim();
            String inner = t.substring(lt + 1, t.length() - 1).trim();
            if ("List".equals(outer)) outer = "MutableList";
            else if ("Map".equals(outer)) outer = "MutableMap";
            else if ("Set".equals(outer)) outer = "MutableSet";
            else outer = JAVA_TO_KT_TYPES.getOrDefault(outer, outer);

            List<String> args = splitTopLevel(inner, ',');
            List<String> mappedArgs = new ArrayList<>();
            for (String a : args) {
                String arg = a.trim();
                if (arg.equals("?")) mappedArgs.add("*");
                else if (arg.startsWith("? extends ")) mappedArgs.add("out " + mapJavaTypeToKotlin(arg.substring(10).trim()));
                else if (arg.startsWith("? super ")) mappedArgs.add("in " + mapJavaTypeToKotlin(arg.substring(8).trim()));
                else mappedArgs.add(mapJavaTypeToKotlin(arg));
            }
            return outer + "<" + joinList(mappedArgs, ", ") + ">";
        }

        if ("List".equals(t)) return "MutableList<Any>";
        if ("Map".equals(t)) return "MutableMap<Any, Any>";
        if ("Set".equals(t)) return "MutableSet<Any>";

        return JAVA_TO_KT_TYPES.getOrDefault(t, t);
    }

    private static boolean isPrimitiveOrStringKotlinType(String ktType) {
        return "Int".equals(ktType) || "Long".equals(ktType) || "Float".equals(ktType)
                || "Double".equals(ktType) || "Boolean".equals(ktType) || "String".equals(ktType)
                || "Byte".equals(ktType) || "Short".equals(ktType) || "Char".equals(ktType);
    }

    private static String getDefaultKotlinInitializer(String ktType) {
        switch (ktType) {
            case "Int":
            case "Short":
            case "Byte":
                return "0";
            case "Long":
                return "0L";
            case "Float":
                return "0f";
            case "Double":
                return "0.0";
            case "Boolean":
                return "false";
            default:
                return "null";
        }
    }

    // =========================================================================================
    // 2. KOTLIN -> JAVA CONVERTER ENGINE
    // =========================================================================================
    private static String convertKotlinToJava(String kotlinCode) {
        LiteralVault vault = new LiteralVault();
        String masked = vault.maskLiteralsAndComments(kotlinCode);

        List<String> lines = normalizeMultilineStatements(masked);
        List<String> outputLines = new ArrayList<>();

        boolean insideWhen = false;
        boolean whenHasSubject = false;
        int whenBraceDepth = 0;
        int whenBranchCount = 0;
        boolean insideCompanion = false;
        int companionBraceDepth = 0;
        int currentBraceDepth = 0;
        String currentClassName = null;
        boolean hasEnclosingClass = false;
        boolean hasPrimaryCtorGenerated = false;
        List<String> pendingDataClassMethods = new ArrayList<>();
        Set<Integer> lambdaClosingDepths = new LinkedHashSet<>();
        int mainClassBraceDepth = -1;

        for (int i = 0; i < lines.size(); i++) {
            String rawLine = lines.get(i);
            String trimmed = rawLine.trim();

            if (trimmed.isEmpty()) {
                outputLines.add("");
                continue;
            }

            if (isStandaloneCommentToken(trimmed)) {
                outputLines.add(trimmed);
                continue;
            }

            if (trimmed.startsWith("package ")) {
                outputLines.add(ensureSemicolon(trimmed));
                continue;
            }

            if (trimmed.startsWith("import ")) {
                outputLines.add(ensureSemicolon(trimmed));
                continue;
            }

            int netBraces = countNetChars(trimmed, '{', '}');

            // Check if closing a trailing lambda block
            if (trimmed.equals("}") && lambdaClosingDepths.contains(currentBraceDepth)) {
                lambdaClosingDepths.remove(currentBraceDepth);
                outputLines.add("});");
                currentBraceDepth += netBraces;
                continue;
            }

            // Handle companion object { ... } by unwrapping members as static
            if (trimmed.matches("^companion\\s+object(?:\\s+[A-Za-z0-9_]+)?\\s*\\{$")) {
                insideCompanion = true;
                currentBraceDepth += netBraces;
                companionBraceDepth = currentBraceDepth;
                continue;
            }

            if (insideCompanion && currentBraceDepth + netBraces < companionBraceDepth && trimmed.equals("}")) {
                insideCompanion = false;
                currentBraceDepth += netBraces;
                continue;
            }

            // Handle Kotlin init { ... } block
            if (trimmed.matches("^init\\s*\\{$")) {
                if (hasPrimaryCtorGenerated && !outputLines.isEmpty()
                        && outputLines.get(outputLines.size() - 1).trim().equals("}")) {
                    // Merge init block directly into the just-generated primary constructor
                    outputLines.remove(outputLines.size() - 1);
                } else if (currentClassName != null) {
                    outputLines.add("public " + currentClassName + "() {");
                    hasPrimaryCtorGenerated = true;
                } else {
                    outputLines.add("{");
                }
                currentBraceDepth += netBraces;
                continue;
            }

            // Handle active when block
            if (insideWhen) {
                if (currentBraceDepth + netBraces < whenBraceDepth && trimmed.equals("}")) {
                    insideWhen = false;
                    outputLines.add("}");
                    currentBraceDepth += netBraces;
                    continue;
                }
                if (trimmed.contains("->")) {
                    int arrowIdx = trimmed.indexOf("->");
                    String condPart = trimmed.substring(0, arrowIdx).trim();
                    String bodyPart = trimmed.substring(arrowIdx + 2).trim();

                    if (!whenHasSubject) {
                        // Subjectless when -> if / else if / else
                        String prefix = (whenBranchCount == 0) ? "if (" : "} else if (";
                        whenBranchCount++;
                        if ("else".equals(condPart)) {
                            if (bodyPart.equals("{")) {
                                outputLines.add("} else {");
                            } else {
                                outputLines.add("} else { " + convertKotlinStatementToJava(bodyPart) + " }");
                            }
                        } else {
                            String jCond = convertKotlinExpressionToJava(condPart);
                            if (bodyPart.equals("{")) {
                                outputLines.add(prefix + jCond + ") {");
                            } else {
                                outputLines.add(prefix + jCond + ") { " + convertKotlinStatementToJava(bodyPart) + " }");
                            }
                        }
                        currentBraceDepth += netBraces;
                        continue;
                    }

                    // Subject when -> switch cases
                    if ("else".equals(condPart)) {
                        if (bodyPart.equals("{")) {
                            outputLines.add("default: {");
                        } else {
                            String jStmt = convertKotlinStatementToJava(bodyPart);
                            outputLines.add("default: " + jStmt + (jStmt.startsWith("return ") ? "" : " break;"));
                        }
                    } else {
                        List<String> cases = splitTopLevel(condPart, ',');
                        for (String c : cases) {
                            outputLines.add("case " + convertKotlinExpressionToJava(c.trim()) + ":");
                        }
                        if (bodyPart.equals("{")) {
                            outputLines.add("{");
                        } else {
                            String jStmt = convertKotlinStatementToJava(bodyPart);
                            outputLines.add(jStmt + (jStmt.startsWith("return ") ? "" : " break;"));
                        }
                    }
                    currentBraceDepth += netBraces;
                    continue;
                }
            }

            // Detect when (expr) { or subjectless when {
            Matcher whenMatcher = Pattern.compile("^when\\s*(?:\\((.+)\\))?\\s*\\{$").matcher(trimmed);
            if (whenMatcher.find()) {
                insideWhen = true;
                whenBranchCount = 0;
                currentBraceDepth += netBraces;
                whenBraceDepth = currentBraceDepth;
                String subj = whenMatcher.group(1);
                if (subj != null && !subj.trim().isEmpty()) {
                    whenHasSubject = true;
                    outputLines.add("switch (" + convertKotlinExpressionToJava(subj.trim()) + ") {");
                } else {
                    whenHasSubject = false;
                }
                continue;
            }

            // Detect Class / Data Class / Object / Interface / Enum Class
            Matcher ktClassMatcher = Pattern.compile(
                    "^(?:(public|private|protected|internal)\\s+)?(?:(data|open|abstract|sealed|inner|enum)\\s+)*(class|interface|object)\\s+([A-Za-z0-9_<>]+)(?:\\s*(?:private|protected|public|internal)?\\s*(?:constructor)?\\s*\\(([^)]*)\\))?(?:\\s*:\\s*([^{]+))?\\s*(\\{?)$"
            ).matcher(trimmed);
            if (ktClassMatcher.find()) {
                String vis = ktClassMatcher.group(1);
                String mod = ktClassMatcher.group(2);
                String kind = ktClassMatcher.group(3);
                String name = ktClassMatcher.group(4);
                String primaryCtorParams = ktClassMatcher.group(5);
                String parentsRaw = ktClassMatcher.group(6);
                String brace = ktClassMatcher.group(7);

                hasEnclosingClass = true;
                hasPrimaryCtorGenerated = false;
                if (currentClassName == null) {
                    currentClassName = name.replaceAll("<.*>", "");
                    mainClassBraceDepth = currentBraceDepth + ("{".equals(brace) ? 1 : 0);
                }

                String jVis = ("private".equals(vis) || "protected".equals(vis)) ? vis : "public";
                String staticNested = (currentBraceDepth >= 1 && !"inner".equals(mod) && "class".equals(kind)) ? "static " : "";
                String jMod = "abstract".equals(mod) ? "abstract " : ("object".equals(kind) ? "final " : "");
                String jKind = "enum".equals(mod) ? "enum" : ("interface".equals(kind) ? "interface" : "class");

                StringBuilder header = new StringBuilder();
                header.append(jVis).append(" ").append(staticNested).append(jMod).append(jKind).append(" ").append(name);

                String superCtorArgs = null;
                if (parentsRaw != null && !parentsRaw.trim().isEmpty()) {
                    List<String> parents = splitTopLevel(parentsRaw.trim(), ',');
                    String extClass = null;
                    List<String> interfaces = new ArrayList<>();
                    for (String p : parents) {
                        String pt = p.trim();
                        if (pt.endsWith(")")) {
                            int openP = pt.indexOf('(');
                            extClass = mapKotlinTypeToJava(pt.substring(0, openP).trim(), false);
                            superCtorArgs = pt.substring(openP + 1, pt.length() - 1).trim();
                        } else {
                            interfaces.add(mapKotlinTypeToJava(pt, false));
                        }
                    }
                    if (extClass != null) {
                        header.append(" extends ").append(extClass);
                    }
                    if (!interfaces.isEmpty()) {
                        header.append("interface".equals(jKind) ? " extends " : " implements ")
                                .append(joinList(interfaces, ", "));
                    }
                }

                boolean hasOpenBrace = "{".equals(brace) || (primaryCtorParams != null && !primaryCtorParams.trim().isEmpty());
                if (hasOpenBrace) {
                    header.append(" {");
                }
                outputLines.add(header.toString());

                // Generate fields, constructor, and getters/setters if primary constructor parameters exist
                if (primaryCtorParams != null && !primaryCtorParams.trim().isEmpty()) {
                    generatePrimaryConstructorJavaMembers(
                            name.replaceAll("<.*>", ""),
                            primaryCtorParams,
                            superCtorArgs,
                            outputLines,
                            pendingDataClassMethods
                    );
                    hasPrimaryCtorGenerated = true;
                    if (!"{".equals(brace)) {
                        // It was a bodyless `data class User(val id: Int, val name: String)`
                        outputLines.addAll(pendingDataClassMethods);
                        pendingDataClassMethods.clear();
                        outputLines.add("}");
                    }
                }

                currentBraceDepth += netBraces;
                continue;
            }

            // Detect Secondary Constructor: constructor(...) : super(...) {
            Matcher secCtor = Pattern.compile(
                    "^(?:(public|private|protected)\\s+)?constructor\\s*\\(([^)]*)\\)(?:\\s*:\\s*(super|this)\\s*\\(([^)]*)\\))?\\s*\\{$"
            ).matcher(trimmed);
            if (secCtor.find() && currentClassName != null) {
                String vis = secCtor.group(1) != null ? secCtor.group(1) : "public";
                String params = convertKotlinParamsToJava(secCtor.group(2).trim());
                String delegateKind = secCtor.group(3);
                String delegateArgs = secCtor.group(4);
                outputLines.add(vis + " " + currentClassName + "(" + params + ") {");
                if (delegateKind != null) {
                    outputLines.add(delegateKind + "(" + convertKotlinExpressionToJava(delegateArgs != null ? delegateArgs : "") + ");");
                }
                currentBraceDepth += netBraces;
                continue;
            }

            // Detect Function declaration: [override] [private] fun [Type.]name(params)[: ReturnType] [{ | = expr]
            Matcher funMatcher = Pattern.compile(
                    "^(override\\s+)?(?:(public|private|protected|internal)\\s+)?(?:(abstract|open|suspend|inline)\\s+)*fun\\s+(?:<([^>]+)>\\s+)?([A-Za-z0-9_]+)\\s*\\(([^)]*)\\)(?:\\s*:\\s*([A-Za-z0-9_<>?., \\[\\]]+))?\\s*(\\{|=.*)?$"
            ).matcher(trimmed);
            if (funMatcher.find()) {
                boolean isOverride = funMatcher.group(1) != null;
                String vis = funMatcher.group(2);
                String mod = funMatcher.group(3);
                String typeParam = funMatcher.group(4);
                String funName = funMatcher.group(5).trim();
                String paramsRaw = funMatcher.group(6).trim();
                String retRaw = funMatcher.group(7) != null ? funMatcher.group(7).trim() : "Unit";
                String tail = funMatcher.group(8) != null ? funMatcher.group(8).trim() : "";

                if (!hasEnclosingClass) {
                    outputLines.add("public class KotlinConverted {");
                    hasEnclosingClass = true;
                    currentClassName = "KotlinConverted";
                    mainClassBraceDepth = 1;
                }

                if ("main".equals(funName)) {
                    outputLines.add("public static void main(String[] args) {");
                    currentBraceDepth += netBraces;
                    continue;
                }

                if (isOverride) {
                    outputLines.add("@Override");
                }

                String jVis = ("private".equals(vis) || "protected".equals(vis)) ? vis : "public";
                String staticMod = (insideCompanion || currentBraceDepth == 0) ? "static " : "";
                String abstractMod = "abstract".equals(mod) ? "abstract " : "";
                String jTypeParam = (typeParam != null && !typeParam.isEmpty())
                        ? "<" + typeParam.replace(" : ", " extends ") + "> " : "";
                String jRet = mapKotlinTypeToJava(retRaw, false);
                String jParams = convertKotlinParamsToJava(paramsRaw);

                if (tail.startsWith("=")) {
                    String exprBody = convertKotlinExpressionToJava(tail.substring(1).trim());
                    if ("void".equals(jRet)) jRet = inferJavaTypeFromExpression(exprBody, true);
                    outputLines.add(jVis + " " + staticMod + jTypeParam + jRet + " " + funName + "(" + jParams + ") {");
                    outputLines.add("return " + exprBody + ";");
                    outputLines.add("}");
                } else {
                    String suffix = "{".equals(tail) ? " {" : ";";
                    outputLines.add(jVis + " " + staticMod + abstractMod + jTypeParam + jRet + " " + funName + "(" + jParams + ")" + suffix);
                }
                currentBraceDepth += netBraces;
                continue;
            }

            // Detect Kotlin trailing lambda call: e.g., button.setOnClickListener { [v ->] or runOnUiThread {
            Matcher trailingLambdaM = Pattern.compile(
                    "^([A-Za-z0-9_?.()]+)\\.(setOnClickListener|setOnLongClickListener|post)\\s*\\{\\s*(?:([A-Za-z0-9_]+)\\s*->)?$"
            ).matcher(trimmed);
            if (trailingLambdaM.find()) {
                String target = convertKotlinExpressionToJava(trailingLambdaM.group(1));
                String method = trailingLambdaM.group(2);
                String param = trailingLambdaM.group(3);
                if ("post".equals(method)) {
                    outputLines.add(target + ".post(() -> {");
                } else {
                    String pName = (param != null && !param.isEmpty()) ? param : "view";
                    outputLines.add(target + "." + method + "(" + pName + " -> {");
                }
                currentBraceDepth += netBraces;
                lambdaClosingDepths.add(currentBraceDepth);
                continue;
            }

            // Inject pending getters/setters before closing main class
            if (trimmed.equals("}") && currentBraceDepth == mainClassBraceDepth && !pendingDataClassMethods.isEmpty()) {
                outputLines.add("");
                outputLines.addAll(pendingDataClassMethods);
                pendingDataClassMethods.clear();
            }

            // General control or statement conversion
            String converted = convertKotlinControlOrStatementToJava(trimmed, insideCompanion, currentBraceDepth == mainClassBraceDepth);
            outputLines.add(converted);
            currentBraceDepth += netBraces;
        }

        if (hasEnclosingClass && "KotlinConverted".equals(currentClassName)) {
            outputLines.add("}");
        }

        String joined = joinList(outputLines, "\n");
        String restored = vault.restoreForJavaWithTemplateExpansion(joined);
        return formatIndentation(restored);
    }

    private static void generatePrimaryConstructorJavaMembers(
            String className,
            String primaryCtorParams,
            String superCtorArgs,
            List<String> outputLines,
            List<String> pendingMethods) {
        List<String> parts = splitTopLevel(primaryCtorParams, ',');
        List<String> ctorSigParams = new ArrayList<>();
        List<String> ctorAssignments = new ArrayList<>();

        for (String p : parts) {
            String clean = p.trim();
            if (clean.isEmpty()) continue;
            // Strip default value if present: val x: Int = 0
            if (clean.contains("=")) {
                clean = clean.substring(0, clean.indexOf('=')).trim();
            }
            boolean isVal = clean.matches("^(?:(?:private|public|protected|internal)\\s+)?val\\b.*");
            boolean isVar = clean.matches("^(?:(?:private|public|protected|internal)\\s+)?var\\b.*");
            clean = clean.replaceFirst("^(?:private|public|protected|internal)?\\s*(?:val|var)\\s+", "").trim();

            int colon = clean.indexOf(':');
            if (colon > 0) {
                String fName = clean.substring(0, colon).trim();
                String ktType = clean.substring(colon + 1).trim();
                String jType = mapKotlinTypeToJava(ktType, false);

                if (isVal || isVar) {
                    outputLines.add("private " + (isVal ? "final " : "") + jType + " " + fName + ";");
                    String cap = Character.toUpperCase(fName.charAt(0)) + fName.substring(1);
                    pendingMethods.add("public " + jType + " get" + cap + "() { return this." + fName + "; }");
                    if (isVar) {
                        pendingMethods.add("public void set" + cap + "(" + jType + " " + fName + ") { this." + fName + " = " + fName + "; }");
                    }
                }
                ctorSigParams.add(jType + " " + fName);
                if (isVal || isVar) {
                    ctorAssignments.add("this." + fName + " = " + fName + ";");
                }
            }
        }

        outputLines.add("");
        outputLines.add("public " + className + "(" + joinList(ctorSigParams, ", ") + ") {");
        if (superCtorArgs != null && !superCtorArgs.isEmpty()) {
            outputLines.add("super(" + convertKotlinExpressionToJava(superCtorArgs) + ");");
        }
        outputLines.addAll(ctorAssignments);
        outputLines.add("}");
    }

    private static String convertKotlinControlOrStatementToJava(String line, boolean isStaticScope, boolean isClassFieldLevel) {
        // 1. x?.let { ... } -> if (x != null) {
        Matcher letMatcher = Pattern.compile("^([A-Za-z0-9_.]+)\\?\\.let\\s*\\{\\s*(?:([A-Za-z0-9_]+)\\s*->)?$").matcher(line);
        if (letMatcher.find()) {
            String target = letMatcher.group(1);
            return "if (" + target + " != null) {";
        }

        // 2. Destructuring map for-loop: for ((k, v) in map) {
        Matcher forMapM = Pattern.compile("^for\\s*\\(\\s*\\(\\s*([A-Za-z0-9_]+)\\s*,\\s*([A-Za-z0-9_]+)\\s*\\)\\s+in\\s+(.+)\\)\\s*\\{$").matcher(line);
        if (forMapM.find()) {
            String k = forMapM.group(1).trim();
            String v = forMapM.group(2).trim();
            String mapExpr = convertKotlinExpressionToJava(forMapM.group(3).trim());
            if (mapExpr.endsWith(".entrySet()")) {
                mapExpr = mapExpr.substring(0, mapExpr.length() - ".entrySet()".length());
            }
            return "for (var entry : " + mapExpr + ".entrySet()) {\n"
                    + "var " + k + " = entry.getKey();\n"
                    + "var " + v + " = entry.getValue();";
        }

        // 3. Range for-loops: for (i in a until b [step s]) {
        Matcher forRange = Pattern.compile(
                "^for\\s*\\(\\s*([A-Za-z0-9_]+)\\s+in\\s+(.+?)\\s+(until|\\.\\.|downTo)\\s+(.+?)(?:\\s+step\\s+(.+))?\\)\\s*\\{$"
        ).matcher(line);
        if (forRange.find()) {
            String v = forRange.group(1).trim();
            String start = convertKotlinExpressionToJava(forRange.group(2).trim());
            String kind = forRange.group(3).trim();
            String end = convertKotlinExpressionToJava(forRange.group(4).trim());
            String step = forRange.group(5) != null ? convertKotlinExpressionToJava(forRange.group(5).trim()) : "1";

            if ("until".equals(kind)) {
                String upd = "1".equals(step) ? v + "++" : v + " += " + step;
                return "for (int " + v + " = " + start + "; " + v + " < " + end + "; " + upd + ") {";
            } else if ("..".equals(kind)) {
                String upd = "1".equals(step) ? v + "++" : v + " += " + step;
                return "for (int " + v + " = " + start + "; " + v + " <= " + end + "; " + upd + ") {";
            } else {
                String upd = "1".equals(step) ? v + "--" : v + " -= " + step;
                return "for (int " + v + " = " + start + "; " + v + " >= " + end + "; " + upd + ") {";
            }
        }

        // 4. Collection for-each: for (item in list) {
        Matcher forIn = Pattern.compile("^for\\s*\\(\\s*([A-Za-z0-9_]+)(?:\\s*:\\s*([A-Za-z0-9_<>]+))?\\s+in\\s+(.+)\\)\\s*\\{$").matcher(line);
        if (forIn.find()) {
            String v = forIn.group(1).trim();
            String explicitType = forIn.group(2) != null ? mapKotlinTypeToJava(forIn.group(2).trim(), false) : "var";
            String col = convertKotlinExpressionToJava(forIn.group(3).trim());
            return "for (" + explicitType + " " + v + " : " + col + ") {";
        }

        // 5. catch (e: Exception) {
        Matcher catchM = Pattern.compile("^(\\}?\\s*)catch\\s*\\(\\s*([A-Za-z0-9_]+)\\s*:\\s*([A-Za-z0-9_<>]+)\\s*\\)\\s*\\{$").matcher(line);
        if (catchM.find()) {
            String prefix = catchM.group(1).trim();
            String v = catchM.group(2).trim();
            String t = mapKotlinTypeToJava(catchM.group(3).trim(), false);
            return (prefix.isEmpty() ? "" : prefix + " ") + "catch (" + t + " " + v + ") {";
        }

        // 6. if / else if / while
        Matcher condM = Pattern.compile("^(\\}?\\s*(?:else\\s+if|if|while))\\s*\\((.+)\\)\\s*(\\{?)$").matcher(line);
        if (condM.find()) {
            String kw = condM.group(1).trim();
            String cond = convertKotlinExpressionToJava(condM.group(2).trim());
            if (cond.startsWith("(") && cond.endsWith(")") && isBalancedParens(cond.substring(1, cond.length() - 1))) {
                cond = cond.substring(1, cond.length() - 1).trim();
            }
            String brace = condM.group(3).trim();
            return kw + " (" + cond + ")" + (brace.isEmpty() ? "" : " {");
        }

        // 7. Property / Variable declaration: [private] [const] [lateinit] val/var name[: Type] [= expr]
        Matcher propM = Pattern.compile(
                "^(?:(public|private|protected|internal)\\s+)?(const\\s+)?(lateinit\\s+)?(val|var)\\s+([A-Za-z0-9_]+)(?:\\s*:\\s*([A-Za-z0-9_<>?., \\[\\]]+))?(?:\\s*=\\s*(.+))?$"
        ).matcher(line);
        if (propM.find()) {
            String vis = propM.group(1);
            boolean isConst = propM.group(2) != null;
            boolean isLateinit = propM.group(3) != null;
            boolean isVal = "val".equals(propM.group(4));
            String vName = propM.group(5).trim();
            String ktType = propM.group(6) != null ? propM.group(6).trim() : null;
            String rhsRaw = propM.group(7) != null ? propM.group(7).trim() : null;

            // Handle `by lazy { expr }`
            if (rhsRaw != null && rhsRaw.startsWith("by lazy")) {
                rhsRaw = rhsRaw.replaceFirst("^by\\s+lazy\\s*\\{?", "").replaceAll("\\}$", "").trim();
            }

            // Skip redundant `= null` on lateinit or uninitialized field if needed
            String jRhs = rhsRaw != null ? convertKotlinExpressionToJava(rhsRaw) : null;
            boolean isField = isClassFieldLevel || isStaticScope || isLateinit || vis != null;
            String jType = ktType != null
                    ? mapKotlinTypeToJava(ktType, false)
                    : inferJavaTypeFromExpression(jRhs != null ? jRhs : "", isField);

            StringBuilder decl = new StringBuilder();
            if (isField) {
                String jVis = ("private".equals(vis) || "protected".equals(vis) || "public".equals(vis))
                        ? vis : (isConst ? "public" : "private");
                decl.append(jVis).append(" ");
                if (isStaticScope || isConst) decl.append("static ");
            }
            if ((isVal || isConst) && !isLateinit) decl.append("final ");
            decl.append(jType).append(" ").append(vName);
            if (jRhs != null && !jRhs.isEmpty() && !(isField && !isVal && "null".equals(jRhs))) {
                decl.append(" = ").append(jRhs);
            }
            decl.append(";");
            return decl.toString();
        }

        return convertKotlinStatementToJava(line);
    }

    private static String convertKotlinStatementToJava(String stmt) {
        String trimmed = stmt.trim();
        if (trimmed.isEmpty() || trimmed.equals("{") || trimmed.equals("}")
                || trimmed.endsWith("{") || trimmed.endsWith("}") || trimmed.startsWith("@")) {
            return trimmed;
        }

        if (trimmed.startsWith("println(") && trimmed.endsWith(")")) {
            String inner = trimmed.substring(8, trimmed.length() - 1);
            return "System.out.println(" + convertKotlinExpressionToJava(inner) + ");";
        }
        if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
            String inner = trimmed.substring(6, trimmed.length() - 1);
            return "System.out.print(" + convertKotlinExpressionToJava(inner) + ");";
        }

        if (trimmed.equals("return")) return "return;";
        if (trimmed.startsWith("return ")) {
            return "return " + convertKotlinExpressionToJava(trimmed.substring(7).trim()) + ";";
        }
        if (trimmed.startsWith("throw ")) {
            return "throw " + convertKotlinExpressionToJava(trimmed.substring(6).trim()) + ";";
        }

        return ensureSemicolon(convertKotlinExpressionToJava(trimmed));
    }

    private static String convertKotlinExpressionToJava(String expr) {
        if (expr == null || expr.trim().isEmpty()) return "";
        String res = expr.trim();

        // 0. Qualified this: this@MainActivity -> MainActivity.this
        res = res.replaceAll("\\bthis@([A-Za-z0-9_]+)\\b", "$1.this");

        // 0b. Kotlin null/empty helpers: x.isNullOrEmpty() -> (x == null || x.isEmpty())
        res = res.replaceAll("\\b([A-Za-z0-9_.]+)\\??\\.isNullOrEmpty\\s*\\(\\s*\\)", "($1 == null || $1.isEmpty())");
        res = res.replaceAll("\\b([A-Za-z0-9_.]+)\\??\\.isNullOrBlank\\s*\\(\\s*\\)", "($1 == null || $1.trim().isEmpty())");

        // 0c. Common Android property assignments: tv.text = x -> tv.setText(x)
        Matcher propAssign = Pattern.compile("^([A-Za-z0-9_?.]+)\\.(text|visibility|isEnabled|isClickable|alpha)\\s*=\\s*(.+)$").matcher(res);
        if (propAssign.find()) {
            String target = propAssign.group(1).replace("?.", ".");
            String prop = propAssign.group(2);
            String val = convertKotlinExpressionToJava(propAssign.group(3));
            String setter;
            if ("isEnabled".equals(prop)) setter = "setEnabled";
            else if ("isClickable".equals(prop)) setter = "setClickable";
            else setter = "set" + Character.toUpperCase(prop.charAt(0)) + prop.substring(1);
            return target + "." + setter + "(" + val + ")";
        }

        // 0d. Map entry & collection/exception properties:
        res = res.replaceAll("\\b(entry|item|kv)\\.key\\b", "$1.getKey()");
        res = res.replaceAll("\\b(entry|item|kv)\\.value\\b", "$1.getValue()");
        res = res.replaceAll("\\.entries\\b", ".entrySet()");
        res = res.replaceAll("\\.size\\b(?!\\s*\\()", ".size()");
        res = res.replaceAll("\\b([eE]|ex|err|error|throwable)\\.message\\b(?!\\s*\\()", "$1.getMessage()");

        // 1. Inline if-else expression: if (cond) a else b -> (cond) ? a : b
        Matcher inlineIf = Pattern.compile("^if\\s*\\(([^)]+)\\)\\s+(.+?)\\s+else\\s+(.+)$").matcher(res);
        if (inlineIf.find() && !res.contains("{")) {
            return "(" + convertKotlinExpressionToJava(inlineIf.group(1).trim()) + ") ? "
                    + convertKotlinExpressionToJava(inlineIf.group(2).trim()) + " : "
                    + convertKotlinExpressionToJava(inlineIf.group(3).trim());
        }

        // 2. Elvis operator: a ?: b -> (a != null ? a : b)
        if (res.contains("?:")) {
            int elvisIdx = res.indexOf("?:");
            String left = res.substring(0, elvisIdx).trim();
            String right = res.substring(elvisIdx + 2).trim();
            res = "(" + left + " != null ? " + left + " : " + right + ")";
        }

        // 3. Safe calls & non-null assertions
        res = res.replace("?.", ".");
        res = res.replace("!!", "");

        // 4. Class references: MainActivity::class.java -> MainActivity.class
        res = res.replaceAll("\\b([A-Za-z0-9_]+)::class\\.java\\b", "$1.class");
        res = res.replaceAll("\\b([A-Za-z0-9_]+)::class\\b", "$1.class");

        // 5. Collections & Arrays
        res = res.replaceAll("\\b(?:mutableListOf|listOf|arrayListOf)(?:<[^>]+>)?\\s*\\(\\s*\\)", "new ArrayList<>()");
        res = res.replaceAll("\\b(?:mutableListOf|listOf|arrayListOf)(?:<[^>]+>)?\\s*\\(([^)]+)\\)", "new ArrayList<>(Arrays.asList($1))");
        res = res.replaceAll("\\bemptyList(?:<[^>]+>)?\\s*\\(\\s*\\)", "Collections.emptyList()");
        res = res.replaceAll("\\b(?:mutableMapOf|hashMapOf|mapOf)(?:<[^>]+>)?\\s*\\(\\s*\\)", "new HashMap<>()");
        res = res.replaceAll("\\bintArrayOf\\s*\\(([^)]*)\\)", "new int[]{$1}");
        res = res.replaceAll("\\blongArrayOf\\s*\\(([^)]*)\\)", "new long[]{$1}");
        res = res.replaceAll("\\bfloatArrayOf\\s*\\(([^)]*)\\)", "new float[]{$1}");
        res = res.replaceAll("\\bdoubleArrayOf\\s*\\(([^)]*)\\)", "new double[]{$1}");
        res = res.replaceAll("\\bbooleanArrayOf\\s*\\(([^)]*)\\)", "new boolean[]{$1}");
        res = res.replaceAll("\\barrayOf\\s*\\(([^)]*)\\)", "new Object[]{$1}");
        res = res.replaceAll("\\bIntArray\\s*\\(([^)]+)\\)", "new int[$1]");
        res = res.replaceAll("\\bByteArray\\s*\\(([^)]+)\\)", "new byte[$1]");
        res = res.replaceAll("\\barrayOfNulls<([A-Za-z0-9_]+)>\\s*\\(([^)]+)\\)", "new $1[$2]");

        // 6. Type checks & casts: x is Type -> x instanceof Type, x as Type -> (Type) x
        res = res.replaceAll("\\b([A-Za-z0-9_.()]+)\\s+!is\\s+([A-Za-z0-9_<>]+)\\b", "!($1 instanceof $2)");
        res = res.replaceAll("\\b([A-Za-z0-9_.()]+)\\s+is\\s+([A-Za-z0-9_<>]+)\\b", "$1 instanceof $2");
        res = res.replaceAll("\\(\\s*([A-Za-z0-9_.()]+)\\s+as\\??\\s+([A-Za-z0-9_<>]+)\\s*\\)", "(($2) $1)");
        res = res.replaceAll("\\b([A-Za-z0-9_.()]+)\\s+as\\??\\s+([A-Za-z0-9_<>]+)\\b", "(($2) $1)");

        // 7. Bitwise infix functions
        res = res.replaceAll("\\s+and\\s+", " & ");
        res = res.replaceAll("\\s+or\\s+", " | ");
        res = res.replaceAll("\\s+xor\\s+", " ^ ");
        res = res.replaceAll("\\s+shl\\s+", " << ");
        res = res.replaceAll("\\s+shr\\s+", " >> ");
        res = res.replaceAll("\\s+ushr\\s+", " >>> ");

        // 8. Constructor calls for Uppercase classes without `new `
        res = addNewToKotlinConstructorCalls(res);

        return res;
    }

    private static String addNewToKotlinConstructorCalls(String expr) {
        Pattern ctorCall = Pattern.compile("(?<![A-Za-z0-9_.])([A-Z][A-Za-z0-9_]*(?:<[^>]+>)?)\\s*\\(");
        Matcher m = ctorCall.matcher(expr);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String className = m.group(1);
            int start = m.start();
            String before = expr.substring(0, start).trim();
            boolean alreadyNew = before.endsWith("new");
            boolean isStaticHelper = className.equals("Toast") || className.equals("Log")
                    || className.equals("Color") || className.equals("Math")
                    || className.equals("System") || className.equals("Collections")
                    || className.equals("Arrays") || className.equals("String")
                    || className.equals("Integer") || className.equals("Boolean");
            if (!alreadyNew && !isStaticHelper) {
                String rawBase = className.replaceAll("<.*>", "");
                if ("ArrayList".equals(rawBase) || "HashMap".equals(rawBase) || "HashSet".equals(rawBase)) {
                    m.appendReplacement(sb, "new " + Matcher.quoteReplacement(rawBase) + "<>(");
                } else {
                    m.appendReplacement(sb, "new " + Matcher.quoteReplacement(className) + "(");
                }
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
            }
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String convertKotlinParamsToJava(String paramsRaw) {
        if (paramsRaw == null || paramsRaw.trim().isEmpty()) return "";
        List<String> parts = splitTopLevel(paramsRaw, ',');
        List<String> jParams = new ArrayList<>();

        for (String part : parts) {
            String p = part.trim();
            if (p.isEmpty()) continue;
            if (p.contains("=")) {
                p = p.substring(0, p.indexOf('=')).trim();
            }
            boolean isVararg = p.startsWith("vararg ");
            p = p.replaceFirst("^(?:vararg|val|var)\\s+", "").trim();
            int colon = p.indexOf(':');
            if (colon > 0) {
                String name = p.substring(0, colon).trim();
                String ktType = p.substring(colon + 1).trim();
                String jType = mapKotlinTypeToJava(ktType, false);
                jParams.add(jType + (isVararg ? "... " : " ") + name);
            } else {
                jParams.add(p);
            }
        }
        return joinList(jParams, ", ");
    }

    private static String mapKotlinTypeToJava(String ktType, boolean boxed) {
        if (ktType == null || ktType.isEmpty()) return "void";
        String t = ktType.trim();
        boolean nullable = t.endsWith("?");
        if (nullable) {
            t = t.substring(0, t.length() - 1).trim();
        }

        switch (t) {
            case "IntArray": return "int[]";
            case "LongArray": return "long[]";
            case "ByteArray": return "byte[]";
            case "ShortArray": return "short[]";
            case "FloatArray": return "float[]";
            case "DoubleArray": return "double[]";
            case "BooleanArray": return "boolean[]";
            case "CharArray": return "char[]";
        }

        if (t.startsWith("Array<") && t.endsWith(">")) {
            String inner = t.substring(6, t.length() - 1).trim();
            return mapKotlinTypeToJava(inner, true) + "[]";
        }

        if (t.contains("<") && t.endsWith(">")) {
            int lt = t.indexOf('<');
            String outer = t.substring(0, lt).trim();
            String inner = t.substring(lt + 1, t.length() - 1).trim();
            if ("MutableList".equals(outer)) outer = "List";
            else if ("MutableMap".equals(outer)) outer = "Map";
            else if ("MutableSet".equals(outer)) outer = "Set";

            List<String> args = splitTopLevel(inner, ',');
            List<String> mappedArgs = new ArrayList<>();
            for (String a : args) {
                String arg = a.trim();
                if (arg.equals("*")) mappedArgs.add("?");
                else if (arg.startsWith("out ")) mappedArgs.add("? extends " + mapKotlinTypeToJava(arg.substring(4).trim(), true));
                else if (arg.startsWith("in ")) mappedArgs.add("? super " + mapKotlinTypeToJava(arg.substring(3).trim(), true));
                else mappedArgs.add(mapKotlinTypeToJava(arg, true));
            }
            return outer + "<" + joinList(mappedArgs, ", ") + ">";
        }

        if (boxed || nullable) {
            if ("Int".equals(t) && !boxed) return "Integer";
            return KT_TO_JAVA_BOXED.getOrDefault(t, KT_TO_JAVA_PRIMITIVES.getOrDefault(t, t));
        }
        return KT_TO_JAVA_PRIMITIVES.getOrDefault(t, t);
    }

    private static String inferJavaTypeFromExpression(String expr, boolean disallowVar) {
        if (expr == null || expr.isEmpty()) return "Object";
        if (expr.startsWith("new int[")) return "int[]";
        if (expr.startsWith("new long[")) return "long[]";
        if (expr.startsWith("new float[")) return "float[]";
        if (expr.startsWith("new double[")) return "double[]";
        if (expr.startsWith("new boolean[")) return "boolean[]";
        if (expr.startsWith("new ArrayList")) return "List<Object>";
        if (expr.startsWith("new HashMap")) return "Map<Object, Object>";
        if (expr.startsWith("new ")) {
            Matcher m = Pattern.compile("^new\\s+([A-Za-z0-9_<>\\[\\]]+)").matcher(expr);
            if (m.find()) {
                String t = m.group(1);
                return t.endsWith("<>") ? t.substring(0, t.length() - 2) : t;
            }
        }
        if (expr.startsWith("\"") || expr.startsWith("__STR_TOKEN_") || expr.startsWith("getMessage(")) return "String";
        if ("true".equals(expr) || "false".equals(expr) || expr.contains("==") || expr.contains("!=")) return "boolean";
        if (expr.matches("^-?\\d+L$")) return "long";
        if (expr.matches("^-?\\d+\\.\\d+[fF]$")) return "float";
        if (expr.matches("^-?\\d+\\.\\d+$")) return "double";
        if (expr.matches("^-?\\d+$")) return "int";
        if (expr.contains("__STR_TOKEN_")) return "String";
        if (expr.matches("^[A-Za-z0-9_.()\\s+\\-*/%]+$") && (expr.contains("/") || expr.contains("*") || expr.contains("-") || expr.contains("%") || expr.contains("+"))) {
            return "int";
        }
        return disallowVar ? "Object" : "var";
    }

    // =========================================================================================
    // SHARED HELPERS & INDENTATION FORMATTER
    // =========================================================================================
    private static boolean isControlKeyword(String word) {
        if (word == null) return false;
        String w = word.trim();
        return "if".equals(w) || "else".equals(w) || "for".equals(w) || "while".equals(w)
                || "switch".equals(w) || "when".equals(w) || "try".equals(w) || "catch".equals(w)
                || "return".equals(w) || "throw".equals(w) || "new".equals(w);
    }

    private static String stripTrailingSemicolon(String s) {
        String t = s.trim();
        while (t.endsWith(";")) {
            t = t.substring(0, t.length() - 1).trim();
        }
        return t;
    }

    private static String ensureSemicolon(String s) {
        String t = s.trim();
        if (t.isEmpty() || t.endsWith(";") || t.endsWith("{") || t.endsWith("}") || t.endsWith(":")) {
            return t;
        }
        return t + ";";
    }

    private static List<String> splitTopLevel(String input, char delimiter) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int depth = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '<' || c == '(' || c == '[' || c == '{') depth++;
            else if (c == '>' || c == ')' || c == ']' || c == '}') depth--;
            if (c == delimiter && depth == 0) {
                result.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        if (current.length() > 0) {
            result.add(current.toString());
        }
        return result;
    }

    private static String joinList(List<String> list, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(list.get(i));
        }
        return sb.toString();
    }

    private static String formatIndentation(String rawCode) {
        String[] lines = rawCode.split("\n", -1);
        StringBuilder out = new StringBuilder();
        int indent = 0;
        int blankStreak = 0;

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) {
                blankStreak++;
                if (blankStreak <= 1) {
                    out.append("\n");
                }
                continue;
            }
            blankStreak = 0;

            if (trimmed.startsWith("}")) {
                indent = Math.max(0, indent - 1);
            }

            for (int i = 0; i < indent; i++) {
                out.append("    ");
            }
            out.append(trimmed).append("\n");

            int net = countNetChars(trimmed, '{', '}');
            if (trimmed.startsWith("}")) {
                if (trimmed.endsWith("{")) {
                    indent++;
                }
            } else if (net > 0) {
                indent += net;
            } else if (net < 0) {
                indent = Math.max(0, indent + net);
            }
        }
        return out.toString().trim() + "\n";
    }
}
