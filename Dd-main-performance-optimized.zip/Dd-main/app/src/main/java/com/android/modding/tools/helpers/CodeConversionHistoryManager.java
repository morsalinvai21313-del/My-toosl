package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import com.android.modding.tools.models.CodeConversionItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CodeConversionHistoryManager {

    private static final String PREF_NAME = "morsalin_code_converter_history";
    private static final String KEY_ITEMS = "conversion_history_items";

    public static void saveConversion(Context context, CodeConversionItem item) {
        List<CodeConversionItem> current = getAllConversions(context);
        current.add(0, item);
        if (current.size() > 60) {
            current = current.subList(0, 60);
        }
        saveList(context, current);
    }

    public static List<CodeConversionItem> getAllConversions(Context context) {
        List<CodeConversionItem> list = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String jsonStr = prefs.getString(KEY_ITEMS, "[]");
        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                list.add(new CodeConversionItem(
                        obj.optString("id", String.valueOf(System.currentTimeMillis() + i)),
                        obj.optString("originalLanguage", "Java"),
                        obj.optString("convertedLanguage", "Kotlin"),
                        obj.optString("originalFileName", "Source.java"),
                        obj.optString("convertedFileName", "Source.kt"),
                        obj.optLong("timestamp", System.currentTimeMillis()),
                        obj.optString("originalCode", ""),
                        obj.optString("convertedCode", ""),
                        obj.optInt("linesProcessed", 0),
                        obj.optInt("linesGenerated", 0),
                        obj.optInt("warningsCount", 0),
                        obj.optLong("conversionTimeMs", 0L)
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<CodeConversionItem> searchConversions(Context context, String query) {
        List<CodeConversionItem> all = getAllConversions(context);
        if (query == null || query.trim().isEmpty()) {
            return all;
        }
        String lower = query.trim().toLowerCase(Locale.US);
        List<CodeConversionItem> filtered = new ArrayList<>();
        for (CodeConversionItem item : all) {
            if (item.getOriginalFileName().toLowerCase(Locale.US).contains(lower)
                    || item.getConvertedFileName().toLowerCase(Locale.US).contains(lower)
                    || item.getDirectionTitle().toLowerCase(Locale.US).contains(lower)
                    || item.getOriginalCode().toLowerCase(Locale.US).contains(lower)
                    || item.getConvertedCode().toLowerCase(Locale.US).contains(lower)) {
                filtered.add(item);
            }
        }
        return filtered;
    }

    public static void deleteConversion(Context context, String id) {
        List<CodeConversionItem> current = getAllConversions(context);
        List<CodeConversionItem> updated = new ArrayList<>();
        for (CodeConversionItem item : current) {
            if (!item.getId().equals(id)) {
                updated.add(item);
            }
        }
        saveList(context, updated);
    }

    public static void clearAllConversions(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_ITEMS).apply();
    }

    private static void saveList(Context context, List<CodeConversionItem> list) {
        JSONArray array = new JSONArray();
        try {
            for (CodeConversionItem item : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", item.getId());
                obj.put("originalLanguage", item.getOriginalLanguage());
                obj.put("convertedLanguage", item.getConvertedLanguage());
                obj.put("originalFileName", item.getOriginalFileName());
                obj.put("convertedFileName", item.getConvertedFileName());
                obj.put("timestamp", item.getTimestamp());
                obj.put("originalCode", item.getOriginalCode());
                obj.put("convertedCode", item.getConvertedCode());
                obj.put("linesProcessed", item.getLinesProcessed());
                obj.put("linesGenerated", item.getLinesGenerated());
                obj.put("warningsCount", item.getWarningsCount());
                obj.put("conversionTimeMs", item.getConversionTimeMs());
                array.put(obj);
            }
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_ITEMS, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
