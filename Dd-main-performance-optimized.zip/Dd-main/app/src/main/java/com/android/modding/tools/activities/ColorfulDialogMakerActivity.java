package com.android.modding.tools.activities;

import android.view.View;
import com.android.modding.tools.dialogmaker.DialogConfig;

/**
 * Colorful Neon Dialog Maker.
 * High-voltage gradients, dynamic glowing strokes, and fluid cyber entrance animations.
 */
public class ColorfulDialogMakerActivity extends BaseDialogMakerActivity {

    @Override
    protected DialogConfig getInitialConfig() {
        return DialogConfig.createColorfulDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Colorful Neon Dialog Maker";
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("⚡ COLORFUL NEON PRESETS");
        }
        if (btnPreset1 != null) {
            btnPreset1.setText("Cyberpunk");
            btnPreset1.setOnClickListener(v -> applyPreset(createCyberpunkPreset(), "Cyberpunk Neon"));
        }
        if (btnPreset2 != null) {
            btnPreset2.setText("Sunset Fire");
            btnPreset2.setOnClickListener(v -> applyPreset(createSunsetFirePreset(), "Sunset Fire"));
        }
        if (btnPreset3 != null) {
            btnPreset3.setText("Matrix Green");
            btnPreset3.setOnClickListener(v -> applyPreset(createMatrixGreenPreset(), "Matrix Green"));
        }
        if (btnPreset4 != null) {
            btnPreset4.setText("Electric Violet");
            btnPreset4.setOnClickListener(v -> applyPreset(createElectricVioletPreset(), "Electric Violet"));
        }
    }

    @Override
    protected void setupCustomMakerOptions() {
        if (layoutProfilePhotoSection != null) layoutProfilePhotoSection.setVisibility(View.GONE);
        if (layoutVectorIconSection != null) layoutVectorIconSection.setVisibility(View.VISIBLE);
        if (tvEmblemSectionTitle != null) tvEmblemSectionTitle.setText("4. NEON GRAPHIC & VECTOR EMBLEM");
    }

    private DialogConfig createCyberpunkPreset() {
        DialogConfig c = DialogConfig.createColorfulDefault();
        c.bgHex = "#120B24";
        c.isGradient = true;
        c.bgGradientEndHex = "#280A48";
        c.borderHex = "#FF007F";
        c.titleColorHex = "#00F0FF";
        c.subtitleColorHex = "#FF007F";
        c.titleText = "Cyberpunk 2099";
        c.subtitleText = "⚡ Ultra Glowing Interface";
        c.messageText = "High-voltage gradient styling with dynamic neon glow borders and fluid animations.";
        c.hasImage = true;
        c.iconName = "CODE";
        c.iconResIndex = 1;
        c.openAnimMode = "Cyber Glitch";
        return c;
    }

    private DialogConfig createSunsetFirePreset() {
        DialogConfig c = DialogConfig.createColorfulDefault();
        c.bgHex = "#1F0B0B";
        c.isGradient = true;
        c.bgGradientEndHex = "#3B1313";
        c.borderHex = "#FF512F";
        c.titleColorHex = "#FFA07A";
        c.subtitleColorHex = "#FF512F";
        c.titleText = "Sunset Firestorm";
        c.subtitleText = "🔥 Fiery Gradient Energy";
        c.messageText = "Warm radiant gradients inspired by blazing sunset horizons and high contrast buttons.";
        c.hasImage = true;
        c.iconName = "STAR";
        c.iconResIndex = 4;
        c.openAnimMode = "Boomerang";
        return c;
    }

    private DialogConfig createMatrixGreenPreset() {
        DialogConfig c = DialogConfig.createColorfulDefault();
        c.bgHex = "#051A10";
        c.isGradient = true;
        c.bgGradientEndHex = "#0C2E1D";
        c.borderHex = "#00FF88";
        c.titleColorHex = "#00FF88";
        c.subtitleColorHex = "#80FFC0";
        c.titleText = "Matrix Terminal";
        c.subtitleText = "💻 Cyber Infiltration System";
        c.messageText = "Toxic emerald glow engineered for underground modders and security researchers.";
        c.hasImage = true;
        c.iconName = "SHIELD";
        c.iconResIndex = 0;
        c.openAnimMode = "Matrix Drop";
        return c;
    }

    private DialogConfig createElectricVioletPreset() {
        DialogConfig c = DialogConfig.createColorfulDefault();
        c.bgHex = "#1E0836";
        c.isGradient = true;
        c.bgGradientEndHex = "#3A0CA3";
        c.borderHex = "#C77DFF";
        c.titleColorHex = "#E0AAFF";
        c.subtitleColorHex = "#C77DFF";
        c.titleText = "Electric Ultraviolet";
        c.subtitleText = "✨ Nebula Galaxy Edition";
        c.messageText = "Deep space violet hues with shimmering lavender borders and cosmic glow effects.";
        c.hasImage = true;
        c.iconName = "TROPHY";
        c.iconResIndex = 8;
        c.openAnimMode = "Hologram";
        return c;
    }
}
