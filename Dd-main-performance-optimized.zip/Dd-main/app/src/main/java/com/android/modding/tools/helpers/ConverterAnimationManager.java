package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Universal Conversion & Loading Visual Animation Manager.
 * Features 5 completely new, distinct, high-tech procedural visual animations
 * for generation, compiling and conversion workflows across the app,
 * plus user-created custom animations and shuffle modes.
 */
public class ConverterAnimationManager {

    private static final String PREF_NAME = "morsalin_converter_anim_prefs";
    private static final String KEY_SELECTED_CONV_ANIM = "selected_conv_anim_id";
    private static final String KEY_CONV_SHUFFLE_MODE = "conv_anim_shuffle_mode";
    private static final String KEY_CUSTOM_CONV_ANIMS = "custom_conv_anims_json";

    public static final int SHUFFLE_OFF = 0;
    public static final int SHUFFLE_ALL = 1;
    public static final int SHUFFLE_HACKING = 2;
    public static final int SHUFFLE_CINEMATIC = 3;

    public static final String CAT_HACKING = "HACKING";
    public static final String CAT_CINEMATIC = "CINEMATIC";
    public static final String CAT_CUSTOM = "CUSTOM";

    // 5 Brand-New Visual Engine IDs (0 to 4)
    public static final int ENGINE_COSMIC_NEBULA = 0;
    public static final int ENGINE_CYBER_HEX_SHIELD = 1;
    public static final int ENGINE_NEON_WARP_TUNNEL = 2;
    public static final int ENGINE_PHOENIX_INFERNO = 3;
    public static final int ENGINE_QUANTUM_COLLIDER = 4;

    // Legacy Engine Aliases
    public static final int ENGINE_JARVIS_HUD = ENGINE_CYBER_HEX_SHIELD;
    public static final int ENGINE_MATRIX_RAIN = ENGINE_QUANTUM_COLLIDER;
    public static final int ENGINE_ORBITAL_RADAR = ENGINE_CYBER_HEX_SHIELD;
    public static final int ENGINE_HYPERSPACE_WARP = ENGINE_NEON_WARP_TUNNEL;
    public static final int ENGINE_SYNTHWAVE_SPECTRUM = ENGINE_COSMIC_NEBULA;

    // Color Palettes
    public static final int PALETTE_SIGNATURE = 0;
    public static final int PALETTE_CYBER_NEON = 1;
    public static final int PALETTE_MATRIX_GREEN = 2;
    public static final int PALETTE_RED_OVERDRIVE = 3;
    public static final int PALETTE_QUANTUM_VIOLET = 4;
    public static final int PALETTE_SOLAR_GOLD = 5;

    private static final Random RANDOM = new Random();

    public static class ConverterAnimItem {
        public final String id;
        public final String name;
        public final String description;
        public final String category;
        public final String headerBanner;
        public final int engineType;
        public final int paletteType;
        public final boolean overdriveParticles;
        public final boolean isCustom;

        public ConverterAnimItem(String id, String name, String description, String category,
                                 String headerBanner, int engineType, int paletteType,
                                 boolean overdriveParticles, boolean isCustom) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.category = category;
            this.headerBanner = headerBanner;
            this.engineType = engineType;
            this.paletteType = paletteType;
            this.overdriveParticles = overdriveParticles;
            this.isCustom = isCustom;
        }
    }

    private static final List<ConverterAnimItem> BUILTIN_LIST = new ArrayList<>();

    static {
        BUILTIN_LIST.add(new ConverterAnimItem(
                "conv_cosmic_nebula",
                "1. Cosmic Nebula & Pulsar Vortex",
                "Galactic spiral nebula arms, rotating cosmic dust, pulsing stellar event horizon & orbit stars",
                CAT_CINEMATIC,
                "🌌 COSMIC NEBULA & PULSAR VORTEX 🌌",
                ENGINE_COSMIC_NEBULA,
                PALETTE_SIGNATURE,
                true,
                false
        ));

        BUILTIN_LIST.add(new ConverterAnimItem(
                "conv_cyber_hex_shield",
                "2. Cyber Hologram Hex-Shield",
                "3D honeycomb hexagonal forcefield, 360° radar sweep, holographic telemetry reticles & neon node pulses",
                CAT_HACKING,
                "🛡️ CYBER HOLOGRAM HEX-SHIELD 🛡️",
                ENGINE_CYBER_HEX_SHIELD,
                PALETTE_CYBER_NEON,
                false,
                false
        ));

        BUILTIN_LIST.add(new ConverterAnimItem(
                "conv_neon_warp_tunnel",
                "3. Neon Vortex Hyperspace Tunnel",
                "Hypnotic 3D perspective warp tunnel, expanding concentric polygons, light-speed lasers & chromatic warp core",
                CAT_CINEMATIC,
                "🚀 NEON VORTEX HYPERSPACE TUNNEL 🚀",
                ENGINE_NEON_WARP_TUNNEL,
                PALETTE_QUANTUM_VIOLET,
                true,
                false
        ));

        BUILTIN_LIST.add(new ConverterAnimItem(
                "conv_phoenix_inferno",
                "4. Dragon Fire & Phoenix Inferno",
                "Double-helix rising flame tornado, upward convection embers, molten magma sun core & solar shockwave flares",
                CAT_CINEMATIC,
                "🔥 DRAGON FIRE & PHOENIX INFERNO 🔥",
                ENGINE_PHOENIX_INFERNO,
                PALETTE_SOLAR_GOLD,
                true,
                false
        ));

        BUILTIN_LIST.add(new ConverterAnimItem(
                "conv_quantum_collider",
                "5. Quantum Particle Collider",
                "Counter-rotating synchrotron magnetic rings, relativistic particle beam collisions, tachyon flash bursts & Lorentz flux arcs",
                CAT_HACKING,
                "⚛️ QUANTUM SUBATOMIC COLLIDER ⚛️",
                ENGINE_QUANTUM_COLLIDER,
                PALETTE_MATRIX_GREEN,
                true,
                false
        ));
    }

    public static List<ConverterAnimItem> getBuiltInAnimations() {
        return BUILTIN_LIST;
    }

    public static List<ConverterAnimItem> getAllAnimations(Context context) {
        List<ConverterAnimItem> all = new ArrayList<>(BUILTIN_LIST);
        if (context != null) {
            all.addAll(getCustomAnimations(context));
        }
        return all;
    }

    public static List<ConverterAnimItem> getCustomAnimations(Context context) {
        List<ConverterAnimItem> list = new ArrayList<>();
        if (context == null) return list;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_CONV_ANIMS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = obj.optString("id", "custom_conv_" + i);
                String name = obj.optString("name", "Custom Visual FX");
                int engine = obj.optInt("engineType", ENGINE_COSMIC_NEBULA);
                int palette = obj.optInt("paletteType", PALETTE_CYBER_NEON);
                boolean overdrive = obj.optBoolean("overdrive", true);
                String engineLabel = getEngineShortName(engine);
                String paletteLabel = getPaletteShortName(palette);
                String desc = "Custom Studio: " + engineLabel + " • " + paletteLabel
                        + (overdrive ? " • Overdrive FX" : "");
                list.add(new ConverterAnimItem(
                        id,
                        "★ " + name,
                        desc,
                        CAT_CUSTOM,
                        "⚡ " + name.toUpperCase() + " ENGINE ⚡",
                        engine,
                        palette,
                        overdrive,
                        true
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static ConverterAnimItem createCustomAnimation(
            Context context, String customName, int engineType, int paletteType, boolean overdrive) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_CONV_ANIMS, "[]");
        String newId = "custom_conv_" + System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(raw);
            JSONObject obj = new JSONObject();
            obj.put("id", newId);
            obj.put("name", customName);
            obj.put("engineType", engineType);
            obj.put("paletteType", paletteType);
            obj.put("overdrive", overdrive);
            arr.put(obj);
            sp.edit()
                    .putString(KEY_CUSTOM_CONV_ANIMS, arr.toString())
                    .putString(KEY_SELECTED_CONV_ANIM, newId)
                    .putInt(KEY_CONV_SHUFFLE_MODE, SHUFFLE_OFF)
                    .apply();
        } catch (Exception ignored) {}
        return getSelectedAnimation(context);
    }

    public static void deleteCustomAnimation(Context context, String customId) {
        if (context == null || customId == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_CONV_ANIMS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            JSONArray updated = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (!customId.equals(obj.optString("id"))) {
                    updated.put(obj);
                }
            }
            SharedPreferences.Editor editor = sp.edit().putString(KEY_CUSTOM_CONV_ANIMS, updated.toString());
            if (customId.equals(sp.getString(KEY_SELECTED_CONV_ANIM, ""))) {
                editor.putString(KEY_SELECTED_CONV_ANIM, "conv_cosmic_nebula");
            }
            editor.apply();
        } catch (Exception ignored) {}
    }

    public static ConverterAnimItem getSelectedAnimation(Context context) {
        if (context == null) return BUILTIN_LIST.get(0);
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String id = sp.getString(KEY_SELECTED_CONV_ANIM, "conv_cosmic_nebula");
        for (ConverterAnimItem item : getAllAnimations(context)) {
            if (item.id.equals(id)) {
                return item;
            }
        }
        return BUILTIN_LIST.get(0);
    }

    public static void setSelectedAnimation(Context context, String animId) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_SELECTED_CONV_ANIM, animId).apply();
    }

    public static int getShuffleMode(Context context) {
        if (context == null) return SHUFFLE_OFF;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_CONV_SHUFFLE_MODE, SHUFFLE_OFF);
    }

    public static void setShuffleMode(Context context, int mode) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_CONV_SHUFFLE_MODE, mode).apply();
    }

    public static ConverterAnimItem resolveAnimationForConversion(Context context) {
        if (context == null) return BUILTIN_LIST.get(0);
        int shuffle = getShuffleMode(context);
        List<ConverterAnimItem> all = getAllAnimations(context);
        if (shuffle == SHUFFLE_ALL && !all.isEmpty()) {
            return all.get(RANDOM.nextInt(all.size()));
        } else if (shuffle == SHUFFLE_HACKING) {
            List<ConverterAnimItem> pool = new ArrayList<>();
            for (ConverterAnimItem item : all) {
                if (CAT_HACKING.equals(item.category) || item.isCustom) {
                    pool.add(item);
                }
            }
            if (!pool.isEmpty()) return pool.get(RANDOM.nextInt(pool.size()));
        } else if (shuffle == SHUFFLE_CINEMATIC) {
            List<ConverterAnimItem> pool = new ArrayList<>();
            for (ConverterAnimItem item : all) {
                if (CAT_CINEMATIC.equals(item.category) || item.isCustom) {
                    pool.add(item);
                }
            }
            if (!pool.isEmpty()) return pool.get(RANDOM.nextInt(pool.size()));
        }
        return getSelectedAnimation(context);
    }

    public static void resetToDefault(Context context) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit()
                .putString(KEY_SELECTED_CONV_ANIM, "conv_cosmic_nebula")
                .putInt(KEY_CONV_SHUFFLE_MODE, SHUFFLE_OFF)
                .apply();
    }

    public static String getEngineShortName(int engineType) {
        switch (engineType) {
            case ENGINE_COSMIC_NEBULA: return "Cosmic Nebula Vortex";
            case ENGINE_CYBER_HEX_SHIELD: return "Cyber Hex-Shield HUD";
            case ENGINE_NEON_WARP_TUNNEL: return "Neon Hyperspace Warp";
            case ENGINE_PHOENIX_INFERNO: return "Phoenix Inferno Aura";
            case ENGINE_QUANTUM_COLLIDER: return "Quantum Particle Collider";
            default: return "Cosmic Nebula Vortex";
        }
    }

    public static String getPaletteShortName(int paletteType) {
        switch (paletteType) {
            case PALETTE_SIGNATURE: return "Signature Theme";
            case PALETTE_CYBER_NEON: return "Cyber Cyan & Magenta";
            case PALETTE_MATRIX_GREEN: return "Matrix Hacker Green";
            case PALETTE_RED_OVERDRIVE: return "Crimson Red & Gold";
            case PALETTE_QUANTUM_VIOLET: return "Ultraviolet & Ice";
            case PALETTE_SOLAR_GOLD: return "Solar Supernova Gold";
            default: return "Signature Theme";
        }
    }
}
