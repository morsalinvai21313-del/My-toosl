package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public class AnimatedDividerManager {

    private static final String PREF_NAME = "morsalin_app_settings";
    public static final String KEY_DIVIDER_STYLE = "global_animated_divider_style";

    // 1, 3, 6 preserved as requested, and 10 brand-new premium styles added!
    public static final int STYLE_LIGHT_SWEEP_LTR = 0;       // 1. একদিক থেকে অন্যদিকে চলমান আলো (Kept)
    public static final int STYLE_DUAL_INWARD_BEAMS = 1;     // 2. দুই দিক থেকে মাঝখানে আসা আলো (Kept #3)
    public static final int STYLE_CENTER_GLOW = 2;           // 3. মাঝখান থেকে উজ্জ্বল আলো (Kept #6)
    public static final int STYLE_PLASMA_COMET = 3;          // 4. প্লাজমা ধূমকেতু ও স্পার্কলিং টেইল (New)
    public static final int STYLE_CYBER_GLITCH_SCAN = 4;     // 5. সাইবার গ্লিচ লেজার স্ক্যানার (New)
    public static final int STYLE_QUANTUM_RIPPLE = 5;        // 6. কোয়ান্টাম রিপল শকওয়েভ (New)
    public static final int STYLE_ELECTRIC_TESLA_ARC = 6;    // 7. হাই-ভোল্টেজ টেসলা ইলেকট্রিক আর্ক (New)
    public static final int STYLE_DIGITAL_BINARY_STREAM = 7; // 8. ডিজিটাল ম্যাট্রিক্স বিট স্ট্রিম (New)
    public static final int STYLE_HYPERDRIVE_WARP = 8;       // 9. হাইপারড্রাইভ ওয়ার্প স্পিড স্ট্রিক (New)
    public static final int STYLE_DUAL_PING_PONG = 9;        // 10. ডুয়াল পিং-পং বাউন্সিং ওর্ব (New)
    public static final int STYLE_SUPERNOVA_LASER = 10;      // 11. সুপারনোভা কোর লেজার বার্স্ট (New)
    public static final int STYLE_AURORA_CYBER_RIBBON = 11;  // 12. অরোরা সাইবার রিবন ফ্লো (New)
    public static final int STYLE_BREATHING_STARLIGHT_RAIL = 12; // 13. ব্রিদিং স্টারলাইট নোডস রেল (New)

    public static final int TOTAL_STYLES = 13;

    public static final String[] STYLE_NAMES = {
            "1. Light Sweep (Left → Right)",
            "2. Dual Inward Beams (Colliding Flare)",
            "3. Center Glow (Core Pulse)",
            "4. Plasma Comet (Sparkling Tail)",
            "5. Cyber Glitch Scanner",
            "6. Quantum Ripple (Drop Shockwave)",
            "7. Electric Tesla Arc (Live Sparks)",
            "8. Digital Matrix Bit Stream",
            "9. Hyperdrive Warp Streak",
            "10. Dual Orb Ping-Pong",
            "11. Supernova Laser Burst",
            "12. Aurora Cyber Ribbon",
            "13. Breathing Starlight Nodes"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Smooth luminous cyan beam sweeping left to right",
            "Two energetic light pulses meeting in the center with a flare",
            "Intense luminous glow expanding outward from the center",
            "Radiant plasma comet with lens flare and a glittering trailing dust tail",
            "High-tech sci-fi scanner bar sweeping with digital micro-hops and cyber flicker",
            "Periodic droplet impulse at center sending high-speed capillary ripple waves outward",
            "High-voltage lightning arc sparking along the rail with jittering micro-branches",
            "Glowing cyber pixel blocks and binary data packets streaming in multi-lane parallax",
            "Charges up and streaks across at warp speed with dynamic motion blur",
            "Two luminous neon orbs bouncing off opposite walls and passing through at center",
            "Central photon charge builds up and unleashes an intense double-sided laser blade eruption",
            "Soft, ethereal undulating cyan-turquoise luminescence flowing like an aurora borealis",
            "Minimalist elegant track with 7 starlight nodes pulsing in a gentle organic wave"
    };

    public interface OnDividerStyleChangeListener {
        void onDividerStyleChanged(int newStyle);
    }

    private static final List<OnDividerStyleChangeListener> listeners = new ArrayList<>();

    public static synchronized void registerListener(OnDividerStyleChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public static synchronized void unregisterListener(OnDividerStyleChangeListener listener) {
        if (listener != null) {
            listeners.remove(listener);
        }
    }

    public static synchronized void notifyListeners(int newStyle) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            OnDividerStyleChangeListener l = listeners.get(i);
            if (l != null) {
                l.onDividerStyleChanged(newStyle);
            }
        }
    }

    public static int getSavedStyle(Context context) {
        if (context == null) return STYLE_LIGHT_SWEEP_LTR;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        int style = sp.getInt(KEY_DIVIDER_STYLE, STYLE_LIGHT_SWEEP_LTR);
        if (style < 0 || style >= TOTAL_STYLES) {
            style = STYLE_LIGHT_SWEEP_LTR;
        }
        return style;
    }

    public static void setSavedStyle(Context context, int style) {
        if (context == null) return;
        if (style < 0 || style >= TOTAL_STYLES) {
            style = STYLE_LIGHT_SWEEP_LTR;
        }
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_DIVIDER_STYLE, style).apply();
        notifyListeners(style);
    }

    public static String getStyleName(int style) {
        if (style >= 0 && style < STYLE_NAMES.length) {
            return STYLE_NAMES[style];
        }
        return STYLE_NAMES[STYLE_LIGHT_SWEEP_LTR];
    }

    public static String getStyleShortName(int style) {
        if (style >= 0 && style < STYLE_NAMES.length) {
            return STYLE_NAMES[style].replaceFirst("^\\d+\\.\\s*", "").split(" \\(")[0];
        }
        return "Light Sweep";
    }

    public static String getStyleDescription(int style) {
        if (style >= 0 && style < STYLE_DESCRIPTIONS.length) {
            return STYLE_DESCRIPTIONS[style];
        }
        return "";
    }
}
