package com.android.modding.tools.activities;

import com.android.modding.tools.toastmaker.ToastConfig;

/**
 * Colorful Toast Maker.
 * Focused on rich gradient backgrounds, vibrant neon borders, and eye-catching
 * visual aesthetics compiled into Dalvik classes.dex executables and packages.
 */
public class ColorfulToastActivity extends BaseToastMakerActivity {

    @Override
    protected ToastConfig getInitialConfig() {
        return ToastConfig.createColorfulDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Colorful Toast Maker";
    }

    @Override
    protected boolean showGalleryPickerSection() {
        return false;
    }

    @Override
    protected boolean showEmblemSection() {
        return false;
    }

    @Override
    protected boolean showTitleInput() {
        return false;
    }

    @Override
    protected boolean showAnimationSection() {
        return false;
    }

    @Override
    protected boolean showBase64Section() {
        return false;
    }

    @Override
    protected boolean showGradientSection() {
        return true;
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("🌈 VIBRANT COLORFUL QUICK PRESETS");
        }

        if (btnPreset1 != null) {
            btnPreset1.setText("Cyber Neon");
            btnPreset1.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createColorfulDefault();
                p.toastName = "Colorful_Cyber_Neon";
                p.messageText = "Cyberpunk 2077 Theme Activated!";
                p.bgHex = "#FF007F";
                p.bgGradientEndHex = "#00E5FF";
                p.borderHex = "#FFFFFF";
                p.borderWidthDp = 2;
                p.cornerRadiusDp = 24;
                p.animMode = "Zoom";
                applyPreset(p, "Cyber Neon");
            });
        }

        if (btnPreset2 != null) {
            btnPreset2.setText("Sunset Blaze");
            btnPreset2.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createColorfulDefault();
                p.toastName = "Colorful_Sunset_Blaze";
                p.messageText = "Burning Hot Premium Privileges Unlocked!";
                p.bgHex = "#FF3D00";
                p.bgGradientEndHex = "#FFD600";
                p.borderHex = "#FFF59D";
                p.borderWidthDp = 2;
                p.cornerRadiusDp = 20;
                p.animMode = "Bounce";
                applyPreset(p, "Sunset Blaze");
            });
        }

        if (btnPreset3 != null) {
            btnPreset3.setText("Toxic Emerald");
            btnPreset3.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createColorfulDefault();
                p.toastName = "Colorful_Toxic_Emerald";
                p.messageText = "Hyper-Speed Injection Successful!";
                p.bgHex = "#00E676";
                p.bgGradientEndHex = "#00B0FF";
                p.borderHex = "#B9F6CA";
                p.borderWidthDp = 2;
                p.cornerRadiusDp = 22;
                p.animMode = "Slide";
                applyPreset(p, "Toxic Emerald");
            });
        }

        if (btnPreset4 != null) {
            btnPreset4.setText("Velvet Nebula");
            btnPreset4.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createColorfulDefault();
                p.toastName = "Colorful_Velvet_Nebula";
                p.messageText = "Welcome to Galaxy Modding Edition • Sanny & Morsalin";
                p.bgHex = "#7C4DFF";
                p.bgGradientEndHex = "#FF4081";
                p.borderHex = "#EA80FC";
                p.borderWidthDp = 2;
                p.cornerRadiusDp = 26;
                p.animMode = "Flip 3D";
                applyPreset(p, "Velvet Nebula");
            });
        }
    }
}
