package com.android.modding.tools.helpers;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.TypedValue;








import java.util.List;
import java.util.Map;

public class LiveDrawableRenderer {

    /**
     * Builds a single GradientDrawable for a LayerModel.
     */
    public static GradientDrawable createShapeDrawable(Context context, LayerModel layer) {
        GradientDrawable drawable = new GradientDrawable();

        // Shape type
        if (LayerModel.SHAPE_OVAL.equals(layer.getShapeType())) {
            drawable.setShape(GradientDrawable.OVAL);
        } else if (LayerModel.SHAPE_LINE.equals(layer.getShapeType())) {
            drawable.setShape(GradientDrawable.LINE);
        } else if (LayerModel.SHAPE_RING.equals(layer.getShapeType())) {
            drawable.setShape(GradientDrawable.RING);
        } else {
            drawable.setShape(GradientDrawable.RECTANGLE);
        }

        // Fill: Gradient or Solid
        if (layer.isGradient()) {
            GradientModel g = layer.getGradient();
            int start = parseColorSafe(g.getStartColor(), Color.TRANSPARENT);
            int end = parseColorSafe(g.getEndColor(), Color.TRANSPARENT);

            int[] colors;
            boolean hasValidCenter = g.isUseCenterColor()
                    && g.getCenterColor() != null
                    && !g.getCenterColor().isEmpty()
                    && !g.getCenterColor().equals("#00000000");

            if (hasValidCenter) {
                int center = parseColorSafe(g.getCenterColor(), Color.TRANSPARENT);
                colors = new int[]{start, center, end};
            } else {
                colors = new int[]{start, end};
            }
            drawable.setColors(colors);

            if (GradientModel.TYPE_RADIAL.equals(g.getType())) {
                drawable.setGradientType(GradientDrawable.RADIAL_GRADIENT);
                float radiusPx = dpToPx(context, g.getGradientRadiusDp());
                drawable.setGradientRadius(Math.max(1f, radiusPx));
                drawable.setGradientCenter(g.getCenterX(), g.getCenterY());
            } else if (GradientModel.TYPE_SWEEP.equals(g.getType())) {
                drawable.setGradientType(GradientDrawable.SWEEP_GRADIENT);
                drawable.setGradientCenter(g.getCenterX(), g.getCenterY());
            } else {
                drawable.setGradientType(GradientDrawable.LINEAR_GRADIENT);
                drawable.setOrientation(angleToOrientation(g.getNormalizedAngle()));
            }
        } else {
            int solidColor = parseColorSafe(layer.getSolidColor(), Color.TRANSPARENT);
            drawable.setColor(solidColor);
        }

        // Corners
        CornersModel corners = layer.getCorners();
        if (corners != null) {
            float tl = dpToPx(context, corners.getTopLeftDp());
            float tr = dpToPx(context, corners.getTopRightDp());
            float br = dpToPx(context, corners.getBottomRightDp());
            float bl = dpToPx(context, corners.getBottomLeftDp());
            drawable.setCornerRadii(new float[]{tl, tl, tr, tr, br, br, bl, bl});
        }

        // Stroke
        StrokeModel stroke = layer.getStroke();
        if (stroke != null && stroke.getWidthDp() > 0) {
            int strokeWidthPx = (int) dpToPx(context, stroke.getWidthDp());
            int strokeColor = parseColorSafe(stroke.getColor(), Color.CYAN);
            if (stroke.getDashWidthDp() > 0) {
                float dashW = dpToPx(context, stroke.getDashWidthDp());
                float dashG = dpToPx(context, stroke.getDashGapDp());
                drawable.setStroke(strokeWidthPx, strokeColor, dashW, dashG);
            } else {
                drawable.setStroke(strokeWidthPx, strokeColor);
            }
        }

        return drawable;
    }

    /**
     * Builds a LayerDrawable from a list of LayerModels.
     */
    public static Drawable createLayerListDrawable(Context context, List<LayerModel> layers) {
        if (layers == null || layers.isEmpty()) {
            return new GradientDrawable();
        }

        // Count enabled
        int count = 0;
        for (LayerModel l : layers) {
            if (l.isEnabled()) count++;
        }
        if (count == 0) return new GradientDrawable();

        Drawable[] drawables = new Drawable[count];
        InsetsModel[] insets = new InsetsModel[count];
        int index = 0;
        for (LayerModel l : layers) {
            if (l.isEnabled()) {
                drawables[index] = createShapeDrawable(context, l);
                insets[index] = l.getInsets();
                index++;
            }
        }

        LayerDrawable layerDrawable = new LayerDrawable(drawables);
        for (int i = 0; i < count; i++) {
            InsetsModel ins = insets[i];
            if (ins != null && ins.hasAnyInset()) {
                int left = (int) dpToPx(context, ins.getLeftDp());
                int top = (int) dpToPx(context, ins.getTopDp());
                int right = (int) dpToPx(context, ins.getRightDp());
                int bottom = (int) dpToPx(context, ins.getBottomDp());
                layerDrawable.setLayerInset(i, left, top, right, bottom);
            }
        }
        return layerDrawable;
    }

    /**
     * Builds a full interactive StateListDrawable (Selector) for button states.
     */
    public static StateListDrawable createSelectorDrawable(Context context, Map<String, StateModel> stateMap) {
        StateListDrawable sld = new StateListDrawable();

        // 1. Pressed
        StateModel pressed = stateMap.get(StateModel.STATE_PRESSED);
        if (pressed != null && pressed.isActive()) {
            sld.addState(new int[]{android.R.attr.state_pressed}, createLayerListDrawable(context, pressed.getLayers()));
        }

        // 2. Checked
        StateModel checked = stateMap.get(StateModel.STATE_CHECKED);
        if (checked != null && checked.isActive()) {
            sld.addState(new int[]{android.R.attr.state_checked}, createLayerListDrawable(context, checked.getLayers()));
        }

        // 3. Focused
        StateModel focused = stateMap.get(StateModel.STATE_FOCUSED);
        if (focused != null && focused.isActive()) {
            sld.addState(new int[]{android.R.attr.state_focused}, createLayerListDrawable(context, focused.getLayers()));
        }

        // 4. Default / Normal
        StateModel normal = stateMap.get(StateModel.STATE_NORMAL);
        if (normal != null) {
            sld.addState(new int[]{}, createLayerListDrawable(context, normal.getLayers()));
        }

        return sld;
    }

    /**
     * Builds a RippleDrawable (API 21+)
     */
    public static Drawable createRippleDrawable(Context context, String rippleColorHex, LayerModel content, LayerModel mask) {
        int color = parseColorSafe(rippleColorHex, Color.parseColor("#4000FFFF"));
        ColorStateList csl = ColorStateList.valueOf(color);
        Drawable contentDraw = content != null ? createShapeDrawable(context, content) : null;
        Drawable maskDraw = mask != null ? createShapeDrawable(context, mask) : null;

        return new RippleDrawable(csl, contentDraw, maskDraw);
    }

    public static int parseColorSafe(String hex, int fallback) {
        if (hex == null || hex.trim().isEmpty()) return fallback;
        try {
            return Color.parseColor(hex.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    public static float dpToPx(Context context, float dp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    private static GradientDrawable.Orientation angleToOrientation(int angle) {
        switch (angle) {
            case 0:
                return GradientDrawable.Orientation.LEFT_RIGHT;
            case 45:
                return GradientDrawable.Orientation.BL_TR;
            case 90:
                return GradientDrawable.Orientation.BOTTOM_TOP;
            case 135:
                return GradientDrawable.Orientation.BR_TL;
            case 180:
                return GradientDrawable.Orientation.RIGHT_LEFT;
            case 225:
                return GradientDrawable.Orientation.TR_BL;
            case 270:
                return GradientDrawable.Orientation.TOP_BOTTOM;
            case 315:
                return GradientDrawable.Orientation.TL_BR;
            default:
                return GradientDrawable.Orientation.TOP_BOTTOM;
        }
    }
}
