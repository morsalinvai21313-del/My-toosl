package com.android.modding.tools.activities;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.ConverterDialogManager;
import com.android.modding.tools.generators.JavaKotlinConverterEngine;
import com.android.modding.tools.generators.JavaKotlinConverterEngine.ConversionResult;
import com.android.modding.tools.generators.JavaKotlinConverterEngine.Direction;
import com.android.modding.tools.helpers.CodeConversionHistoryManager;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.CodeConversionItem;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class JavaKotlinConverterActivity extends AppCompatActivity {

    private Direction currentDirection = Direction.JAVA_TO_KOTLIN;
    private com.android.modding.tools.generators.ConversionPostProcessor.QualityMode currentQualityMode =
            com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.BALANCED;
    private String currentInputFileName = "MyActivity.java";
    private String currentOutputFileName = "MyActivity.kt";
    private String pendingSafExportContent = "";
    private String pendingSafExportFileName = "MyActivity.kt";

    // Top & Mode buttons
    private Button btnModeJavaToKt;
    private Button btnModeKtToJava;
    private Button btnSwapDirection;
    private Button btnQualityFast;
    private Button btnQualityBalanced;
    private Button btnQualityStrict;

    // Panels
    private LinearLayout panelInput;
    private LinearLayout panelAnim;
    private LinearLayout panelError;
    private LinearLayout panelOutput;

    // Input controls
    private TextView tvInputFileName;
    private TextView tvInputCharCount;
    private TextView tvInputLineCount;
    private TextView tvInputLineNumbers;
    private EditText etInputCode;
    private ScrollView scrollInputEditor;
    private LinearLayout layoutInputSearchBar;
    private EditText etInputSearchQuery;
    private Button btnInputSearchGo;
    private boolean isInputJumpMode = false;

    // Animation controls
    private TextView tvAnimStepBadge;
    private TextView tvAnimStepStatus;
    private ConversionAnimationView viewConversionAnim;

    // Error controls
    private TextView tvErrorTitle;
    private TextView tvErrorReason;
    private TextView tvErrorDetails;

    // Output controls
    private TextView tvOutputSourceTargetBadge;
    private TextView tvOutputStats;
    private TextView tvOutputWarnings;
    private TextView tvOutputLineNumbers;
    private EditText etOutputCode;
    private ScrollView scrollOutputEditor;
    private Button btnOutputEditToggle;
    private LinearLayout layoutOutputSearchBar;
    private EditText etOutputSearchQuery;
    private Button btnOutputSearchGo;
    private boolean isOutputJumpMode = false;
    private boolean isOutputEditable = false;

    // Undo / Redo stacks
    private final List<String> inputUndoStack = new ArrayList<>();
    private int inputUndoIndex = -1;
    private boolean suppressInputHistory = false;

    private final List<String> outputUndoStack = new ArrayList<>();
    private int outputUndoIndex = -1;
    private boolean suppressOutputHistory = false;

    private ConversionResult lastConversionResult = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable highlightInputRunnable = () -> {
        if (etInputCode != null && etInputCode.getText() != null) {
            String search = (layoutInputSearchBar != null && layoutInputSearchBar.getVisibility() == View.VISIBLE && !isInputJumpMode)
                    ? etInputSearchQuery.getText().toString() : null;
            SyntaxHighlighter.applyHighlighting(etInputCode.getText(), search);
        }
    };
    private final Runnable highlightOutputRunnable = () -> {
        if (etOutputCode != null && etOutputCode.getText() != null) {
            String search = (layoutOutputSearchBar != null && layoutOutputSearchBar.getVisibility() == View.VISIBLE && !isOutputJumpMode)
                    ? etOutputSearchQuery.getText().toString() : null;
            SyntaxHighlighter.applyHighlighting(etOutputCode.getText(), search);
        }
    };

    // SAF File Picker for importing .java / .kt files
    private final ActivityResultLauncher<String[]> openFileLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::handleImportedFileUri);

    // SAF Document Creator for saving/exporting converted file
    private final ActivityResultLauncher<String> createDocumentLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("text/plain"), this::handleCreatedDocumentUri);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_kotlin_converter);

        GlobalTouchParticleManager.attach(this);

        bindViews();
        setupEditors();
        setupClickListeners();
        updateDirectionUI();

        // Pre-populate sample Java code so user can test immediately or clear/import
        setInputCodeProgrammatically(JavaKotlinConverterEngine.getSampleJavaCode(), "MyActivity.java", true);
    }

    private void bindViews() {
        btnModeJavaToKt = findViewById(R.id.btn_mode_java_to_kotlin);
        btnModeKtToJava = findViewById(R.id.btn_mode_kotlin_to_java);
        btnSwapDirection = findViewById(R.id.btn_swap_direction);
        btnQualityFast = findViewById(R.id.btn_quality_fast);
        btnQualityBalanced = findViewById(R.id.btn_quality_balanced);
        btnQualityStrict = findViewById(R.id.btn_quality_strict);

        panelInput = findViewById(R.id.layout_converter_input_panel);
        panelAnim = findViewById(R.id.layout_converter_anim_panel);
        panelError = findViewById(R.id.layout_converter_error_panel);
        panelOutput = findViewById(R.id.layout_converter_output_panel);

        tvInputFileName = findViewById(R.id.tv_input_file_name);
        tvInputCharCount = findViewById(R.id.tv_input_char_count);
        tvInputLineCount = findViewById(R.id.tv_input_line_count);
        tvInputLineNumbers = findViewById(R.id.tv_input_line_numbers);
        etInputCode = findViewById(R.id.et_input_source_code);
        scrollInputEditor = findViewById(R.id.scroll_input_editor);
        layoutInputSearchBar = findViewById(R.id.layout_input_search_bar);
        etInputSearchQuery = findViewById(R.id.et_input_search_query);
        btnInputSearchGo = findViewById(R.id.btn_input_search_go);

        tvAnimStepBadge = findViewById(R.id.tv_anim_step_badge);
        tvAnimStepStatus = findViewById(R.id.tv_anim_step_status);
        viewConversionAnim = findViewById(R.id.view_conversion_animation);

        tvErrorTitle = findViewById(R.id.tv_error_title);
        tvErrorReason = findViewById(R.id.tv_error_reason);
        tvErrorDetails = findViewById(R.id.tv_error_details);

        tvOutputSourceTargetBadge = findViewById(R.id.tv_output_source_target_badge);
        tvOutputStats = findViewById(R.id.tv_output_stats);
        tvOutputWarnings = findViewById(R.id.tv_output_warnings);
        tvOutputLineNumbers = findViewById(R.id.tv_output_line_numbers);
        etOutputCode = findViewById(R.id.et_output_code);
        scrollOutputEditor = findViewById(R.id.scroll_output_editor);
        btnOutputEditToggle = findViewById(R.id.btn_output_edit_toggle);
        layoutOutputSearchBar = findViewById(R.id.layout_output_search_bar);
        etOutputSearchQuery = findViewById(R.id.et_output_search_query);
        btnOutputSearchGo = findViewById(R.id.btn_output_search_go);
    }

    private void setupEditors() {
        etInputCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                updateInputCountersAndLines(text);
                if (!suppressInputHistory) {
                    pushInputUndoState(text);
                }
                mainHandler.removeCallbacks(highlightInputRunnable);
                mainHandler.postDelayed(highlightInputRunnable, 120);
            }
        });

        etOutputCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString();
                updateLineNumbersView(tvOutputLineNumbers, text);
                if (!suppressOutputHistory) {
                    pushOutputUndoState(text);
                }
                mainHandler.removeCallbacks(highlightOutputRunnable);
                mainHandler.postDelayed(highlightOutputRunnable, 120);
            }
        });
    }

    private void setupClickListeners() {
        findViewById(R.id.btn_converter_back).setOnClickListener(v -> finishWithBackwardAnim());

        findViewById(R.id.btn_converter_sample).setOnClickListener(v -> {
            if (currentDirection == Direction.JAVA_TO_KOTLIN) {
                setInputCodeProgrammatically(JavaKotlinConverterEngine.getSampleJavaCode(), "MyActivity.java", true);
                MorsalinToast.showSuccess(this, "Sample Loaded", "Loaded sample Android Java Activity.");
            } else {
                setInputCodeProgrammatically(JavaKotlinConverterEngine.getSampleKotlinCode(), "MainActivity.kt", true);
                MorsalinToast.showSuccess(this, "Sample Loaded", "Loaded sample Android Kotlin Activity.");
            }
            showPanel(panelInput);
        });

        findViewById(R.id.btn_converter_history_top).setOnClickListener(v -> openHistoryModal());

        if (btnQualityFast != null) {
            btnQualityFast.setOnClickListener(v -> {
                currentQualityMode = com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.FAST;
                updateQualityUI();
            });
        }
        if (btnQualityBalanced != null) {
            btnQualityBalanced.setOnClickListener(v -> {
                currentQualityMode = com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.BALANCED;
                updateQualityUI();
            });
        }
        if (btnQualityStrict != null) {
            btnQualityStrict.setOnClickListener(v -> {
                currentQualityMode = com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.STRICT;
                updateQualityUI();
            });
        }

        // Mode & Swap buttons
        btnModeJavaToKt.setOnClickListener(v -> {
            if (currentDirection != Direction.JAVA_TO_KOTLIN) {
                currentDirection = Direction.JAVA_TO_KOTLIN;
                syncFileNameExtensionForDirection();
                updateDirectionUI();
                showPanel(panelInput);
            }
        });

        btnModeKtToJava.setOnClickListener(v -> {
            if (currentDirection != Direction.KOTLIN_TO_JAVA) {
                currentDirection = Direction.KOTLIN_TO_JAVA;
                syncFileNameExtensionForDirection();
                updateDirectionUI();
                showPanel(panelInput);
            }
        });

        btnSwapDirection.setOnClickListener(v -> {
            v.animate().rotationBy(180f).setDuration(220).start();
            if (panelOutput.getVisibility() == View.VISIBLE && etOutputCode.getText().length() > 0) {
                // Swap output into input and flip direction
                String outCode = etOutputCode.getText().toString();
                currentDirection = (currentDirection == Direction.JAVA_TO_KOTLIN)
                        ? Direction.KOTLIN_TO_JAVA : Direction.JAVA_TO_KOTLIN;
                currentInputFileName = currentOutputFileName;
                syncFileNameExtensionForDirection();
                setInputCodeProgrammatically(outCode, currentInputFileName, true);
                updateDirectionUI();
                showPanel(panelInput);
                MorsalinToast.showSuccess(this, "Direction Swapped ⇄",
                        "Loaded converted code into editor for reverse conversion.");
            } else {
                currentDirection = (currentDirection == Direction.JAVA_TO_KOTLIN)
                        ? Direction.KOTLIN_TO_JAVA : Direction.JAVA_TO_KOTLIN;
                syncFileNameExtensionForDirection();
                updateDirectionUI();
                MorsalinToast.showSuccess(this, "Direction Swapped ⇄",
                        currentDirection == Direction.JAVA_TO_KOTLIN ? "Mode: Java → Kotlin" : "Mode: Kotlin → Java");
            }
        });

        // Import File & Paste Code
        findViewById(R.id.btn_import_source_file).setOnClickListener(v -> {
            try {
                openFileLauncher.launch(new String[]{"*/*"});
            } catch (Exception e) {
                MorsalinToast.show(this, R.drawable.ic_download, "File Picker Error", e.getMessage());
            }
        });

        findViewById(R.id.btn_paste_source_code).setOnClickListener(v -> pasteFromClipboard());

        // Input Editor Utility Toolbar
        findViewById(R.id.btn_input_undo).setOnClickListener(v -> performInputUndo());
        findViewById(R.id.btn_input_redo).setOnClickListener(v -> performInputRedo());
        findViewById(R.id.btn_input_search_toggle).setOnClickListener(v -> toggleSearchBar(true, false));
        findViewById(R.id.btn_input_jump_line).setOnClickListener(v -> toggleSearchBar(true, true));
        findViewById(R.id.btn_input_copy_line).setOnClickListener(v -> copyCurrentLine(etInputCode));
        findViewById(R.id.btn_input_select_all).setOnClickListener(v -> {
            etInputCode.requestFocus();
            etInputCode.selectAll();
            MorsalinToast.showSuccess(this, "Selected All", "All source code selected.");
        });
        findViewById(R.id.btn_input_copy_all).setOnClickListener(v -> {
            String code = etInputCode.getText().toString();
            if (code.trim().isEmpty()) {
                MorsalinToast.show(this, R.drawable.ic_content_copy, "Empty", "Nothing to copy.");
                return;
            }
            ConverterDialogManager.copyToClipboard(this, currentInputFileName, code);
            MorsalinToast.showCopy(this, "Source code copied to clipboard!");
        });
        findViewById(R.id.btn_input_clear).setOnClickListener(v -> {
            etInputCode.setText("");
            MorsalinToast.showReset(this, "Source code editor cleared.");
        });

        btnInputSearchGo.setOnClickListener(v -> executeSearchOrJump(etInputCode, scrollInputEditor, etInputSearchQuery, isInputJumpMode));
        findViewById(R.id.btn_input_search_close).setOnClickListener(v -> {
            layoutInputSearchBar.setVisibility(View.GONE);
            SyntaxHighlighter.applyHighlighting(etInputCode.getText(), null);
        });

        // Primary Convert Button
        findViewById(R.id.btn_convert_code_main).setOnClickListener(v -> startConversionProcess());

        // Error Panel Buttons
        findViewById(R.id.btn_error_back_editor).setOnClickListener(v -> showPanel(panelInput));
        findViewById(R.id.btn_error_try_again).setOnClickListener(v -> startConversionProcess());

        // Output Screen Controls
        findViewById(R.id.btn_output_back_to_input).setOnClickListener(v -> showPanel(panelInput));
        findViewById(R.id.btn_output_select_all).setOnClickListener(v -> {
            etOutputCode.requestFocus();
            etOutputCode.selectAll();
            MorsalinToast.showSuccess(this, "Selected All", "All converted code selected.");
        });
        findViewById(R.id.btn_output_search_toggle).setOnClickListener(v -> toggleSearchBar(false, false));
        findViewById(R.id.btn_output_jump_line).setOnClickListener(v -> toggleSearchBar(false, true));
        findViewById(R.id.btn_output_copy_line).setOnClickListener(v -> copyCurrentLine(etOutputCode));
        findViewById(R.id.btn_output_undo).setOnClickListener(v -> performOutputUndo());
        findViewById(R.id.btn_output_redo).setOnClickListener(v -> performOutputRedo());

        btnOutputSearchGo.setOnClickListener(v -> executeSearchOrJump(etOutputCode, scrollOutputEditor, etOutputSearchQuery, isOutputJumpMode));
        findViewById(R.id.btn_output_search_close).setOnClickListener(v -> {
            layoutOutputSearchBar.setVisibility(View.GONE);
            SyntaxHighlighter.applyHighlighting(etOutputCode.getText(), null);
        });

        // Output Bottom Action Buttons
        btnOutputEditToggle.setOnClickListener(v -> toggleOutputEditMode());

        findViewById(R.id.btn_output_copy).setOnClickListener(v -> {
            String out = etOutputCode.getText().toString();
            ConverterDialogManager.copyToClipboard(this, currentOutputFileName, out);
            MorsalinToast.showCopy(this, "Converted code copied to clipboard!");
        });

        findViewById(R.id.btn_output_save_device).setOnClickListener(v -> {
            pendingSafExportContent = etOutputCode.getText().toString();
            pendingSafExportFileName = currentOutputFileName;
            try {
                createDocumentLauncher.launch(currentOutputFileName);
            } catch (Exception e) {
                ConverterDialogManager.exportCodeToDownloads(this, currentOutputFileName, pendingSafExportContent);
            }
        });

        findViewById(R.id.btn_output_export).setOnClickListener(v -> {
            String defaultExt = (currentDirection == Direction.JAVA_TO_KOTLIN) ? ".kt" : ".java";
            String out = etOutputCode.getText().toString();
            ConverterDialogManager.showExportDialog(
                    this,
                    currentOutputFileName,
                    defaultExt,
                    out,
                    (fullFileName, mimeType, codeContent) -> {
                        pendingSafExportFileName = fullFileName;
                        pendingSafExportContent = codeContent;
                        try {
                            createDocumentLauncher.launch(fullFileName);
                        } catch (Exception e) {
                            ConverterDialogManager.exportCodeToDownloads(this, fullFileName, codeContent);
                        }
                    }
            );
        });

        findViewById(R.id.btn_output_share).setOnClickListener(v -> {
            String out = etOutputCode.getText().toString();
            ConverterDialogManager.shareCodeFileOrText(this, currentOutputFileName, out);
        });

        findViewById(R.id.btn_output_save_history).setOnClickListener(v -> saveCurrentConversionToHistory());
    }

    private void startConversionProcess() {
        final String sourceCode = etInputCode.getText().toString();
        if (sourceCode.trim().isEmpty()) {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Empty Input", "Please paste or import source code first!");
            return;
        }

        // Auto-detect if user forgot to switch tab when importing/pasting obvious file
        final Direction activeDirection = currentDirection;
        final String srcLang = (activeDirection == Direction.JAVA_TO_KOTLIN) ? "Java" : "Kotlin";
        final String dstLang = (activeDirection == Direction.JAVA_TO_KOTLIN) ? "Kotlin" : "Java";

        showPanel(panelAnim);
        viewConversionAnim.loadSelectedFromPrefs();
        viewConversionAnim.setLanguages(srcLang, dstLang);
        viewConversionAnim.setProgressAndStage(8f, "ANALYZING");
        viewConversionAnim.startParticleAnimation();

        // Run actual conversion engine
        final ConversionResult result = JavaKotlinConverterEngine.convert(sourceCode, activeDirection, currentQualityMode);
        lastConversionResult = result;

        final String[] stepTitles = {
                "Analyzing Source Code...",
                "Parsing Code Structure...",
                "Converting Syntax...",
                "Optimizing Android Code...",
                "Generating Output...",
                "Conversion Complete ✓"
        };
        final String[] stageBadges = {
                "ANALYZING",
                "PARSING AST",
                "CONVERTING",
                "OPTIMIZING",
                "GENERATING",
                "COMPLETE ✓"
        };
        final float[] stepProgress = {16f, 34f, 55f, 74f, 90f, 100f};
        android.content.SharedPreferences sp = getSharedPreferences("morsalin_app_settings", MODE_PRIVATE);
        int speedPref = sp.getInt(SettingsActivity.KEY_CONVERTER_SPEED, 1);
        final long stepDelayMs = (speedPref == 0) ? 140L : (speedPref == 1 ? 240L : 360L);

        for (int s = 0; s < stepTitles.length; s++) {
            final int stepIndex = s;
            mainHandler.postDelayed(() -> {
                if (isFinishing() || isDestroyed()) return;
                tvAnimStepBadge.setText("STEP " + (stepIndex + 1) + " OF 6");
                tvAnimStepStatus.setText(stepTitles[stepIndex]);
                viewConversionAnim.setProgressAndStage(stepProgress[stepIndex], stepTitles[stepIndex]);

                // If conversion failed, stop at Step 2 (Parsing Code Structure) and show Error Panel
                if (!result.success && stepIndex == 1) {
                    mainHandler.postDelayed(() -> {
                        viewConversionAnim.stopParticleAnimation();
                        displayErrorPanel(result);
                    }, 260);
                }
            }, s * stepDelayMs);

            if (!result.success && s == 1) {
                return;
            }
        }

        // Transition to Output Panel immediately after Step 6 completes
        mainHandler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            viewConversionAnim.stopParticleAnimation();
            displayOutputPanel(result, srcLang, dstLang);
        }, stepTitles.length * stepDelayMs + 180L);
    }

    private void displayErrorPanel(ConversionResult result) {
        tvErrorTitle.setText(result.errorTitle != null ? result.errorTitle : "Syntax Validation Failed");
        tvErrorReason.setText(result.errorReason != null ? result.errorReason : "Invalid or incomplete source code.");
        tvErrorDetails.setText(result.errorDetails != null ? result.errorDetails : "Please verify brackets, quotes, and statements.");
        showPanel(panelError);
    }

    private void displayOutputPanel(ConversionResult result, String srcLang, String dstLang) {
        String statusBadge = result.needsReview ? "  •  ⚠ Needs Review" : "  •  ✓ Validated";
        tvOutputSourceTargetBadge.setText("Source: " + srcLang + "  →  Converted: " + dstLang + statusBadge);
        String statsText = String.format(
                Locale.US,
                "%,d lines processed • %,d lines generated • %d warnings • %d ms",
                result.linesProcessed,
                result.linesGenerated,
                result.warnings.size(),
                result.conversionTimeMs
        );
        tvOutputStats.setText(statsText);

        if (!result.warnings.isEmpty()) {
            StringBuilder warnSb = new StringBuilder();
            for (int i = 0; i < result.warnings.size(); i++) {
                if (i > 0) warnSb.append("\n");
                warnSb.append("⚠ ").append(result.warnings.get(i));
            }
            tvOutputWarnings.setText(warnSb.toString());
            tvOutputWarnings.setVisibility(View.VISIBLE);
        } else {
            tvOutputWarnings.setVisibility(View.GONE);
        }

        // Default output editor to read-only until Edit is pressed
        isOutputEditable = false;
        applyOutputEditableState();

        suppressOutputHistory = true;
        outputUndoStack.clear();
        outputUndoIndex = -1;
        etOutputCode.setText(result.convertedCode);
        SyntaxHighlighter.applyHighlighting(etOutputCode.getText(), null);
        suppressOutputHistory = false;
        pushOutputUndoState(result.convertedCode);

        showPanel(panelOutput);
    }

    private void toggleOutputEditMode() {
        isOutputEditable = !isOutputEditable;
        applyOutputEditableState();
        if (isOutputEditable) {
            etOutputCode.requestFocus();
            MorsalinToast.showSuccess(this, "Edit Output Enabled", "You can now edit the converted code directly.");
        } else {
            MorsalinToast.showSuccess(this, "Read-Only Locked", "Output editor is now read-only.");
        }
    }

    private void applyOutputEditableState() {
        etOutputCode.setFocusable(isOutputEditable);
        etOutputCode.setFocusableInTouchMode(isOutputEditable);
        etOutputCode.setCursorVisible(isOutputEditable);
        btnOutputEditToggle.setText(isOutputEditable ? "🔒 Lock" : "✎ Edit");
        btnOutputEditToggle.setTextColor(isOutputEditable ? Color.parseColor("#00FF88") : Color.parseColor("#00E5FF"));
    }

    private void saveCurrentConversionToHistory() {
        String origCode = etInputCode.getText().toString();
        String convCode = etOutputCode.getText().toString();
        if (convCode.trim().isEmpty()) {
            MorsalinToast.show(this, R.drawable.ic_save, "Empty Output", "Convert code first before saving to history.");
            return;
        }
        String origLang = (currentDirection == Direction.JAVA_TO_KOTLIN) ? "Java" : "Kotlin";
        String convLang = (currentDirection == Direction.JAVA_TO_KOTLIN) ? "Kotlin" : "Java";
        int linesProc = lastConversionResult != null ? lastConversionResult.linesProcessed : origCode.split("\n", -1).length;
        int linesGen = convCode.split("\n", -1).length;
        int warns = lastConversionResult != null ? lastConversionResult.warnings.size() : 0;
        long timeMs = lastConversionResult != null ? lastConversionResult.conversionTimeMs : 15L;

        CodeConversionItem item = new CodeConversionItem(
                String.valueOf(System.currentTimeMillis()),
                origLang,
                convLang,
                currentInputFileName,
                currentOutputFileName,
                System.currentTimeMillis(),
                origCode,
                convCode,
                linesProc,
                linesGen,
                warns,
                timeMs
        );
        CodeConversionHistoryManager.saveConversion(this, item);
        MorsalinToast.showSave(this, "Saved " + currentInputFileName + " → " + currentOutputFileName + " to History!");
    }

    private void openHistoryModal() {
        ConverterDialogManager.showHistoryDialog(
                this,
                item -> {
                    currentDirection = item.getOriginalLanguage().equalsIgnoreCase("Java")
                            ? Direction.JAVA_TO_KOTLIN : Direction.KOTLIN_TO_JAVA;
                    currentInputFileName = item.getOriginalFileName();
                    currentOutputFileName = item.getConvertedFileName();
                    updateDirectionUI();
                    setInputCodeProgrammatically(item.getOriginalCode(), item.getOriginalFileName(), false);

                    lastConversionResult = new ConversionResult(
                            true,
                            item.getConvertedCode(),
                            null, null, null,
                            new ArrayList<>(),
                            item.getLinesProcessed(),
                            item.getLinesGenerated(),
                            item.getConversionTimeMs()
                    );
                    displayOutputPanel(lastConversionResult, item.getOriginalLanguage(), item.getConvertedLanguage());
                    MorsalinToast.showSuccess(this, "History Loaded", "Opened " + item.getOriginalFileName() + " conversion.");
                },
                (fullFileName, mimeType, codeContent) -> {
                    pendingSafExportFileName = fullFileName;
                    pendingSafExportContent = codeContent;
                    try {
                        createDocumentLauncher.launch(fullFileName);
                    } catch (Exception e) {
                        ConverterDialogManager.exportCodeToDownloads(this, fullFileName, codeContent);
                    }
                }
        );
    }

    private void handleImportedFileUri(Uri uri) {
        if (uri == null) return;
        try {
            String displayName = queryFileName(uri);
            if (displayName == null || displayName.trim().isEmpty()) {
                displayName = "ImportedSource.java";
            }

            String lower = displayName.toLowerCase(Locale.US);
            if (!lower.endsWith(".java") && !lower.endsWith(".kt") && !lower.endsWith(".kts") && !lower.endsWith(".txt")) {
                MorsalinToast.show(this, R.drawable.ic_download, "Unsupported File",
                        "Please select a .java or .kt source file.");
                return;
            }

            StringBuilder sb = new StringBuilder();
            try (InputStream is = getContentResolver().openInputStream(uri);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                boolean first = true;
                while ((line = reader.readLine()) != null) {
                    if (!first) sb.append("\n");
                    sb.append(line);
                    first = false;
                }
            }

            String content = sb.toString();
            setInputCodeProgrammatically(content, displayName, true);
            showPanel(panelInput);
            MorsalinToast.showSuccess(this, "File Imported",
                    "Loaded " + displayName + " (" + (currentDirection == Direction.JAVA_TO_KOTLIN ? "Java → Kotlin" : "Kotlin → Java") + ")");
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Import Failed", "Could not read file: " + e.getMessage());
        }
    }

    private void handleCreatedDocumentUri(Uri uri) {
        if (uri == null) return;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os != null) {
                os.write((pendingSafExportContent != null ? pendingSafExportContent : "").getBytes(StandardCharsets.UTF_8));
                os.flush();
                MorsalinToast.showDownload(this, "File exported successfully (" + pendingSafExportFileName + ")");
            }
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_download, "Save Failed", "Error saving file: " + e.getMessage());
        }
    }

    private String queryFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        result = cursor.getString(idx);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }

    private void pasteFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip() != null
                && clipboard.getPrimaryClip().getItemCount() > 0) {
            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
            CharSequence text = item.coerceToText(this);
            if (text != null && text.length() > 0) {
                String code = text.toString();
                Direction detected = JavaKotlinConverterEngine.detectDirection(null, code);
                currentDirection = detected;
                String fileName = (detected == Direction.JAVA_TO_KOTLIN) ? "PastedCode.java" : "PastedCode.kt";
                setInputCodeProgrammatically(code, fileName, true);
                updateDirectionUI();
                MorsalinToast.showCopy(this, "Code pasted! Auto-detected: " + (detected == Direction.JAVA_TO_KOTLIN ? "Java" : "Kotlin"));
                return;
            }
        }
        MorsalinToast.show(this, R.drawable.ic_content_copy, "Clipboard Empty", "No code found in clipboard.");
    }

    private void setInputCodeProgrammatically(String code, String fileName, boolean autoDetectDirection) {
        if (fileName != null && !fileName.trim().isEmpty()) {
            currentInputFileName = fileName.trim();
        }
        if (autoDetectDirection) {
            currentDirection = JavaKotlinConverterEngine.detectDirection(currentInputFileName, code);
        }
        syncFileNameExtensionForDirection();
        updateDirectionUI();

        suppressInputHistory = true;
        etInputCode.setText(code != null ? code : "");
        SyntaxHighlighter.applyHighlighting(etInputCode.getText(), null);
        suppressInputHistory = false;
        pushInputUndoState(code != null ? code : "");
        updateInputCountersAndLines(code != null ? code : "");
    }

    private void syncFileNameExtensionForDirection() {
        String base = ConverterDialogManager.stripExtension(currentInputFileName);
        if (base.isEmpty()) base = "MyActivity";
        if (currentDirection == Direction.JAVA_TO_KOTLIN) {
            currentInputFileName = base + ".java";
            currentOutputFileName = base + ".kt";
        } else {
            currentInputFileName = base + ".kt";
            currentOutputFileName = base + ".java";
        }
        if (tvInputFileName != null) {
            tvInputFileName.setText("File: " + currentInputFileName);
        }
    }

    private void updateDirectionUI() {
        boolean j2k = (currentDirection == Direction.JAVA_TO_KOTLIN);
        btnModeJavaToKt.setTextColor(j2k ? Color.parseColor("#00FF88") : Color.WHITE);
        btnModeKtToJava.setTextColor(!j2k ? Color.parseColor("#00FF88") : Color.WHITE);
        btnModeJavaToKt.setText(j2k ? "✓ Java → Kotlin" : "Java → Kotlin");
        btnModeKtToJava.setText(!j2k ? "✓ Kotlin → Java" : "Kotlin → Java");
        if (tvInputFileName != null) {
            tvInputFileName.setText("File: " + currentInputFileName);
        }
        updateQualityUI();
    }

    private void updateQualityUI() {
        if (btnQualityFast == null || btnQualityBalanced == null || btnQualityStrict == null) return;
        boolean isFast = currentQualityMode == com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.FAST;
        boolean isBal = currentQualityMode == com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.BALANCED;
        boolean isStrict = currentQualityMode == com.android.modding.tools.generators.ConversionPostProcessor.QualityMode.STRICT;
        btnQualityFast.setText(isFast ? "✓ FAST" : "FAST");
        btnQualityBalanced.setText(isBal ? "✓ BALANCED" : "BALANCED");
        btnQualityStrict.setText(isStrict ? "✓ STRICT" : "STRICT");
        btnQualityFast.setTextColor(isFast ? Color.parseColor("#00E5FF") : Color.WHITE);
        btnQualityBalanced.setTextColor(isBal ? Color.parseColor("#00E5FF") : Color.WHITE);
        btnQualityStrict.setTextColor(isStrict ? Color.parseColor("#00E5FF") : Color.WHITE);
    }

    private void updateInputCountersAndLines(String text) {
        int chars = text != null ? text.length() : 0;
        int lines = (text == null || text.isEmpty()) ? 1 : text.split("\n", -1).length;
        tvInputCharCount.setText(String.format(Locale.US, "Chars: %,d", chars));
        tvInputLineCount.setText(String.format(Locale.US, "Lines: %,d", lines));
        updateLineNumbersView(tvInputLineNumbers, text);
    }

    private void updateLineNumbersView(TextView tvGutter, String text) {
        int lines = (text == null || text.isEmpty()) ? 1 : text.split("\n", -1).length;
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            if (i > 1) sb.append("\n");
            sb.append(i);
        }
        tvGutter.setText(sb.toString());
    }

    private void toggleSearchBar(boolean forInput, boolean jumpLineMode) {
        if (forInput) {
            isInputJumpMode = jumpLineMode;
            layoutInputSearchBar.setVisibility(View.VISIBLE);
            etInputSearchQuery.setHint(jumpLineMode ? "Enter line number (e.g. 15)..." : "Search code text...");
            btnInputSearchGo.setText(jumpLineMode ? "Jump" : "Find");
            etInputSearchQuery.requestFocus();
        } else {
            isOutputJumpMode = jumpLineMode;
            layoutOutputSearchBar.setVisibility(View.VISIBLE);
            etOutputSearchQuery.setHint(jumpLineMode ? "Enter line number (e.g. 15)..." : "Search converted code...");
            btnOutputSearchGo.setText(jumpLineMode ? "Jump" : "Find");
            etOutputSearchQuery.requestFocus();
        }
    }

    private void executeSearchOrJump(EditText editor, ScrollView scrollView, EditText queryField, boolean jumpMode) {
        String q = queryField.getText().toString().trim();
        if (q.isEmpty()) return;
        String code = editor.getText().toString();

        if (jumpMode) {
            try {
                int targetLine = Integer.parseInt(q);
                String[] lines = code.split("\n", -1);
                if (targetLine < 1 || targetLine > lines.length) {
                    MorsalinToast.show(this, R.drawable.ic_refresh, "Out of Range",
                            "Line must be between 1 and " + lines.length);
                    return;
                }
                int charOffset = 0;
                for (int i = 0; i < targetLine - 1; i++) {
                    charOffset += lines[i].length() + 1;
                }
                int endOffset = charOffset + lines[targetLine - 1].length();
                editor.requestFocus();
                editor.setSelection(Math.min(charOffset, code.length()), Math.min(endOffset, code.length()));
                if (editor.getLayout() != null) {
                    int y = editor.getLayout().getLineTop(targetLine - 1);
                    scrollView.smoothScrollTo(0, y);
                }
                MorsalinToast.showSuccess(this, "Jumped to Line " + targetLine, lines[targetLine - 1].trim());
            } catch (NumberFormatException e) {
                MorsalinToast.show(this, R.drawable.ic_refresh, "Invalid Line #", "Please enter a valid line number.");
            }
        } else {
            SyntaxHighlighter.applyHighlighting(editor.getText(), q);
            String lowerCode = code.toLowerCase(Locale.US);
            String lowerQ = q.toLowerCase(Locale.US);
            int curSel = Math.max(0, editor.getSelectionEnd());
            int foundIdx = lowerCode.indexOf(lowerQ, curSel);
            if (foundIdx < 0) {
                foundIdx = lowerCode.indexOf(lowerQ);
            }
            if (foundIdx >= 0) {
                editor.requestFocus();
                editor.setSelection(foundIdx, foundIdx + q.length());
                if (editor.getLayout() != null) {
                    int line = editor.getLayout().getLineForOffset(foundIdx);
                    int y = editor.getLayout().getLineTop(line);
                    scrollView.smoothScrollTo(0, y);
                }
            } else {
                MorsalinToast.show(this, R.drawable.ic_refresh, "Not Found", "No match found for \"" + q + "\".");
            }
        }
    }

    private void copyCurrentLine(EditText editor) {
        String text = editor.getText().toString();
        if (text.isEmpty()) return;
        int sel = Math.max(0, editor.getSelectionStart());
        int lineStart = text.lastIndexOf('\n', sel - 1) + 1;
        int lineEnd = text.indexOf('\n', sel);
        if (lineEnd < 0) lineEnd = text.length();
        String lineText = text.substring(Math.min(lineStart, lineEnd), Math.max(lineStart, lineEnd));
        ConverterDialogManager.copyToClipboard(this, "Code Line", lineText);
        MorsalinToast.showCopy(this, "Copied line: " + lineText.trim());
    }

    private void pushInputUndoState(String text) {
        if (inputUndoIndex >= 0 && inputUndoIndex < inputUndoStack.size()
                && inputUndoStack.get(inputUndoIndex).equals(text)) {
            return;
        }
        while (inputUndoStack.size() > inputUndoIndex + 1) {
            inputUndoStack.remove(inputUndoStack.size() - 1);
        }
        inputUndoStack.add(text);
        if (inputUndoStack.size() > 35) {
            inputUndoStack.remove(0);
        }
        inputUndoIndex = inputUndoStack.size() - 1;
    }

    private void performInputUndo() {
        if (inputUndoIndex > 0) {
            inputUndoIndex--;
            suppressInputHistory = true;
            String state = inputUndoStack.get(inputUndoIndex);
            etInputCode.setText(state);
            etInputCode.setSelection(state.length());
            SyntaxHighlighter.applyHighlighting(etInputCode.getText(), null);
            suppressInputHistory = false;
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Undo", "Nothing more to undo.");
        }
    }

    private void performInputRedo() {
        if (inputUndoIndex < inputUndoStack.size() - 1) {
            inputUndoIndex++;
            suppressInputHistory = true;
            String state = inputUndoStack.get(inputUndoIndex);
            etInputCode.setText(state);
            etInputCode.setSelection(state.length());
            SyntaxHighlighter.applyHighlighting(etInputCode.getText(), null);
            suppressInputHistory = false;
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Redo", "Nothing more to redo.");
        }
    }

    private void pushOutputUndoState(String text) {
        if (outputUndoIndex >= 0 && outputUndoIndex < outputUndoStack.size()
                && outputUndoStack.get(outputUndoIndex).equals(text)) {
            return;
        }
        while (outputUndoStack.size() > outputUndoIndex + 1) {
            outputUndoStack.remove(outputUndoStack.size() - 1);
        }
        outputUndoStack.add(text);
        if (outputUndoStack.size() > 35) {
            outputUndoStack.remove(0);
        }
        outputUndoIndex = outputUndoStack.size() - 1;
    }

    private void performOutputUndo() {
        if (!isOutputEditable) {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Read-Only", "Press 'Edit' first to modify output code.");
            return;
        }
        if (outputUndoIndex > 0) {
            outputUndoIndex--;
            suppressOutputHistory = true;
            String state = outputUndoStack.get(outputUndoIndex);
            etOutputCode.setText(state);
            etOutputCode.setSelection(state.length());
            SyntaxHighlighter.applyHighlighting(etOutputCode.getText(), null);
            suppressOutputHistory = false;
        }
    }

    private void performOutputRedo() {
        if (!isOutputEditable) {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Read-Only", "Press 'Edit' first to modify output code.");
            return;
        }
        if (outputUndoIndex < outputUndoStack.size() - 1) {
            outputUndoIndex++;
            suppressOutputHistory = true;
            String state = outputUndoStack.get(outputUndoIndex);
            etOutputCode.setText(state);
            etOutputCode.setSelection(state.length());
            SyntaxHighlighter.applyHighlighting(etOutputCode.getText(), null);
            suppressOutputHistory = false;
        }
    }

    private void showPanel(View targetPanel) {
        panelInput.setVisibility(targetPanel == panelInput ? View.VISIBLE : View.GONE);
        panelAnim.setVisibility(targetPanel == panelAnim ? View.VISIBLE : View.GONE);
        panelError.setVisibility(targetPanel == panelError ? View.VISIBLE : View.GONE);
        panelOutput.setVisibility(targetPanel == panelOutput ? View.VISIBLE : View.GONE);
    }

    private void finishWithBackwardAnim() {
        if (panelOutput.getVisibility() == View.VISIBLE || panelError.getVisibility() == View.VISIBLE) {
            showPanel(panelInput);
            return;
        }
        finish();
        TransitionAnimationManager.applyBackward(this);
    }

    @Override
    public void onBackPressed() {
        if (panelOutput.getVisibility() == View.VISIBLE || panelError.getVisibility() == View.VISIBLE) {
            showPanel(panelInput);
            return;
        }
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
