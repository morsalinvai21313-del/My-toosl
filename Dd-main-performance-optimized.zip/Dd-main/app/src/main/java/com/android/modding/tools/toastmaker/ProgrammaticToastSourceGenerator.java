package com.android.modding.tools.toastmaker;

import android.util.Base64;

import java.nio.charset.StandardCharsets;

/**
 * Generates 100% Programmatic Android Java Source Code for Standalone Dalvik classes.dex.
 * ZERO XML layout files, ZERO resource IDs required.
 * Fully compatible with all Android versions (Android 4.4 to 15+).
 */
public class ProgrammaticToastSourceGenerator {

    public static String generateJavaCode(ToastConfig config) {
        if (config == null) {
            config = ToastConfig.createSimpleDefault();
        }

        String rawMsg = config.messageText != null ? config.messageText : "Welcome to Modded App by Morsalin!";
        String rawTitle = config.titleText != null ? config.titleText : "";
        String symbol = config.symbolIcon != null ? config.symbolIcon : "";
        boolean isBase64 = config.isBase64Encoded;
        String b64Encoded = Base64.encodeToString(rawMsg.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);

        int durationMs = config.isLongDuration ? 3500 : 2000;
        int animDuration = config.animDurationMs > 0 ? config.animDurationMs : 450;
        int cornerRadius = config.cornerRadiusDp > 0 ? config.cornerRadiusDp : 24;
        int strokeWidth = config.strokeWidthDp >= 0 ? config.strokeWidthDp : 1;
        String bgHex = config.bgHex != null && !config.bgHex.isEmpty() ? config.bgHex : "#E621252B";
        String bgEndHex = config.bgGradientEndHex != null ? config.bgGradientEndHex : "";
        boolean isGradient = config.isGradient && !bgEndHex.isEmpty();
        String textHex = config.textColorHex != null && !config.textColorHex.isEmpty() ? config.textColorHex : "#FFFFFF";
        String titleHex = config.titleColorHex != null && !config.titleColorHex.isEmpty() ? config.titleColorHex : "#00E5FF";
        String strokeHex = config.strokeColorHex != null && !config.strokeColorHex.isEmpty() ? config.strokeColorHex : "#00E5FF";

        int gravityConst;
        int yOffsetDp;
        if (config.gravity == 1) { // Center
            gravityConst = 17; // Gravity.CENTER
            yOffsetDp = 0;
        } else if (config.gravity == 2) { // Top
            gravityConst = 49; // Gravity.TOP | Gravity.CENTER_HORIZONTAL
            yOffsetDp = 70;
        } else { // Bottom (Default)
            gravityConst = 81; // Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
            yOffsetDp = 80;
        }

        boolean hasCustomImg = config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0;
        String thumbnailB64 = "";
        if (hasCustomImg) {
            try {
                android.graphics.Bitmap rawBmp = android.graphics.BitmapFactory.decodeByteArray(
                        config.customImageBytes, 0, config.customImageBytes.length);
                if (rawBmp != null) {
                    int maxThumb = 64;
                    int w = rawBmp.getWidth();
                    int h = rawBmp.getHeight();
                    float scale = Math.min((float) maxThumb / w, (float) maxThumb / h);
                    if (scale < 1f && scale > 0f) {
                        rawBmp = android.graphics.Bitmap.createScaledBitmap(rawBmp,
                                Math.max(1, Math.round(w * scale)),
                                Math.max(1, Math.round(h * scale)), true);
                    }
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    rawBmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 85, baos);
                    byte[] thumbBytes = baos.toByteArray();
                    if (thumbBytes.length <= 16384) {
                        thumbnailB64 = android.util.Base64.encodeToString(thumbBytes, android.util.Base64.NO_WRAP);
                    }
                }
            } catch (Throwable ignored) {}
        }

        StringBuilder sb = new StringBuilder();
        sb.append("package com.morsalin.toast;\n\n");

        sb.append("import android.app.Activity;\n");
        sb.append("import android.content.Context;\n");
        sb.append("import android.graphics.Bitmap;\n");
        sb.append("import android.graphics.BitmapFactory;\n");
        sb.append("import android.graphics.Canvas;\n");
        sb.append("import android.graphics.Color;\n");
        sb.append("import android.graphics.Paint;\n");
        sb.append("import android.graphics.PorterDuff;\n");
        sb.append("import android.graphics.PorterDuffXfermode;\n");
        sb.append("import android.graphics.Rect;\n");
        sb.append("import android.graphics.RectF;\n");
        sb.append("import android.graphics.Typeface;\n");
        sb.append("import android.graphics.drawable.GradientDrawable;\n");
        sb.append("import android.os.Handler;\n");
        sb.append("import android.os.Looper;\n");
        sb.append("import android.util.Base64;\n");
        sb.append("import android.view.Gravity;\n");
        sb.append("import android.view.View;\n");
        sb.append("import android.view.ViewGroup;\n");
        sb.append("import android.view.animation.AlphaAnimation;\n");
        sb.append("import android.view.animation.Animation;\n");
        sb.append("import android.view.animation.AnimationSet;\n");
        sb.append("import android.view.animation.OvershootInterpolator;\n");
        sb.append("import android.view.animation.ScaleAnimation;\n");
        sb.append("import android.view.animation.TranslateAnimation;\n");
        sb.append("import android.widget.FrameLayout;\n");
        sb.append("import android.widget.ImageView;\n");
        sb.append("import android.widget.LinearLayout;\n");
        sb.append("import android.widget.TextView;\n");
        sb.append("import android.widget.Toast;\n");
        sb.append("import java.io.InputStream;\n\n");

        sb.append("/**\n");
        sb.append(" * Morsalin Custom Toast Dalvik Standalone Component.\n");
        sb.append(" * Generated by Morsalin XML Creator Pro.\n");
        sb.append(" * Pure Programmatic UI • ZERO XML Layout Dependencies.\n");
        sb.append(" */\n");
        sb.append("public class MorsalinCustomToast {\n\n");

        sb.append("    private static final String PAYLOAD_BASE64 = \"").append(escape(b64Encoded)).append("\";\n");
        sb.append("    private static final String DEFAULT_RAW_MSG = \"").append(escape(rawMsg)).append("\";\n");
        sb.append("    private static final String DEFAULT_TITLE = \"").append(escape(rawTitle)).append("\";\n");
        sb.append("    private static final String SYMBOL_ICON = \"").append(escape(symbol)).append("\";\n");
        sb.append("    private static final boolean HAS_CUSTOM_IMAGE = ").append(hasCustomImg).append(";\n");
        sb.append("    private static final String CUSTOM_IMAGE_THUMBNAIL_B64 = \"").append(escape(thumbnailB64)).append("\";\n");
        sb.append("    private static final boolean IS_BASE64 = ").append(isBase64).append(";\n");
        sb.append("    private static final int DISPLAY_DURATION_MS = ").append(durationMs).append(";\n");
        sb.append("    private static final int ANIM_DURATION_MS = ").append(animDuration).append(";\n");
        sb.append("    private static final int GRAVITY_FLAG = ").append(gravityConst).append(";\n");
        sb.append("    private static final int Y_OFFSET_DP = ").append(yOffsetDp).append(";\n");
        sb.append("    private static final int CORNER_RADIUS_DP = ").append(cornerRadius).append(";\n");
        sb.append("    private static final int STROKE_WIDTH_DP = ").append(strokeWidth).append(";\n");
        sb.append("    private static final String BG_HEX = \"").append(escape(bgHex)).append("\";\n");
        sb.append("    private static final String BG_END_HEX = \"").append(escape(bgEndHex)).append("\";\n");
        sb.append("    private static final boolean IS_GRADIENT = ").append(isGradient).append(";\n");
        sb.append("    private static final String TEXT_HEX = \"").append(escape(textHex)).append("\";\n");
        sb.append("    private static final String TITLE_HEX = \"").append(escape(titleHex)).append("\";\n");
        sb.append("    private static final String STROKE_HEX = \"").append(escape(strokeHex)).append("\";\n");
        sb.append("    private static final String ANIM_MODE = \"").append(escape(config.animMode)).append("\";\n\n");

        sb.append("    /**\n");
        sb.append("     * Authoritative one-line Smali Hook invocation:\n");
        sb.append("     * invoke-static {p0}, Lcom/morsalin/toast/MorsalinCustomToast;->show(Landroid/content/Context;)V\n");
        sb.append("     */\n");
        sb.append("    public static void show(final Context context) {\n");
        sb.append("        show(context, null);\n");
        sb.append("    }\n\n");

        sb.append("    public static void show(final Context context, final String customMessage) {\n");
        sb.append("        if (context == null) return;\n");
        sb.append("        new Handler(Looper.getMainLooper()).post(new Runnable() {\n");
        sb.append("            @Override\n");
        sb.append("            public void run() {\n");
        sb.append("                try {\n");
        sb.append("                    displayToast(context, customMessage);\n");
        sb.append("                } catch (Throwable t) {\n");
        sb.append("                    try {\n");
        sb.append("                        String fallback = customMessage != null ? customMessage : resolveMessage();\n");
        sb.append("                        Toast.makeText(context, fallback, Toast.LENGTH_SHORT).show();\n");
        sb.append("                    } catch (Throwable ignored) {}\n");
        sb.append("                }\n");
        sb.append("            }\n");
        sb.append("        });\n");
        sb.append("    }\n\n");

        sb.append("    private static String resolveMessage() {\n");
        sb.append("        if (IS_BASE64 && PAYLOAD_BASE64 != null && !PAYLOAD_BASE64.isEmpty()) {\n");
        sb.append("            try {\n");
        sb.append("                byte[] data = Base64.decode(PAYLOAD_BASE64, Base64.DEFAULT);\n");
        sb.append("                return new String(data, \"UTF-8\");\n");
        sb.append("            } catch (Throwable ignored) {}\n");
        sb.append("        }\n");
        sb.append("        return DEFAULT_RAW_MSG;\n");
        sb.append("    }\n\n");

        sb.append("    private static int parseColor(String hex, int defaultColor) {\n");
        sb.append("        if (hex == null || hex.trim().isEmpty()) return defaultColor;\n");
        sb.append("        try {\n");
        sb.append("            return Color.parseColor(hex.trim());\n");
        sb.append("        } catch (Throwable t) {\n");
        sb.append("            return defaultColor;\n");
        sb.append("        }\n");
        sb.append("    }\n\n");

        sb.append("    private static int dp(Context ctx, int valueDp) {\n");
        sb.append("        float density = ctx.getResources().getDisplayMetrics().density;\n");
        sb.append("        return Math.round(valueDp * density);\n");
        sb.append("    }\n\n");

        sb.append("    private static void displayToast(Context context, String overrideMsg) {\n");
        sb.append("        String finalMsg = (overrideMsg != null && !overrideMsg.trim().isEmpty())\n");
        sb.append("                ? overrideMsg : resolveMessage();\n\n");

        sb.append("        if (context instanceof Activity) {\n");
        sb.append("            Activity act = (Activity) context;\n");
        sb.append("            if (act.isFinishing()) return;\n");
        sb.append("            final ViewGroup decorView = (ViewGroup) act.getWindow().getDecorView();\n");
        sb.append("            if (decorView == null) return;\n");
        sb.append("            View existing = decorView.findViewWithTag(\"morsalin_custom_toast_overlay\");\n");
        sb.append("            if (existing != null) {\n");
        sb.append("                try { decorView.removeView(existing); } catch (Throwable ignored) {}\n");
        sb.append("            }\n");
        sb.append("            final FrameLayout overlay = new FrameLayout(act);\n");
        sb.append("            overlay.setTag(\"morsalin_custom_toast_overlay\");\n");
        sb.append("            overlay.setClipChildren(false);\n");
        sb.append("            overlay.setClipToPadding(false);\n\n");

        sb.append("        // Construct View Tree Programmatically (ZERO XML)\n");
        sb.append("        LinearLayout bubble = new LinearLayout(act);\n");
        sb.append("        bubble.setOrientation(LinearLayout.HORIZONTAL);\n");
        sb.append("        bubble.setGravity(Gravity.CENTER_VERTICAL);\n");
        sb.append("        int padH = dp(act, 22);\n");
        sb.append("        int padV = dp(act, 12);\n");
        sb.append("        bubble.setPadding(padH, padV, padH, padV);\n\n");

        sb.append("        // Styling: Background Drawable\n");
        sb.append("        GradientDrawable bg = new GradientDrawable();\n");
        sb.append("        int startCol = parseColor(BG_HEX, 0xE621252B);\n");
        sb.append("        if (IS_GRADIENT && BG_END_HEX != null && !BG_END_HEX.isEmpty()) {\n");
        sb.append("            int endCol = parseColor(BG_END_HEX, 0xE6151A21);\n");
        sb.append("            bg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);\n");
        sb.append("            bg.setColors(new int[]{startCol, endCol});\n");
        sb.append("        } else {\n");
        sb.append("            bg.setColor(startCol);\n");
        sb.append("        }\n");
        sb.append("        bg.setCornerRadius(dp(act, CORNER_RADIUS_DP));\n");
        sb.append("        if (STROKE_WIDTH_DP > 0) {\n");
        sb.append("            bg.setStroke(dp(act, STROKE_WIDTH_DP), parseColor(STROKE_HEX, 0xFF00E5FF));\n");
        sb.append("        }\n");
        sb.append("        bubble.setBackground(bg);\n\n");

        // Optional Badge Symbol / Custom Gallery Photo / Icon
        sb.append("        if (HAS_CUSTOM_IMAGE) {\n");
        sb.append("            ImageView ivIcon = new ImageView(act);\n");
        sb.append("            int iconSize = dp(act, 32);\n");
        sb.append("            LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(iconSize, iconSize);\n");
        sb.append("            ivLp.setMargins(0, 0, dp(act, 10), 0);\n");
        sb.append("            ivIcon.setLayoutParams(ivLp);\n");
        sb.append("            ivIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);\n");
        sb.append("            Bitmap bmp = loadAssetBitmap(act, \"toast_icon.png\");\n");
        sb.append("            if (bmp == null && CUSTOM_IMAGE_THUMBNAIL_B64 != null && !CUSTOM_IMAGE_THUMBNAIL_B64.isEmpty()) {\n");
        sb.append("                bmp = decodeBase64Bitmap(CUSTOM_IMAGE_THUMBNAIL_B64);\n");
        sb.append("            }\n");
        sb.append("            if (bmp != null) {\n");
        sb.append("                ivIcon.setImageBitmap(getRoundedCornerBitmap(bmp, dp(act, 8)));\n");
        sb.append("                bubble.addView(ivIcon);\n");
        sb.append("            }\n");
        sb.append("        } else if (SYMBOL_ICON != null && !SYMBOL_ICON.isEmpty()) {\n");
        sb.append("            TextView iconTv = new TextView(act);\n");
        sb.append("            iconTv.setText(SYMBOL_ICON);\n");
        sb.append("            iconTv.setTextSize(22f);\n");
        sb.append("            iconTv.setGravity(Gravity.CENTER);\n");
        sb.append("            iconTv.setPadding(0, 0, dp(act, 10), 0);\n");
        sb.append("            bubble.addView(iconTv);\n");
        sb.append("        }\n\n");

        sb.append("        // Text Container (Title + Message)\n");
        sb.append("        LinearLayout textLayout = new LinearLayout(act);\n");
        sb.append("        textLayout.setOrientation(LinearLayout.VERTICAL);\n");
        sb.append("        textLayout.setGravity(Gravity.CENTER_VERTICAL);\n\n");

        sb.append("        if (DEFAULT_TITLE != null && !DEFAULT_TITLE.isEmpty()) {\n");
        sb.append("            TextView titleTv = new TextView(act);\n");
        sb.append("            titleTv.setText(DEFAULT_TITLE);\n");
        sb.append("            titleTv.setTextColor(parseColor(TITLE_HEX, 0xFF00E5FF));\n");
        sb.append("            titleTv.setTextSize(12f);\n");
        sb.append("            titleTv.setTypeface(Typeface.DEFAULT_BOLD);\n");
        sb.append("            titleTv.setPadding(0, 0, 0, dp(act, 3));\n");
        sb.append("            textLayout.addView(titleTv);\n");
        sb.append("        }\n\n");

        sb.append("        TextView msgTv = new TextView(act);\n");
        sb.append("        msgTv.setText(finalMsg);\n");
        sb.append("        msgTv.setTextColor(parseColor(TEXT_HEX, 0xFFFFFFFF));\n");
        sb.append("        msgTv.setTextSize(13.5f);\n");
        sb.append("        msgTv.setTypeface(Typeface.DEFAULT_BOLD);\n");
        sb.append("        textLayout.addView(msgTv);\n");
        sb.append("        bubble.addView(textLayout);\n\n");

        sb.append("        // Positioning in overlay\n");
        sb.append("        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(\n");
        sb.append("                FrameLayout.LayoutParams.WRAP_CONTENT,\n");
        sb.append("                FrameLayout.LayoutParams.WRAP_CONTENT\n");
        sb.append("        );\n");
        sb.append("        lp.gravity = GRAVITY_FLAG;\n");
        sb.append("        if ((GRAVITY_FLAG & Gravity.TOP) == Gravity.TOP) {\n");
        sb.append("            lp.topMargin = dp(act, Y_OFFSET_DP);\n");
        sb.append("        } else if ((GRAVITY_FLAG & Gravity.BOTTOM) == Gravity.BOTTOM) {\n");
        sb.append("            lp.bottomMargin = dp(act, Y_OFFSET_DP);\n");
        sb.append("        }\n");
        sb.append("        overlay.addView(bubble, lp);\n");
        sb.append("        decorView.addView(overlay, new ViewGroup.LayoutParams(\n");
        sb.append("                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));\n\n");

        sb.append("        // Entrance Animation\n");
        sb.append("        applyEntranceAnimation(bubble);\n\n");

        sb.append("        // Auto-dismiss handler\n");
        sb.append("        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {\n");
        sb.append("            @Override\n");
        sb.append("            public void run() {\n");
        sb.append("                try {\n");
        sb.append("                    AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);\n");
        sb.append("                    fadeOut.setDuration(280);\n");
        sb.append("                    fadeOut.setAnimationListener(new Animation.AnimationListener() {\n");
        sb.append("                        @Override public void onAnimationStart(Animation a) {}\n");
        sb.append("                        @Override public void onAnimationEnd(Animation a) {\n");
        sb.append("                            try { decorView.removeView(overlay); } catch (Throwable ignored) {}\n");
        sb.append("                        }\n");
        sb.append("                        @Override public void onAnimationRepeat(Animation a) {}\n");
        sb.append("                    });\n");
        sb.append("                    bubble.startAnimation(fadeOut);\n");
        sb.append("                } catch (Throwable ignored) {\n");
        sb.append("                    try { decorView.removeView(overlay); } catch (Throwable ignored2) {}\n");
        sb.append("                }\n");
        sb.append("            }\n");
        sb.append("        }, DISPLAY_DURATION_MS);\n");
        sb.append("        } else {\n");
        sb.append("            try { Toast.makeText(context, finalMsg, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}\n");
        sb.append("        }\n");
        sb.append("    }\n\n");

        sb.append("    private static void applyEntranceAnimation(View view) {\n");
        sb.append("        if (view == null) return;\n");
        sb.append("        String mode = ANIM_MODE != null ? ANIM_MODE.toLowerCase() : \"zoom\";\n");
        sb.append("        if (mode.contains(\"fade\")) {\n");
        sb.append("            AlphaAnimation anim = new AlphaAnimation(0f, 1f);\n");
        sb.append("            anim.setDuration(ANIM_DURATION_MS);\n");
        sb.append("            view.startAnimation(anim);\n");
        sb.append("        } else if (mode.contains(\"slide\")) {\n");
        sb.append("            TranslateAnimation anim = new TranslateAnimation(0, 0, 100, 0);\n");
        sb.append("            anim.setDuration(ANIM_DURATION_MS);\n");
        sb.append("            anim.setInterpolator(new OvershootInterpolator(1.2f));\n");
        sb.append("            view.startAnimation(anim);\n");
        sb.append("        } else if (mode.contains(\"bounce\")) {\n");
        sb.append("            AnimationSet set = new AnimationSet(true);\n");
        sb.append("            ScaleAnimation scale = new ScaleAnimation(0.3f, 1.0f, 0.3f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);\n");
        sb.append("            scale.setDuration(ANIM_DURATION_MS);\n");
        sb.append("            scale.setInterpolator(new OvershootInterpolator(2.0f));\n");
        sb.append("            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);\n");
        sb.append("            alpha.setDuration(ANIM_DURATION_MS / 2);\n");
        sb.append("            set.addAnimation(scale);\n");
        sb.append("            set.addAnimation(alpha);\n");
        sb.append("            view.startAnimation(set);\n");
        sb.append("        } else { // Zoom / Cyber Glitch / Default\n");
        sb.append("            AnimationSet set = new AnimationSet(true);\n");
        sb.append("            ScaleAnimation scale = new ScaleAnimation(0.5f, 1.0f, 0.5f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);\n");
        sb.append("            scale.setDuration(ANIM_DURATION_MS);\n");
        sb.append("            scale.setInterpolator(new OvershootInterpolator(1.4f));\n");
        sb.append("            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);\n");
        sb.append("            alpha.setDuration(ANIM_DURATION_MS);\n");
        sb.append("            set.addAnimation(scale);\n");
        sb.append("            set.addAnimation(alpha);\n");
        sb.append("            view.startAnimation(set);\n");
        sb.append("        }\n");
        sb.append("    }\n\n");
        sb.append("    private static Bitmap loadAssetBitmap(Context context, String fileName) {\n");
        sb.append("        if (context == null || fileName == null) return null;\n");
        sb.append("        InputStream is = null;\n");
        sb.append("        try {\n");
        sb.append("            is = context.getAssets().open(fileName);\n");
        sb.append("            return BitmapFactory.decodeStream(is);\n");
        sb.append("        } catch (Throwable t) {\n");
        sb.append("            return null;\n");
        sb.append("        } finally {\n");
        sb.append("            if (is != null) {\n");
        sb.append("                try { is.close(); } catch (Throwable ignored) {}\n");
        sb.append("            }\n");
        sb.append("        }\n");
        sb.append("    }\n\n");
        sb.append("    private static Bitmap decodeBase64Bitmap(String b64) {\n");
        sb.append("        if (b64 == null || b64.trim().isEmpty()) return null;\n");
        sb.append("        try {\n");
        sb.append("            byte[] data = Base64.decode(b64.trim(), Base64.DEFAULT);\n");
        sb.append("            return BitmapFactory.decodeByteArray(data, 0, data.length);\n");
        sb.append("        } catch (Throwable t) {\n");
        sb.append("            return null;\n");
        sb.append("        }\n");
        sb.append("    }\n\n");
        sb.append("    private static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {\n");
        sb.append("        if (bitmap == null) return null;\n");
        sb.append("        try {\n");
        sb.append("            Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);\n");
        sb.append("            Canvas canvas = new Canvas(output);\n");
        sb.append("            final Paint paint = new Paint();\n");
        sb.append("            final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());\n");
        sb.append("            final RectF rectF = new RectF(rect);\n");
        sb.append("            paint.setAntiAlias(true);\n");
        sb.append("            canvas.drawARGB(0, 0, 0, 0);\n");
        sb.append("            paint.setColor(0xFF424242);\n");
        sb.append("            canvas.drawRoundRect(rectF, (float) pixels, (float) pixels, paint);\n");
        sb.append("            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));\n");
        sb.append("            canvas.drawBitmap(bitmap, rect, rect, paint);\n");
        sb.append("            return output;\n");
        sb.append("        } catch (Throwable t) {\n");
        sb.append("            return bitmap;\n");
        sb.append("        }\n");
        sb.append("    }\n\n");
        sb.append("    private static Bitmap createFallbackEmblem(int size, int accentColor) {\n");
        sb.append("        try {\n");
        sb.append("            Bitmap b = Bitmap.createBitmap(Math.max(16, size), Math.max(16, size), Bitmap.Config.ARGB_8888);\n");
        sb.append("            Canvas c = new Canvas(b);\n");
        sb.append("            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);\n");
        sb.append("            p.setColor(accentColor);\n");
        sb.append("            c.drawCircle(size / 2f, size / 2f, (size / 2f) - 2f, p);\n");
        sb.append("            return b;\n");
        sb.append("        } catch (Throwable t) {\n");
        sb.append("            return null;\n");
        sb.append("        }\n");
        sb.append("    }\n");
        sb.append("}\n");

        return sb.toString();
    }

    private static String escape(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
