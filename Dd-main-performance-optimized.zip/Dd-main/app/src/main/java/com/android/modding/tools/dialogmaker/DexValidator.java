package com.android.modding.tools.dialogmaker;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;

import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.Adler32;

/**
 * Strict Dalvik/ART Executable (classes.dex) Binary Validator.
 * Verifies magic header, Adler32 checksum, SHA-1 signature, and dexlib2 structural integrity.
 */
public class DexValidator {

    public static class ValidationResult {
        public final boolean isValid;
        public final int sizeBytes;
        public final String checksumHex;
        public final String sha1Hex;
        public final int classCount;
        public final int methodCount;
        public final String verifiedClass;
        public final String errorMessage;

        public ValidationResult(boolean isValid, int sizeBytes, String checksumHex,
                                String sha1Hex, int classCount, int methodCount,
                                String verifiedClass, String errorMessage) {
            this.isValid = isValid;
            this.sizeBytes = sizeBytes;
            this.checksumHex = checksumHex;
            this.sha1Hex = sha1Hex;
            this.classCount = classCount;
            this.methodCount = methodCount;
            this.verifiedClass = verifiedClass;
            this.errorMessage = errorMessage;
        }

        public static ValidationResult failure(String error) {
            return new ValidationResult(false, 0, "00000000",
                    "0000000000000000000000000000000000000000", 0, 0, "", error);
        }
    }

    public static ValidationResult validate(byte[] dexBytes, File cacheDir) {
        if (dexBytes == null || dexBytes.length < 112) {
            return ValidationResult.failure("DEX binary is empty or truncated (< 112 bytes). Size: "
                    + (dexBytes != null ? dexBytes.length : 0));
        }

        // 1. Verify Magic Header (bytes 0..7)
        if (dexBytes[0] != 'd' || dexBytes[1] != 'e' || dexBytes[2] != 'x' || dexBytes[3] != '\n') {
            return ValidationResult.failure("Corrupted DEX magic header: Missing 'dex\\n' identifier.");
        }

        // 2. Extract and verify Adler32 checksum (bytes 8..11 little-endian)
        long storedChecksum = ((dexBytes[8] & 0xFFL))
                | ((dexBytes[9] & 0xFFL) << 8)
                | ((dexBytes[10] & 0xFFL) << 16)
                | ((dexBytes[11] & 0xFFL) << 24);

        Adler32 adler = new Adler32();
        adler.update(dexBytes, 12, dexBytes.length - 12);
        long computedChecksum = adler.getValue();

        String checksumHex = String.format(Locale.US, "%08X", storedChecksum);
        if (storedChecksum != computedChecksum) {
            return ValidationResult.failure(String.format(Locale.US,
                    "DEX Checksum Mismatch: stored=0x%08X, computed=0x%08X", storedChecksum, computedChecksum));
        }

        // 3. Extract and verify SHA-1 signature (bytes 12..31)
        StringBuilder storedShaSb = new StringBuilder();
        for (int i = 12; i < 32; i++) {
            storedShaSb.append(String.format(Locale.US, "%02x", dexBytes[i] & 0xFF));
        }
        String storedSha = storedShaSb.toString();

        try {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            sha1.update(dexBytes, 32, dexBytes.length - 32);
            byte[] computedShaBytes = sha1.digest();
            StringBuilder computedShaSb = new StringBuilder();
            for (byte b : computedShaBytes) {
                computedShaSb.append(String.format(Locale.US, "%02x", b & 0xFF));
            }
            String computedSha = computedShaSb.toString();

            if (!storedSha.equalsIgnoreCase(computedSha)) {
                return ValidationResult.failure("DEX SHA-1 signature verification failed.");
            }
        } catch (Exception e) {
            return ValidationResult.failure("Failed computing SHA-1 signature: " + e.getMessage());
        }

        // 4. Dexlib2 Structural Verification
        int classCount = 0;
        int methodCount = 0;
        String verifiedClass = "Lcom/morsalin/xmlcreator/MorsalinCustomDialog;";
        File tempFile = null;
        try {
            tempFile = File.createTempFile("val_dex_", ".dex", cacheDir);
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(dexBytes);
                fos.flush();
            }

            DexFile dexFile = DexFileFactory.loadDexFile(tempFile, Opcodes.getDefault());
            for (ClassDef c : dexFile.getClasses()) {
                classCount++;
                for (Method m : c.getMethods()) {
                    methodCount++;
                }
            }

            if (classCount == 0) {
                return ValidationResult.failure("DEX contains 0 classes (Empty compilation).");
            }

        } catch (Exception e) {
            return ValidationResult.failure("Dexlib2 structural parsing error: " + e.getMessage());
        } finally {
            if (tempFile != null && tempFile.exists()) {
                tempFile.delete();
            }
        }

        return new ValidationResult(true, dexBytes.length, checksumHex, storedSha,
                classCount, methodCount, verifiedClass, null);
    }
}
