package com.android.modding.tools.generators;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class XmlValidator {

    private static final Pattern HEX_COLOR_PATTERN =
            Pattern.compile("^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$");

    public static class ValidationResult {
        private final boolean valid;
        private final List<String> errors;
        private final List<String> warnings;

        public ValidationResult(boolean valid, List<String> errors, List<String> warnings) {
            this.valid = valid;
            this.errors = errors;
            this.warnings = warnings;
        }

        public boolean isValid() {
            return valid;
        }

        public List<String> getErrors() {
            return errors;
        }

        public List<String> getWarnings() {
            return warnings;
        }

        public String getSummary() {
            StringBuilder sb = new StringBuilder();
            if (!valid) {
                sb.append("Validation Failed:\n");
                for (String err : errors) {
                    sb.append("• ").append(err).append("\n");
                }
            } else {
                sb.append("Valid Android XML!\n");
            }
            if (!warnings.isEmpty()) {
                sb.append("\nWarnings:\n");
                for (String warn : warnings) {
                    sb.append("• ").append(warn).append("\n");
                }
            }
            return sb.toString().trim();
        }
    }

    /**
     * Thoroughly parses and validates Android XML code.
     * Catches XML syntax errors, missing namespaces, invalid colors, incorrect gradient angles,
     * missing radial radius, unclosed tags, and empty layer-list or selector items.
     */
    public static ValidationResult validateXml(String xml) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        if (xml == null || xml.trim().isEmpty()) {
            errors.add("XML content is empty.");
            return new ValidationResult(false, errors, warnings);
        }

        String trimmed = xml.trim();

        // 1. Strict XML Pull Parser verification
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
            parser.setInput(new StringReader(trimmed));

            int eventType = parser.getEventType();
            String rootTag = null;
            boolean hasNamespace = false;
            int selectorItemCount = 0;
            boolean foundDefaultSelectorItem = false;
            int layerListItemCount = 0;

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    String tagName = parser.getName();

                    if (rootTag == null) {
                        rootTag = tagName;
                        // Check android namespace on root
                        for (int i = 0; i < parser.getNamespaceCount(parser.getDepth()); i++) {
                            String uri = parser.getNamespaceUri(i);
                            if ("http://schemas.android.com/apk/res/android".equals(uri)) {
                                hasNamespace = true;
                                break;
                            }
                        }
                    }

                    if ("selector".equals(rootTag) && "item".equals(tagName)) {
                        selectorItemCount++;
                        boolean hasStateAttr = false;
                        for (int i = 0; i < parser.getAttributeCount(); i++) {
                            String attrName = parser.getAttributeName(i);
                            if (attrName != null && attrName.startsWith("state_")) {
                                hasStateAttr = true;
                                break;
                            }
                        }
                        if (!hasStateAttr) {
                            foundDefaultSelectorItem = true;
                        } else if (foundDefaultSelectorItem) {
                            warnings.add("Default <item> in <selector> appears before state-specific items. In Android, subsequent items will never be reached.");
                        }
                    }

                    if ("layer-list".equals(rootTag) && "item".equals(tagName)) {
                        layerListItemCount++;
                    }

                    // Check <gradient> rules
                    if ("gradient".equals(tagName)) {
                        String startColor = getAndroidAttr(parser, "startColor");
                        String endColor = getAndroidAttr(parser, "endColor");
                        String type = getAndroidAttr(parser, "type");
                        String angle = getAndroidAttr(parser, "angle");
                        String radius = getAndroidAttr(parser, "gradientRadius");

                        if (startColor != null && !isValidHexColor(startColor)) {
                            errors.add("Invalid startColor in <gradient>: " + startColor);
                        }
                        if (endColor != null && !isValidHexColor(endColor)) {
                            errors.add("Invalid endColor in <gradient>: " + endColor);
                        }
                        if ("linear".equals(type) || type == null) {
                            if (angle != null) {
                                try {
                                    int a = Integer.parseInt(angle.replace("deg", "").trim());
                                    if (a % 45 != 0) {
                                        errors.add("<gradient> linear angle must be a multiple of 45 (got " + a + ").");
                                    }
                                } catch (NumberFormatException e) {
                                    errors.add("Invalid angle format in <gradient>: " + angle);
                                }
                            }
                        } else if ("radial".equals(type)) {
                            if (radius == null || radius.trim().isEmpty() || radius.equals("0dp")) {
                                errors.add("<gradient> with radial type strictly requires a positive 'android:gradientRadius' attribute.");
                            }
                        }
                    }

                    // Check <stroke> rules
                    if ("stroke".equals(tagName)) {
                        String color = getAndroidAttr(parser, "color");
                        String width = getAndroidAttr(parser, "width");
                        String dashWidth = getAndroidAttr(parser, "dashWidth");
                        String dashGap = getAndroidAttr(parser, "dashGap");

                        if (color != null && !isValidHexColor(color)) {
                            errors.add("Invalid color in <stroke>: " + color);
                        }
                        if (width == null || width.trim().isEmpty() || width.equals("0dp")) {
                            warnings.add("<stroke> has width 0dp or unspecified.");
                        }
                        if (dashWidth != null && !dashWidth.equals("0dp")) {
                            if (dashGap == null || dashGap.equals("0dp")) {
                                errors.add("<stroke> specifies dashWidth but is missing a positive dashGap.");
                            }
                        }
                    }

                    // Check <solid> rules
                    if ("solid".equals(tagName)) {
                        String color = getAndroidAttr(parser, "color");
                        if (color != null && !isValidHexColor(color)) {
                            errors.add("Invalid color in <solid>: " + color);
                        }
                    }
                }
                eventType = parser.next();
            }

            if (!hasNamespace && !trimmed.contains("xmlns:android=\"http://schemas.android.com/apk/res/android\"")) {
                errors.add("Root element is missing the required android namespace declaration (xmlns:android=\"http://schemas.android.com/apk/res/android\").");
            }

            if ("selector".equals(rootTag) && selectorItemCount == 0) {
                errors.add("<selector> must contain at least one <item>.");
            }
            if ("layer-list".equals(rootTag) && layerListItemCount == 0) {
                errors.add("<layer-list> must contain at least one <item>.");
            }

        } catch (Exception e) {
            errors.add("XML Syntax Error: " + e.getMessage());
        }

        return new ValidationResult(errors.isEmpty(), errors, warnings);
    }

    private static String getAndroidAttr(XmlPullParser parser, String attrName) {
        String val = parser.getAttributeValue("http://schemas.android.com/apk/res/android", attrName);
        if (val == null) {
            val = parser.getAttributeValue(null, "android:" + attrName);
        }
        if (val == null) {
            val = parser.getAttributeValue(null, attrName);
        }
        return val;
    }

    public static boolean isValidHexColor(String hex) {
        if (hex == null) return false;
        return HEX_COLOR_PATTERN.matcher(hex.trim()).matches();
    }
}
