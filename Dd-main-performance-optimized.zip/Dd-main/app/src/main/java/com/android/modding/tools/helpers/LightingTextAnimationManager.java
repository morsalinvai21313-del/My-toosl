package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * Manager for the "Animation View Lighting Text" feature.
 * Provides 10 distinct, beautiful multi-color flowing gradient animations for text across the app.
 */
public class LightingTextAnimationManager {

    private static final String PREF_NAME = "morsalin_app_settings";
    public static final String KEY_LIGHTING_STYLE = "global_lighting_text_style";
    public static final String KEY_LIGHTING_ENABLED = "global_lighting_text_enabled";

    public static final int STYLE_CYBER_NEON = 0;       // 1. Cyber Neon Wave (Cyan • Deep Blue • White)
    public static final int STYLE_GOLDEN_SUNSET = 1;    // 2. Golden Sunset Flare (Gold • Amber • Coral Red)
    public static final int STYLE_SYNTHWAVE = 2;        // 3. Synthwave Dream (Hot Pink • Magenta • Aqua)
    public static final int STYLE_AURORA_BOREALIS = 3;  // 4. Aurora Borealis (Turquoise • Emerald Green • Cyan)
    public static final int STYLE_TOXIC_MATRIX = 4;     // 5. Toxic Matrix (Lime • Electric Emerald • Mint)
    public static final int STYLE_SUPERNOVA = 5;        // 6. Supernova Flare (Crimson • Fiery Orange • White)
    public static final int STYLE_DEEP_NEBULA = 6;      // 7. Deep Nebula (Violet • Indigo • Celestial Cyan)
    public static final int STYLE_ICE_CRYSTAL = 7;      // 8. Ice Crystal Prism (Diamond White • Arctic Cyan • Lavender)
    public static final int STYLE_ELECTRIC_PLASMA = 8;  // 9. Electric Plasma (Neon Yellow • Aqua Cyan • Magenta)
    public static final int STYLE_RAINBOW_STREAM = 9;   // 10. Chromatic Rainbow (Full-spectrum flow)

    public static final int TOTAL_STYLES = 10;

    public static final String[] STYLE_NAMES = {
            "1. Cyber Neon Wave",
            "2. Golden Sunset Flare",
            "3. Synthwave Dream",
            "4. Aurora Borealis",
            "5. Toxic Matrix Emerald",
            "6. Supernova Solar Flare",
            "7. Deep Space Nebula",
            "8. Ice Crystal Prism",
            "9. Electric Hyper-Plasma",
            "10. Chromatic Rainbow"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Smooth futuristic neon cyan wave with radiant starlight glare",
            "Warm radiant golden hour sunset glow flowing across the text",
            "Vibrant 80s retro synthwave pulse with hot pink and violet",
            "Ethereal northern lights flowing in turquoise and emerald waves",
            "High-tech cyberpunk digital hacker terminal green stream",
            "Cosmic stellar explosion with brilliant white heat core and fire",
            "Deep space cosmic stardust flow with violet and royal blue",
            "Pristine crystal light refraction with arctic ice blue and lavender",
            "Hyper-energetic tri-color electric plasma burst pulse",
            "Full spectrum chromatic prism stream flowing seamlessly"
    };

    // Color definitions for each of the 10 styles (2 to 4 harmonious colors each)
    private static final int[][] STYLE_COLORS = {
            // 1. Cyber Neon Wave
            new int[]{0xFF00E5FF, 0xFF0077B6, 0xFFFFFFFF, 0xFF00E5FF},
            // 2. Golden Sunset Flare
            new int[]{0xFFFFD166, 0xFFFF9F1C, 0xFFFF385C, 0xFFFFD166},
            // 3. Synthwave Dream
            new int[]{0xFFFF007F, 0xFF9D4EDD, 0xFF00F5D4, 0xFFFF007F},
            // 4. Aurora Borealis
            new int[]{0xFF00F5D4, 0xFF52B788, 0xFF00B4D8, 0xFF00F5D4},
            // 5. Toxic Matrix Emerald
            new int[]{0xFF39FF14, 0xFF00E676, 0xFF69F0AE, 0xFF39FF14},
            // 6. Supernova Solar Flare
            new int[]{0xFFFF3B30, 0xFFFF9500, 0xFFFFFFFF, 0xFFFF3B30},
            // 7. Deep Space Nebula
            new int[]{0xFF7209B7, 0xFF4361EE, 0xFF4CC9F0, 0xFF7209B7},
            // 8. Ice Crystal Prism
            new int[]{0xFFFFFFFF, 0xFF80DEEA, 0xFFB388FF, 0xFFFFFFFF},
            // 9. Electric Hyper-Plasma
            new int[]{0xFFFFEE00, 0xFF00F0FF, 0xFFFF006E, 0xFFFFEE00},
            // 10. Chromatic Rainbow
            new int[]{0xFFFF1744, 0xFFFFD600, 0xFF00E5FF, 0xFFD500F9, 0xFFFF1744}
    };

    public interface OnLightingStyleChangeListener {
        void onLightingStyleChanged(int newStyle, boolean isEnabled);
    }

    private static final List<OnLightingStyleChangeListener> listeners = new ArrayList<>();

    public static synchronized void registerListener(OnLightingStyleChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public static synchronized void unregisterListener(OnLightingStyleChangeListener listener) {
        if (listener != null) {
            listeners.remove(listener);
        }
    }

    public static synchronized void notifyListeners(int newStyle, boolean isEnabled) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            OnLightingStyleChangeListener l = listeners.get(i);
            if (l != null) {
                l.onLightingStyleChanged(newStyle, isEnabled);
            }
        }
    }

    public static int getSavedStyle(Context context) {
        if (context == null) return STYLE_CYBER_NEON;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        int style = sp.getInt(KEY_LIGHTING_STYLE, STYLE_CYBER_NEON);
        if (style < 0 || style >= TOTAL_STYLES) {
            style = STYLE_CYBER_NEON;
        }
        return style;
    }

    public static void setSavedStyle(Context context, int style) {
        if (context == null) return;
        if (style < 0 || style >= TOTAL_STYLES) {
            style = STYLE_CYBER_NEON;
        }
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_LIGHTING_STYLE, style).apply();
        notifyListeners(style, isEnabled(context));
    }

    public static boolean isEnabled(Context context) {
        if (context == null) return false;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getBoolean(KEY_LIGHTING_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_LIGHTING_ENABLED, enabled).apply();
        notifyListeners(getSavedStyle(context), enabled);
    }

    public static int[] getColorsForStyle(int style) {
        if (style >= 0 && style < STYLE_COLORS.length) {
            return STYLE_COLORS[style];
        }
        return STYLE_COLORS[STYLE_CYBER_NEON];
    }

    public static String getStyleName(int style) {
        if (style >= 0 && style < STYLE_NAMES.length) {
            return STYLE_NAMES[style];
        }
        return STYLE_NAMES[STYLE_CYBER_NEON];
    }

    public static String getStyleDescription(int style) {
        if (style >= 0 && style < STYLE_DESCRIPTIONS.length) {
            return STYLE_DESCRIPTIONS[style];
        }
        return "";
    }
}
