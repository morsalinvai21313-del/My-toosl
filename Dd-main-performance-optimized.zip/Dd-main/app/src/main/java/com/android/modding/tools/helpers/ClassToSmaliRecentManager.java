package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class ClassToSmaliRecentManager {

    private static final String PREF_NAME = "morsalin_class_to_smali_recents";
    private static final String KEY_ITEMS = "recent_smali_items";

    public static class RecentSmaliItem {
        public String id;
        public String fileName;
        public String formattedSize;
        public String smaliContent;
        public String className;
        public String timestamp;

        public RecentSmaliItem(String id, String fileName, String formattedSize, String smaliContent, String className, String timestamp) {
            this.id = id;
            this.fileName = fileName;
            this.formattedSize = formattedSize;
            this.smaliContent = smaliContent;
            this.className = className;
            this.timestamp = timestamp;
        }
    }

    public static void addRecent(Context context, String fileName, String formattedSize, String smaliContent, String className) {
        String id = UUID.randomUUID().toString();
        String timestamp = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(new Date());
        RecentSmaliItem item = new RecentSmaliItem(id, fileName, formattedSize, smaliContent, className, timestamp);

        List<RecentSmaliItem> list = getRecents(context);
        list.add(0, item);
        if (list.size() > 50) {
            list = list.subList(0, 50);
        }
        saveRecents(context, list);
    }

    public static List<RecentSmaliItem> getRecents(Context context) {
        List<RecentSmaliItem> list = new ArrayList<>();
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String jsonStr = prefs.getString(KEY_ITEMS, "[]");
        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                list.add(new RecentSmaliItem(
                        obj.optString("id", ""),
                        obj.optString("fileName", ""),
                        obj.optString("formattedSize", ""),
                        obj.optString("smaliContent", ""),
                        obj.optString("className", ""),
                        obj.optString("timestamp", "")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void deleteRecent(Context context, String id) {
        List<RecentSmaliItem> list = getRecents(context);
        List<RecentSmaliItem> updated = new ArrayList<>();
        for (RecentSmaliItem item : list) {
            if (!item.id.equals(id)) {
                updated.add(item);
            }
        }
        saveRecents(context, updated);
    }

    private static void saveRecents(Context context, List<RecentSmaliItem> list) {
        JSONArray array = new JSONArray();
        try {
            for (RecentSmaliItem item : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", item.id);
                obj.put("fileName", item.fileName);
                obj.put("formattedSize", item.formattedSize);
                obj.put("smaliContent", item.smaliContent);
                obj.put("className", item.className);
                obj.put("timestamp", item.timestamp);
                array.put(obj);
            }
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_ITEMS, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
