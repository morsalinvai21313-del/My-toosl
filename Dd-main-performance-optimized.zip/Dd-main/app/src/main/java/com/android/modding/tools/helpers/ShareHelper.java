package com.android.modding.tools.helpers;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class ShareHelper {

    /**
     * Shares XML code as plain text.
     */
    public static void shareXmlText(Context context, String xmlCode, String subject) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, subject != null ? subject : "Android XML Code");
        intent.putExtra(Intent.EXTRA_TEXT, xmlCode);
        context.startActivity(Intent.createChooser(intent, "Share XML Code via"));
    }

    /**
     * Shares XML code as an attached .xml file.
     */
    public static void shareXmlFile(Context context, String fileName, String xmlContent) {
        try {
            if (!fileName.toLowerCase().endsWith(".xml")) {
                fileName += ".xml";
            }
            File cacheDir = new File(context.getCacheDir(), "shared");
            if (!cacheDir.exists()) {
                cacheDir.mkdirs();
            }
            File tempFile = new File(cacheDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(xmlContent.getBytes());
                fos.flush();
            }

            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", tempFile);

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/xml");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(Intent.EXTRA_SUBJECT, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(intent, "Share XML File via"));
        } catch (Exception e) {
            // Fallback to text sharing
            shareXmlText(context, xmlContent, fileName);
        }
    }
}
