package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private View layoutEmpty;
    private HistoryManager historyManager;
    private HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);

        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });
        recyclerView = findViewById(R.id.recycler_history);
        layoutEmpty = findViewById(R.id.layout_empty_history);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private void loadHistory() {
        List<XmlProject> list = historyManager.getAllProjects();
        if (list.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);
            adapter = new HistoryAdapter(list);
            recyclerView.setAdapter(adapter);
        }
    }

    private class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
        private final List<XmlProject> projects;
        private final SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault());

        public HistoryAdapter(List<XmlProject> projects) {
            this.projects = projects;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history_project, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            XmlProject p = projects.get(position);
            holder.tvName.setText(p.getName());
            holder.tvTypeBadge.setText(p.getType());
            holder.tvMeta.setText(p.getType() + " • " + sdf.format(new Date(p.getTimestamp())));

            holder.btnOpen.setOnClickListener(v -> {
                Intent intent;
                if (XmlProject.TYPE_GRADIENT.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, GradientEditorActivity.class);
                } else if (XmlProject.TYPE_3D.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, ThreeDEditorActivity.class);
                } else if (XmlProject.TYPE_LAYOUT.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, LayoutXmlEditorActivity.class);
                } else if (XmlProject.TYPE_ANIMATION.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, AnimationMakerActivity.class);
                } else if (XmlProject.TYPE_TEXT_ANIM.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, TextAnimationMakerActivity.class);
                } else if (XmlProject.TYPE_DIALOG.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, AdvancedDialogMakerActivity.class);
                } else if (XmlProject.TYPE_NOTIFICATION.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, NotificationDesignerActivity.class);
                } else if (XmlProject.TYPE_TOAST.equals(p.getType())) {
                    intent = new Intent(HistoryActivity.this, SimpleSmaliToastActivity.class);
                } else {
                    intent = new Intent(HistoryActivity.this, NormalEditorActivity.class);
                }
                intent.putExtra("EXTRA_IMPORTED_XML", p.getXmlCode());
                intent.putExtra("EXTRA_JSON_CONFIG", p.getJsonConfig());
                try {
                    startActivity(intent);
                    TransitionAnimationManager.applyForward(HistoryActivity.this);
                } catch (Exception ignored) {}
            });

            holder.btnCopy.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Saved XML", p.getXmlCode()));
                Toast.makeText(HistoryActivity.this, "Copied " + p.getName() + " XML!", Toast.LENGTH_SHORT).show();
            });

            holder.btnShare.setOnClickListener(v -> {
                ShareHelper.shareXmlFile(HistoryActivity.this, p.getName().replaceAll("[^a-zA-Z0-9_]", "_") + ".xml", p.getXmlCode());
            });

            holder.btnDelete.setOnClickListener(v -> {
                historyManager.deleteProject(p.getId());
                projects.remove(position);
                notifyItemRemoved(position);
                if (projects.isEmpty()) {
                    recyclerView.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                }
                Toast.makeText(HistoryActivity.this, "Deleted project", Toast.LENGTH_SHORT).show();
            });
        }

        @Override
        public int getItemCount() {
            return projects.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvMeta, tvTypeBadge;
            Button btnOpen, btnCopy, btnShare, btnDelete;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_project_name);
                tvMeta = itemView.findViewById(R.id.tv_project_meta);
                tvTypeBadge = itemView.findViewById(R.id.tv_project_type_badge);
                btnOpen = itemView.findViewById(R.id.btn_item_open);
                btnCopy = itemView.findViewById(R.id.btn_item_copy);
                btnShare = itemView.findViewById(R.id.btn_item_share);
                btnDelete = itemView.findViewById(R.id.btn_item_delete);
            }
        }
    }
}
