package com.android.modding.tools.generators;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dedicated AST pre/post-processor, constructor & property synthesizer,
 * nullability analyzer, Android context normalizer, and strict syntax validator
 * for Java <-> Kotlin conversion.
 */
public class ConversionPostProcessor {

    public enum QualityMode {
        FAST,
        BALANCED,
        STRICT
    }

    public static class PreprocessedJavaResult {
        public final String code;
        public final Set<String> collapsedGetters;
        public final Set<String> collapsedSetters;

        public PreprocessedJavaResult(String code, Set<String> collapsedGetters, Set<String> collapsedSetters) {
            this.code = code;
            this.collapsedGetters = collapsedGetters;
            this.collapsedSetters = collapsedSetters;
        }
    }

    /**
     * Pre-processes Java source before AST conversion while keeping string literals/comments safe.
     */
    public static String preprocessJavaSource(String javaCode, QualityMode mode) {
        return preprocessJavaSourceDetailed(javaCode, mode).code;
    }

    public static PreprocessedJavaResult preprocessJavaSourceDetailed(String javaCode, QualityMode mode) {
        if (javaCode == null || javaCode.isEmpty()) {
            return new PreprocessedJavaResult("", new LinkedHashSet<>(), new LinkedHashSet<>());
        }
        String code = javaCode.replace("\r\n", "\n").replace("\r", "\n");

        // 1. Convert OuterClass.this -> __THIS_AT_OuterClass__ token so AST preserves it
        code = code.replaceAll("\\b([A-Z][A-Za-z0-9_]*)\\.this\\b", "__THIS_AT_$1__");

        Set<String> getters = new LinkedHashSet<>();
        Set<String> setters = new LinkedHashSet<>();

        // 2. Analyze getters/setters in the source file so property access (user.name) can be used
        scanGettersAndSetters(code, getters, setters);

        // 3. Collapse trivial getter/setter methods when in BALANCED or STRICT mode
        if (mode != QualityMode.FAST) {
            code = collapseTrivialGettersAndSetters(code, getters, setters);
        }

        return new PreprocessedJavaResult(code, getters, setters);
    }

    private static void scanGettersAndSetters(String code, Set<String> getters, Set<String> setters) {
        Matcher gm = Pattern.compile(
                "(?s)\\bpublic\\s+([A-Za-z0-9_<>\\[\\]?]+)\\s+get([A-Z][A-Za-z0-9_]*)\\s*\\(\\s*\\)\\s*\\{\\s*return\\s+(?:this\\.)?([a-zA-Z0-9_]+)\\s*;\\s*\\}"
        ).matcher(code);
        while (gm.find()) {
            String propFromMethod = Character.toLowerCase(gm.group(2).charAt(0)) + gm.group(2).substring(1);
            String returnedField = gm.group(3);
            if (propFromMethod.equals(returnedField)) {
                getters.add(returnedField);
            }
        }

        Matcher sm = Pattern.compile(
                "(?s)\\bpublic\\s+void\\s+set([A-Z][A-Za-z0-9_]*)\\s*\\(\\s*[A-Za-z0-9_<>\\[\\]?]+\\s+([a-zA-Z0-9_]+)\\s*\\)\\s*\\{\\s*(?:this\\.)?([a-zA-Z0-9_]+)\\s*=\\s*\\2\\s*;\\s*\\}"
        ).matcher(code);
        while (sm.find()) {
            String propFromMethod = Character.toLowerCase(sm.group(1).charAt(0)) + sm.group(1).substring(1);
            String targetField = sm.group(3);
            if (propFromMethod.equals(targetField)) {
                setters.add(targetField);
            }
        }
    }

    private static String collapseTrivialGettersAndSetters(String code, Set<String> getters, Set<String> setters) {
        String updated = code;
        for (String field : getters) {
            String cap = Character.toUpperCase(field.charAt(0)) + field.substring(1);
            Pattern getterP = Pattern.compile(
                    "(?s)\\n?[ \\t]*public\\s+[A-Za-z0-9_<>\\[\\]?]+\\s+get" + Pattern.quote(cap)
                            + "\\s*\\(\\s*\\)\\s*\\{\\s*return\\s+(?:this\\.)?" + Pattern.quote(field) + "\\s*;\\s*\\}"
            );
            Matcher gm = getterP.matcher(updated);
            if (gm.find()) {
                updated = gm.replaceFirst("");
                if (setters.contains(field)) {
                    Pattern setterP = Pattern.compile(
                            "(?s)\\n?[ \\t]*public\\s+void\\s+set" + Pattern.quote(cap)
                                    + "\\s*\\(\\s*[A-Za-z0-9_<>\\[\\]?]+\\s+([A-Za-z0-9_]+)\\s*\\)\\s*\\{\\s*(?:this\\.)?"
                                    + Pattern.quote(field) + "\\s*=\\s*\\1\\s*;\\s*\\}"
                    );
                    Matcher sm = setterP.matcher(updated);
                    if (sm.find()) {
                        updated = sm.replaceFirst("");
                    }
                }
                // Upgrade private field visibility to public so Kotlin property is accessible
                updated = updated.replaceAll(
                        "(?m)^(\\s*)private(\\s+(?:final\\s+)?[A-Za-z0-9_<>\\[\\], ?]+\\s+" + Pattern.quote(field) + "\\b)",
                        "$1public$2"
                );
            }
        }
        return updated;
    }

    /**
     * Applies Kotlin-specific AST refinements after structural conversion:
     * - Restores this@ClassName
     * - Promotes constructors into idiomatic primary constructors + optional init { ... } blocks
     * - Ensures getter return types match nullable backing fields
     * - Infers parameter nullability when checked against null
     * - Converts string concatenation into Kotlin string templates
     * - Cleans up SAM lambda formatting
     */
    public static String refineGeneratedKotlin(String ktCode, QualityMode mode) {
        if (ktCode == null || ktCode.isEmpty()) return "";
        String code = ktCode;

        // 1. Restore this@OuterClass
        code = code.replaceAll("__THIS_AT_([A-Za-z0-9_]+)__", "this@$1");

        // 2. Promote secondary constructors that initialize class fields into primary constructors
        code = promoteConstructorsToPrimary(code);

        // 3. Infer parameter nullability from null checks inside function bodies
        code = inferParameterNullability(code);

        // 4. Fix getter return types if backing field is nullable
        code = reconcileGetterReturnNullability(code);

        // 5. Convert string concatenations to idiomatic Kotlin templates
        code = convertStringConcatenationToTemplates(code);

        // 6. Optimize listener lambda parameters and braces
        code = optimizeLambdaParametersAndFormatting(code);

        return code;
    }

    /**
     * Promotes classes with field declarations + a constructor assigning those fields
     * into a Kotlin primary constructor, placing any extra constructor statements into `init { ... }`.
     */
    public static String promoteConstructorsToPrimary(String code) {
        String[] lines = code.split("\n", -1);
        List<String> out = new ArrayList<>();
        int i = 0;

        while (i < lines.length) {
            String line = lines[i];
            String trimmed = line.trim();

            // Detect `class Name {` without existing primary constructor or superclass call
            Matcher classM = Pattern.compile("^(\\s*(?:private\\s+|protected\\s+|internal\\s+)?(?:open\\s+|inner\\s+|data\\s+)?class\\s+([A-Za-z0-9_]+))\\s*\\{$").matcher(line);
            if (classM.find()) {
                String classPrefix = classM.group(1);
                String indent = line.substring(0, line.indexOf(trimmed));

                // Find matching closing brace of this class
                int classEnd = findMatchingCloseBraceLine(lines, i);
                if (classEnd > i) {
                    PrimaryCtorTransformResult transformed = tryTransformClassBodyToPrimaryCtor(
                            classPrefix, indent, lines, i + 1, classEnd
                    );
                    if (transformed != null) {
                        out.addAll(transformed.lines);
                        i = classEnd + 1;
                        continue;
                    }
                }
            }
            out.add(line);
            i++;
        }
        return String.join("\n", out);
    }

    private static class PrimaryCtorTransformResult {
        final List<String> lines;
        PrimaryCtorTransformResult(List<String> lines) {
            this.lines = lines;
        }
    }

    private static class FieldDeclInfo {
        final int lineIndex;
        final String visibility; // "" or "private " or "protected "
        final String valOrVar;   // "val" or "var"
        final String name;
        final String type;       // non-nullable base type if uninitialized

        FieldDeclInfo(int lineIndex, String visibility, String valOrVar, String name, String type) {
            this.lineIndex = lineIndex;
            this.visibility = visibility;
            this.valOrVar = valOrVar;
            this.name = name;
            this.type = type;
        }
    }

    private static PrimaryCtorTransformResult tryTransformClassBodyToPrimaryCtor(
            String classPrefix, String classIndent, String[] lines, int bodyStart, int bodyEnd) {

        Map<String, FieldDeclInfo> topFields = new LinkedHashMap<>();
        int ctorStartLine = -1;
        int ctorEndLine = -1;
        String ctorParamsRaw = null;
        int constructorCount = 0;

        int depth = 0;
        for (int idx = bodyStart; idx < bodyEnd; idx++) {
            String t = lines[idx].trim();
            if (depth == 0) {
                Matcher fm = Pattern.compile(
                        "^(?:(private|protected|public|internal)\\s+)?(?:lateinit\\s+)?(val|var)\\s+([A-Za-z0-9_]+)\\s*:\\s*([A-Za-z0-9_<>?., ]+?)(?:\\s*=\\s*(null|0|0L|0\\.0|0f|false|\"\"))?$"
                ).matcher(t);
                if (fm.find()) {
                    String vis = fm.group(1) != null && !fm.group(1).equals("public") ? fm.group(1) + " " : "";
                    String valVar = fm.group(2);
                    String fName = fm.group(3);
                    String fType = fm.group(4).trim();
                    topFields.put(fName, new FieldDeclInfo(idx, vis, valVar, fName, fType));
                }

                Matcher cm = Pattern.compile("^(?:(?:public|private|protected)\\s+)?constructor\\s*\\(([^)]*)\\)\\s*\\{$").matcher(t);
                if (cm.find()) {
                    constructorCount++;
                    ctorStartLine = idx;
                    ctorParamsRaw = cm.group(1).trim();
                    ctorEndLine = findMatchingCloseBraceLine(lines, idx);
                }
            }
            depth += countNetBraces(t);
        }

        if (constructorCount != 1 || ctorStartLine < 0 || ctorEndLine < 0 || ctorParamsRaw.isEmpty()) {
            return null;
        }

        // Parse constructor parameters
        List<String> paramParts = splitTopLevelCommas(ctorParamsRaw);
        Map<String, String> ctorParamTypes = new LinkedHashMap<>();
        for (String p : paramParts) {
            String pt = p.trim();
            int colon = pt.indexOf(':');
            if (colon <= 0) return null;
            String pName = pt.substring(0, colon).trim();
            String pType = pt.substring(colon + 1).trim();
            ctorParamTypes.put(pName, pType);
        }

        // Inspect constructor body lines
        Map<String, String> assignedParamToField = new LinkedHashMap<>();
        List<String> remainingInitLines = new ArrayList<>();
        for (int k = ctorStartLine + 1; k < ctorEndLine; k++) {
            String bt = lines[k].trim();
            if (bt.isEmpty()) continue;
            Matcher assignM = Pattern.compile("^(?:this\\.)?([A-Za-z0-9_]+)\\s*=\\s*([A-Za-z0-9_]+)$").matcher(bt);
            if (assignM.find()) {
                String fName = assignM.group(1);
                String pName = assignM.group(2);
                if (fName.equals(pName) && topFields.containsKey(fName) && ctorParamTypes.containsKey(pName)) {
                    assignedParamToField.put(pName, fName);
                    continue;
                }
            }
            remainingInitLines.add(lines[k]);
        }

        // Only promote if all constructor params correspond to fields
        if (assignedParamToField.size() != ctorParamTypes.size() || assignedParamToField.isEmpty()) {
            return null;
        }

        Set<Integer> consumedFieldLines = new LinkedHashSet<>();
        List<String> primaryParams = new ArrayList<>();
        for (Map.Entry<String, String> entry : ctorParamTypes.entrySet()) {
            String pName = entry.getKey();
            String pType = entry.getValue();
            FieldDeclInfo fInfo = topFields.get(pName);
            consumedFieldLines.add(fInfo.lineIndex);
            primaryParams.add(classIndent + "    " + fInfo.visibility + fInfo.valOrVar + " " + pName + ": " + pType);
        }

        // Collect remaining class body lines
        List<String> remainingBody = new ArrayList<>();
        if (!remainingInitLines.isEmpty()) {
            remainingBody.add(classIndent + "    init {");
            for (String il : remainingInitLines) {
                remainingBody.add(il);
            }
            remainingBody.add(classIndent + "    }");
        }

        for (int idx = bodyStart; idx < bodyEnd; idx++) {
            if (consumedFieldLines.contains(idx)) continue;
            if (idx >= ctorStartLine && idx <= ctorEndLine) continue;
            remainingBody.add(lines[idx]);
        }

        // Trim leading/trailing blank lines in remainingBody
        while (!remainingBody.isEmpty() && remainingBody.get(0).trim().isEmpty()) {
            remainingBody.remove(0);
        }
        while (!remainingBody.isEmpty() && remainingBody.get(remainingBody.size() - 1).trim().isEmpty()) {
            remainingBody.remove(remainingBody.size() - 1);
        }

        List<String> resultLines = new ArrayList<>();
        resultLines.add(classPrefix + "(");
        for (int p = 0; p < primaryParams.size(); p++) {
            String suffix = (p < primaryParams.size() - 1) ? "," : "";
            resultLines.add(primaryParams.get(p) + suffix);
        }
        if (remainingBody.isEmpty()) {
            resultLines.add(classIndent + ")");
        } else {
            resultLines.add(classIndent + ") {");
            resultLines.addAll(remainingBody);
            resultLines.add(classIndent + "}");
        }
        return new PrimaryCtorTransformResult(resultLines);
    }

    private static int findMatchingCloseBraceLine(String[] lines, int openLine) {
        int depth = 0;
        for (int i = openLine; i < lines.length; i++) {
            depth += countNetBraces(lines[i]);
            if (depth == 0 && i >= openLine) {
                return i;
            }
        }
        return -1;
    }

    private static int countNetBraces(String s) {
        String clean = s.replaceAll("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"", "\"\"");
        int net = 0;
        for (int i = 0; i < clean.length(); i++) {
            char c = clean.charAt(i);
            if (c == '{') net++;
            else if (c == '}') net--;
        }
        return net;
    }

    private static List<String> splitTopLevelCommas(String input) {
        List<String> list = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '<' || c == '(' || c == '[') depth++;
            else if (c == '>' || c == ')' || c == ']') depth--;
            if (c == ',' && depth == 0) {
                list.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        if (sb.length() > 0) list.add(sb.toString());
        return list;
    }

    private static String inferParameterNullability(String code) {
        String[] lines = code.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            Matcher funM = Pattern.compile("^(\\s*(?:override\\s+)?(?:private\\s+|protected\\s+|internal\\s+)?fun\\s+[A-Za-z0-9_<>]+\\s*\\()([^)]+)(\\).*\\{)\\s*$").matcher(line);
            if (funM.find()) {
                String prefix = funM.group(1);
                String paramsStr = funM.group(2);
                String suffix = funM.group(3);

                StringBuilder body = new StringBuilder();
                int depth = 1;
                int endLine = i;
                for (int j = i + 1; j < lines.length && depth > 0; j++) {
                    String bl = lines[j];
                    depth += countNetBraces(bl);
                    body.append(bl).append("\n");
                    endLine = j;
                }
                String bodyStr = body.toString();

                List<String> params = splitTopLevelCommas(paramsStr);
                List<String> updatedParams = new ArrayList<>();
                Set<String> newlyNullableParams = new LinkedHashSet<>();

                for (String p : params) {
                    String pt = p.trim();
                    int colon = pt.indexOf(':');
                    if (colon > 0 && !pt.endsWith("?")) {
                        String pName = pt.substring(0, colon).replace("vararg ", "").trim();
                        String pType = pt.substring(colon + 1).trim();
                        boolean checkedForNull = Pattern.compile("\\b" + Pattern.quote(pName) + "\\s*(==|!=)\\s*null\\b").matcher(bodyStr).find()
                                || Pattern.compile("\\bnull\\s*(==|!=)\\s*" + Pattern.quote(pName) + "\\b").matcher(bodyStr).find()
                                || bodyStr.contains(pName + "?.")
                                || bodyStr.contains(pName + ".isNullOrEmpty()")
                                || bodyStr.contains(pName + ".isNullOrBlank()");
                        if (checkedForNull) {
                            pt = pt.substring(0, colon + 1) + " " + pType + "?";
                            newlyNullableParams.add(pName);
                        }
                    }
                    updatedParams.add(pt);
                }
                lines[i] = prefix + String.join(", ", updatedParams) + suffix;

                // Remove unnecessary `?.` after an early-return `if (param.isNullOrEmpty()) return ...`
                if (!newlyNullableParams.isEmpty()) {
                    for (String np : newlyNullableParams) {
                        for (int k = i + 1; k <= endLine; k++) {
                            lines[k] = lines[k].replaceAll(
                                    "if\\s*\\(\\s*" + Pattern.quote(np) + "\\s*==\\s*null\\s*\\|\\|\\s*" + Pattern.quote(np) + "\\??\\.isEmpty\\(\\)\\s*\\)",
                                    "if (" + np + ".isNullOrEmpty())"
                            );
                        }
                    }
                }
            }
        }
        String joined = String.join("\n", lines);
        joined = joined.replaceAll(
                "if\\s*\\(\\s*([A-Za-z0-9_]+)\\s*==\\s*null\\s*\\|\\|\\s*\\1\\??\\.isEmpty\\(\\)\\s*\\)",
                "if ($1.isNullOrEmpty())"
        );
        joined = joined.replaceAll(
                "if\\s*\\(\\s*([A-Za-z0-9_]+)\\s*!=\\s*null\\s*&&\\s*!\\1\\??\\.isEmpty\\(\\)\\s*\\)",
                "if (!$1.isNullOrEmpty())"
        );
        return joined;
    }

    /**
     * Ensures that if a class field is nullable (`private var name: String? = null`),
     * any explicit getter returning that field has a matching nullable return type (`fun getName(): String?`).
     */
    private static String reconcileGetterReturnNullability(String code) {
        String[] lines = code.split("\n", -1);
        Set<String> nullableFields = new LinkedHashSet<>();
        for (String line : lines) {
            Matcher fm = Pattern.compile("^\\s*(?:private\\s+|protected\\s+)?(?:var|val)\\s+([A-Za-z0-9_]+)\\s*:\\s*([A-Za-z0-9_<>]+\\?)\\s*=").matcher(line);
            if (fm.find()) {
                nullableFields.add(fm.group(1));
            }
        }
        if (nullableFields.isEmpty()) return code;

        for (int i = 0; i < lines.length; i++) {
            Matcher gm = Pattern.compile("^(\\s*(?:private\\s+|protected\\s+)?fun\\s+get[A-Z][A-Za-z0-9_]*\\s*\\(\\s*\\)\\s*:\\s*[A-Za-z0-9_<>]+)(\\s*\\{)$").matcher(lines[i]);
            if (gm.find() && i + 1 < lines.length) {
                String nextTrim = lines[i + 1].trim();
                Matcher retM = Pattern.compile("^return\\s+(?:this\\.)?([A-Za-z0-9_]+)$").matcher(nextTrim);
                if (retM.find() && nullableFields.contains(retM.group(1))) {
                    lines[i] = gm.group(1) + "?" + gm.group(2);
                }
            }
        }
        return String.join("\n", lines);
    }

    private static String convertStringConcatenationToTemplates(String code) {
        String[] lines = code.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (!line.contains("\"") || !line.contains("+")) continue;

            // 1. "literal" + var.prop / var.method() -> "literal${var.prop}"
            Matcher exprM = Pattern.compile("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\s*\\+\\s*([A-Za-z_][A-Za-z0-9_]*(?:\\??\\.[A-Za-z_][A-Za-z0-9_]*(?:\\(\\))?)+)").matcher(line);
            int guard = 0;
            while (exprM.find() && guard++ < 8) {
                String lit = exprM.group(1);
                String expr = exprM.group(2);
                line = line.substring(0, exprM.start()) + "\"" + lit + "${" + expr + "}\"" + line.substring(exprM.end());
                line = line.replaceAll("\"([^\"]*)\"\\s*\\+\\s*\"([^\"]*)\"", "\"$1$2\"");
                exprM = Pattern.compile("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\s*\\+\\s*([A-Za-z_][A-Za-z0-9_]*(?:\\??\\.[A-Za-z_][A-Za-z0-9_]*(?:\\(\\))?)+)").matcher(line);
            }

            // 2. "literal" + varName -> "literal$varName"
            Matcher m = Pattern.compile("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\s*\\+\\s*([A-Za-z_][A-Za-z0-9_]*)\\b(?!\\s*[.(])").matcher(line);
            guard = 0;
            while (m.find() && guard++ < 8) {
                String lit = m.group(1);
                String var = m.group(2);
                String templateVar = (m.end() < line.length() && Character.isJavaIdentifierPart(line.charAt(m.end())))
                        ? "${" + var + "}" : "$" + var;
                line = line.substring(0, m.start()) + "\"" + lit + templateVar + "\"" + line.substring(m.end());
                line = line.replaceAll("\"([^\"]*)\"\\s*\\+\\s*\"([^\"]*)\"", "\"$1$2\"");
                m = Pattern.compile("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\s*\\+\\s*([A-Za-z_][A-Za-z0-9_]*)\\b(?!\\s*[.(])").matcher(line);
            }

            // 3. varName + "literal" -> "$varName..." when preceded by `= ` or `(` or `, `
            Matcher prefixM = Pattern.compile("([=(,]\\s*)([A-Za-z_][A-Za-z0-9_]*)\\s*\\+\\s*\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"").matcher(line);
            if (prefixM.find()) {
                String lead = prefixM.group(1);
                String var = prefixM.group(2);
                String lit = prefixM.group(3);
                String tpl = (!lit.isEmpty() && Character.isJavaIdentifierPart(lit.charAt(0)))
                        ? "${" + var + "}" + lit : "$" + var + lit;
                line = line.substring(0, prefixM.start()) + lead + "\"" + tpl + "\"" + line.substring(prefixM.end());
            }

            lines[i] = line;
        }
        return String.join("\n", lines);
    }

    private static String optimizeLambdaParametersAndFormatting(String code) {
        code = code.replaceAll("\\.setOnClickListener\\(\\{\\s*([A-Za-z0-9_]+)\\s*->", ".setOnClickListener { $1 ->");
        code = code.replaceAll("\\.setOnClickListener\\(\\{", ".setOnClickListener {");
        code = code.replaceAll("\\.post\\(Runnable\\s*\\{", ".post {");

        String[] lines = code.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            // Case A: Explicit parameter `{ v ->` — remove if unused inside lambda body
            Matcher m = Pattern.compile("^(\\s*.+\\.(?:setOnClickListener|setOnLongClickListener)\\s*\\{)\\s*([A-Za-z0-9_]+)\\s*->\\s*$").matcher(lines[i]);
            if (m.find()) {
                String prefix = m.group(1);
                String param = m.group(2);
                int closeLine = findMatchingCloseBraceLine(lines, i);
                if (closeLine > i) {
                    boolean paramUsed = false;
                    Pattern pUsage = Pattern.compile("\\b" + Pattern.quote(param) + "\\b");
                    for (int k = i + 1; k < closeLine; k++) {
                        if (pUsage.matcher(lines[k]).find()) {
                            paramUsed = true;
                            break;
                        }
                    }
                    if (!paramUsed) {
                        lines[i] = prefix;
                    }
                }
                continue;
            }

            // Case B: Parameterless `{` — Step 7 (Detect unresolved references): if `view` or `v` is referenced inside body without declaration, restore `{ view ->` or `{ v ->`
            Matcher noParamM = Pattern.compile("^(\\s*.+\\.(?:setOnClickListener|setOnLongClickListener)\\s*\\{)\\s*$").matcher(lines[i]);
            if (noParamM.find()) {
                String prefix = noParamM.group(1);
                int closeLine = findMatchingCloseBraceLine(lines, i);
                if (closeLine > i) {
                    boolean usesView = false;
                    boolean usesV = false;
                    Pattern viewP = Pattern.compile("(?<!\\.)\\bview\\b");
                    Pattern vP = Pattern.compile("(?<!\\.)\\bv\\b");
                    for (int k = i + 1; k < closeLine; k++) {
                        String bodyLine = lines[k].replaceAll("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"", "\"\"");
                        if (viewP.matcher(bodyLine).find()) usesView = true;
                        if (vP.matcher(bodyLine).find()) usesV = true;
                    }
                    if (usesView) {
                        lines[i] = prefix + " view ->";
                    } else if (usesV) {
                        lines[i] = prefix + " v ->";
                    }
                }
            }
        }
        return String.join("\n", lines);
    }

    // =========================================================================================
    // 11-STEP SEMANTIC ANALYZER, TYPE-MISMATCH DETECTOR & MULTI-PASS AUTO-REPAIR ENGINE
    // =========================================================================================
    public static class RepairAndValidationReport {
        public final String repairedCode;
        public final List<String> structuredWarnings;
        public final boolean hasUnresolvedCriticalErrors;
        public final String criticalErrorSummary;

        public RepairAndValidationReport(
                String repairedCode,
                List<String> structuredWarnings,
                boolean hasUnresolvedCriticalErrors,
                String criticalErrorSummary) {
            this.repairedCode = repairedCode;
            this.structuredWarnings = structuredWarnings;
            this.hasUnresolvedCriticalErrors = hasUnresolvedCriticalErrors;
            this.criticalErrorSummary = criticalErrorSummary;
        }
    }

    /**
     * Step 1: Structured symbol table of generated Kotlin declarations for semantic analysis.
     */
    private static class KotlinSemanticModel {
        final Map<String, String> varBaseTypes = new LinkedHashMap<>();
        final Set<String> nullableVars = new LinkedHashSet<>();
        final Set<String> nonNullVars = new LinkedHashSet<>();
        final Set<String> varsAssignedNull = new LinkedHashSet<>();
        final Set<String> varsCheckedForNull = new LinkedHashSet<>();
        final Set<String> varsInitializedByFindViewById = new LinkedHashSet<>();
        final Set<String> declaredIdentifiers = new LinkedHashSet<>();
        final Set<String> classNames = new LinkedHashSet<>();

        static KotlinSemanticModel parse(String kotlinCode) {
            KotlinSemanticModel model = new KotlinSemanticModel();
            String[] lines = kotlinCode.split("\n", -1);

            Matcher classScanner = Pattern.compile("(?m)^\\s*(?:private\\s+|protected\\s+|internal\\s+|open\\s+|abstract\\s+|data\\s+|enum\\s+|inner\\s+)*class\\s+([A-Za-z0-9_]+)").matcher(kotlinCode);
            while (classScanner.find()) {
                model.classNames.add(classScanner.group(1));
                model.declaredIdentifiers.add(classScanner.group(1));
            }

            // Scan null assignments and null checks first
            Pattern assignNullP = Pattern.compile("\\b([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*null\\b");
            Pattern checkNullP = Pattern.compile("\\b([A-Za-z_][A-Za-z0-9_]*)\\s*(?:==|!=)\\s*null\\b|\\b([A-Za-z_][A-Za-z0-9_]*)\\??\\.isNullOr(?:Empty|Blank)\\b");
            Pattern findViewP = Pattern.compile("\\b([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*findViewById\\b");

            for (String raw : lines) {
                String trimmed = raw.trim();
                if (trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) continue;
                String codeOnly = trimmed.replaceAll("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"", "\"\"");

                // Skip declaration `= null` when checking for subsequent null assignments
                if (!codeOnly.matches("^(?:private\\s+|protected\\s+|public\\s+|internal\\s+)?(?:val|var)\\s+.*=\\s*null$")) {
                    Matcher anm = assignNullP.matcher(codeOnly);
                    while (anm.find()) {
                        model.varsAssignedNull.add(anm.group(1));
                    }
                }
                Matcher cnm = checkNullP.matcher(codeOnly);
                while (cnm.find()) {
                    String v = cnm.group(1) != null ? cnm.group(1) : cnm.group(2);
                    if (v != null) model.varsCheckedForNull.add(v);
                }
                Matcher fvm = findViewP.matcher(codeOnly);
                while (fvm.find()) {
                    model.varsInitializedByFindViewById.add(fvm.group(1));
                }
            }

            // Scan property and local declarations + function parameters
            Pattern declP = Pattern.compile(
                    "^(?:(?:private|protected|public|internal|const|lateinit|override)\\s+)*(val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s*:\\s*([A-Za-z0-9_<>?, ]+?))?(?:\\s*=\\s*(.+))?$"
            );
            Pattern funP = Pattern.compile(
                    "^(?:(?:override|private|protected|public|internal|open|abstract|suspend)\\s+)*fun\\s+(?:<[^>]+>\\s+)?([A-Za-z0-9_]+)\\s*\\(([^)]*)\\)(?:\\s*:\\s*([A-Za-z0-9_<>?]+))?"
            );

            for (String raw : lines) {
                String trimmed = raw.trim();
                Matcher dm = declP.matcher(trimmed);
                if (dm.find()) {
                    String vName = dm.group(2).trim();
                    String typeRaw = dm.group(3) != null ? dm.group(3).trim() : null;
                    String initRaw = dm.group(4) != null ? dm.group(4).trim() : null;
                    model.declaredIdentifiers.add(vName);
                    if (typeRaw != null) {
                        boolean isNull = typeRaw.endsWith("?");
                        String base = isNull ? typeRaw.substring(0, typeRaw.length() - 1).trim() : typeRaw;
                        model.varBaseTypes.put(vName, base);
                        if (isNull) model.nullableVars.add(vName);
                        else model.nonNullVars.add(vName);
                    } else if (initRaw != null) {
                        if (initRaw.matches("^-?\\d+$")) {
                            model.varBaseTypes.put(vName, "Int");
                            model.nonNullVars.add(vName);
                        } else if (initRaw.startsWith("\"")) {
                            model.varBaseTypes.put(vName, "String");
                            model.nonNullVars.add(vName);
                        }
                    }
                    continue;
                }

                Matcher fm = funP.matcher(trimmed);
                if (fm.find()) {
                    model.declaredIdentifiers.add(fm.group(1).trim());
                    String params = fm.group(2).trim();
                    if (!params.isEmpty()) {
                        for (String p : splitTopLevelCommas(params)) {
                            String pt = p.trim().replaceFirst("^(?:vararg|val|var)\\s+", "");
                            int colon = pt.indexOf(':');
                            if (colon > 0) {
                                String pName = pt.substring(0, colon).trim();
                                String pType = pt.substring(colon + 1).trim();
                                if (pType.contains("=")) pType = pType.substring(0, pType.indexOf('=')).trim();
                                model.declaredIdentifiers.add(pName);
                                boolean isNull = pType.endsWith("?");
                                String base = isNull ? pType.substring(0, pType.length() - 1).trim() : pType;
                                model.varBaseTypes.put(pName, base);
                                if (isNull) model.nullableVars.add(pName);
                                else model.nonNullVars.add(pName);
                            }
                        }
                    }
                }
            }

            return model;
        }
    }

    /**
     * Executes Steps 1–10:
     * 1. Parse generated Kotlin
     * 2. Detect nullable/non-nullable type mismatch
     * 3. Detect invalid comparisons such as Int? >= Int
     * 4. Detect unnecessary nullable declarations
     * 5. Detect Java API artifacts
     * 6. Detect invalid Kotlin syntax
     * 7. Detect unresolved references
     * 8. Detect invalid Android API conversions
     * 9. Auto-fix safe problems
     * 10. Re-validate
     */
    public static RepairAndValidationReport validateAndRepairKotlin(String generatedKotlin, QualityMode mode) {
        String current = generatedKotlin != null ? generatedKotlin : "";
        List<String> warnings = new ArrayList<>();

        // Step 9: Run multi-pass semantic & syntax auto-repair (Steps 1 through 8)
        for (int pass = 1; pass <= 3; pass++) {
            String before = current;
            current = runSingleKotlinRepairPass(current);
            current = runSemanticNullabilityAndComparisonPass(current);
            current = optimizeLambdaParametersAndFormatting(current);
            if (current.equals(before)) {
                break;
            }
        }

        // Step 10: Re-validate the repaired Kotlin AST & semantic model
        KotlinSemanticModel finalModel = KotlinSemanticModel.parse(current);
        String[] lines = current.split("\n", -1);
        boolean criticalError = false;
        StringBuilder criticalDetails = new StringBuilder();
        int methodBraceDepth = 0;
        boolean insideMethod = false;

        for (int i = 0; i < lines.length; i++) {
            int lineNo = i + 1;
            String raw = lines[i];
            String trimmed = raw.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) {
                continue;
            }

            // Strip string literals on the line before checking forbidden syntax
            String codeOnly = trimmed.replaceAll("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"", "\"\"");

            if (codeOnly.matches("^(?:override\\s+)?(?:private\\s+|protected\\s+|internal\\s+)?fun\\s+.*\\{\\s*$")) {
                if (!insideMethod) {
                    insideMethod = true;
                    methodBraceDepth = 0;
                }
            }
            if (insideMethod) {
                methodBraceDepth += countNetBraces(codeOnly);
                if (methodBraceDepth <= 0) {
                    insideMethod = false;
                    methodBraceDepth = 0;
                }
            }

            // Check 1: Forbidden declaration syntax (`var : int`, `val : String`)
            if (codeOnly.matches(".*\\b(private|public|protected)?\\s*(var|val)\\s*:\\s*.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Invalid declaration syntax ('var/val :'). Expected 'val/var name: Type'.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 2: Java modifier inside Kotlin type (`: private`, `: final`, `: static`, `: public`)
            if (codeOnly.matches(".*:\\s*(private|public|protected|final|static)\\b.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Invalid Java modifier inside Kotlin type annotation.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 3: Java primitive type names in Kotlin type positions (`: int`, `: boolean`, `: long`, etc.)
            if (codeOnly.matches(".*:\\s*(int|boolean|long|double|float|short|byte|char|void)\\b.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Java primitive type used in Kotlin type annotation.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 4: Java `new` keyword (`new int`, `new String`, `new ArrayList`, `new ClassName(...)`)
            if (codeOnly.matches(".*\\bnew\\s+([A-Za-z0-9_<>]+)\\s*[(\\[].*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Java 'new' keyword detected in Kotlin output.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 5: `MainActivity.this` or `ClassName.this`
            if (codeOnly.matches(".*\\b[A-Z][A-Za-z0-9_]*\\.this\\b.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Java 'ClassName.this' detected; must be 'this@ClassName'.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 6: `public void`, `private void`, `public static`, `private final`
            if (codeOnly.matches(".*\\b(public|private|protected)\\s+(void|static|final)\\b.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Unconverted Java modifier/void declaration detected.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 7: Unconverted Java local variable `String variable =` or `Integer variable =` or `int variable =`
            if (codeOnly.matches("^(?:final\\s+)?(?:String|Integer|Boolean|Long|Double|Float|Short|Byte|Character|int|boolean|long|double|float|short|byte|char)\\s+[A-Za-z0-9_]+\\s*=.*")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": Unconverted Java local variable declaration ('" + trimmed + "').";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 8: `fun ClassName(...)` constructor converted as function
            Matcher funNameM = Pattern.compile("\\bfun\\s+([A-Z][A-Za-z0-9_]*)\\s*\\(").matcher(codeOnly);
            if (funNameM.find()) {
                String fn = funNameM.group(1);
                if (finalModel.classNames.contains(fn) || codeOnly.matches(".*\\)\\s*:\\s*(public|private|protected)\\b.*")) {
                    criticalError = true;
                    String msg = "Line " + lineNo + ": Constructor '" + fn + "' was erroneously converted into a function.";
                    warnings.add(msg);
                    criticalDetails.append(msg).append("\n");
                }
            }

            // Check 9: `companion object` inside method scope
            if (insideMethod && codeOnly.startsWith("companion object")) {
                criticalError = true;
                String msg = "Line " + lineNo + ": 'companion object' is illegally placed inside a method scope.";
                warnings.add(msg);
                criticalDetails.append(msg).append("\n");
            }

            // Check 10: Unguarded relational comparison on nullable numeric (`Int? >= Int`)
            for (String nv : finalModel.nullableVars) {
                String baseT = finalModel.varBaseTypes.getOrDefault(nv, "");
                if (isNumericKotlinType(baseT)) {
                    Pattern relP = Pattern.compile("\\b" + Pattern.quote(nv) + "\\s*(>=|<=|>|<)\\s*");
                    if (relP.matcher(codeOnly).find() && !codeOnly.contains(nv + " != null")) {
                        warnings.add("Line " + lineNo + ": Nullable '" + nv + ": " + baseT + "?' compared with relational operator without null check.");
                    }
                }
            }
        }

        return new RepairAndValidationReport(
                current,
                warnings,
                criticalError,
                criticalDetails.toString().trim()
        );
    }

    /**
     * Steps 1, 2, 3, 4, 7:
     * - Step 1: Parse generated Kotlin into KotlinSemanticModel
     * - Step 4: Eliminate unnecessary nullable declarations (`var counter: Int? = 0` -> `var counter: Int = 0`,
     *   and `private var tv: TextView? = null` initialized with `findViewById` -> `private lateinit var tv: TextView`)
     * - Step 2: Fix nullable/non-nullable type mismatches (strip `?.` on non-null / lateinit vars; fix getter return types)
     * - Step 3: Fix invalid relational comparisons such as `Int? >= Int` by adding `v != null &&` or `(v ?: 0)`
     */
    private static String runSemanticNullabilityAndComparisonPass(String code) {
        KotlinSemanticModel model = KotlinSemanticModel.parse(code);
        String[] lines = code.split("\n", -1);
        Set<String> promotedToNonNull = new LinkedHashSet<>();

        // Step 4: Detect and fix unnecessary nullable declarations
        Pattern nullableInitNonNullP = Pattern.compile(
                "^(\\s*(?:(?:private|protected|public|internal)\\s+)?(?:val|var)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*:\\s*([A-Za-z0-9_<>]+))\\?(\\s*=\\s*(?!null\\b)(.+))$"
        );
        Pattern nullableViewFieldP = Pattern.compile(
                "^(\\s*)(private|protected|internal)?\\s*var\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*:\\s*(TextView|Button|EditText|ImageView|ImageButton|RecyclerView|LinearLayout|RelativeLayout|FrameLayout|ConstraintLayout|ScrollView|View|Switch|CheckBox|ProgressBar|SeekBar|Toolbar|Spinner|CardView)\\?\\s*=\\s*null\\s*$"
        );

        for (int i = 0; i < lines.length; i++) {
            // 4a. `private var counter: Int? = 0` where `counter` is never assigned `null` -> `private var counter: Int = 0`
            Matcher nin = nullableInitNonNullP.matcher(lines[i]);
            if (nin.find()) {
                String prefix = nin.group(1);
                String vName = nin.group(2);
                String baseType = nin.group(3);
                String rhsPart = nin.group(4);
                String rhsExpr = nin.group(5).trim();
                boolean rhsDefinitelyNonNull = rhsExpr.matches("^-?\\d+(\\.\\d+)?[LfdFD]?$")
                        || "true".equals(rhsExpr) || "false".equals(rhsExpr)
                        || rhsExpr.startsWith("\"")
                        || rhsExpr.startsWith("ArrayList(") || rhsExpr.startsWith("HashMap(")
                        || rhsExpr.startsWith("HashSet(") || rhsExpr.startsWith("intArrayOf(")
                        || rhsExpr.startsWith("mutableListOf(") || rhsExpr.startsWith("mutableMapOf(");
                if (rhsDefinitelyNonNull && !model.varsAssignedNull.contains(vName) && !model.varsCheckedForNull.contains(vName)) {
                    lines[i] = prefix + rhsPart;
                    promotedToNonNull.add(vName);
                    model.nullableVars.remove(vName);
                    model.nonNullVars.add(vName);
                    model.varBaseTypes.put(vName, baseType);
                }
                continue;
            }

            // 4b. `private var titleText: TextView? = null` initialized via `findViewById` and never checked/assigned null -> `private lateinit var titleText: TextView`
            Matcher vfm = nullableViewFieldP.matcher(lines[i]);
            if (vfm.find()) {
                String indent = vfm.group(1);
                String vis = vfm.group(2) != null ? vfm.group(2) + " " : "private ";
                String vName = vfm.group(3);
                String viewType = vfm.group(4);
                if (model.varsInitializedByFindViewById.contains(vName)
                        && !model.varsAssignedNull.contains(vName)
                        && !model.varsCheckedForNull.contains(vName)) {
                    lines[i] = indent + vis + "lateinit var " + vName + ": " + viewType;
                    promotedToNonNull.add(vName);
                    model.nullableVars.remove(vName);
                    model.nonNullVars.add(vName);
                }
            }
        }

        String updated = String.join("\n", lines);

        // Step 2: Remove unnecessary safe calls `v?.` on all known non-null / promoted variables
        Set<String> allNonNull = new LinkedHashSet<>(model.nonNullVars);
        allNonNull.addAll(promotedToNonNull);
        for (String nn : allNonNull) {
            updated = updated.replaceAll("\\b" + Pattern.quote(nn) + "\\?\\.", nn + ".");
            updated = updated.replaceAll("\\b" + Pattern.quote(nn) + "!!", nn);
        }

        // Step 2b: Fix getter return type mismatch (`private var name: String? = null` with `fun getName(): String { return name }`)
        lines = updated.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            Matcher funHeaderM = Pattern.compile(
                    "^(\\s*(?:(?:public|private|protected|internal|override|open)\\s+)*fun\\s+[A-Za-z0-9_]+\\s*\\([^)]*\\)\\s*:\\s*)([A-Za-z0-9_<>]+)(\\s*\\{)$"
            ).matcher(lines[i]);
            if (funHeaderM.find()) {
                String prefix = funHeaderM.group(1);
                String retType = funHeaderM.group(2).trim();
                String suffix = funHeaderM.group(3);
                if (!retType.endsWith("?") && !"Unit".equals(retType)) {
                    int closeBrace = findMatchingCloseBraceLine(lines, i);
                    if (closeBrace > i) {
                        boolean returnsNullable = false;
                        for (int k = i + 1; k < closeBrace; k++) {
                            Matcher retM = Pattern.compile("^return\\s+([A-Za-z_][A-Za-z0-9_]*)$").matcher(lines[k].trim());
                            if (retM.find()) {
                                String retVar = retM.group(1);
                                if ("null".equals(retVar) || model.nullableVars.contains(retVar)) {
                                    returnsNullable = true;
                                    break;
                                }
                            }
                        }
                        if (returnsNullable) {
                            lines[i] = prefix + retType + "?" + suffix;
                        }
                    }
                }
            }
        }

        // Step 3: Detect and auto-fix invalid comparisons such as `Int? >= Int` (or `Int? > Int`, `Int? < Int`, `Int? <= Int`)
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("//")) continue;

            for (String nv : model.nullableVars) {
                String baseType = model.varBaseTypes.getOrDefault(nv, "");
                if (!isNumericKotlinType(baseType)) continue;

                // Check if line has `if (... nv >= expr ...)` without `nv != null`
                Matcher ifRelM = Pattern.compile(
                        "^(\\s*(?:\\}\\s*else\\s+if|if|while)\\s*\\()([^)]*?)\\b(" + Pattern.quote(nv) + "\\s*(?:>=|<=|>|<)\\s*[^)&|]+)(.*\\)\\s*\\{?)$"
                ).matcher(line);
                if (ifRelM.find()) {
                    String beforeVar = ifRelM.group(2);
                    if (!beforeVar.contains(nv + " != null")) {
                        lines[i] = ifRelM.group(1) + beforeVar + nv + " != null && " + ifRelM.group(3) + ifRelM.group(4);
                        line = lines[i];
                    }
                }

                // Check general inline comparison or arithmetic on `Int?` outside `if (nv != null && ...)`
                if (!line.contains(nv + " != null")) {
                    line = line.replaceAll(
                            "(?<!\\?:\\s*0\\)\\s*)\\b" + Pattern.quote(nv) + "\\s*(>=|<=|>|<)\\s*([A-Za-z0-9_.]+)",
                            "(" + nv + " ?: 0) $1 $2"
                    );
                    lines[i] = line;
                }
            }
        }

        return String.join("\n", lines);
    }

    private static boolean isNumericKotlinType(String baseType) {
        return "Int".equals(baseType) || "Long".equals(baseType)
                || "Double".equals(baseType) || "Float".equals(baseType)
                || "Short".equals(baseType) || "Byte".equals(baseType);
    }

    private static String runSingleKotlinRepairPass(String code) {
        String fixed = code;

        // 1. Repair `private var : int counter = 0` or `var : String userName = "Morsalin"`
        fixed = fixed.replaceAll(
                "(?m)^(\\s*(?:private|public|protected|internal)?\\s*(?:val|var))\\s*:\\s*([A-Za-z0-9_<>\\[\\]?]+)\\s+([A-Za-z0-9_]+)",
                "$1 $3: $2"
        );

        // 2. Repair `var languages: private final List<String>` -> `private val languages: MutableList<String>`
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)(?:var|val)\\s+([A-Za-z0-9_]+)\\s*:\\s*(private|public|protected)\\s+final\\s+([A-Za-z0-9_<>\\[\\]?, ]+)",
                "$1$3 val $2: $4"
        );
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)(?:var|val)\\s+([A-Za-z0-9_]+)\\s*:\\s*final\\s+([A-Za-z0-9_<>\\[\\]?, ]+)",
                "$1val $2: $3"
        );
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)(?:var|val)\\s+([A-Za-z0-9_]+)\\s*:\\s*(private|public|protected)\\s+([A-Za-z0-9_<>\\[\\]?, ]+)",
                "$1$3 var $2: $4"
        );

        // 3. Repair Java collection interfaces in Kotlin types if initialized with mutable implementation
        fixed = fixed.replaceAll(":\\s*List<([^>]+)>(\\s*=\\s*ArrayList)", ": MutableList<$1>$2");
        fixed = fixed.replaceAll(":\\s*Map<([^>]+)>(\\s*=\\s*HashMap)", ": MutableMap<$1>$2");
        fixed = fixed.replaceAll(":\\s*Set<([^>]+)>(\\s*=\\s*HashSet)", ": MutableSet<$1>$2");

        // 4. Repair lowercase primitive types in Kotlin type annotations (`: int` -> `: Int`, etc.)
        fixed = fixed.replaceAll(":\\s*int\\b", ": Int");
        fixed = fixed.replaceAll(":\\s*long\\b", ": Long");
        fixed = fixed.replaceAll(":\\s*float\\b", ": Float");
        fixed = fixed.replaceAll(":\\s*double\\b", ": Double");
        fixed = fixed.replaceAll(":\\s*boolean\\b", ": Boolean");
        fixed = fixed.replaceAll(":\\s*byte\\b", ": Byte");
        fixed = fixed.replaceAll(":\\s*short\\b", ": Short");
        fixed = fixed.replaceAll(":\\s*char\\b", ": Char");
        fixed = fixed.replaceAll(":\\s*void\\b", ": Unit");
        fixed = fixed.replaceAll(":\\s*Integer\\b", ": Int");
        fixed = fixed.replaceAll(":\\s*Object\\b", ": Any");

        // 5. Repair `fun ClassName(...): public {` -> `constructor(...) {`
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)fun\\s+[A-Z][A-Za-z0-9_]*\\s*\\(([^)]*)\\)\\s*:\\s*(?:public|private|protected)\\s*\\{",
                "$1constructor($2) {"
        );

        // 6. Repair leftover Java local variable declarations inside functions/lambdas
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)(?:final\\s+)?(?:String|int|long|double|float|boolean|char|byte|short)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.+?);?$",
                "$1val $2 = $3"
        );
        fixed = fixed.replaceAll(
                "(?m)^(\\s*)(?:final\\s+)?Integer\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.+?);?$",
                "$1val $2: Int? = $3"
        );

        // 7. Repair multi-line or single-line `new int[] { ... }`
        fixed = Pattern.compile("\\bnew\\s+int\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("intArrayOf($1)");
        fixed = Pattern.compile("\\bnew\\s+long\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("longArrayOf($1)");
        fixed = Pattern.compile("\\bnew\\s+double\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("doubleArrayOf($1)");
        fixed = Pattern.compile("\\bnew\\s+float\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("floatArrayOf($1)");
        fixed = Pattern.compile("\\bnew\\s+boolean\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("booleanArrayOf($1)");
        fixed = Pattern.compile("\\bnew\\s+[A-Za-z0-9_<>]+\\s*\\[\\s*\\]\\s*\\{([^}]*)\\}", Pattern.DOTALL)
                .matcher(fixed).replaceAll("arrayOf($1)");

        // 8. Repair leftover `@Override` annotation line & modifier order (`override protected fun` -> `override fun`)
        fixed = fixed.replaceAll("(?m)^\\s*@Override\\s*\\n", "");
        fixed = fixed.replaceAll("\\boverride\\s+protected\\s+fun\\b", "override fun");
        fixed = fixed.replaceAll("\\boverride\\s+public\\s+fun\\b", "override fun");

        // 9. Repair leftover Java API & Android API artifacts (Steps 5 & 8)
        fixed = fixed.replaceAll("\\b([A-Z][A-Za-z0-9_]*)\\.this\\b", "this@$1");
        fixed = fixed.replaceAll("\\b([A-Z][A-Za-z0-9_]*)\\.class\\b", "$1::class.java");
        fixed = fixed.replaceAll("\\.entrySet\\(\\s*\\)", ".entries");
        fixed = fixed.replaceAll("\\.keySet\\(\\s*\\)", ".keys");
        fixed = fixed.replaceAll("\\.getKey\\(\\s*\\)", ".key");
        fixed = fixed.replaceAll("\\.getValue\\(\\s*\\)", ".value");
        fixed = fixed.replaceAll("\\.getMessage\\(\\s*\\)", ".message");
        fixed = fixed.replaceAll("\\.size\\(\\s*\\)", ".size");
        fixed = fixed.replaceAll("\\.length\\(\\s*\\)", ".length");
        fixed = fixed.replaceAll("([A-Za-z0-9_]+)\\.setText\\(([^)]+)\\)", "$1.text = $2");
        fixed = fixed.replaceAll("([A-Za-z0-9_]+)\\.setVisibility\\(([^)]+)\\)", "$1.visibility = $2");
        fixed = fixed.replaceAll("([A-Za-z0-9_]+)\\.setEnabled\\(([^)]+)\\)", "$1.isEnabled = $2");

        // 10. Repair leftover `new SomeClass(...)`
        fixed = fixed.replaceAll("\\bnew\\s+([A-Z][A-Za-z0-9_.]+)\\s*<\\s*>\\s*\\(", "$1(");
        fixed = fixed.replaceAll("\\bnew\\s+([A-Z][A-Za-z0-9_<>]*)\\s*\\(", "$1(");

        // 11. Repair leftover `public void foo(` or `private void foo(`
        fixed = fixed.replaceAll("(?m)^(\\s*)public\\s+void\\s+([A-Za-z0-9_]+)\\s*\\(", "$1fun $2(");
        fixed = fixed.replaceAll("(?m)^(\\s*)(private|protected)\\s+void\\s+([A-Za-z0-9_]+)\\s*\\(", "$1$2 fun $3(");

        // 12. Clean up redundant `public ` visibility on Kotlin declarations
        fixed = fixed.replaceAll("(?m)^(\\s*)public\\s+(class|interface|enum|fun|val|var|constructor)\\b", "$1$2");

        return fixed;
    }

    public static RepairAndValidationReport validateAndRepairJava(String generatedJava, QualityMode mode) {
        String current = generatedJava != null ? generatedJava : "";
        List<String> warnings = new ArrayList<>();

        // Repair common leftover Kotlin tokens in Java output
        current = current.replaceAll("\\bthis@([A-Za-z0-9_]+)\\b", "$1.this");
        current = current.replaceAll("\\b([A-Za-z0-9_]+)::class\\.java\\b", "$1.class");
        current = current.replaceAll("\\b([A-Za-z0-9_]+)::class\\b", "$1.class");
        current = current.replaceAll("\\bval\\s+([A-Za-z0-9_]+)\\s*=", "final var $1 =");
        current = current.replaceAll("(?m)^(\\s*)fun\\s+([A-Za-z0-9_]+)\\s*\\(", "$1public void $2(");

        // Convert `listVar[idx]` -> `listVar.get(idx)` and infer element types for declared List variables
        Map<String, String> listElemTypes = new LinkedHashMap<>();
        Matcher listDeclM = Pattern.compile("\\b(?:List|ArrayList)<([^>]+)>\\s+([A-Za-z0-9_]+)\\b").matcher(current);
        while (listDeclM.find()) {
            listElemTypes.put(listDeclM.group(2).trim(), listDeclM.group(1).trim());
        }
        for (Map.Entry<String, String> le : listElemTypes.entrySet()) {
            String lv = le.getKey();
            String elemType = le.getValue();
            current = current.replaceAll("\\b" + Pattern.quote(lv) + "\\[([^\\]]+)\\]", lv + ".get($1)");
            current = current.replaceAll("((?:final\\s+)?)\\bvar\\s+([A-Za-z0-9_]+)\\s*=\\s*" + Pattern.quote(lv) + "\\.get\\(", "$1" + Matcher.quoteReplacement(elemType) + " $2 = " + lv + ".get(");
            current = current.replaceAll("for\\s*\\(\\s*var\\s+([A-Za-z0-9_]+)\\s*:\\s*" + Pattern.quote(lv) + "\\s*\\)", "for (" + Matcher.quoteReplacement(elemType) + " $1 : " + lv + ")");
        }

        // Infer key/value types for declared Map variables
        Matcher mapDeclM = Pattern.compile("\\b(?:Map|HashMap)<\\s*([^,>]+)\\s*,\\s*([^>]+)\\s*>\\s+([A-Za-z0-9_]+)\\b").matcher(current);
        while (mapDeclM.find()) {
            String kType = mapDeclM.group(1).trim();
            String vType = mapDeclM.group(2).trim();
            String mv = mapDeclM.group(3).trim();
            current = current.replaceAll(
                    "for\\s*\\(\\s*var\\s+([A-Za-z0-9_]+)\\s*:\\s*" + Pattern.quote(mv) + "\\.entrySet\\(\\s*\\)\\s*\\)",
                    "for (Map.Entry<" + Matcher.quoteReplacement(kType) + ", " + Matcher.quoteReplacement(vType) + "> $1 : " + mv + ".entrySet())"
            );
            current = current.replaceAll("((?:final\\s+)?)\\bvar\\s+([A-Za-z0-9_]+)\\s*=\\s*entry\\.getKey\\(\\s*\\)", "$1" + Matcher.quoteReplacement(kType) + " $2 = entry.getKey()");
            current = current.replaceAll("((?:final\\s+)?)\\bvar\\s+([A-Za-z0-9_]+)\\s*=\\s*entry\\.getValue\\(\\s*\\)", "$1" + Matcher.quoteReplacement(vType) + " $2 = entry.getValue()");
        }

        // Convert `arrVar.size()` -> `arrVar.length` and infer element types for declared Java arrays
        Matcher arrDeclM = Pattern.compile("\\b(int|long|double|float|boolean|byte|short|char|String|[A-Z][A-Za-z0-9_]*)\\[\\]\\s+([A-Za-z0-9_]+)\\b").matcher(current);
        Map<String, String> arrElemTypes = new LinkedHashMap<>();
        while (arrDeclM.find()) {
            arrElemTypes.put(arrDeclM.group(2).trim(), arrDeclM.group(1).trim());
        }
        for (Map.Entry<String, String> ae : arrElemTypes.entrySet()) {
            String av = ae.getKey();
            String elemType = ae.getValue();
            current = current.replaceAll("\\b" + Pattern.quote(av) + "\\.size\\(\\s*\\)", av + ".length");
            current = current.replaceAll("for\\s*\\(\\s*var\\s+([A-Za-z0-9_]+)\\s*:\\s*" + Pattern.quote(av) + "\\s*\\)", "for (" + Matcher.quoteReplacement(elemType) + " $1 : " + av + ")");
            current = current.replaceAll("((?:final\\s+)?)\\bvar\\s+([A-Za-z0-9_]+)\\s*=\\s*" + Pattern.quote(av) + "\\[", "$1" + Matcher.quoteReplacement(elemType) + " $2 = " + av + "[");
        }

        // Convert `obj.prop` -> `obj.getProp()` for properties with generated getters in the same file
        Set<String> getterProps = new LinkedHashSet<>();
        Matcher getterM = Pattern.compile("\\bpublic\\s+[A-Za-z0-9_<>\\[\\]]+\\s+get([A-Z][A-Za-z0-9_]*)\\s*\\(\\s*\\)").matcher(current);
        while (getterM.find()) {
            String cap = getterM.group(1);
            String prop = Character.toLowerCase(cap.charAt(0)) + cap.substring(1);
            getterProps.add(prop);
        }
        for (String prop : getterProps) {
            String cap = Character.toUpperCase(prop.charAt(0)) + prop.substring(1);
            current = current.replaceAll("\\b(?!this\\b)([a-z][A-Za-z0-9_]*)\\." + Pattern.quote(prop) + "\\b(?!\\s*[=(])", "$1.get" + cap + "()");
        }

        boolean critical = false;
        StringBuilder criticalSb = new StringBuilder();
        String[] lines = current.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            int lineNo = i + 1;
            String trimmed = lines[i].trim();
            if (trimmed.isEmpty() || trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) {
                continue;
            }
            String codeOnly = trimmed.replaceAll("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"", "\"\"");
            if (codeOnly.contains("?.") || codeOnly.contains("?:")) {
                String msg = "Line " + lineNo + ": Kotlin null-safe operator detected in Java output.";
                warnings.add(msg);
            }
            if (codeOnly.matches(".*\\bfun\\s+[A-Za-z0-9_]+\\s*\\(.*") || codeOnly.startsWith("companion object")) {
                critical = true;
                String msg = "Line " + lineNo + ": Unconverted Kotlin declaration in Java output.";
                warnings.add(msg);
                criticalSb.append(msg).append("\n");
            }
        }

        return new RepairAndValidationReport(current, warnings, critical, criticalSb.toString().trim());
    }
}
