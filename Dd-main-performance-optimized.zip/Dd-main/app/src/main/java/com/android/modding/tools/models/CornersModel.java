package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class CornersModel implements Serializable {
    private int topLeftDp = 0;
    private int topRightDp = 0;
    private int bottomLeftDp = 0;
    private int bottomRightDp = 0;
    private boolean linked = false;

    public CornersModel() {}

    public CornersModel(int topLeftDp, int topRightDp, int bottomLeftDp, int bottomRightDp) {
        this.topLeftDp = topLeftDp;
        this.topRightDp = topRightDp;
        this.bottomLeftDp = bottomLeftDp;
        this.bottomRightDp = bottomRightDp;
    }

    public void setCorners(int tl, int tr, int bl, int br, boolean linked) {
        this.linked = linked;
        this.topLeftDp = Math.max(0, tl);
        this.topRightDp = Math.max(0, tr);
        this.bottomLeftDp = Math.max(0, bl);
        this.bottomRightDp = Math.max(0, br);
    }

    public int getTopLeftDp() {
        return topLeftDp;
    }

    public void setTopLeftDp(int topLeftDp) {
        this.topLeftDp = Math.max(0, topLeftDp);
        if (linked) {
            this.topRightDp = this.topLeftDp;
            this.bottomLeftDp = this.topLeftDp;
            this.bottomRightDp = this.topLeftDp;
        }
    }

    public int getTopRightDp() {
        return topRightDp;
    }

    public void setTopRightDp(int topRightDp) {
        this.topRightDp = Math.max(0, topRightDp);
        if (linked) {
            this.topLeftDp = this.topRightDp;
            this.bottomLeftDp = this.topRightDp;
            this.bottomRightDp = this.topRightDp;
        }
    }

    public int getBottomLeftDp() {
        return bottomLeftDp;
    }

    public void setBottomLeftDp(int bottomLeftDp) {
        this.bottomLeftDp = Math.max(0, bottomLeftDp);
        if (linked) {
            this.topLeftDp = this.bottomLeftDp;
            this.topRightDp = this.bottomLeftDp;
            this.bottomRightDp = this.bottomLeftDp;
        }
    }

    public int getBottomRightDp() {
        return bottomRightDp;
    }

    public void setBottomRightDp(int bottomRightDp) {
        this.bottomRightDp = Math.max(0, bottomRightDp);
        if (linked) {
            this.topLeftDp = this.bottomRightDp;
            this.topRightDp = this.bottomRightDp;
            this.bottomLeftDp = this.bottomRightDp;
        }
    }

    public boolean isLinked() {
        return linked;
    }

    public void setLinked(boolean linked) {
        this.linked = linked;
    }

    public boolean areAllCornersEqual() {
        return topLeftDp == topRightDp && topRightDp == bottomLeftDp && bottomLeftDp == bottomRightDp;
    }

    public CornersModel copy() {
        CornersModel copy = new CornersModel(topLeftDp, topRightDp, bottomLeftDp, bottomRightDp);
        copy.setLinked(linked);
        return copy;
    }
}
