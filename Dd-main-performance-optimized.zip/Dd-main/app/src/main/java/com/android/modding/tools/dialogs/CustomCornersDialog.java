package com.android.modding.tools.dialogs;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class CustomCornersDialog extends Dialog {

    public interface OnCornersAppliedListener {
        void onCornersApplied(int tl, int tr, int bl, int br, boolean linked);
    }

    private final CornersModel initialCorners;
    private final OnCornersAppliedListener listener;
    private OnCornersAppliedListener liveListener;

    private SeekBar seekTl, seekTr, seekBl, seekBr;
    private TextView tvTlVal, tvTrVal, tvBlVal, tvBrVal;

    public CustomCornersDialog(Context context, CornersModel initialCorners, OnCornersAppliedListener listener) {
        super(context, R.style.Theme_MyApplication_Dialog);
        this.initialCorners = initialCorners != null ? initialCorners.copy() : new CornersModel();
        this.listener = listener;
    }

    public CustomCornersDialog setLiveListener(OnCornersAppliedListener liveListener) {
        this.liveListener = liveListener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_custom_corners);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setLayout((int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.90),
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        seekTl = findViewById(R.id.seek_corner_tl);
        seekTr = findViewById(R.id.seek_corner_tr);
        seekBl = findViewById(R.id.seek_corner_bl);
        seekBr = findViewById(R.id.seek_corner_br);

        tvTlVal = findViewById(R.id.tv_corner_tl_val);
        tvTrVal = findViewById(R.id.tv_corner_tr_val);
        tvBlVal = findViewById(R.id.tv_corner_bl_val);
        tvBrVal = findViewById(R.id.tv_corner_br_val);

        Button btnTlMinus = findViewById(R.id.btn_corner_tl_minus);
        Button btnTlPlus = findViewById(R.id.btn_corner_tl_plus);
        Button btnTrMinus = findViewById(R.id.btn_corner_tr_minus);
        Button btnTrPlus = findViewById(R.id.btn_corner_tr_plus);
        Button btnBlMinus = findViewById(R.id.btn_corner_bl_minus);
        Button btnBlPlus = findViewById(R.id.btn_corner_bl_plus);
        Button btnBrMinus = findViewById(R.id.btn_corner_br_minus);
        Button btnBrPlus = findViewById(R.id.btn_corner_br_plus);

        Button btnApply = findViewById(R.id.btn_corners_apply);

        seekTl.setProgress(initialCorners.getTopLeftDp());
        seekTr.setProgress(initialCorners.getTopRightDp());
        seekBl.setProgress(initialCorners.getBottomLeftDp());
        seekBr.setProgress(initialCorners.getBottomRightDp());
        updateLabels();

        setupCornerSlider(seekTl, btnTlMinus, btnTlPlus);
        setupCornerSlider(seekTr, btnTrMinus, btnTrPlus);
        setupCornerSlider(seekBl, btnBlMinus, btnBlPlus);
        setupCornerSlider(seekBr, btnBrMinus, btnBrPlus);

        btnApply.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCornersApplied(
                        seekTl.getProgress(),
                        seekTr.getProgress(),
                        seekBl.getProgress(),
                        seekBr.getProgress(),
                        false
                );
            }
            dismiss();
        });
    }

    private void setupCornerSlider(SeekBar seekBar, Button minus, Button plus) {
        minus.setOnClickListener(v -> {
            int newProgress = Math.max(0, seekBar.getProgress() - 1);
            seekBar.setProgress(newProgress);
            updateLabels();
            notifyLiveChange();
        });

        plus.setOnClickListener(v -> {
            int newProgress = Math.min(100, seekBar.getProgress() + 1);
            seekBar.setProgress(newProgress);
            updateLabels();
            notifyLiveChange();
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                updateLabels();
                notifyLiveChange();
            }
            @Override
            public void onStartTrackingTouch(SeekBar sb) {}
            @Override
            public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    private void updateLabels() {
        if (tvTlVal != null) tvTlVal.setText(seekTl.getProgress() + "dp");
        if (tvTrVal != null) tvTrVal.setText(seekTr.getProgress() + "dp");
        if (tvBlVal != null) tvBlVal.setText(seekBl.getProgress() + "dp");
        if (tvBrVal != null) tvBrVal.setText(seekBr.getProgress() + "dp");
    }

    private void notifyLiveChange() {
        if (liveListener != null) {
            liveListener.onCornersApplied(
                    seekTl.getProgress(),
                    seekTr.getProgress(),
                    seekBl.getProgress(),
                    seekBr.getProgress(),
                    false
            );
        }
    }
}
