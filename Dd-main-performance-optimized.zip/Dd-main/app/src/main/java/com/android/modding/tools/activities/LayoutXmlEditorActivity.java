package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Advance XML Creator Activity.
 * Supports a 3-layer architecture for each state (Normal, Checked, Pressed):
 * - Layer 1: Main Button Face (drawn over bottom base, offset at bottom to reveal Layer 2)
 * - Layer 2: Bottom Extruded Base (drawn underneath Layer 1, peeking out at bottom edge)
 * - Layer 3: Top Inner Overlay (drawn on top of Layer 1, smaller on all four sides)
 *
 * All states start blank & unconfigured with no pre-generated code or shapes,
 * exactly like the Normal, Gradient, and 3D XML creators.
 * Each layer defaults to 6dp rounded corners and is fully customizable.
 */
public class LayoutXmlEditorActivity extends AppCompatActivity {

    public static final String XML_INITIAL_PLACEHOLDER =
            "<!-- XML will be generated here when you select colors or configure layers -->";

    private final Map<String, StateModel> stateMap = new HashMap<>();
    private String currentState = StateModel.STATE_NORMAL;
    private int activeLayerIndex = 0; // 0 = Layer 1 (Main Face), 1 = Layer 2 (Bottom Base), 2 = Layer 3 (Top Overlay)

    // Sticky Preview Views
    private FrameLayout boxFrameNormal, boxFrameChecked, boxFramePressed;
    private FrameLayout cardNormal, cardChecked, cardPressed;
    private TextView tvPreviewNormalLabel, tvPreviewCheckedLabel, tvPreviewPressedLabel;

    // State Tabs
    private Button tabNormal, tabChecked, tabPressed;

    // 3 Layer Buttons
    private Button btnLayer1, btnLayer2, btnLayer3;
    private TextView tvActiveLayerTitle;

    // Color UI Controls
    private TextView tvStartColorHex, tvCenterColorHex, tvEndColorHex, tvStrokeColorHex;
    private LinearLayout layoutCenterColor;
    private Button btnPickStartColor, btnPickCenterColor, btnPickEndColor, btnPickStrokeColor;
    private CheckBox cbThreeColor;

    // Gradient Type Controls
    private Button btnTypeLinear, btnTypeRadial, btnTypeSweep;
    private LinearLayout layoutLinearOptions, layoutRadialOptions, layoutRadiusRow;
    private TextView tvAngleVal, tvRadiusVal, tvCenterXVal, tvCenterYVal;
    private SeekBar seekAngle, seekRadius, seekCenterX, seekCenterY;

    // Code & Scrolling
    private TextView etGeneratedXml;
    private ScrollView scrollCodeVertical;
    private HorizontalScrollView scrollCodeHorizontal;
    private HistoryManager historyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_editor);

        GlobalTouchParticleManager.attach(this);
        historyManager = new HistoryManager(this);

        initBlankStates();
        initViews();

        String importedXml = getIntent().getStringExtra("EXTRA_IMPORTED_XML");
        if (importedXml != null && !importedXml.trim().isEmpty()) {
            loadImportedXml(importedXml.trim());
        } else {
            updateLayerButtons();
            updateUiForActiveLayer();
            updateStateFrameSelection();
            updatePreviewAndXml();
        }
    }

    /**
     * Initializes all states completely blank (no pre-filled colors, no auto-generated XML).
     * Exactly like Normal, Gradient, and 3D editors, XML is only generated once the user configures layers!
     *
     * Layer drawing order inside StateModel (for Android's <layer-list>):
     * - Index 0: Layer 2 (Bottom Base) - drawn first underneath Layer 1, insets=(0, 0, 0, 0)
     * - Index 1: Layer 1 (Main Face) - drawn second over Layer 2, with 6dp bottom offset insets=(0, 0, 0, 6)
     * - Index 2: Layer 3 (Top Overlay) - drawn third over Layer 1, smaller on all 4 sides insets=(5, 5, 5, 11)
     * All layers default to 6dp rounded corners.
     */
    private void initBlankStates() {
        stateMap.clear();

        for (String stateKey : new String[]{StateModel.STATE_NORMAL, StateModel.STATE_CHECKED, StateModel.STATE_PRESSED}) {
            StateModel sm = new StateModel(stateKey);
            sm.setActive(false);
            sm.getLayers().clear();

            // Layer 2: Bottom Base (index 0 in draw order)
            LayerModel l2 = new LayerModel("Layer 2 (Bottom Base)");
            l2.setGradient(true);
            l2.getGradient().setType(GradientModel.TYPE_LINEAR);
            l2.getGradient().setAngle(0);
            l2.getGradient().setStartColor("#00000000");
            l2.getGradient().setCenterColor("#00000000");
            l2.getGradient().setEndColor("#00000000");
            l2.getGradient().setUseCenterColor(false);
            l2.getCorners().setCorners(8, 8, 8, 8, true);
            l2.setInsets(new InsetsModel(0, 0, 0, 0));
            l2.getStroke().setColor("#00000000");
            l2.getStroke().setWidthDp(0);

            // Layer 1: Main Face (index 1 in draw order)
            LayerModel l1 = new LayerModel("Layer 1 (Main Face)");
            l1.setGradient(true);
            l1.getGradient().setType(GradientModel.TYPE_LINEAR);
            l1.getGradient().setAngle(90);
            l1.getGradient().setStartColor("#00000000");
            l1.getGradient().setCenterColor("#00000000");
            l1.getGradient().setEndColor("#00000000");
            l1.getGradient().setUseCenterColor(false);
            l1.getCorners().setCorners(8, 8, 8, 8, true);
            l1.setInsets(new InsetsModel(0, 0, 0, 5)); // 5dp bottom offset exposes Layer 2 (reduced by 1dp)
            l1.getStroke().setColor("#00000000");
            l1.getStroke().setWidthDp(0);

            // Layer 3: Top Overlay (index 2 in draw order)
            LayerModel l3 = new LayerModel("Layer 3 (Top Overlay)");
            l3.setGradient(true);
            l3.getGradient().setType(GradientModel.TYPE_LINEAR);
            l3.getGradient().setAngle(90);
            l3.getGradient().setStartColor("#00000000");
            l3.getGradient().setCenterColor("#00000000");
            l3.getGradient().setEndColor("#00000000");
            l3.getGradient().setUseCenterColor(false);
            l3.getCorners().setCorners(8, 8, 8, 8, true);
            l3.setInsets(new InsetsModel(8, 8, 8, 13)); // smaller on all 4 sides inside Layer 1
            l3.getStroke().setColor("#00000000");
            l3.getStroke().setWidthDp(0);

            sm.getLayers().add(l2);
            sm.getLayers().add(l1);
            sm.getLayers().add(l3);
            stateMap.put(stateKey, sm);
        }
    }

    private void loadImportedXml(String xml) {
        XmlParser.ParseResult result = XmlParser.parseXml(xml);
        if (!result.success) return;

        if (result.selectorStates != null && !result.selectorStates.isEmpty()) {
            stateMap.clear();
            for (Map.Entry<String, StateModel> entry : result.selectorStates.entrySet()) {
                StateModel sm = entry.getValue();
                ensureThreeLayers(sm);
                stateMap.put(entry.getKey(), sm);
            }
            if (!stateMap.containsKey(StateModel.STATE_NORMAL)) {
                StateModel normal = new StateModel(StateModel.STATE_NORMAL);
                normal.setActive(true);
                ensureThreeLayers(normal);
                stateMap.put(StateModel.STATE_NORMAL, normal);
            }
        } else if (result.layerList != null && !result.layerList.isEmpty()) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            for (int i = 0; i < Math.min(3, result.layerList.size()); i++) {
                normal.getLayers().add(result.layerList.get(i));
            }
            ensureThreeLayers(normal);
            stateMap.put(StateModel.STATE_NORMAL, normal);
        }

        currentState = StateModel.STATE_NORMAL;
        activeLayerIndex = 0;
        updateLayerButtons();
        updateStateFrameSelection();
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    private void ensureThreeLayers(StateModel sm) {
        if (sm == null) return;
        List<LayerModel> layers = sm.getLayers();
        while (layers.size() < 3) {
            LayerModel extra = new LayerModel("Layer " + (layers.size() + 1));
            extra.getCorners().setCorners(8, 8, 8, 8, true);
            extra.setSolidColor("#00000000");
            extra.getStroke().setColor("#00000000");
            extra.getStroke().setWidthDp(0);
            layers.add(extra);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });
        findViewById(R.id.btn_reset).setOnClickListener(v -> showResetDialog());

        boxFrameNormal = findViewById(R.id.box_frame_normal);
        boxFrameChecked = findViewById(R.id.box_frame_checked);
        boxFramePressed = findViewById(R.id.box_frame_pressed);

        cardNormal = findViewById(R.id.card_preview_normal);
        cardChecked = findViewById(R.id.card_preview_checked);
        cardPressed = findViewById(R.id.card_preview_pressed);

        tvPreviewNormalLabel = findViewById(R.id.tv_preview_normal_label);
        tvPreviewCheckedLabel = findViewById(R.id.tv_preview_checked_label);
        tvPreviewPressedLabel = findViewById(R.id.tv_preview_pressed_label);

        tabNormal = findViewById(R.id.tab_edit_normal);
        tabChecked = findViewById(R.id.tab_edit_checked);
        tabPressed = findViewById(R.id.tab_edit_pressed);

        btnLayer1 = findViewById(R.id.btn_layer_1);
        btnLayer2 = findViewById(R.id.btn_layer_2);
        btnLayer3 = findViewById(R.id.btn_layer_3);

        btnLayer1.setOnClickListener(v -> selectLayer(0));
        btnLayer2.setOnClickListener(v -> selectLayer(1));
        btnLayer3.setOnClickListener(v -> selectLayer(2));

        tvActiveLayerTitle = findViewById(R.id.tv_active_layer_title);

        tvStartColorHex = findViewById(R.id.tv_start_color_hex);
        tvCenterColorHex = findViewById(R.id.tv_center_color_hex);
        tvEndColorHex = findViewById(R.id.tv_end_color_hex);
        tvStrokeColorHex = findViewById(R.id.tv_stroke_color_hex);

        layoutCenterColor = findViewById(R.id.layout_center_color);
        btnPickStartColor = findViewById(R.id.btn_pick_start_color);
        btnPickCenterColor = findViewById(R.id.btn_pick_center_color);
        btnPickEndColor = findViewById(R.id.btn_pick_end_color);
        btnPickStrokeColor = findViewById(R.id.btn_pick_stroke_color);
        cbThreeColor = findViewById(R.id.cb_three_color_gradient);

        btnTypeLinear = findViewById(R.id.btn_type_linear);
        btnTypeRadial = findViewById(R.id.btn_type_radial);
        btnTypeSweep = findViewById(R.id.btn_type_sweep);

        layoutLinearOptions = findViewById(R.id.layout_linear_options);
        layoutRadialOptions = findViewById(R.id.layout_radial_options);
        layoutRadiusRow = findViewById(R.id.layout_radius_row);

        tvAngleVal = findViewById(R.id.tv_angle_val);
        tvRadiusVal = findViewById(R.id.tv_radius_val);
        tvCenterXVal = findViewById(R.id.tv_center_x_val);
        tvCenterYVal = findViewById(R.id.tv_center_y_val);

        seekAngle = findViewById(R.id.seek_angle);
        seekRadius = findViewById(R.id.seek_radius);
        seekCenterX = findViewById(R.id.seek_center_x);
        seekCenterY = findViewById(R.id.seek_center_y);

        scrollCodeVertical = findViewById(R.id.scroll_code_vertical);
        scrollCodeHorizontal = findViewById(R.id.scroll_code_horizontal);
        etGeneratedXml = findViewById(R.id.et_generated_xml);

        // Smooth code box scroll
        XmlFormatter.enableCodeBoxScroll(etGeneratedXml, scrollCodeVertical, scrollCodeHorizontal);

        // State Tab and Preview Card Clicks
        tabNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        tabChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        tabPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        cardNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        cardChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        cardPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        // 3-Color Checkbox
        cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ensureCurrentStateActive();
            getActiveLayer().getGradient().setUseCenterColor(isChecked);
            updateUiForActiveLayer();
            updatePreviewAndXml();
        });

        // Color Picker Listeners
        btnPickStartColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getStartColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = (activeLayerIndex == 1) ? "#FFB703" : ((activeLayerIndex == 2) ? "#FFFFFF" : "#1E1B4B");
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickCenterColor.setOnClickListener(v -> {
            if (!cbThreeColor.isChecked()) return;
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getCenterColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = (activeLayerIndex == 1) ? "#E63946" : "#2A1B6D";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setCenterColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setCenterColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickEndColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getEndColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = (activeLayerIndex == 1) ? "#06D6A0" : ((activeLayerIndex == 2) ? "#0AFFFFFF" : "#312E81");
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickStrokeColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            StrokeModel s = layer.getStroke();
            String initial = s.getColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = (activeLayerIndex == 2) ? "#FFFFFF" : "#00E5FF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        s.setColor(color);
                        if (s.getWidthDp() == 0) s.setWidthDp(1);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        s.setColor(color);
                        if (s.getWidthDp() == 0) s.setWidthDp(1);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        // Gradient Type Buttons
        btnTypeLinear.setOnClickListener(v -> setGradientType(GradientModel.TYPE_LINEAR));
        btnTypeRadial.setOnClickListener(v -> setGradientType(GradientModel.TYPE_RADIAL));
        btnTypeSweep.setOnClickListener(v -> setGradientType(GradientModel.TYPE_SWEEP));

        // Stepper buttons for angle
        findViewById(R.id.btn_angle_minus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int newAngle = Math.max(0, seekAngle.getProgress() - 15);
            seekAngle.setProgress(newAngle);
            getActiveLayer().getGradient().setAngle(newAngle);
            tvAngleVal.setText(newAngle + "°");
            updatePreviewAndXml();
        });
        findViewById(R.id.btn_angle_plus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int newAngle = Math.min(360, seekAngle.getProgress() + 15);
            seekAngle.setProgress(newAngle);
            getActiveLayer().getGradient().setAngle(newAngle);
            tvAngleVal.setText(newAngle + "°");
            updatePreviewAndXml();
        });

        // Stepper buttons for radius
        View btnRadiusMinus = findViewById(R.id.btn_radius_minus);
        if (btnRadiusMinus != null) {
            btnRadiusMinus.setOnClickListener(v -> {
                ensureCurrentStateActive();
                int newRadius = Math.max(10, seekRadius.getProgress() - 10);
                seekRadius.setProgress(newRadius);
                getActiveLayer().getGradient().setGradientRadiusDp(newRadius);
                tvRadiusVal.setText(newRadius + "dp");
                updatePreviewAndXml();
            });
        }
        View btnRadiusPlus = findViewById(R.id.btn_radius_plus);
        if (btnRadiusPlus != null) {
            btnRadiusPlus.setOnClickListener(v -> {
                ensureCurrentStateActive();
                int newRadius = Math.min(400, seekRadius.getProgress() + 10);
                seekRadius.setProgress(newRadius);
                getActiveLayer().getGradient().setGradientRadiusDp(newRadius);
                tvRadiusVal.setText(newRadius + "dp");
                updatePreviewAndXml();
            });
        }

        // Sliders with live preview
        seekAngle.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getActiveLayer().getGradient().setAngle(progress);
                    tvAngleVal.setText(progress + "°");
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getActiveLayer().getGradient().setGradientRadiusDp(progress);
                    tvRadiusVal.setText(progress + "dp");
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekCenterX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getActiveLayer().getGradient().setCenterX(val);
                    tvCenterXVal.setText(String.format(Locale.US, "%.2f", val));
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekCenterY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getActiveLayer().getGradient().setCenterY(val);
                    tvCenterYVal.setText(String.format(Locale.US, "%.2f", val));
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Custom Geometry Dialogs
        findViewById(R.id.btn_set_custom_insets).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomInsetsDialog dialog = new CustomInsetsDialog(this, layer.getInsets(),
                    (left, top, right, bottom, linked) -> {
                        ensureCurrentStateActive();
                        layer.getInsets().setInsets(left, top, right, bottom, linked);
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((left, top, right, bottom, linked) -> {
                ensureCurrentStateActive();
                layer.getInsets().setInsets(left, top, right, bottom, linked);
                updatePreviewOnly();
            });
            dialog.show();
        });

        findViewById(R.id.btn_set_custom_corners).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomCornersDialog dialog = new CustomCornersDialog(this, layer.getCorners(),
                    (tl, tr, bl, br, linked) -> {
                        ensureCurrentStateActive();
                        layer.getCorners().setCorners(tl, tr, bl, br, linked);
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((tl, tr, bl, br, linked) -> {
                ensureCurrentStateActive();
                layer.getCorners().setCorners(tl, tr, bl, br, linked);
                updatePreviewOnly();
            });
            dialog.show();
        });

        findViewById(R.id.btn_set_custom_stroke).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomStrokeDialog dialog = new CustomStrokeDialog(this, layer.getStroke(),
                    (widthDp, dashWidthDp, dashGapDp) -> {
                        ensureCurrentStateActive();
                        layer.getStroke().setWidthDp(widthDp);
                        layer.getStroke().setDashWidthDp(dashWidthDp);
                        layer.getStroke().setDashGapDp(dashGapDp);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((widthDp, dashWidthDp, dashGapDp) -> {
                ensureCurrentStateActive();
                layer.getStroke().setWidthDp(widthDp);
                layer.getStroke().setDashWidthDp(dashWidthDp);
                layer.getStroke().setDashGapDp(dashGapDp);
                updatePreviewOnly();
            });
            dialog.show();
        });

        // Bottom Action Buttons (Matching 3D, Gradient, and Normal Editors)
        findViewById(R.id.btn_copy_code).setOnClickListener(v -> copyXmlToClipboard());
        findViewById(R.id.btn_save_history).setOnClickListener(v -> saveToHistory());
        findViewById(R.id.btn_download_xml).setOnClickListener(v -> downloadXmlFile());
        findViewById(R.id.btn_share_export).setOnClickListener(v -> shareXml());
    }

    private void selectLayer(int index) {
        activeLayerIndex = index;
        updateLayerButtons();
        updateUiForActiveLayer();
    }

    private void updateLayerButtons() {
        if (btnLayer1 != null) btnLayer1.setSelected(activeLayerIndex == 0);
        if (btnLayer2 != null) btnLayer2.setSelected(activeLayerIndex == 1);
        if (btnLayer3 != null) btnLayer3.setSelected(activeLayerIndex == 2);
    }

    private void switchState(String stateKey) {
        currentState = stateKey;
        activeLayerIndex = 0;
        updateStateFrameSelection();
        updateLayerButtons();
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    private void updateStateFrameSelection() {
        boolean isNorm = StateModel.STATE_NORMAL.equals(currentState);
        boolean isChk = StateModel.STATE_CHECKED.equals(currentState);
        boolean isPrs = StateModel.STATE_PRESSED.equals(currentState);

        boxFrameNormal.setBackgroundResource(isNorm ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFrameChecked.setBackgroundResource(isChk ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFramePressed.setBackgroundResource(isPrs ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);

        tabNormal.setSelected(isNorm);
        tabChecked.setSelected(isChk);
        tabPressed.setSelected(isPrs);
    }

    private void setGradientType(String type) {
        ensureCurrentStateActive();
        getActiveLayer().getGradient().setType(type);
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    private void ensureCurrentStateActive() {
        StateModel state = getCurrentStateModel();
        if (!state.isActive()) {
            state.setActive(true);
        }
    }

    private StateModel getCurrentStateModel() {
        StateModel state = stateMap.get(currentState);
        if (state == null) {
            state = new StateModel(currentState);
            state.setActive(false);
            ensureThreeLayers(state);
            stateMap.put(currentState, state);
        }
        return state;
    }

    /**
     * Maps user UI layer selection to the corresponding LayerModel:
     * - activeLayerIndex == 0: Layer 1 (Main Face) -> stored at index 1 in StateModel
     * - activeLayerIndex == 1: Layer 2 (Bottom Base) -> stored at index 0 in StateModel
     * - activeLayerIndex == 2: Layer 3 (Top Overlay) -> stored at index 2 in StateModel
     */
    private LayerModel getActiveLayer() {
        StateModel state = getCurrentStateModel();
        ensureThreeLayers(state);
        List<LayerModel> layers = state.getLayers();

        if (activeLayerIndex == 0) {
            // Layer 1 (Main Face)
            return layers.size() > 1 ? layers.get(1) : layers.get(0);
        } else if (activeLayerIndex == 1) {
            // Layer 2 (Bottom Base)
            return layers.get(0);
        } else {
            // Layer 3 (Top Overlay)
            return layers.size() > 2 ? layers.get(2) : layers.get(layers.size() - 1);
        }
    }

    private void updateUiForActiveLayer() {
        LayerModel layer = getActiveLayer();
        GradientModel g = layer.getGradient();

        tvActiveLayerTitle.setText(currentState.toUpperCase() + " • " + layer.getName());

        boolean hasStart = g.getStartColor() != null && !g.getStartColor().isEmpty() && !g.getStartColor().equals("#00000000");
        boolean hasCenter = g.getCenterColor() != null && !g.getCenterColor().isEmpty() && !g.getCenterColor().equals("#00000000");
        boolean hasEnd = g.getEndColor() != null && !g.getEndColor().isEmpty() && !g.getEndColor().equals("#00000000");

        applyColorBadge(tvStartColorHex, hasStart ? g.getStartColor() : null, "None");
        applyColorBadge(tvEndColorHex, hasEnd ? g.getEndColor() : null, "None");

        StrokeModel stroke = layer.getStroke();
        boolean hasStroke = stroke != null && stroke.getWidthDp() > 0 && stroke.getColor() != null && !stroke.getColor().equals("#00000000");
        if (hasStroke) {
            applyColorBadge(tvStrokeColorHex, stroke.getColor(), "None (0dp)");
            tvStrokeColorHex.setText(stroke.getColor() + " (" + stroke.getWidthDp() + "dp)");
        } else {
            tvStrokeColorHex.setText("None (0dp)");
            tvStrokeColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvStrokeColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        boolean is3Color = g.isUseCenterColor();
        cbThreeColor.setOnCheckedChangeListener(null);
        cbThreeColor.setChecked(is3Color);
        cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ensureCurrentStateActive();
            getActiveLayer().getGradient().setUseCenterColor(isChecked);
            updateUiForActiveLayer();
            updatePreviewAndXml();
        });

        if (is3Color) {
            layoutCenterColor.setAlpha(1.0f);
            btnPickCenterColor.setEnabled(true);
            btnPickCenterColor.setText(R.string.action_pick_color);
            applyColorBadge(tvCenterColorHex, hasCenter ? g.getCenterColor() : null, "None");
        } else {
            layoutCenterColor.setAlpha(0.35f);
            btnPickCenterColor.setEnabled(false);
            btnPickCenterColor.setText("DISABLED");
            tvCenterColorHex.setText("Disabled");
            tvCenterColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvCenterColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        btnTypeLinear.setSelected(GradientModel.TYPE_LINEAR.equals(g.getType()));
        btnTypeRadial.setSelected(GradientModel.TYPE_RADIAL.equals(g.getType()));
        btnTypeSweep.setSelected(GradientModel.TYPE_SWEEP.equals(g.getType()));

        if (GradientModel.TYPE_LINEAR.equals(g.getType())) {
            layoutLinearOptions.setVisibility(View.VISIBLE);
            layoutRadialOptions.setVisibility(View.GONE);
            seekAngle.setProgress(g.getAngle());
            tvAngleVal.setText(g.getAngle() + "°");
        } else if (GradientModel.TYPE_RADIAL.equals(g.getType())) {
            layoutLinearOptions.setVisibility(View.GONE);
            layoutRadialOptions.setVisibility(View.VISIBLE);
            layoutRadiusRow.setVisibility(View.VISIBLE);
            seekRadius.setProgress(g.getGradientRadiusDp());
            tvRadiusVal.setText(g.getGradientRadiusDp() + "dp");
            seekCenterX.setProgress((int) (g.getCenterX() * 100));
            seekCenterY.setProgress((int) (g.getCenterY() * 100));
            tvCenterXVal.setText(String.format(Locale.US, "%.2f", g.getCenterX()));
            tvCenterYVal.setText(String.format(Locale.US, "%.2f", g.getCenterY()));
        } else {
            layoutLinearOptions.setVisibility(View.GONE);
            layoutRadialOptions.setVisibility(View.VISIBLE);
            layoutRadiusRow.setVisibility(View.GONE);
            seekCenterX.setProgress((int) (g.getCenterX() * 100));
            seekCenterY.setProgress((int) (g.getCenterY() * 100));
            tvCenterXVal.setText(String.format(Locale.US, "%.2f", g.getCenterX()));
            tvCenterYVal.setText(String.format(Locale.US, "%.2f", g.getCenterY()));
        }
    }

    private void applyColorBadge(TextView tv, String hexColor, String defaultLabel) {
        tv.setBackgroundResource(R.drawable.morsalin_code_bg);
        if (hexColor == null || hexColor.isEmpty() || hexColor.equals("#00000000")) {
            tv.setText(defaultLabel);
            tv.setTextColor(getColor(R.color.morsalin_text_muted));
        } else {
            tv.setText(hexColor);
            tv.setTextColor(getColor(R.color.morsalin_cyan));
        }
    }

    private void updatePreviewOnly() {
        StateModel cur = getCurrentStateModel();
        if (cur.isActive()) {
            if (StateModel.STATE_NORMAL.equals(currentState)) {
                cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewNormalLabel.setVisibility(View.GONE);
            } else if (StateModel.STATE_CHECKED.equals(currentState)) {
                cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewCheckedLabel.setVisibility(View.GONE);
            } else if (StateModel.STATE_PRESSED.equals(currentState)) {
                cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewPressedLabel.setVisibility(View.GONE);
            }
        }
    }

    private void updatePreviewAndXml() {
        boolean hasAnyActive = false;
        for (StateModel sm : stateMap.values()) {
            if (sm.isActive()) {
                hasAnyActive = true;
                break;
            }
        }

        // Normal State Preview
        StateModel normal = stateMap.get(StateModel.STATE_NORMAL);
        if (normal != null && normal.isActive()) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, normal.getLayers()));
            tvPreviewNormalLabel.setVisibility(View.GONE);
        } else {
            cardNormal.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewNormalLabel.setText("Normal\n(Not Set)");
            tvPreviewNormalLabel.setVisibility(View.VISIBLE);
        }

        // Checked State Preview
        StateModel checked = stateMap.get(StateModel.STATE_CHECKED);
        if (checked != null && checked.isActive()) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, checked.getLayers()));
            tvPreviewCheckedLabel.setVisibility(View.GONE);
        } else {
            cardChecked.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewCheckedLabel.setText("Checked\n(Not Set)");
            tvPreviewCheckedLabel.setVisibility(View.VISIBLE);
        }

        // Pressed State Preview
        StateModel pressed = stateMap.get(StateModel.STATE_PRESSED);
        if (pressed != null && pressed.isActive()) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, pressed.getLayers()));
            tvPreviewPressedLabel.setVisibility(View.GONE);
        } else {
            cardPressed.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewPressedLabel.setText("Pressed\n(Not Set)");
            tvPreviewPressedLabel.setVisibility(View.VISIBLE);
        }

        // Generate Selector XML
        if (!hasAnyActive) {
            etGeneratedXml.setText(XML_INITIAL_PLACEHOLDER);
        } else {
            String xml = XmlGenerator.generateSelectorXml(stateMap);
            xml = XmlFormatter.formatXml(xml);
            etGeneratedXml.setText(xml);
        }
    }

    private void copyXmlToClipboard() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_content_copy, "No XML Yet", "Configure an Advance layer or color first.");
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Advance 3D XML", xml);
        cm.setPrimaryClip(clip);
        MorsalinToast.showCopy(this, "Advance 3D XML");
    }

    private void saveToHistory() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_save, "No XML Yet", "Configure an Advance layer or color first.");
            return;
        }
        XmlProject project = new XmlProject(
                "Advance 3D " + (System.currentTimeMillis() % 1000),
                XmlProject.TYPE_3D,
                xml
        );
        historyManager.saveProject(project);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Project successfully added to History.");
    }

    private void downloadXmlFile() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_download, "No XML Yet", "Configure an Advance layer or color first.");
            return;
        }
        FileExporter.exportXmlToFile(this, "MS_ADVANCE_3D_BG.xml", xml);
        MorsalinToast.showDownload(this, "MS_ADVANCE_3D_BG.xml");
    }

    private void shareXml() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_share, "No XML Yet", "Configure an Advance layer or color first.");
            return;
        }
        ShareHelper.shareXmlText(this, xml, "Share Advance 3D XML");
    }

    private void showResetDialog() {
        MorsalinDialogHelper.showResetDialog(
                this,
                "Reset Advance XML",
                "Are you sure you want to reset all Advance layers to initial blank state?",
                () -> {
                    initBlankStates();
                    currentState = StateModel.STATE_NORMAL;
                    activeLayerIndex = 0;
                    updateStateFrameSelection();
                    updateLayerButtons();
                    updateUiForActiveLayer();
                    updatePreviewAndXml();
                    MorsalinToast.show(this, R.drawable.ic_refresh, "Shape Reset", "Reset to initial blank state.");
                }
        );
    }
}
