package com.android.modding.tools.helpers;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.OvershootInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.modding.tools.R;

/**
 * Universal In-App Floating Toast & Notification Preview Helper.
 * Guarantees 100% accurate visual preview on all Android versions (including Android 11-15
 * where native Toast.setView() is restricted by OS).
 */
public class ToastPreviewHelper {

    private static final Handler sHandler = new Handler(Looper.getMainLooper());

    public static void showSimplePreview(Activity activity, String message, boolean isLong, int position) {
        if (activity == null || activity.isFinishing()) return;

        int gravity;
        int yOffsetDp;
        if (position == 1) { // Center
            gravity = Gravity.CENTER;
            yOffsetDp = 0;
        } else if (position == 2) { // Top
            gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            yOffsetDp = 70;
        } else { // Bottom (Default)
            gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            yOffsetDp = 80;
        }

        TextView tv = new TextView(activity);
        tv.setText(message);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(13.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(activity, 22), dp(activity, 11), dp(activity, 22), dp(activity, 11));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE621252B);
        bg.setCornerRadius(dp(activity, 24));
        bg.setStroke(dp(activity, 1), 0xFF00E5FF);
        tv.setBackground(bg);

        displayOverlayView(activity, tv, gravity, yOffsetDp, isLong ? 3500 : 2000, 0, 300);
    }

    public static void showBase64Preview(Activity activity, String decodedPlaintext, String base64Hash, boolean isLong) {
        if (activity == null || activity.isFinishing()) return;

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setPadding(dp(activity, 20), dp(activity, 12), dp(activity, 20), dp(activity, 12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0181D26);
        bg.setCornerRadius(dp(activity, 20));
        bg.setStroke(dp(activity, 1), 0xFF00E5FF);
        layout.setBackground(bg);

        TextView badge = new TextView(activity);
        badge.setText("🔒 DECODED BASE64 HOOK");
        badge.setTextColor(0xFF00E5FF);
        badge.setTextSize(10f);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        layout.addView(badge);

        TextView msgTv = new TextView(activity);
        msgTv.setText(decodedPlaintext);
        msgTv.setTextColor(Color.WHITE);
        msgTv.setTextSize(13.5f);
        msgTv.setTypeface(Typeface.DEFAULT_BOLD);
        msgTv.setGravity(Gravity.CENTER);
        msgTv.setPadding(0, dp(activity, 4), 0, 0);
        layout.addView(msgTv);

        displayOverlayView(activity, layout, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 80, isLong ? 3500 : 2000, 0, 300);
    }

    public static void showColorfulPreview(Activity activity, String message, int bgColor, int textColor,
                                           int cornerRadiusDp, int strokeColor, int strokeWidthDp, boolean isLong) {
        if (activity == null || activity.isFinishing()) return;

        TextView tv = new TextView(activity);
        tv.setText(message);
        tv.setTextColor(textColor);
        tv.setTextSize(14f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(activity, 24), dp(activity, 12), dp(activity, 24), dp(activity, 12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(activity, cornerRadiusDp));
        if (strokeWidthDp > 0) {
            bg.setStroke(dp(activity, strokeWidthDp), strokeColor);
        }
        tv.setBackground(bg);

        displayOverlayView(activity, tv, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 80, isLong ? 3500 : 2000, 0, 300);
    }

    public static void showAnimatedPreview(Activity activity, String message, int animType, int animDurationMs, boolean isLong) {
        if (activity == null || activity.isFinishing()) return;

        TextView tv = new TextView(activity);
        tv.setText("✦ " + message + " ✦");
        tv.setTextColor(0xFF00E5FF);
        tv.setTextSize(14f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(activity, 24), dp(activity, 12), dp(activity, 24), dp(activity, 12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0181D26);
        bg.setCornerRadius(dp(activity, 26));
        bg.setStroke(dp(activity, 1), 0xFF00E5FF);
        tv.setBackground(bg);

        displayOverlayView(activity, tv, Gravity.CENTER, 0, isLong ? 3500 : 2200, animType, animDurationMs);
    }

    public static void showImagePreview(Activity activity, String title, String message, String symbol, boolean isLong) {
        if (activity == null || activity.isFinishing()) return;

        LinearLayout container = new LinearLayout(activity);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        container.setPadding(dp(activity, 18), dp(activity, 11), dp(activity, 20), dp(activity, 11));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0191E28);
        bg.setCornerRadius(dp(activity, 24));
        bg.setStroke(dp(activity, 1), 0xFF00E5FF);
        container.setBackground(bg);

        TextView iconTv = new TextView(activity);
        iconTv.setText(symbol);
        iconTv.setTextSize(22f);
        iconTv.setGravity(Gravity.CENTER);
        container.addView(iconTv);

        LinearLayout textLayout = new LinearLayout(activity);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        textLayout.setPadding(dp(activity, 12), 0, 0, 0);

        if (title != null && !title.isEmpty()) {
            TextView titleTv = new TextView(activity);
            titleTv.setText(title);
            titleTv.setTextColor(0xFF00E5FF);
            titleTv.setTextSize(12.5f);
            titleTv.setTypeface(Typeface.DEFAULT_BOLD);
            textLayout.addView(titleTv);
        }

        TextView msgTv = new TextView(activity);
        msgTv.setText(message);
        msgTv.setTextColor(Color.WHITE);
        msgTv.setTextSize(13f);
        msgTv.setTypeface(Typeface.DEFAULT_BOLD);
        textLayout.addView(msgTv);

        container.addView(textLayout);

        displayOverlayView(activity, container, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 80, isLong ? 3500 : 2000, 0, 300);
    }

    private static void displayOverlayView(Activity activity, View view, int gravity, int yOffsetDp,
                                          long displayDurationMs, int animType, int animDurationMs) {
        ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
        if (decorView == null) return;

        View existing = decorView.findViewWithTag("morsalin_preview_toast_overlay");
        if (existing != null) {
            try { decorView.removeView(existing); } catch (Throwable ignored) {}
        }

        FrameLayout overlayContainer = new FrameLayout(activity);
        overlayContainer.setTag("morsalin_preview_toast_overlay");
        overlayContainer.setClipChildren(false);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.gravity = gravity;
        if ((gravity & Gravity.TOP) == Gravity.TOP) {
            lp.topMargin = dp(activity, yOffsetDp);
        } else if ((gravity & Gravity.BOTTOM) == Gravity.BOTTOM) {
            lp.bottomMargin = dp(activity, yOffsetDp);
        }

        overlayContainer.addView(view, lp);
        decorView.addView(overlayContainer, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Entrance animation
        Animation entranceAnim = createEntranceAnimation(animType, animDurationMs);
        view.startAnimation(entranceAnim);

        // Tap to dismiss
        overlayContainer.setOnClickListener(v -> dismissOverlay(decorView, overlayContainer, view));

        // Auto dismiss timer
        sHandler.postDelayed(() -> dismissOverlay(decorView, overlayContainer, view), displayDurationMs);
    }

    private static Animation createEntranceAnimation(int animType, int durationMs) {
        if (animType == 1) { // Alpha Fade
            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
            alpha.setDuration(durationMs);
            return alpha;
        } else if (animType == 2) { // Slide Up
            AnimationSet set = new AnimationSet(true);
            TranslateAnimation translate = new TranslateAnimation(0, 0, 100, 0);
            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
            set.addAnimation(translate);
            set.addAnimation(alpha);
            set.setInterpolator(new OvershootInterpolator(1.2f));
            set.setDuration(durationMs);
            return set;
        } else { // Zoom Scale (Default)
            AnimationSet set = new AnimationSet(true);
            ScaleAnimation scale = new ScaleAnimation(
                    0.5f, 1.0f, 0.5f, 1.0f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
            );
            AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
            set.addAnimation(scale);
            set.addAnimation(alpha);
            set.setInterpolator(new OvershootInterpolator(1.2f));
            set.setDuration(durationMs);
            return set;
        }
    }

    private static void dismissOverlay(ViewGroup parent, View overlay, View childView) {
        if (overlay == null || overlay.getParent() == null) return;

        AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
        fadeOut.setDuration(220);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}
            @Override
            public void onAnimationEnd(Animation animation) {
                parent.post(() -> {
                    try {
                        parent.removeView(overlay);
                    } catch (Exception ignored) {}
                });
            }
            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        childView.startAnimation(fadeOut);
    }

    private static int dp(Activity activity, int dp) {
        return (int) (dp * activity.getResources().getDisplayMetrics().density + 0.5f);
    }
}
