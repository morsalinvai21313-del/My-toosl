package com.android.modding.tools.dialogs;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class CustomInsetsDialog extends Dialog {

    public interface OnInsetsAppliedListener {
        void onInsetsApplied(int left, int top, int right, int bottom, boolean linked);
    }

    private final InsetsModel initialInsets;
    private final OnInsetsAppliedListener listener;
    private OnInsetsAppliedListener liveListener;

    private SeekBar seekLeft, seekTop, seekRight, seekBottom;
    private TextView tvLeftVal, tvTopVal, tvRightVal, tvBottomVal;

    public CustomInsetsDialog(Context context, InsetsModel initialInsets, OnInsetsAppliedListener listener) {
        super(context, R.style.Theme_MyApplication_Dialog);
        this.initialInsets = initialInsets != null ? initialInsets.copy() : new InsetsModel();
        this.listener = listener;
    }

    public CustomInsetsDialog setLiveListener(OnInsetsAppliedListener liveListener) {
        this.liveListener = liveListener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_custom_insets);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setLayout((int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.90),
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        seekLeft = findViewById(R.id.seek_inset_left);
        seekTop = findViewById(R.id.seek_inset_top);
        seekRight = findViewById(R.id.seek_inset_right);
        seekBottom = findViewById(R.id.seek_inset_bottom);

        tvLeftVal = findViewById(R.id.tv_inset_left_val);
        tvTopVal = findViewById(R.id.tv_inset_top_val);
        tvRightVal = findViewById(R.id.tv_inset_right_val);
        tvBottomVal = findViewById(R.id.tv_inset_bottom_val);

        Button btnLeftMinus = findViewById(R.id.btn_inset_left_minus);
        Button btnLeftPlus = findViewById(R.id.btn_inset_left_plus);
        Button btnTopMinus = findViewById(R.id.btn_inset_top_minus);
        Button btnTopPlus = findViewById(R.id.btn_inset_top_plus);
        Button btnRightMinus = findViewById(R.id.btn_inset_right_minus);
        Button btnRightPlus = findViewById(R.id.btn_inset_right_plus);
        Button btnBottomMinus = findViewById(R.id.btn_inset_bottom_minus);
        Button btnBottomPlus = findViewById(R.id.btn_inset_bottom_plus);

        Button btnApply = findViewById(R.id.btn_insets_apply);

        seekLeft.setProgress(initialInsets.getLeftDp());
        seekTop.setProgress(initialInsets.getTopDp());
        seekRight.setProgress(initialInsets.getRightDp());
        seekBottom.setProgress(initialInsets.getBottomDp());
        updateLabels();

        setupInsetSlider(seekLeft, btnLeftMinus, btnLeftPlus);
        setupInsetSlider(seekTop, btnTopMinus, btnTopPlus);
        setupInsetSlider(seekRight, btnRightMinus, btnRightPlus);
        setupInsetSlider(seekBottom, btnBottomMinus, btnBottomPlus);

        btnApply.setOnClickListener(v -> {
            if (listener != null) {
                listener.onInsetsApplied(
                        seekLeft.getProgress(),
                        seekTop.getProgress(),
                        seekRight.getProgress(),
                        seekBottom.getProgress(),
                        false
                );
            }
            dismiss();
        });
    }

    private void setupInsetSlider(SeekBar seekBar, Button minus, Button plus) {
        minus.setOnClickListener(v -> {
            int newProgress = Math.max(0, seekBar.getProgress() - 1);
            seekBar.setProgress(newProgress);
            updateLabels();
            notifyLiveChange();
        });

        plus.setOnClickListener(v -> {
            int newProgress = Math.min(50, seekBar.getProgress() + 1);
            seekBar.setProgress(newProgress);
            updateLabels();
            notifyLiveChange();
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                updateLabels();
                notifyLiveChange();
            }
            @Override
            public void onStartTrackingTouch(SeekBar sb) {}
            @Override
            public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    private void updateLabels() {
        if (tvLeftVal != null) tvLeftVal.setText(seekLeft.getProgress() + "dp");
        if (tvTopVal != null) tvTopVal.setText(seekTop.getProgress() + "dp");
        if (tvRightVal != null) tvRightVal.setText(seekRight.getProgress() + "dp");
        if (tvBottomVal != null) tvBottomVal.setText(seekBottom.getProgress() + "dp");
    }

    private void notifyLiveChange() {
        if (liveListener != null) {
            liveListener.onInsetsApplied(
                    seekLeft.getProgress(),
                    seekTop.getProgress(),
                    seekRight.getProgress(),
                    seekBottom.getProgress(),
                    false
            );
        }
    }
}
