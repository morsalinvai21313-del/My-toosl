package com.android.modding.tools.toastmaker;

import android.content.Context;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Generates and bundles assets for Toast Package Exporter.
 * Creates clean JSON configs and manifests in assets/ folder.
 */
public class ToastAssetGenerator {

    public static class AssetBundle {
        public final Map<String, byte[]> binaryAssets = new LinkedHashMap<>();
        public final Map<String, String> textAssets = new LinkedHashMap<>();
    }

    public static AssetBundle generateAssets(ToastConfig config, Context context) {
        AssetBundle bundle = new AssetBundle();
        if (config == null) return bundle;

        // Only include custom image asset when explicitly selected by the user
        if (config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0) {
            bundle.binaryAssets.put("assets/toast_icon.png", config.customImageBytes);
        }

        return bundle;
    }
}
