package com.android.modding.tools.helpers;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Runs the Settings-configured Conversion Visual Animation (ConversionAnimationView)
 * when the user taps "GENERATE PACKAGE" in any of the 4 Pro Tools, then reveals
 * the Download (.ZIP + classes.dex + XML + GUIDE.txt) panel upon completion.
 */
public class PackageGenerationRunner {

    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    public static void runGeneratePipeline(
            ScrollView parentScroll,
            View animPanel,
            ConversionAnimationView animView,
            TextView tvAnimBadge,
            TextView tvAnimStatus,
            View readyPanel,
            String srcTag,
            String dstTag,
            Runnable onBuildPackageAndFinish
    ) {
        HANDLER.removeCallbacksAndMessages(animView);

        if (readyPanel != null) {
            readyPanel.setVisibility(View.GONE);
        }
        if (animPanel != null) {
            animPanel.setVisibility(View.VISIBLE);
            animPanel.setAlpha(0f);
            animPanel.animate().alpha(1f).setDuration(200).start();
        }

        String[] stages;
        ConverterAnimationManager.ConverterAnimItem toolAnim = null;

        if ("DIALOG.UI".equals(srcTag)) {
            toolAnim = new ConverterAnimationManager.ConverterAnimItem(
                    "dialog_hud", "Holo-UI Dialog Assembler", "Assembling dynamic dialog framework",
                    ConverterAnimationManager.CAT_CINEMATIC, "⚡ STARK HOLO-UI DIALOG ASSEMBLER ⚡",
                    ConverterAnimationManager.ENGINE_JARVIS_HUD, ConverterAnimationManager.PALETTE_CYBER_NEON, false, false);
            stages = new String[]{
                    "Stage 1/5 • Analyzing Dialog Blueprint & Corner Radii...",
                    "Stage 2/5 • Generating Interactive Action Links & URLs...",
                    "Stage 3/5 • Assembling Standalone classes.dex (MorsalinDialog)...",
                    "Stage 4/5 • Injecting Smali Bytecode & Adler32 Checksum...",
                    "Stage 5/5 • Dialog Package Ready for MT Manager (100%)"
            };
        } else if ("NOTIF.CFG".equals(srcTag)) {
            toolAnim = new ConverterAnimationManager.ConverterAnimItem(
                    "notif_radar", "Orbital Sonar & Radar Dispatch", "Calibrating notification beacon system",
                    ConverterAnimationManager.CAT_HACKING, "📡 ORBITAL SONAR & RADAR DISPATCH 📡",
                    ConverterAnimationManager.ENGINE_ORBITAL_RADAR, ConverterAnimationManager.PALETTE_SIGNATURE, true, false);
            stages = new String[]{
                    "Stage 1/5 • Scanning Notification Channels & System Priority...",
                    "Stage 2/5 • Packaging Action Buttons & Deep-Link Targets...",
                    "Stage 3/5 • Compiling Standalone notif_helper.dex...",
                    "Stage 4/5 • Verifying Broadcast Receivers & Checksums...",
                    "Stage 5/5 • Notification Package Ready (100%)"
            };
        } else if ("ANIM.XML".equals(srcTag)) {
            toolAnim = new ConverterAnimationManager.ConverterAnimItem(
                    "anim_warp", "Hyperspace Warp Interpolator", "Computing frame transformation curves",
                    ConverterAnimationManager.CAT_CINEMATIC, "🌀 HYPERSPACE WARP INTERPOLATOR 🌀",
                    ConverterAnimationManager.ENGINE_HYPERSPACE_WARP, ConverterAnimationManager.PALETTE_QUANTUM_VIOLET, false, false);
            stages = new String[]{
                    "Stage 1/5 • Computing Interpolation Curves & Velocity Matrices...",
                    "Stage 2/5 • Compiling Frame Transforms & Pivot Physics...",
                    "Stage 3/5 • Assembling High-FPS anim_helper.dex...",
                    "Stage 4/5 • Optimizing Hardware Acceleration Buffers...",
                    "Stage 5/5 • Animation DEX & XML Ready (100%)"
            };
        } else if ("TEXT.FX".equals(srcTag)) {
            toolAnim = new ConverterAnimationManager.ConverterAnimItem(
                    "text_synthwave", "Synthwave Glyph Matrix Engine", "Synthesizing typography shaders",
                    ConverterAnimationManager.CAT_CINEMATIC, "🔤 SYNTHWAVE GLYPH MATRIX ENGINE 🔤",
                    ConverterAnimationManager.ENGINE_SYNTHWAVE_SPECTRUM, ConverterAnimationManager.PALETTE_SIGNATURE, false, false);
            stages = new String[]{
                    "Stage 1/5 • Tokenizing Typography Glyphs & Custom Fonts...",
                    "Stage 2/5 • Synthesizing Neon Shimmer & Typewriter Shaders...",
                    "Stage 3/5 • Compiling text_anim_view.dex Engine...",
                    "Stage 4/5 • Verifying Real-Time Canvas Render Loop...",
                    "Stage 5/5 • Animated Text Package Ready (100%)"
            };
        } else {
            stages = new String[]{
                    "Stage 1/5 • Parsing UI, Colors & Button Links...",
                    "Stage 2/5 • Building Android XML Resources...",
                    "Stage 3/5 • Assembling Standalone classes.dex...",
                    "Stage 4/5 • Verifying DEX Checksum & Writing GUIDE.txt...",
                    "Stage 5/5 • Package Compiled Successfully (100%)"
            };
        }

        if (animView != null) {
            if (toolAnim != null) {
                animView.applyAnimationConfig(toolAnim);
            } else {
                animView.loadSelectedFromPrefs();
            }
            animView.setLanguages(srcTag != null ? srcTag : "CONFIG", dstTag != null ? dstTag : "CLASSES.DEX");
            animView.updateState(8, stages[0]);
            animView.startAnimationLoop();
            if (tvAnimBadge != null) {
                tvAnimBadge.setText("ENGINE: " + animView.getActiveStyleTitle().toUpperCase());
            }
        }
        if (tvAnimStatus != null) {
            tvAnimStatus.setText(stages[0]);
        }

        if (parentScroll != null && animPanel != null) {
            parentScroll.post(() -> parentScroll.smoothScrollTo(0, animPanel.getTop()));
        }

        final java.util.concurrent.atomic.AtomicBoolean buildDone = new java.util.concurrent.atomic.AtomicBoolean(false);
        final java.util.concurrent.atomic.AtomicBoolean animDone = new java.util.concurrent.atomic.AtomicBoolean(false);

        // Run heavy DEX bytecode compilation on background worker thread
        new Thread(() -> {
            try {
                if (onBuildPackageAndFinish != null) {
                    onBuildPackageAndFinish.run();
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
            buildDone.set(true);
            if (animDone.get()) {
                HANDLER.post(() -> revealReadyPanel(parentScroll, animPanel, animView, readyPanel));
            }
        }).start();

        HANDLER.postDelayed(() -> {
            if (animView != null) {
                animView.updateState(28, stages[1]);
            }
            if (tvAnimStatus != null) {
                tvAnimStatus.setText(stages[1]);
            }
        }, 350);

        HANDLER.postDelayed(() -> {
            if (animView != null) {
                animView.updateState(56, stages[2]);
            }
            if (tvAnimStatus != null) {
                tvAnimStatus.setText(stages[2]);
            }
        }, 750);

        HANDLER.postDelayed(() -> {
            if (animView != null) {
                animView.updateState(82, stages[3]);
            }
            if (tvAnimStatus != null) {
                tvAnimStatus.setText(stages[3]);
            }
        }, 1150);

        HANDLER.postDelayed(() -> {
            if (animView != null) {
                animView.updateState(100, stages[4]);
            }
            if (tvAnimStatus != null) {
                tvAnimStatus.setText(stages[4]);
            }
            animDone.set(true);
            if (buildDone.get()) {
                revealReadyPanel(parentScroll, animPanel, animView, readyPanel);
            } else {
                if (tvAnimStatus != null) {
                    tvAnimStatus.setText("Finalizing bytecode verification...");
                }
            }
        }, 1500);
    }

    private static void revealReadyPanel(
            ScrollView parentScroll,
            View animPanel,
            ConversionAnimationView animView,
            View readyPanel
    ) {
        if (animView != null) {
            animView.updateState(100, "✓ Complete: classes.dex + Resources Ready!");
            // Stop CPU/GPU-intensive particle and canvas loop to prevent any UI lag
            HANDLER.postDelayed(() -> {
                if (animView != null) {
                    animView.stopAnimationLoop();
                    animView.invalidate();
                }
            }, 300);
        }
        if (readyPanel != null) {
            readyPanel.setVisibility(View.VISIBLE);
            readyPanel.setAlpha(0f);
            readyPanel.setScaleX(0.95f);
            readyPanel.setScaleY(0.95f);
            readyPanel.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(280)
                    .start();
            if (parentScroll != null) {
                parentScroll.post(() -> {
                    int targetY = Math.max(0, (animPanel != null ? animPanel.getTop() : readyPanel.getTop()) - 20);
                    parentScroll.smoothScrollTo(0, targetY);
                });
            }
        }
    }
}
