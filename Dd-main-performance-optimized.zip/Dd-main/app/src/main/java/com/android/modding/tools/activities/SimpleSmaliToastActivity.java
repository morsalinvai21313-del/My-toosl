package com.android.modding.tools.activities;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.ColorPickerDialog;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.ToastPreviewHelper;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import java.util.Locale;

/**
 * Dedicated Simple Smali Toast Maker & OnCreate Hook Generator.
 * Generates pure, clean, zero-DEX Dalvik Smali instructions for onCreate(Landroid/os/Bundle;)V
 * using Html.fromHtml and Toast.getView().setBackgroundColor().
 */
public class SimpleSmaliToastActivity extends AppCompatActivity {

    public static final String STYLISH_BORDER = "# ▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰";

    private String messageText = "MODDER BY SANNY";
    private String fontColorHex = "#FF00E6";
    private String bgColorHex = "#FFFFFF";
    private boolean isBold = true;
    private boolean isItalic = false;
    private boolean isUnderline = false;
    private boolean isLongDuration = true;
    private int gravity = 0; // 0=Bottom, 1=Center, 2=Top

    // Views
    private LinearLayout cardLivePreview;
    private TextView tvLivePreviewMessage;
    private EditText etToastMessage;
    private CheckBox cbFormatBold, cbFormatItalic, cbFormatUnderline;
    private TextView tvFontColorHex, tvBgColorHex;
    private Button btnDurationLong, btnDurationShort;
    private Button btnGravityBottom, btnGravityCenter, btnGravityTop;
    private TextView tvGeneratedSmali;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_smali_toast);

        GlobalTouchParticleManager.attach(this);
        initViews();
        updateUI();
    }

    private void initViews() {
        // Back & Reset
        findViewById(R.id.btn_toast_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_toast_reset).setOnClickListener(v -> {
            messageText = "MODDER BY SANNY";
            fontColorHex = "#FF00E6";
            bgColorHex = "#FFFFFF";
            isBold = true;
            isItalic = false;
            isUnderline = false;
            isLongDuration = true;
            gravity = 0;
            updateUI();
            MorsalinToast.show(this, R.drawable.ic_refresh, "Reset", "Values restored to defaults.");
        });

        // Live Preview Bubble
        cardLivePreview = findViewById(R.id.card_live_toast_preview);
        tvLivePreviewMessage = findViewById(R.id.tv_live_preview_message);
        cardLivePreview.setOnClickListener(v -> testToastPopup());

        // Message input
        etToastMessage = findViewById(R.id.et_toast_message);
        etToastMessage.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                messageText = s.toString();
                updatePreviewAndSmali();
            }
        });

        // HTML formatting checkboxes
        cbFormatBold = findViewById(R.id.cb_format_bold);
        cbFormatItalic = findViewById(R.id.cb_format_italic);
        cbFormatUnderline = findViewById(R.id.cb_format_underline);

        cbFormatBold.setOnCheckedChangeListener((btn, isChecked) -> {
            isBold = isChecked;
            updatePreviewAndSmali();
        });

        cbFormatItalic.setOnCheckedChangeListener((btn, isChecked) -> {
            isItalic = isChecked;
            updatePreviewAndSmali();
        });

        cbFormatUnderline.setOnCheckedChangeListener((btn, isChecked) -> {
            isUnderline = isChecked;
            updatePreviewAndSmali();
        });

        // Colors
        tvFontColorHex = findViewById(R.id.tv_font_color_hex);
        tvBgColorHex = findViewById(R.id.tv_bg_color_hex);

        findViewById(R.id.btn_pick_font_color).setOnClickListener(v -> {
            ColorPickerDialog dialog = new ColorPickerDialog(this, fontColorHex, hex -> {
                fontColorHex = hex;
                updatePreviewAndSmali();
            });
            dialog.show();
        });

        findViewById(R.id.btn_pick_bg_color).setOnClickListener(v -> {
            ColorPickerDialog dialog = new ColorPickerDialog(this, bgColorHex, hex -> {
                bgColorHex = hex;
                updatePreviewAndSmali();
            });
            dialog.show();
        });

        // Font Color Quick Chips
        findViewById(R.id.chip_font_pink).setOnClickListener(v -> setFontColor("#FF00E6"));
        findViewById(R.id.chip_font_cyan).setOnClickListener(v -> setFontColor("#00E5FF"));
        findViewById(R.id.chip_font_gold).setOnClickListener(v -> setFontColor("#FFD700"));
        findViewById(R.id.chip_font_green).setOnClickListener(v -> setFontColor("#00E676"));
        findViewById(R.id.chip_font_white).setOnClickListener(v -> setFontColor("#FFFFFF"));

        // BG Color Quick Chips
        findViewById(R.id.chip_bg_white).setOnClickListener(v -> setBgColor("#FFFFFF"));
        findViewById(R.id.chip_bg_black).setOnClickListener(v -> setBgColor("#000000"));
        findViewById(R.id.chip_bg_dark).setOnClickListener(v -> setBgColor("#121820"));
        findViewById(R.id.chip_bg_navy).setOnClickListener(v -> setBgColor("#0A192F"));

        // Duration Buttons
        btnDurationLong = findViewById(R.id.btn_duration_long);
        btnDurationShort = findViewById(R.id.btn_duration_short);

        btnDurationLong.setOnClickListener(v -> {
            isLongDuration = true;
            updateDurationButtons();
            updatePreviewAndSmali();
        });

        btnDurationShort.setOnClickListener(v -> {
            isLongDuration = false;
            updateDurationButtons();
            updatePreviewAndSmali();
        });

        // Gravity Buttons
        btnGravityBottom = findViewById(R.id.btn_gravity_bottom);
        btnGravityCenter = findViewById(R.id.btn_gravity_center);
        btnGravityTop = findViewById(R.id.btn_gravity_top);

        btnGravityBottom.setOnClickListener(v -> {
            gravity = 0;
            updateGravityButtons();
            updatePreviewAndSmali();
        });

        btnGravityCenter.setOnClickListener(v -> {
            gravity = 1;
            updateGravityButtons();
            updatePreviewAndSmali();
        });

        btnGravityTop.setOnClickListener(v -> {
            gravity = 2;
            updateGravityButtons();
            updatePreviewAndSmali();
        });

        // Quick Presets
        findViewById(R.id.btn_preset_sanny).setOnClickListener(v -> applyPreset(
                "MODDER BY SANNY", "#FF00E6", "#FFFFFF", true, false, false, "Sanny Pink"));

        findViewById(R.id.btn_preset_cyan).setOnClickListener(v -> applyPreset(
                "MORSALIN CYBER MOD", "#00E5FF", "#121820", true, false, false, "Cyber Cyan"));

        findViewById(R.id.btn_preset_gold).setOnClickListener(v -> applyPreset(
                "VIP ACCESS UNLOCKED", "#FFD700", "#000000", true, false, false, "Golden VIP"));

        findViewById(R.id.btn_preset_emerald).setOnClickListener(v -> applyPreset(
                "ANTI-BAN SYSTEM ACTIVE", "#00E676", "#000000", true, false, false, "Toxic Emerald"));

        // Smali code display & action buttons
        tvGeneratedSmali = findViewById(R.id.tv_generated_smali);
        findViewById(R.id.btn_test_toast).setOnClickListener(v -> testToastPopup());
        findViewById(R.id.btn_copy_smali).setOnClickListener(v -> copySmaliHook());
        findViewById(R.id.btn_download_smali).setOnClickListener(v -> downloadSmaliHook());
        findViewById(R.id.btn_share_smali).setOnClickListener(v -> shareSmaliHook());
    }

    private void setFontColor(String hex) {
        fontColorHex = hex;
        updatePreviewAndSmali();
    }

    private void setBgColor(String hex) {
        bgColorHex = hex;
        updatePreviewAndSmali();
    }

    private void applyPreset(String msg, String fontHex, String bgHex, boolean bold, boolean italic, boolean underline, String name) {
        messageText = msg;
        fontColorHex = fontHex;
        bgColorHex = bgHex;
        isBold = bold;
        isItalic = italic;
        isUnderline = underline;
        updateUI();
        MorsalinToast.show(this, R.drawable.ic_settings_anim, "Preset Loaded", name + " applied!");
    }

    private void updateUI() {
        if (etToastMessage != null && !etToastMessage.getText().toString().equals(messageText)) {
            etToastMessage.setText(messageText);
        }
        if (cbFormatBold != null) cbFormatBold.setChecked(isBold);
        if (cbFormatItalic != null) cbFormatItalic.setChecked(isItalic);
        if (cbFormatUnderline != null) cbFormatUnderline.setChecked(isUnderline);

        updateDurationButtons();
        updateGravityButtons();
        updatePreviewAndSmali();
    }

    private void updateDurationButtons() {
        btnDurationLong.setBackgroundResource(isLongDuration ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnDurationLong.setTextColor(isLongDuration ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnDurationShort.setBackgroundResource(!isLongDuration ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnDurationShort.setTextColor(!isLongDuration ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);
    }

    private void updateGravityButtons() {
        btnGravityBottom.setBackgroundResource(gravity == 0 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityBottom.setTextColor(gravity == 0 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnGravityCenter.setBackgroundResource(gravity == 1 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityCenter.setTextColor(gravity == 1 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnGravityTop.setBackgroundResource(gravity == 2 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityTop.setTextColor(gravity == 2 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);
    }

    private String getHtmlString() {
        StringBuilder sb = new StringBuilder();
        if (isBold) sb.append("<b>");
        if (isItalic) sb.append("<i>");
        if (isUnderline) sb.append("<u>");
        sb.append("<font color=").append(fontColorHex).append(">");
        sb.append(messageText).append(" ");
        sb.append("</font>");
        if (isUnderline) sb.append("</u>");
        if (isItalic) sb.append("</i>");
        if (isBold) sb.append("</b>");
        return sb.toString();
    }

    private void updatePreviewAndSmali() {
        String html = getHtmlString();

        // 1. Update Preview Bubble
        int bgCol = parseColorSafe(bgColorHex, Color.WHITE);
        cardLivePreview.setBackgroundColor(bgCol);

        CharSequence spanned;
        try {
            spanned = Html.fromHtml(html);
        } catch (Throwable t) {
            spanned = messageText;
        }
        tvLivePreviewMessage.setText(spanned);

        // 2. Update Hex labels
        tvFontColorHex.setText(fontColorHex);
        tvFontColorHex.setTextColor(parseColorSafe(fontColorHex, 0xFFFF00E6));

        int bgInt = parseColorSafe(bgColorHex, Color.WHITE);
        if (bgInt == -1 || "#FFFFFF".equalsIgnoreCase(bgColorHex)) {
            tvBgColorHex.setText("-1 (#FFFFFF)");
        } else {
            tvBgColorHex.setText(bgColorHex);
        }

        // 3. Generate Smali Hook
        String smaliHook = generateSmaliCode(html, bgCol, isLongDuration, gravity);
        tvGeneratedSmali.setText(smaliHook);
    }

    private String generateSmaliCode(String htmlString, int bgCol, boolean isLong, int pos) {
        StringBuilder sb = new StringBuilder();
        sb.append(STYLISH_BORDER).append("\n");
        sb.append("# HOOK CODE FOR onCreate(Landroid/os/Bundle;)V\n");
        sb.append(STYLISH_BORDER).append("\n\n");

        sb.append("const-string v0, \"").append(escapeSmali(htmlString)).append("\"\n\n");
        sb.append("invoke-static {v0}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;\n\n");
        sb.append("move-result-object v0\n\n");

        int dur = isLong ? 1 : 0;
        sb.append("const/4 v1, 0x").append(dur).append("\n\n");

        sb.append("invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;\n\n");
        sb.append("move-result-object v2\n\n");

        if (pos == 1) { // Center
            sb.append("const/16 v5, 0x11\n");
            sb.append("const/4 v6, 0x0\n");
            sb.append("const/4 v7, 0x0\n");
            sb.append("invoke-virtual {v2, v5, v6, v7}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        } else if (pos == 2) { // Top
            sb.append("const/16 v5, 0x30\n");
            sb.append("const/4 v6, 0x0\n");
            sb.append("const/16 v7, 0x64\n");
            sb.append("invoke-virtual {v2, v5, v6, v7}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        }

        sb.append("invoke-virtual {v2}, Landroid/widget/Toast;->getView()Landroid/view/View;\n\n");
        sb.append("move-result-object v3\n\n");
        sb.append("if-eqz v3, :cond_0\n\n");

        // Format background color constant
        if (bgCol == -1) {
            sb.append("const/4 v4, -0x1\n\n");
        } else if (bgCol >= -8 && bgCol <= 7) {
            sb.append("const/4 v4, ").append(bgCol < 0 ? String.format(Locale.US, "-0x%x", -bgCol) : String.format(Locale.US, "0x%x", bgCol)).append("\n\n");
        } else if (bgCol >= -32768 && bgCol <= 32767) {
            sb.append("const/16 v4, ").append(bgCol < 0 ? String.format(Locale.US, "-0x%x", -bgCol) : String.format(Locale.US, "0x%x", bgCol)).append("\n\n");
        } else {
            sb.append("const v4, ").append(String.format(Locale.US, "0x%08x", bgCol)).append("\n\n");
        }

        sb.append("invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundColor(I)V\n\n");
        sb.append(":cond_0\n");
        sb.append("invoke-virtual {v2}, Landroid/widget/Toast;->show()V\n\n");
        sb.append(STYLISH_BORDER).append("\n");
        sb.append("# 🌸 لَا اِلَهَاِلّا اللهُمَحَمّدُرّسُوْلُالله(ﷺ)__🥰\n");
        sb.append("# -লা ইলাহা ইল্লাল্লাহু মুহাম্মাদর রসূল্লাহ\n");
        sb.append("# ডেভলপার বাই মোরসালিন খান 🇧🇩\n");
        sb.append(STYLISH_BORDER).append("\n");

        return sb.toString();
    }

    private void testToastPopup() {
        try {
            CharSequence styled = Html.fromHtml(getHtmlString());
            Toast t = Toast.makeText(getApplicationContext(), styled, isLongDuration ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
            View v = t.getView();
            if (v != null) {
                v.setBackgroundColor(parseColorSafe(bgColorHex, Color.WHITE));
            }
            if (gravity == 1) t.setGravity(Gravity.CENTER, 0, 0);
            else if (gravity == 2) t.setGravity(Gravity.TOP, 0, 100);
            t.show();
        } catch (Throwable t) {
            // Also trigger overlay feedback
            ToastPreviewHelper.showSimplePreview(this, messageText, isLongDuration, gravity);
        }
    }

    private void copySmaliHook() {
        String hook = tvGeneratedSmali.getText().toString();
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Simple Smali Toast Hook", hook));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied!", "Simple Smali Hook copied to clipboard.");
        }
    }

    private void downloadSmaliHook() {
        String hook = tvGeneratedSmali.getText().toString();
        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinSmali", "hook.smali", "text/plain", hook.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        MorsalinToast.show(this, R.drawable.ic_download,
                res.success ? "hook.smali Saved" : "Save Failed",
                res.success ? "Saved to Downloads/MorsalinSmali/hook.smali!" : res.message);
    }

    private void shareSmaliHook() {
        String hook = tvGeneratedSmali.getText().toString();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Simple Smali Toast Hook");
        send.putExtra(Intent.EXTRA_TEXT, hook);
        startActivity(Intent.createChooser(send, "Share Smali Hook"));
    }

    private static int parseColorSafe(String hex, int fallback) {
        if (hex == null || hex.trim().isEmpty()) return fallback;
        try {
            return Color.parseColor(hex.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static String escapeSmali(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
