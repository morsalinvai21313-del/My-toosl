package com.android.modding.tools.helpers;

import com.android.modding.tools.R;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Universal Package Builder, Tool-Specific Bilingual GUIDE.txt Generator (English + বাংলা),
 * and Binary classes.dex + XML + ZIP Exporter for Morsalin XML Creator Pro Tools.
 */
public class GeneratedPackageExporter {

    public static final String DEV_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";
    public static final String DEV_GITHUB = "https://github.com/morsalinvai21313-del/Dd";
    public static final String DEV_TELEGRAM = "https://t.me/anonymous_modder_king";
    public static final String DEV_YOUTUBE = "https://www.youtube.com/@apk.modding";

    public static class GeneratedPackage {
        public final String projectFolderName;
        public final String toolTitle;
        public final LinkedHashMap<String, byte[]> binaryFiles = new LinkedHashMap<>();
        public final LinkedHashMap<String, String> files = new LinkedHashMap<>();
        public String guideFileName = "GUIDE.txt";
        public String guideContent = "";

        public GeneratedPackage(String projectFolderName, String toolTitle) {
            this.projectFolderName = sanitizeFolderName(projectFolderName);
            this.toolTitle = toolTitle;
        }

        public void addDexBinary(byte[] dexBytes) {
            if (dexBytes != null && dexBytes.length > 0) {
                binaryFiles.put("classes.dex", dexBytes);
            }
        }

        public byte[] getDexBinary() {
            return binaryFiles.get("classes.dex");
        }

        public void addFile(String relativePath, String content) {
            files.put(relativePath, content != null ? content : "");
        }

        public void setGuideContent(String guideContent) {
            setGuideContent("GUIDE.txt", guideContent);
        }

        public void setGuideContent(String customGuideFileName, String guideContent) {
            this.guideFileName = (customGuideFileName != null && !customGuideFileName.trim().isEmpty())
                    ? customGuideFileName.trim() : "GUIDE.txt";
            this.guideContent = guideContent != null ? guideContent : "";
            // Keep strictly a SINGLE guide file to prevent duplicate downloads
            files.remove("GUIDE.txt");
            files.put(this.guideFileName, this.guideContent);
        }

        public String getTreePreview() {
            StringBuilder sb = new StringBuilder();
            sb.append(projectFolderName).append(".zip\n");
            List<String> allKeys = new ArrayList<>();
            for (Map.Entry<String, byte[]> b : binaryFiles.entrySet()) {
                String typeDesc = b.getKey().endsWith(".dex") ? " bytes DEX" : " bytes";
                allKeys.add(b.getKey() + "  (" + b.getValue().length + typeDesc + ")");
            }
            allKeys.addAll(files.keySet());
            for (int i = 0; i < allKeys.size(); i++) {
                String prefix = (i == allKeys.size() - 1) ? "└── " : "├── ";
                sb.append(prefix).append(allKeys.get(i)).append("\n");
            }
            return sb.toString().trim();
        }
    }

    private static String sanitizeFolderName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "Generated_Project";
        }
        return name.trim().replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }

    private static String getDeveloperBannerHeader(String badgeTitle) {
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
        return "╔══════════════════════════════════════════════════════════════════════╗\n"
             + "║  " + padRight(badgeTitle, 68) + "║\n"
             + "║  Morsalin XML Creator — Official Android Modding & UI Suite          ║\n"
             + "╠══════════════════════════════════════════════════════════════════════╣\n"
             + "║  👑 Developers : SANNY & MORSALIN (Anonymous Modder King)            ║\n"
             + "║  ✈️ Telegram   : " + padRight(DEV_TELEGRAM, 52) + "║\n"
             + "║  ▶️ YouTube    : " + padRight(DEV_YOUTUBE, 52) + "║\n"
             + "║  🌐 Facebook   : " + padRight(DEV_FACEBOOK, 52) + "║\n"
             + "║  💻 GitHub     : " + padRight(DEV_GITHUB, 52) + "║\n"
             + "║  🕒 Generated  : " + padRight(ts, 52) + "║\n"
             + "╚══════════════════════════════════════════════════════════════════════╝\n\n";
    }

    private static String getDeveloperFooter() {
        return "\n╔══════════════════════════════════════════════════════════════════════╗\n"
             + "║     ★ STAY CONNECTED WITH MORSALIN XML CREATOR OFFICIAL CHANNELS ★   ║\n"
             + "║  ➤ YouTube  : " + DEV_YOUTUBE + "\n"
             + "║  ➤ Telegram : " + DEV_TELEGRAM + "\n"
             + "║  ➤ Facebook : " + DEV_FACEBOOK + "\n"
             + "║  ➤ GitHub   : " + DEV_GITHUB + "\n"
             + "╚══════════════════════════════════════════════════════════════════════╝\n";
    }

    private static String padRight(String s, int n) {
        if (s == null) s = "";
        if (s.length() >= n) return s.substring(0, n);
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < n) sb.append(' ');
        return sb.toString();
    }

    // =========================================================================
    // GUIDE 1: DEDICATED XML DRAWABLE / LAYOUT GUIDE (FOR XML EDITORS)
    // =========================================================================
    public static String buildXmlDrawableGuide(String fileName, String xmlContent) {
        boolean isLayout = xmlContent != null && (xmlContent.contains("<LinearLayout")
                || xmlContent.contains("<FrameLayout") || xmlContent.contains("<Button")
                || xmlContent.contains("<TextView") || xmlContent.contains("<EditText")
                || xmlContent.contains("androidx.cardview"));
        String cleanName = fileName != null ? fileName.replace(".xml", "") : "morsalin_bg";

        StringBuilder sb = new StringBuilder();
        sb.append(getDeveloperBannerHeader("🎨 XML DRAWABLE & UI RESOURCE INTEGRATION GUIDE"));
        sb.append("📌 GUIDE TYPE : ").append(isLayout ? "ANDROID LAYOUT XML GUIDE" : "ANDROID DRAWABLE XML GUIDE").append("\n");
        sb.append("📌 XML FILE   : ").append(cleanName).append(".xml\n");
        sb.append("📌 TARGET DIR : ").append(isLayout ? "res/layout/" : "res/drawable/").append(cleanName).append(".xml\n\n");

        sb.append("------------------------------------------------------------------------\n");
        sb.append("🇬🇧 ENGLISH GUIDE — HOW TO USE THIS XML FILE IN ANY APP\n");
        sb.append("------------------------------------------------------------------------\n");
        if (isLayout) {
            sb.append("1. Copy `").append(cleanName).append(".xml` into your APK or project's `res/layout/` folder.\n");
            sb.append("2. In your Activity or Layout, reference or inflate `@layout/").append(cleanName).append("`.\n\n");
        } else {
            sb.append("1. Copy `").append(cleanName).append(".xml` into your APK or project's `res/drawable/` folder.\n");
            sb.append("2. Apply it to any Button, Layout, or View in XML using:\n");
            sb.append("   android:background=\"@drawable/").append(cleanName).append("\"\n");
            sb.append("3. If using MaterialButton, add `app:backgroundTint=\"@null\"` so your custom XML colors show clearly.\n\n");
        }

        sb.append("------------------------------------------------------------------------\n");
        sb.append("🇧🇩 বাংলা গাইড — এই XML ফাইলটি যেভাবে আপনার অ্যাপে যুক্ত করবেন\n");
        sb.append("------------------------------------------------------------------------\n");
        if (isLayout) {
            sb.append("১. ডাউনলোড করা `").append(cleanName).append(".xml` ফাইলটি আপনার অ্যাপের `res/layout/` ফোল্ডারে পেস্ট করুন।\n");
            sb.append("২. আপনার Activity বা মেইন লেআউটে `@layout/").append(cleanName).append("` হিসেবে ব্যবহার করুন।\n");
        } else {
            sb.append("১. ডাউনলোড করা `").append(cleanName).append(".xml` ফাইলটি আপনার প্রজেক্ট বা APK-এর `res/drawable/` ফোল্ডারে রাখুন।\n");
            sb.append("২. যেকোনো Button, TextView বা Layout-এ নিচের লাইনটি যোগ করুন:\n");
            sb.append("   android:background=\"@drawable/").append(cleanName).append("\"\n");
            sb.append("৩. যদি বাটনের কালার পরিবর্তন না হয়, তবে বাটনে `app:backgroundTint=\"@null\"` লাইনটি যুক্ত করুন।\n");
        }

        sb.append(getDeveloperFooter());
        return sb.toString();
    }

    // =========================================================================
    // GUIDE 2: DEDICATED ANDROID ANIMATION MAKER GUIDE (CLASSES.DEX + ANIM XML)
    // =========================================================================
    public static String buildAnimationMakerGuide(String seqSummary, int stepCount, int totalDurationMs) {
        StringBuilder sb = new StringBuilder();
        sb.append(getDeveloperBannerHeader("🎬 ANDROID VIEW ANIMATION MAKER — DEX & XML GUIDE"));
        sb.append("╔══════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║  🎬 MODULE        : ANDROID MULTI-STEP VIEW ANIMATION ENGINE         ║\n");
        sb.append("║  ⚡ SEQUENCE      : ").append(padRight(seqSummary + " (" + stepCount + " Steps, " + totalDurationMs + "ms)", 49)).append("║\n");
        sb.append("║  📦 DEX CLASS     : Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;║\n");
        sb.append("╚══════════════════════════════════════════════════════════════════════╝\n\n");

        sb.append("📂 FILES INCLUDED IN THIS ANIMATION PACKAGE:\n");
        sb.append("  1. classes.dex                       -> Compiled Dalvik Bytecode (MorsalinAnimationHelper)\n");
        sb.append("  2. res/anim/morsalin_custom_anim.xml -> Standard Android View Animation XML\n");
        sb.append("  3. ANIMATION_GUIDE.txt / GUIDE.txt   -> This Animation Integration Manual\n\n");

        sb.append("========================================================================\n");
        sb.append("🇬🇧 ENGLISH STEP-BY-STEP INTEGRATION (MT MANAGER / APKTOOL)\n");
        sb.append("========================================================================\n");
        sb.append("METHOD A — USING COMPILED classes.dex (DIRECT APK INJECTION):\n");
        sb.append("  Step 1: Open your target APK in MT Manager.\n");
        sb.append("  Step 2: Add `classes.dex` from this ZIP into the APK:\n");
        sb.append("          • Either rename `classes.dex` to the next number (e.g. `classes2.dex` or `classes3.dex`) and add it directly to the APK root,\n");
        sb.append("          • OR open the APK's `classes.dex` in Dex Editor Plus -> Add/Merge this `classes.dex`.\n");
        sb.append("  Step 3: Copy `res/anim/morsalin_custom_anim.xml` into the APK's `res/anim/` folder (optional).\n");
        sb.append("  Step 4: Open `MainActivity` in Dex Editor Plus, locate `onCreate(Landroid/os/Bundle;)V`, and paste this 1 line before `return-void`:\n\n");
        sb.append("          invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playOnActivity(Landroid/app/Activity;)V\n\n");
        sb.append("  Step 5: Or to animate any specific View register (e.g. `v0`):\n\n");
        sb.append("          invoke-static {v0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n\n");

        sb.append("========================================================================\n");
        sb.append("🇧🇩 বাংলা ধাপে ধাপে ইন্টিগ্রেশন গাইড (অ্যানিমেশন মেকার স্পেশাল গাইড)\n");
        sb.append("========================================================================\n");
        sb.append("ধাপ ১ (classes.dex যুক্ত করা):\n");
        sb.append("  • আপনার ডাউনলোড করা ZIP ফাইলের ভেতর সরাসরি `classes.dex` ফাইল দেওয়া আছে।\n");
        sb.append("  • MT Manager দিয়ে যে অ্যাপে অ্যানিমেশন অ্যাড করতে চান সেটি ওপেন করুন।\n");
        sb.append("  • যদি অ্যাপে আগে থেকেই `classes.dex` থাকে, তবে আমাদের `classes.dex` ফাইলটির নাম `classes2.dex` (বা পরের নম্বর) দিয়ে সরাসরি APK-তে অ্যাড করুন, অথবা Dex Editor Plus দিয়ে Merge করে নিন।\n\n");
        sb.append("ধাপ ২ (XML ফাইল যুক্ত করা):\n");
        sb.append("  • `res/anim/morsalin_custom_anim.xml` ফাইলটি অ্যাপের `res/anim/` ফোল্ডারে কপি করুন।\n\n");
        sb.append("ধাপ ৩ (MainActivity-তে ১ লাইনের কল যুক্ত করা):\n");
        sb.append("  • অ্যাপের `MainActivity` এর `onCreate` মেথডের ভেতরে `return-void` এর ঠিক উপরে নিচের লাইনটি পেস্ট করুন:\n\n");
        sb.append("    invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playOnActivity(Landroid/app/Activity;)V\n\n");
        sb.append("  • অথবা যেকোনো নির্দিষ্ট বাটন বা View রেজিস্টারে (`v0`) অ্যানিমেশন চালাতে:\n");
        sb.append("    invoke-static {v0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n");

        sb.append(getDeveloperFooter());
        return sb.toString();
    }

    // =========================================================================
    // GUIDE 3: DEDICATED TEXT ANIMATION MAKER GUIDE (CLASSES.DEX + LAYOUT XML)
    // =========================================================================
    public static String buildTextAnimationMakerGuide(
            String sampleText,
            String effectType,
            int textSizeSp,
            String primaryHex,
            String glowHex
    ) {
        StringBuilder sb = new StringBuilder();
        sb.append(getDeveloperBannerHeader("🪄 TEXT ANIMATION MAKER — CUSTOM VIEW & DEX GUIDE"));
        sb.append("╔══════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║  🪄 MODULE        : CUSTOM ANIMATED TEXTVIEW WIDGET                  ║\n");
        sb.append("║  ✨ TEXT EFFECT   : ").append(padRight(effectType + " Effect (" + textSizeSp + "sp, Primary " + primaryHex + ")", 49)).append("║\n");
        sb.append("║  📦 DEX CLASS     : Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;║\n");
        sb.append("╚══════════════════════════════════════════════════════════════════════╝\n\n");

        sb.append("📂 FILES INCLUDED IN THIS TEXT ANIMATION PACKAGE:\n");
        sb.append("  1. classes.dex                                 -> Compiled Custom TextView Class\n");
        sb.append("  2. res/layout/layout_morsalin_animated_text.xml -> Ready-to-use XML Layout tag\n");
        sb.append("  3. res/values/colors_morsalin_text.xml         -> Neon & Glow Color Palette XML\n");
        sb.append("  4. TEXT_ANIMATION_GUIDE.txt / GUIDE.txt        -> This Text Animation Manual\n\n");

        sb.append("========================================================================\n");
        sb.append("🇬🇧 ENGLISH GUIDE — HOW TO ADD ANIMATED TEXT TO ANY APK\n");
        sb.append("========================================================================\n");
        sb.append("STEP 1 (Add classes.dex):\n");
        sb.append("  • Add `classes.dex` from this ZIP into your APK in MT Manager (either rename to `classes2.dex`/`classes3.dex` in APK root or merge via Dex Editor Plus).\n\n");
        sb.append("STEP 2 (Use directly inside any Layout XML file!):\n");
        sb.append("  • Open any layout XML file (e.g. `res/layout/activity_main.xml`) and paste:\n\n");
        sb.append("    <com.morsalin.xmlcreator.MorsalinAnimatedTextView\n");
        sb.append("        android:layout_width=\"match_parent\"\n");
        sb.append("        android:layout_height=\"wrap_content\"\n");
        sb.append("        android:text=\"").append(sampleText).append("\" />\n\n");
        sb.append("STEP 3 (Alternative — Apply effect to an existing TextView in Smali):\n");
        sb.append("  • If you have an existing TextView in register `v0`, call:\n");
        sb.append("    invoke-static {v0}, Lcom/morsalin/xmlcreator/MorsalinAnimatedTextView;->applyEffectToTextView(Landroid/widget/TextView;)V\n\n");

        sb.append("========================================================================\n");
        sb.append("🇧🇩 বাংলা গাইড — যেকোনো অ্যাপে অ্যানিমেটেড টেক্সট যুক্ত করার নিয়ম\n");
        sb.append("========================================================================\n");
        sb.append("ধাপ ১ (`classes.dex` যুক্ত করা):\n");
        sb.append("  • ডাউনলোড করা জিপ ফাইলের ভেতরের `classes.dex` ফাইলটি MT Manager দিয়ে আপনার টার্গেট APK-তে অ্যাড করুন (`classes2.dex` বা `classes3.dex` নাম দিয়ে অথবা Dex Editor Plus-এ Merge করে)।\n\n");
        sb.append("ধাপ ২ (লেআউট XML ফাইলে ব্যবহার):\n");
        sb.append("  • যেকোনো লেআউট ফাইলে (`res/layout/activity_main.xml`) সরাসরি নিচের XML কোডটি বসিয়ে দিন:\n\n");
        sb.append("    <com.morsalin.xmlcreator.MorsalinAnimatedTextView\n");
        sb.append("        android:layout_width=\"match_parent\"\n");
        sb.append("        android:layout_height=\"wrap_content\"\n");
        sb.append("        android:text=\"").append(sampleText).append("\" />\n\n");
        sb.append("  • অ্যাপ ওপেন করলেই আপনার তৈরি করা `").append(effectType).append("` টেক্সট অ্যানিমেশন অটোমেটিক চলতে থাকবে!\n");

        sb.append(getDeveloperFooter());
        return sb.toString();
    }

    // =========================================================================
    // GUIDE 4: DEDICATED ADVANCED DIALOG MAKER GUIDE (WITH BUTTON LINKS/URLS)
    // =========================================================================
    public static String buildDialogMakerGuide(
            String dlgTitle,
            int buttonCount,
            String btn1Text,
            String btn1Url,
            String btn2Text,
            String btn2Url,
            String btn3Text,
            String btn3Url,
            String openAnimMode
    ) {
        StringBuilder sb = new StringBuilder();
        sb.append(getDeveloperBannerHeader("💬 ADVANCED DIALOG MAKER — DEX, LINKS & XML GUIDE"));
        sb.append("╔══════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║  💬 MODULE        : CUSTOM POPUP DIALOG WITH DIRECT BUTTON LINKS     ║\n");
        sb.append("║  🏷️ DIALOG TITLE  : ").append(padRight(dlgTitle, 49)).append("║\n");
        sb.append("║  🔘 BUTTONS       : ").append(padRight(buttonCount + " Button(s) | Open Anim: " + openAnimMode, 49)).append("║\n");
        sb.append("║  📦 DEX CLASS     : Lcom/morsalin/xmlcreator/MorsalinCustomDialog;   ║\n");
        sb.append("╚══════════════════════════════════════════════════════════════════════╝\n\n");

        sb.append("🔗 CONFIGURED DIALOG BUTTONS & CLICK LINKS (বাটন ও লিংক তালিকা):\n");
        if (buttonCount >= 2) {
            sb.append("  • Button 1 [").append(btn1Text).append("] -> ")
              .append(btn1Url != null && !btn1Url.trim().isEmpty() ? "Opens Link: " + btn1Url : "Dismisses Dialog").append("\n");
        }
        if (buttonCount == 3) {
            sb.append("  • Button 2 [").append(btn2Text).append("] -> ")
              .append(btn2Url != null && !btn2Url.trim().isEmpty() ? "Opens Link: " + btn2Url : "Dismisses Dialog").append("\n");
        }
        sb.append("  • Button ").append(buttonCount).append(" [").append(btn3Text).append("] -> ")
          .append(btn3Url != null && !btn3Url.trim().isEmpty() ? "Opens Link: " + btn3Url : "Dismisses Dialog").append("\n\n");

        sb.append("📂 FILES INCLUDED IN THIS DIALOG PACKAGE:\n");
        sb.append("  1. classes.dex                        -> Compiled Dialog + Button URL Launcher DEX\n");
        sb.append("  2. res/layout/dialog_morsalin_custom.xml -> Custom Dialog XML Layout\n");
        sb.append("  3. res/drawable/bg_morsalin_dialog.xml   -> Dialog Background & Border XML\n");
        sb.append("  4. res/anim/dialog_open_anim.xml         -> Dialog Opening Animation XML\n");
        sb.append("  5. DIALOG_GUIDE.txt / GUIDE.txt          -> This Custom Dialog Integration Guide\n\n");

        sb.append("========================================================================\n");
        sb.append("🇬🇧 ENGLISH STEP-BY-STEP DIALOG INTEGRATION (MT MANAGER / APKTOOL)\n");
        sb.append("========================================================================\n");
        sb.append("STEP 1 (Add classes.dex to the APK):\n");
        sb.append("  • Open the target APK in MT Manager.\n");
        sb.append("  • Take `classes.dex` from this ZIP and either rename it to the next DEX index (e.g. `classes2.dex` or `classes3.dex`) in the APK root, OR merge it into the main `classes.dex` using Dex Editor Plus.\n\n");
        sb.append("STEP 2 (Copy XML files — Optional for reference/resources):\n");
        sb.append("  • Note: `MorsalinCustomDialog` inside `classes.dex` is 100% standalone! It renders your exact colors, rounded borders, texts, and button links automatically without needing any R.id hex IDs.\n");
        sb.append("  • You can also place `bg_morsalin_dialog.xml` into `res/drawable/` and `dialog_morsalin_custom.xml` into `res/layout/`.\n\n");
        sb.append("STEP 3 (Hook MainActivity->onCreate with 1 line):\n");
        sb.append("  • Open `MainActivity` in Dex Editor Plus, find `.method protected onCreate(Landroid/os/Bundle;)V`, and right after `invoke-super`, paste:\n\n");
        sb.append("    invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->show(Landroid/content/Context;)V\n\n");
        sb.append("  • Save & Sign the APK! When anyone opens the app, your custom dialog will pop up and clicking the button will directly open your configured link!\n\n");

        sb.append("========================================================================\n");
        sb.append("🇧🇩 বাংলা ধাপে ধাপে ডায়ালগ ইন্টিগ্রেশন গাইড (বাটন লিংকসহ)\n");
        sb.append("========================================================================\n");
        sb.append("ধাপ ১ (`classes.dex` অ্যাপে যুক্ত করা):\n");
        sb.append("  • ডাউনলোড করা ZIP ফাইল বা `Downloads/MorsalinXML` ফোল্ডার থেকে `classes.dex` ফাইলটি নিন।\n");
        sb.append("  • MT Manager দিয়ে যে অ্যাপের ভেতর ডায়ালগ বসাতে চান সেটি ওপেন করুন।\n");
        sb.append("  • APK-তে যদি `classes.dex` আগে থেকেই থাকে, তবে আমাদের `classes.dex` ফাইলটির নাম `classes2.dex` (বা `classes3.dex`) করে APK-এর ভেতরে অ্যাড করে দিন। (অথবা Dex Editor Plus দিয়ে দুটি dex একসাথে ওপেন করে Merge করুন)।\n\n");
        sb.append("ধাপ ২ (`MainActivity`-তে ১ লাইনের কোড বসানো):\n");
        sb.append("  • অ্যাপের `MainActivity` ক্লাসের ভেতরে `onCreate(Landroid/os/Bundle;)V` মেথডে যান।\n");
        sb.append("  • `invoke-super {p0, p1}, ...->onCreate(Landroid/os/Bundle;)V` লাইনের নিচে নিচের এই ১টি লাইন পেস্ট করুন:\n\n");
        sb.append("    invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->show(Landroid/content/Context;)V\n\n");
        sb.append("ধাপ ৩ (বাটন লিংক কাজ করার নিয়ম):\n");
        sb.append("  • আপনি বাটনের সাথে যে লিংক (Telegram, YouTube, Update Link বা Website) যুক্ত করেছেন, সেটি সরাসরি `classes.dex` এর ভেতরে সেভ হয়ে গেছে।\n");
        sb.append("  • অ্যাপ ওপেন করলে ডায়ালগ আসবে এবং ইউজার ওই বাটনে চাপ দিলে সরাসরি আপনার দেওয়া লিংকে চলে যাবে!\n");

        sb.append(getDeveloperFooter());
        return sb.toString();
    }

    // =========================================================================
    // GUIDE 5: DEDICATED NOTIFICATION DESIGNER GUIDE (WITH ACTION BUTTON LINKS)
    // =========================================================================
    public static String buildNotificationDesignerGuide(
            String notifStyle,
            String notifTitle,
            int actionCount,
            String mainUrl,
            String act1Text,
            String act1Url,
            String act2Text,
            String act2Url,
            String act3Text,
            String act3Url
    ) {
        StringBuilder sb = new StringBuilder();
        sb.append(getDeveloperBannerHeader("🔔 NOTIFICATION DESIGNER — DEX, ACTION LINKS & XML GUIDE"));
        sb.append("╔══════════════════════════════════════════════════════════════════════╗\n");
        sb.append("║  🔔 MODULE        : ANDROID SYSTEM NOTIFICATION + URL ACTIONS        ║\n");
        sb.append("║  📌 STYLE & TITLE : ").append(padRight("[" + notifStyle + "] " + notifTitle, 49)).append("║\n");
        sb.append("║  📦 DEX CLASS     : Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;║\n");
        sb.append("╚══════════════════════════════════════════════════════════════════════╝\n\n");

        sb.append("🔗 CONFIGURED NOTIFICATION & ACTION BUTTON LINKS (লিংক তালিকা):\n");
        sb.append("  • Notification Body Tap -> ")
          .append(mainUrl != null && !mainUrl.trim().isEmpty() ? "Opens Link: " + mainUrl : "Launches App").append("\n");
        if (actionCount >= 1) {
            sb.append("  • Action Button 1 [").append(act1Text).append("] -> ")
              .append(act1Url != null && !act1Url.trim().isEmpty() ? "Opens Link: " + act1Url : "Uses Default Tap Action").append("\n");
        }
        if (actionCount >= 2) {
            sb.append("  • Action Button 2 [").append(act2Text).append("] -> ")
              .append(act2Url != null && !act2Url.trim().isEmpty() ? "Opens Link: " + act2Url : "Uses Default Tap Action").append("\n");
        }
        if (actionCount >= 3) {
            sb.append("  • Action Button 3 [").append(act3Text).append("] -> ")
              .append(act3Url != null && !act3Url.trim().isEmpty() ? "Opens Link: " + act3Url : "Uses Default Tap Action").append("\n");
        }
        sb.append("\n");

        sb.append("📂 FILES INCLUDED IN THIS NOTIFICATION PACKAGE:\n");
        sb.append("  1. classes.dex                             -> Compiled Notification & URL Helper DEX\n");
        sb.append("  2. res/drawable/ic_morsalin_notification.xml -> Vector Small Icon XML\n");
        sb.append("  3. AndroidManifest_Snippet.xml             -> Required Permission XML Snippet\n");
        sb.append("  4. NOTIFICATION_GUIDE.txt / GUIDE.txt      -> This Notification Integration Guide\n\n");

        sb.append("========================================================================\n");
        sb.append("🇬🇧 ENGLISH STEP-BY-STEP NOTIFICATION INTEGRATION\n");
        sb.append("========================================================================\n");
        sb.append("STEP 1 (Add Permission in AndroidManifest.xml):\n");
        sb.append("  • Open `AndroidManifest.xml` and make sure this permission is present above `<application>`:\n");
        sb.append("    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />\n\n");
        sb.append("STEP 2 (Add classes.dex to the APK):\n");
        sb.append("  • Add `classes.dex` from this ZIP into your APK (rename to `classes2.dex` / `classes3.dex` or merge into `classes.dex` via MT Manager Dex Editor Plus).\n\n");
        sb.append("STEP 3 (Trigger Notification from MainActivity->onCreate):\n");
        sb.append("  • Paste this 1 line inside `MainActivity->onCreate(Landroid/os/Bundle;)V`:\n\n");
        sb.append("    invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;->sendNotification(Landroid/content/Context;)V\n\n");

        sb.append("========================================================================\n");
        sb.append("🇧🇩 বাংলা ধাপে ধাপে নোটিফিকেশন ইন্টিগ্রেশন গাইড (বাটন লিংকসহ)\n");
        sb.append("========================================================================\n");
        sb.append("ধাপ ১ (`AndroidManifest.xml`-এ পারমিশন যোগ করা):\n");
        sb.append("  • অ্যাপের `AndroidManifest.xml` ওপেন করে `<application>` ট্যাগের উপরে নিচের পারমিশন লাইনটি যোগ করুন:\n");
        sb.append("    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />\n\n");
        sb.append("ধাপ ২ (`classes.dex` অ্যাপে যুক্ত করা):\n");
        sb.append("  • ডাউনলোড করা `classes.dex` ফাইলটি MT Manager দিয়ে আপনার টার্গেট APK-তে `classes2.dex` (বা পরের নম্বর) হিসেবে অ্যাড করুন অথবা Dex Editor Plus দিয়ে Merge করুন।\n\n");
        sb.append("ধাপ ৩ (`MainActivity`-তে ১ লাইনের কল যুক্ত করা):\n");
        sb.append("  • `MainActivity` এর `onCreate` মেথডে নিচের লাইনটি পেস্ট করুন:\n\n");
        sb.append("    invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;->sendNotification(Landroid/content/Context;)V\n\n");
        sb.append("ধাপ ৪ (অ্যাকশন বাটন লিংক):\n");
        sb.append("  • নোটিফিকেশন বা অ্যাকশন বাটনে চাপ দিলে সরাসরি আপনার সেট করা লিংকে (Telegram / YouTube / Update URL) নিয়ে যাবে!\n");

        sb.append(getDeveloperFooter());
        return sb.toString();
    }

    /**
     * Legacy helper retained for backward compatibility if called anywhere else.
     */
    public static String buildBilingualGuide(
            String toolName,
            String featureSummary,
            List<String> filePlacementList,
            List<String> englishSteps,
            List<String> bengaliSteps,
            String permissionsOrDepsNoteEn,
            String permissionsOrDepsNoteBn,
            String usageCodeSnippet
    ) {
        return buildAnimationMakerGuide(featureSummary, 1, 700);
    }

    /**
     * Shows the Download Options Dialog using the existing app's button and panel styles.
     * Clicking the main ZIP download button downloads the .zip archive AND extracts all files
     * (classes.dex + XML files + GUIDE.txt) into the Downloads/MorsalinXML/<projectFolderName>/ folder!
     */
    public static void showDownloadDialog(
            Activity context,
            GeneratedPackage pkg,
            String currentTabFileName,
            String currentTabContent
    ) {
        if (context == null || pkg == null) return;

        Dialog dialog = new Dialog(context, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_package_export);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        TextView tvTitle = dialog.findViewById(R.id.tv_export_dialog_title);
        TextView tvSub = dialog.findViewById(R.id.tv_export_dialog_subtitle);
        Button btnZip = dialog.findViewById(R.id.btn_export_zip);
        Button btnDexOnly = dialog.findViewById(R.id.btn_export_smali_only);
        Button btnJavaClass = dialog.findViewById(R.id.btn_export_java_class);
        Button btnSmaliClass = dialog.findViewById(R.id.btn_export_smali_class);
        Button btnAllFiles = dialog.findViewById(R.id.btn_export_all_files);
        Button btnGuideOnly = dialog.findViewById(R.id.btn_export_guide_only);
        Button btnCurrent = dialog.findViewById(R.id.btn_export_current_file);
        Button btnCancel = dialog.findViewById(R.id.btn_export_cancel);

        tvTitle.setText(pkg.toolTitle);
        tvSub.setText(pkg.getTreePreview());

        if (btnZip != null) {
            btnZip.setText("📦 Download ZIP Package");
            btnZip.setOnClickListener(v -> {
                dialog.dismiss();
                FileExporter.ExportResult zipRes = exportPackageAsZip(context, pkg);
                MorsalinToast.show(context, R.drawable.ic_download,
                        zipRes.success ? "ZIP Package Downloaded" : "Export Error",
                        zipRes.success
                                ? "Saved " + pkg.projectFolderName + ".zip to Downloads/MorsalinXML/"
                                : zipRes.message);
            });
        }

        if (btnDexOnly != null) {
            btnDexOnly.setText("⚡ Download classes.dex");
            btnDexOnly.setOnClickListener(v -> {
                dialog.dismiss();
                byte[] dexBytes = pkg.getDexBinary();
                if (dexBytes != null && dexBytes.length > 0) {
                    FileExporter.ExportResult res = saveSingleFileToDownloads(
                            context, "MorsalinXML/" + pkg.projectFolderName,
                            "classes.dex", "application/octet-stream", dexBytes);
                    MorsalinToast.show(context, R.drawable.ic_download,
                            res.success ? "classes.dex Downloaded" : "Export Error", res.message);
                } else {
                    MorsalinToast.show(context, R.drawable.ic_download,
                            "classes.dex Ready", "classes.dex compiled in package!");
                }
            });
        }

        if (btnGuideOnly != null) {
            String guideLabel = pkg.guideFileName != null ? pkg.guideFileName : "hook.smali";
            btnGuideOnly.setText("📜 Download " + guideLabel);
            btnGuideOnly.setOnClickListener(v -> {
                dialog.dismiss();
                String guideName = pkg.guideFileName != null ? pkg.guideFileName : "hook.smali";
                FileExporter.ExportResult res = saveSingleFileToDownloads(
                        context, "MorsalinXML/" + pkg.projectFolderName, guideName, "text/plain",
                        pkg.guideContent.getBytes(StandardCharsets.UTF_8));
                MorsalinToast.show(context, R.drawable.ic_download,
                        res.success ? guideName + " Saved" : "Export Error", res.message);
            });
        }

        if (btnSmaliClass != null) {
            btnSmaliClass.setText("📋 Copy Smali Hook");
            btnSmaliClass.setOnClickListener(v -> {
                dialog.dismiss();
                String hook = (pkg.toolTitle != null && pkg.toolTitle.toLowerCase(Locale.US).contains("toast"))
                        ? "invoke-static {p0}, Lcom/morsalin/toast/MorsalinCustomToast;->show(Landroid/content/Context;)V"
                        : "invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V";
                android.content.ClipboardManager cb = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) {
                    cb.setPrimaryClip(android.content.ClipData.newPlainText("Smali Hook", hook));
                }
                MorsalinToast.show(context, R.drawable.ic_content_copy, "Smali Hook Copied", hook);
            });
        }

        if (btnJavaClass != null) btnJavaClass.setVisibility(View.GONE);
        if (btnAllFiles != null) btnAllFiles.setVisibility(View.GONE);
        if (btnCurrent != null) btnCurrent.setVisibility(View.GONE);

        btnCancel.setText("Close");
        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    /**
     * Shows the Share Options Dialog using the existing app's button and panel styles.
     */
    public static void showShareDialog(
            Context context,
            GeneratedPackage pkg,
            String currentTabFileName,
            String currentTabContent
    ) {
        if (context == null || pkg == null) return;

        Dialog dialog = new Dialog(context, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_package_export);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        TextView tvTitle = dialog.findViewById(R.id.tv_export_dialog_title);
        TextView tvSub = dialog.findViewById(R.id.tv_export_dialog_subtitle);
        Button btnZip = dialog.findViewById(R.id.btn_export_zip);
        Button btnDexOnly = dialog.findViewById(R.id.btn_export_smali_only);
        Button btnGuideOnly = dialog.findViewById(R.id.btn_export_guide_only);
        Button btnSmaliClass = dialog.findViewById(R.id.btn_export_smali_class);
        Button btnJavaClass = dialog.findViewById(R.id.btn_export_java_class);
        Button btnAllFiles = dialog.findViewById(R.id.btn_export_all_files);
        Button btnCurrent = dialog.findViewById(R.id.btn_export_current_file);
        Button btnCancel = dialog.findViewById(R.id.btn_export_cancel);

        tvTitle.setText("Share: " + pkg.toolTitle);
        tvSub.setText(pkg.getTreePreview());

        if (btnZip != null) {
            btnZip.setText("📦 Share ZIP Package");
            btnZip.setOnClickListener(v -> {
                dialog.dismiss();
                sharePackageAsZip(context, pkg);
            });
        }

        if (btnDexOnly != null) {
            btnDexOnly.setText("⚡ Share classes.dex");
            btnDexOnly.setOnClickListener(v -> {
                dialog.dismiss();
                byte[] dexBytes = pkg.getDexBinary();
                if (dexBytes != null && dexBytes.length > 0) {
                    shareSingleTempFile(context, "classes.dex", "application/octet-stream", dexBytes);
                }
            });
        }

        if (btnGuideOnly != null) {
            String guideLabel = pkg.guideFileName != null ? pkg.guideFileName : "hook.smali";
            btnGuideOnly.setText("📜 Share " + guideLabel);
            btnGuideOnly.setOnClickListener(v -> {
                dialog.dismiss();
                String guideName = pkg.guideFileName != null ? pkg.guideFileName : "hook.smali";
                shareSingleTempFile(context, guideName, "text/plain",
                        pkg.guideContent.getBytes(StandardCharsets.UTF_8));
            });
        }

        if (btnSmaliClass != null) {
            btnSmaliClass.setText("📋 Copy Smali Hook");
            btnSmaliClass.setOnClickListener(v -> {
                dialog.dismiss();
                String hook = (pkg.toolTitle != null && pkg.toolTitle.toLowerCase(Locale.US).contains("toast"))
                        ? "invoke-static {p0}, Lcom/morsalin/toast/MorsalinCustomToast;->show(Landroid/content/Context;)V"
                        : "invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V";
                android.content.ClipboardManager cb = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) {
                    cb.setPrimaryClip(android.content.ClipData.newPlainText("Smali Hook", hook));
                }
                if (context instanceof Activity) {
                    MorsalinToast.show((Activity) context, R.drawable.ic_content_copy, "Smali Hook Copied", hook);
                } else {
                    android.widget.Toast.makeText(context, "Smali Hook Copied", android.widget.Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnJavaClass != null) btnJavaClass.setVisibility(View.GONE);
        if (btnAllFiles != null) btnAllFiles.setVisibility(View.GONE);
        if (btnCurrent != null) btnCurrent.setVisibility(View.GONE);

        btnCancel.setText("Close");
        dialog.show();
    }

    public static boolean isUnnecessaryFile(String name) {
        if (name == null || name.trim().isEmpty()) return true;
        String lower = name.toLowerCase(Locale.US);
        if (lower.endsWith(".tmp") || lower.endsWith(".bak") || lower.endsWith(".log")) return true;
        if (lower.contains("toast_config.json") || lower.contains("dialog_config.json")) return true;
        if (lower.contains("toast_manifest.txt") || lower.contains("readme_assets.txt")) return true;
        if (lower.contains("classes_rename.dex")) return true;
        if (lower.equals("readme.txt") || lower.equals("readme.smali")) return true;
        return false;
    }

    public static byte[] buildZipBytes(GeneratedPackage pkg) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            // 1. Write binary files (classes.dex, assets/...) directly into ZIP
            for (Map.Entry<String, byte[]> bEntry : pkg.binaryFiles.entrySet()) {
                byte[] data = bEntry.getValue();
                if (data == null || data.length == 0) continue;
                String key = bEntry.getKey();
                if (isUnnecessaryFile(key)) continue;
                ZipEntry zipEntry = new ZipEntry(key);
                zos.putNextEntry(zipEntry);
                zos.write(data);
                zos.closeEntry();
            }
            // 2. Write smali guide / hook files directly into ZIP
            for (Map.Entry<String, String> entry : pkg.files.entrySet()) {
                String key = entry.getKey();
                if (isUnnecessaryFile(key)) continue;
                String content = entry.getValue();
                if (content == null || content.trim().isEmpty()) continue;
                ZipEntry zipEntry = new ZipEntry(key);
                zos.putNextEntry(zipEntry);
                byte[] data = content.getBytes(StandardCharsets.UTF_8);
                zos.write(data);
                zos.closeEntry();
            }
            zos.finish();
        }
        return baos.toByteArray();
    }

    public static FileExporter.ExportResult exportPackageAsZip(Context context, GeneratedPackage pkg) {
        try {
            byte[] zipBytes = buildZipBytes(pkg);
            String zipFileName = pkg.projectFolderName + ".zip";
            return saveSingleFileToDownloads(context, "MorsalinXML", zipFileName, "application/zip", zipBytes);
        } catch (Exception e) {
            return new FileExporter.ExportResult(false, null, "Failed to create ZIP: " + e.getMessage());
        }
    }

    public static FileExporter.ExportResult exportAllPackageFiles(Context context, GeneratedPackage pkg) {
        int savedCount = 0;
        String baseFolder = "MorsalinXML/" + pkg.projectFolderName;

        cleanupLegacyFilesInFolder(context, baseFolder);
        cleanupLegacyFilesInFolder(context, baseFolder + "/assets");

        // 1. Save binary files (classes.dex, assets/...)
        for (Map.Entry<String, byte[]> bEntry : pkg.binaryFiles.entrySet()) {
            byte[] data = bEntry.getValue();
            if (data == null || data.length == 0) continue;
            String relPath = bEntry.getKey();
            if (isUnnecessaryFile(relPath)) continue;
            String subDir = baseFolder;
            String fileName = relPath;
            if (relPath.contains("/")) {
                int lastSlash = relPath.lastIndexOf('/');
                subDir = baseFolder + "/" + relPath.substring(0, lastSlash);
                fileName = relPath.substring(lastSlash + 1);
            }
            FileExporter.ExportResult res = saveSingleFileToDownloads(
                    context, subDir, fileName, "application/octet-stream", data);
            if (res.success) {
                savedCount++;
            }
        }

        // 2. Save hook.smali / resource files
        for (Map.Entry<String, String> entry : pkg.files.entrySet()) {
            String relPath = entry.getKey();
            if (isUnnecessaryFile(relPath)) continue;
            String content = entry.getValue();
            if (content == null || content.trim().isEmpty()) continue;
            String subDir = baseFolder;
            String fileName = relPath;
            if (relPath.contains("/")) {
                int lastSlash = relPath.lastIndexOf('/');
                subDir = baseFolder + "/" + relPath.substring(0, lastSlash);
                fileName = relPath.substring(lastSlash + 1);
            }
            String mime = fileName.endsWith(".xml") ? "application/xml" : "text/plain";
            FileExporter.ExportResult res = saveSingleFileToDownloads(
                    context, subDir, fileName, mime,
                    content.getBytes(StandardCharsets.UTF_8));
            if (res.success) {
                savedCount++;
            }
        }
        if (savedCount > 0) {
            return new FileExporter.ExportResult(true, "Downloads/" + baseFolder,
                    "Saved " + savedCount + " file(s) to Downloads/" + baseFolder);
        }
        return new FileExporter.ExportResult(false, null, "Could not export files.");
    }

    private static void cleanupLegacyFilesInFolder(Context context, String subFolder) {
        if (context == null || subFolder == null) return;
        String[] legacyNames = {
                "GUIDE.smali", "GUIDE.txt", "ReadMe.smali",
                "toast_config.json", "toast_manifest.txt", "README_ASSETS.txt",
                "dialog_config.json", "classes_rename.dex"
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                String relPath = Environment.DIRECTORY_DOWNLOADS + "/" + subFolder + "/";
                for (String legacy : legacyNames) {
                    try {
                        context.getContentResolver().delete(
                                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                                MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                                new String[]{relPath, legacy}
                        );
                    } catch (Throwable ignored) {}
                }
                try {
                    context.getContentResolver().delete(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                            new String[]{relPath, "%_GUIDE.smali"}
                    );
                } catch (Throwable ignored) {}
            }
            File docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (docsDir != null) {
                File targetDir = new File(docsDir, subFolder);
                if (targetDir.exists() && targetDir.isDirectory()) {
                    File[] children = targetDir.listFiles();
                    if (children != null) {
                        for (File f : children) {
                            String name = f.getName();
                            if (name.endsWith("_GUIDE.smali")) {
                                f.delete();
                            } else {
                                for (String legacy : legacyNames) {
                                    if (legacy.equalsIgnoreCase(name)) {
                                        f.delete();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    public static FileExporter.ExportResult saveSingleFileToDownloads(
            Context context,
            String subFolder,
            String fileName,
            String mimeType,
            byte[] bytes
    ) {
        try {
            if ("hook.smali".equals(fileName) || "classes.dex".equals(fileName)) {
                cleanupLegacyFilesInFolder(context, subFolder);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                String relPath = Environment.DIRECTORY_DOWNLOADS + "/" + subFolder;
                try {
                    context.getContentResolver().delete(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                            new String[]{relPath + "/", fileName}
                    );
                } catch (Throwable ignored) {}

                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);

                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream os = context.getContentResolver().openOutputStream(uri)) {
                        if (os != null) {
                            os.write(bytes);
                            os.flush();
                            return new FileExporter.ExportResult(true,
                                    "Downloads/" + subFolder + "/" + fileName,
                                    "Saved to Downloads/" + subFolder + "/" + fileName);
                        }
                    }
                }
            }

            File docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (docsDir == null) {
                docsDir = context.getFilesDir();
            }
            File targetDir = new File(docsDir, subFolder);
            if (!targetDir.exists()) {
                targetDir.mkdirs();
            }
            File outFile = new File(targetDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                fos.write(bytes);
                fos.flush();
            }
            return new FileExporter.ExportResult(true, outFile.getAbsolutePath(),
                    "Saved to " + subFolder + "/" + fileName);
        } catch (Exception e) {
            return new FileExporter.ExportResult(false, null, "Export failed: " + e.getMessage());
        }
    }

    public static void sharePackageAsZip(Context context, GeneratedPackage pkg) {
        try {
            byte[] zipBytes = buildZipBytes(pkg);
            shareSingleTempFile(context, pkg.projectFolderName + ".zip", "application/zip", zipBytes);
        } catch (Exception e) {
            ShareHelper.shareXmlText(context, pkg.guideContent, pkg.toolTitle);
        }
    }

    public static void shareSingleTempFile(Context context, String fileName, String mimeType, byte[] bytes) {
        try {
            File cacheDir = new File(context.getCacheDir(), "shared");
            if (!cacheDir.exists()) {
                cacheDir.mkdirs();
            }
            File tempFile = new File(cacheDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(bytes);
                fos.flush();
            }
            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", tempFile);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType(mimeType);
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(Intent.EXTRA_SUBJECT, fileName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(intent, "Share " + fileName));
        } catch (Exception e) {
            ShareHelper.shareXmlText(context, new String(bytes, StandardCharsets.UTF_8), fileName);
        }
    }
}
