package com.android.modding.tools.helpers;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

import com.android.modding.tools.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Universal Typing & Animated Text Manager for Morsalin XML Creator.
 * Supports 18 high-end professional animations, continuous looping,
 * speed customization, cursor selection, and seamless whole-app activation.
 */
public class MorsalinTypingTextHelper {

    private static final String PREF_NAME = "morsalin_typing_text_prefs";
    public static final String KEY_TYPING_ENABLED = "key_typing_text_enabled";
    public static final String KEY_TYPING_STYLE = "key_typing_text_style";
    public static final String KEY_TYPING_SPEED = "key_typing_text_speed";
    public static final String KEY_TYPING_CURSOR = "key_typing_text_cursor";
    public static final String KEY_TYPING_LOOP = "key_typing_text_loop";
    public static final String KEY_TYPING_LOOP_DELAY = "key_typing_text_loop_delay";

    public static final int STYLE_TYPEWRITER = 0;
    public static final int STYLE_HACKER_SCRAMBLE = 1;
    public static final int STYLE_NEON_PULSE = 2;
    public static final int STYLE_RAINBOW_SHIMMER = 3;
    public static final int STYLE_BOUNCE_DROP = 4;
    public static final int STYLE_CINEMATIC_FADE = 5;
    public static final int STYLE_QUANTUM_GLITCH = 6;
    public static final int STYLE_ELASTIC_POP = 7;
    public static final int STYLE_GOLD_SHIMMER = 8;
    public static final int STYLE_MATRIX_RAIN = 9;
    public static final int STYLE_RGB_GLITCH = 10;
    public static final int STYLE_LASER_SCANNER = 11;
    public static final int STYLE_3D_FLIP = 12;
    public static final int STYLE_FIRE_MAGMA = 13;
    public static final int STYLE_AURORA_WAVE = 14;
    public static final int STYLE_ARCADE_PIXEL = 15;
    public static final int STYLE_LIGHTNING_ARC = 16;
    public static final int STYLE_HOLOGRAM_GHOST = 17;

    public static final String[] STYLE_NAMES = {
            "1. Classic Typewriter (Cursor)",
            "2. Cyber Hacker Scramble",
            "3. Neon Tube Glow Pulse",
            "4. Rainbow Spectrum Shimmer",
            "5. Bounce Letter Drop",
            "6. Cinematic Smooth Fade",
            "7. Quantum Teleport Glitch",
            "8. Elastic Word Pop",
            "9. Cyber Gold Shimmer",
            "10. Matrix Digital Cipher",
            "11. RGB Chromatic Glitch",
            "12. Laser Beam Scanner",
            "13. 3D Perspective Flip",
            "14. Fire & Magma Flare",
            "15. Aurora Borealis Wave",
            "16. Retro 8-Bit Arcade",
            "17. Electric Lightning Arc",
            "18. Vaporwave Hologram"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Types character by character with blinking terminal cursor & auto-rewind loop",
            "Letters rapidly scramble with cyber symbols before resolving cleanly",
            "Glowing neon tube pulse that sweeps across words with breathing brightness",
            "Dynamic iridescent rainbow spectrum gradient traveling across characters",
            "Playful letter-by-letter spring drop-in from top into position",
            "High-end cinematic word-by-word smooth alpha & tracking transition",
            "Reverse binary quantum glitch pulse resolving into razor cyan",
            "Playful elastic scale overshoot pop for friendly titles & labels",
            "Luxurious golden metallic wave shimmer across characters",
            "Falling green matrix cipher code resolving dynamically into readable text",
            "Cyberpunk RGB channel offset split with horizontal chromatic jitter",
            "High intensity cyan-white laser scan line traveling across the word",
            "Letters tumble and unfold smoothly in 3D perspective space",
            "Incandescent magma orange-yellow heat wave with burning ember glow",
            "Ethereal northern lights wave blending emerald, teal, and violet rays",
            "Classic 8-bit gaming progressive pixel block reveal",
            "Crackling blue-white electric zap burst illuminating each letter",
            "Translucent iridescent vaporwave hologram breathing in soft cycles"
    };

    public static final String[] CURSOR_SYMBOLS = {"|", "_", "█", "◆", "►", ""};
    public static final String[] CURSOR_NAMES = {"Bar (|)", "Underscore (_)", "Cyber Block (█)", "Diamond (◆)", "Arrow (►)", "None"};

    private static final String SCRAMBLE_CHARS = "0101XYZ#%@&<>[]{}/*+=?!$";
    private static final String MATRIX_CHARS = "0110100101110100";

    private static final int[] RAINBOW_COLORS = {
            0xFFFF1744, 0xFFFF9100, 0xFFFFEA00, 0xFF00E676,
            0xFF00E5FF, 0xFF2979FF, 0xFFD500F9
    };
    private static final int[] AURORA_COLORS = {
            0xFF00F5D4, 0xFF00BBF9, 0xFF7209B7, 0xFF4361EE, 0xFF4CC9F0
    };
    private static final int[] MAGMA_COLORS = {
            0xFFFF3D00, 0xFFFF9100, 0xFFFFD600, 0xFFFFAB00, 0xFFFF6D00
    };

    private static final Random RANDOM = new Random();
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static boolean isTypingEnabled(Context context) {
        if (context == null) return false;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getBoolean(KEY_TYPING_ENABLED, false);
    }

    public static void setTypingEnabled(Context context, boolean enabled) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_TYPING_ENABLED, enabled).apply();
    }

    public static boolean isLoopEnabled(Context context) {
        if (context == null) return true;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        // Default to TRUE so animations loop continuously as requested by the user
        return sp.getBoolean(KEY_TYPING_LOOP, true);
    }

    public static void setLoopEnabled(Context context, boolean loop) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_TYPING_LOOP, loop).apply();
    }

    public static int getLoopDelay(Context context) {
        if (context == null) return 1800;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_TYPING_LOOP_DELAY, 1800);
    }

    public static void setLoopDelay(Context context, int delayMs) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_TYPING_LOOP_DELAY, delayMs).apply();
    }

    public static int getTypingStyle(Context context) {
        if (context == null) return STYLE_TYPEWRITER;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_TYPING_STYLE, STYLE_TYPEWRITER);
    }

    public static void setTypingStyle(Context context, int style) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_TYPING_STYLE, Math.max(0, Math.min(style, STYLE_NAMES.length - 1))).apply();
    }

    public static int getTypingSpeed(Context context) {
        if (context == null) return 35;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_TYPING_SPEED, 35);
    }

    public static void setTypingSpeed(Context context, int delayMs) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_TYPING_SPEED, Math.max(10, Math.min(delayMs, 250))).apply();
    }

    public static int getCursorStyle(Context context) {
        if (context == null) return 0;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_TYPING_CURSOR, 0);
    }

    public static void setCursorStyle(Context context, int cursorIndex) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_TYPING_CURSOR, cursorIndex).apply();
    }

    public static void cancelAnimation(TextView textView) {
        if (textView == null) return;
        Object oldRunnable = textView.getTag(R.id.tag_typing_runnable);
        if (oldRunnable instanceof Runnable) {
            MAIN_HANDLER.removeCallbacks((Runnable) oldRunnable);
            textView.setTag(R.id.tag_typing_runnable, null);
        }
        Object oldAnimator = textView.getTag(R.id.tag_typing_animator);
        if (oldAnimator instanceof Animator) {
            ((Animator) oldAnimator).cancel();
            textView.setTag(R.id.tag_typing_animator, null);
        }
    }

    public static void animateText(final TextView textView, final String targetText) {
        animateText(textView, targetText, null);
    }

    public static void animateText(final TextView textView, final String targetText, final Runnable onComplete) {
        if (textView == null) return;
        if (targetText == null || targetText.isEmpty()) {
            textView.setText("");
            if (onComplete != null) onComplete.run();
            return;
        }

        cancelAnimation(textView);

        textView.setTag(R.id.tag_typing_original_text, targetText);

        Context ctx = textView.getContext();
        if (!isTypingEnabled(ctx)) {
            textView.setText(targetText);
            resetViewTransforms(textView);
            if (onComplete != null) onComplete.run();
            return;
        }

        int style = getTypingStyle(ctx);
        int speed = getTypingSpeed(ctx);
        boolean loop = isLoopEnabled(ctx);
        int loopDelay = getLoopDelay(ctx);
        String cursor = CURSOR_SYMBOLS[Math.max(0, Math.min(getCursorStyle(ctx), CURSOR_SYMBOLS.length - 1))];

        Runnable loopCallback = () -> {
            if (onComplete != null) onComplete.run();
            if (loop) {
                scheduleNextLoop(textView, targetText, loopDelay);
            }
        };

        dispatchAnimation(textView, targetText, style, speed, cursor, loopCallback);
    }

    private static void scheduleNextLoop(final TextView tv, final String targetText, final int loopDelay) {
        if (tv == null) return;
        Runnable loopRunnable = new Runnable() {
            @Override
            public void run() {
                if (tv.isAttachedToWindow() && tv.getVisibility() == View.VISIBLE && isTypingEnabled(tv.getContext())) {
                    animateText(tv, targetText);
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, loopRunnable);
        MAIN_HANDLER.postDelayed(loopRunnable, loopDelay);
    }

    private static void resetViewTransforms(TextView tv) {
        tv.setScaleX(1f);
        tv.setScaleY(1f);
        tv.setTranslationX(0f);
        tv.setTranslationY(0f);
        tv.setRotationX(0f);
        tv.setRotationY(0f);
        tv.setAlpha(1f);
    }

    private static void dispatchAnimation(final TextView tv, final String text, int style,
                                          int speed, String cursor, final Runnable onFinish) {
        resetViewTransforms(tv);

        switch (style) {
            case STYLE_HACKER_SCRAMBLE:
                runHackerScramble(tv, text, speed, cursor, onFinish);
                break;
            case STYLE_NEON_PULSE:
                runNeonPulse(tv, text, onFinish);
                break;
            case STYLE_RAINBOW_SHIMMER:
                runRainbowShimmer(tv, text, speed, onFinish);
                break;
            case STYLE_BOUNCE_DROP:
                runBounceDrop(tv, text, speed, onFinish);
                break;
            case STYLE_CINEMATIC_FADE:
                runCinematicFade(tv, text, onFinish);
                break;
            case STYLE_QUANTUM_GLITCH:
                runQuantumGlitch(tv, text, speed, onFinish);
                break;
            case STYLE_ELASTIC_POP:
                runElasticPop(tv, text, onFinish);
                break;
            case STYLE_GOLD_SHIMMER:
                runGoldShimmer(tv, text, speed, onFinish);
                break;
            case STYLE_MATRIX_RAIN:
                runMatrixRain(tv, text, speed, onFinish);
                break;
            case STYLE_RGB_GLITCH:
                runRgbGlitch(tv, text, speed, onFinish);
                break;
            case STYLE_LASER_SCANNER:
                runLaserScanner(tv, text, speed, onFinish);
                break;
            case STYLE_3D_FLIP:
                run3DFlip(tv, text, onFinish);
                break;
            case STYLE_FIRE_MAGMA:
                runFireMagma(tv, text, speed, onFinish);
                break;
            case STYLE_AURORA_WAVE:
                runAuroraWave(tv, text, speed, onFinish);
                break;
            case STYLE_ARCADE_PIXEL:
                runArcadePixel(tv, text, speed, onFinish);
                break;
            case STYLE_LIGHTNING_ARC:
                runLightningArc(tv, text, speed, onFinish);
                break;
            case STYLE_HOLOGRAM_GHOST:
                runHologramGhost(tv, text, onFinish);
                break;
            case STYLE_TYPEWRITER:
            default:
                runClassicTypewriter(tv, text, speed, cursor, onFinish);
                break;
        }
    }

    // 1. Classic Typewriter with blinking cursor
    private static void runClassicTypewriter(final TextView tv, final String text, final int delayMs,
                                             final String cursor, final Runnable onFinish) {
        final int length = text.length();
        final int[] index = {0};

        final Runnable typeStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (index[0] <= length) {
                    String current = text.substring(0, index[0]);
                    boolean showCursor = (index[0] < length) || ((System.currentTimeMillis() / 400) % 2 == 0);
                    tv.setText(current + (showCursor && !cursor.isEmpty() ? cursor : ""));
                    index[0]++;
                    MAIN_HANDLER.postDelayed(this, delayMs);
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };

        tv.setTag(R.id.tag_typing_runnable, typeStep);
        MAIN_HANDLER.post(typeStep);
    }

    // 2. Cyber Hacker Scramble
    private static void runHackerScramble(final TextView tv, final String text, final int delayMs,
                                          final String cursor, final Runnable onFinish) {
        final int length = text.length();
        final int[] revealed = {0};
        final int[] scrambleTicks = {0};

        final Runnable scrambleStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                scrambleTicks[0]++;
                if (scrambleTicks[0] % 2 == 0 && revealed[0] < length) {
                    revealed[0]++;
                }

                if (revealed[0] < length) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(text, 0, revealed[0]);
                    int remaining = length - revealed[0];
                    for (int i = 0; i < remaining; i++) {
                        char c = text.charAt(revealed[0] + i);
                        if (Character.isWhitespace(c)) {
                            sb.append(c);
                        } else {
                            sb.append(SCRAMBLE_CHARS.charAt(RANDOM.nextInt(SCRAMBLE_CHARS.length())));
                        }
                    }
                    if (!cursor.isEmpty()) sb.append(cursor);
                    tv.setText(sb.toString());
                    MAIN_HANDLER.postDelayed(this, Math.max(16, delayMs / 2));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };

        tv.setTag(R.id.tag_typing_runnable, scrambleStep);
        MAIN_HANDLER.post(scrambleStep);
    }

    // 3. Neon Tube Glow Pulse
    private static void runNeonPulse(final TextView tv, final String text, final Runnable onFinish) {
        tv.setText(text);
        final int origColor = tv.getCurrentTextColor();
        ValueAnimator pulseAnim = ValueAnimator.ofFloat(0.4f, 1.25f, 1.0f);
        pulseAnim.setDuration(900);
        pulseAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        pulseAnim.addUpdateListener(animation -> {
            float val = (float) animation.getAnimatedValue();
            tv.setScaleX(Math.min(1.06f, val));
            tv.setScaleY(Math.min(1.06f, val));
            tv.setAlpha(Math.min(1f, val * 0.95f));
            tv.setShadowLayer(18f * Math.max(0.1f, val - 0.7f), 0, 0, 0xFF00E5FF);
        });
        pulseAnim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                resetViewTransforms(tv);
                tv.setTextColor(origColor);
                tv.setTag(R.id.tag_typing_animator, null);
                if (onFinish != null) onFinish.run();
            }
        });
        tv.setTag(R.id.tag_typing_animator, pulseAnim);
        pulseAnim.start();
    }

    // 4. Rainbow Spectrum Shimmer
    private static void runRainbowShimmer(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] wavePos = {0};
        final int totalWaves = length + RAINBOW_COLORS.length + 2;

        final Runnable waveStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (wavePos[0] < totalWaves) {
                    SpannableString ss = new SpannableString(text);
                    for (int i = 0; i < length; i++) {
                        int dist = Math.abs(i - wavePos[0]);
                        if (dist < RAINBOW_COLORS.length) {
                            int color = RAINBOW_COLORS[dist % RAINBOW_COLORS.length];
                            ss.setSpan(new ForegroundColorSpan(color), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    wavePos[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(25, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };

        tv.setTag(R.id.tag_typing_runnable, waveStep);
        MAIN_HANDLER.post(waveStep);
    }

    // 5. Bounce Letter Drop
    private static void runBounceDrop(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] index = {0};

        final Runnable dropStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (index[0] <= length) {
                    tv.setText(text.substring(0, index[0]));
                    tv.setTranslationY(-14f + (index[0] % 2 == 0 ? 4f : -4f));
                    tv.animate().translationY(0f).setDuration(Math.max(45, delayMs * 2)).start();
                    index[0]++;
                    MAIN_HANDLER.postDelayed(this, delayMs);
                } else {
                    tv.setText(text);
                    tv.setTranslationY(0f);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };

        tv.setTag(R.id.tag_typing_runnable, dropStep);
        MAIN_HANDLER.post(dropStep);
    }

    // 6. Cinematic Smooth Fade
    private static void runCinematicFade(final TextView tv, final String text, final Runnable onFinish) {
        tv.setText(text);
        tv.setAlpha(0f);
        tv.setTranslationY(14f);
        tv.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(750)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    resetViewTransforms(tv);
                    if (onFinish != null) onFinish.run();
                })
                .start();
    }

    // 7. Quantum Teleport Glitch
    private static void runQuantumGlitch(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] index = {0};
        final Runnable glitchStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (index[0] <= length) {
                    StringBuilder sb = new StringBuilder(text.substring(0, index[0]));
                    if (index[0] < length) {
                        sb.append(RANDOM.nextBoolean() ? "01" : "10");
                    }
                    tv.setText(sb.toString());
                    tv.setAlpha(0.7f + RANDOM.nextFloat() * 0.3f);
                    index[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(20, delayMs));
                } else {
                    tv.setText(text);
                    tv.setAlpha(1f);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, glitchStep);
        MAIN_HANDLER.post(glitchStep);
    }

    // 8. Elastic Word Pop
    private static void runElasticPop(final TextView tv, final String text, final Runnable onFinish) {
        tv.setText(text);
        tv.setScaleX(0.5f);
        tv.setScaleY(0.5f);
        tv.setAlpha(0f);
        tv.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(600)
                .setInterpolator(new OvershootInterpolator(2.4f))
                .withEndAction(() -> {
                    resetViewTransforms(tv);
                    if (onFinish != null) onFinish.run();
                })
                .start();
    }

    // 9. Cyber Gold Shimmer
    private static void runGoldShimmer(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] wavePos = {0};
        final int[] goldPalette = {0xFFFFD700, 0xFFFFA000, 0xFFFFE082, 0xFFFFFFFF, 0xFFFFD700};
        final int totalWaves = length + goldPalette.length + 2;

        final Runnable waveStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (wavePos[0] < totalWaves) {
                    SpannableString ss = new SpannableString(text);
                    for (int i = 0; i < length; i++) {
                        int dist = Math.abs(i - wavePos[0]);
                        if (dist < goldPalette.length) {
                            ss.setSpan(new ForegroundColorSpan(goldPalette[dist]), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    wavePos[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(25, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, waveStep);
        MAIN_HANDLER.post(waveStep);
    }

    // 10. Matrix Digital Cipher
    private static void runMatrixRain(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] revealed = {0};
        final Runnable matrixStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (revealed[0] <= length) {
                    SpannableString ss = new SpannableString(text);
                    int green = 0xFF00FF66;
                    int bright = 0xFFCCFF90;

                    for (int i = revealed[0]; i < length; i++) {
                        if (!Character.isWhitespace(text.charAt(i))) {
                            char cipher = MATRIX_CHARS.charAt(RANDOM.nextInt(MATRIX_CHARS.length()));
                            ss.setSpan(new ForegroundColorSpan(i == revealed[0] ? bright : green),
                                    i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    revealed[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(18, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, matrixStep);
        MAIN_HANDLER.post(matrixStep);
    }

    // 11. RGB Chromatic Glitch
    private static void runRgbGlitch(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        tv.setText(text);
        final int[] ticks = {0};
        final Runnable glitchLoop = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                ticks[0]++;
                if (ticks[0] < 10) {
                    float shiftX = (RANDOM.nextFloat() - 0.5f) * 12f;
                    tv.setTranslationX(shiftX);
                    tv.setShadowLayer(8f, shiftX, 0, RANDOM.nextBoolean() ? 0xFFFF0055 : 0xFF00E5FF);
                    MAIN_HANDLER.postDelayed(this, Math.max(30, delayMs));
                } else {
                    resetViewTransforms(tv);
                    tv.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, glitchLoop);
        MAIN_HANDLER.post(glitchLoop);
    }

    // 12. Laser Beam Scanner
    private static void runLaserScanner(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] scanIdx = {0};
        final int totalSteps = length + 5;
        final Runnable scanStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (scanIdx[0] < totalSteps) {
                    SpannableString ss = new SpannableString(text);
                    for (int i = 0; i < length; i++) {
                        int diff = Math.abs(i - scanIdx[0]);
                        if (diff == 0) {
                            ss.setSpan(new ForegroundColorSpan(0xFFFFFFFF), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        } else if (diff == 1) {
                            ss.setSpan(new ForegroundColorSpan(0xFF00F5D4), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        } else if (diff == 2) {
                            ss.setSpan(new ForegroundColorSpan(0xFF0077B6), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    scanIdx[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(25, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, scanStep);
        MAIN_HANDLER.post(scanStep);
    }

    // 13. 3D Perspective Flip
    private static void run3DFlip(final TextView tv, final String text, final Runnable onFinish) {
        tv.setText(text);
        tv.setRotationX(90f);
        tv.setAlpha(0f);
        tv.animate()
                .rotationX(0f)
                .alpha(1f)
                .setDuration(700)
                .setInterpolator(new OvershootInterpolator(1.8f))
                .withEndAction(() -> {
                    resetViewTransforms(tv);
                    if (onFinish != null) onFinish.run();
                })
                .start();
    }

    // 14. Fire & Magma Flare
    private static void runFireMagma(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] wavePos = {0};
        final int totalWaves = length + MAGMA_COLORS.length + 2;

        final Runnable magmaStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (wavePos[0] < totalWaves) {
                    SpannableString ss = new SpannableString(text);
                    for (int i = 0; i < length; i++) {
                        int dist = Math.abs(i - wavePos[0]);
                        if (dist < MAGMA_COLORS.length) {
                            ss.setSpan(new ForegroundColorSpan(MAGMA_COLORS[dist]), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    wavePos[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(25, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, magmaStep);
        MAIN_HANDLER.post(magmaStep);
    }

    // 15. Aurora Borealis Wave
    private static void runAuroraWave(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] wavePos = {0};
        final int totalWaves = length + AURORA_COLORS.length + 2;

        final Runnable auroraStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (wavePos[0] < totalWaves) {
                    SpannableString ss = new SpannableString(text);
                    for (int i = 0; i < length; i++) {
                        int dist = Math.abs(i - wavePos[0]);
                        if (dist < AURORA_COLORS.length) {
                            ss.setSpan(new ForegroundColorSpan(AURORA_COLORS[dist]), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                    tv.setText(ss);
                    wavePos[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(25, delayMs));
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, auroraStep);
        MAIN_HANDLER.post(auroraStep);
    }

    // 16. Retro 8-Bit Arcade Sweep
    private static void runArcadePixel(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] count = {0};
        final Runnable arcadeStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (count[0] <= length) {
                    StringBuilder sb = new StringBuilder(text.substring(0, count[0]));
                    if (count[0] < length) sb.append("■");
                    tv.setText(sb.toString());
                    count[0]++;
                    MAIN_HANDLER.postDelayed(this, delayMs);
                } else {
                    tv.setText(text);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, arcadeStep);
        MAIN_HANDLER.post(arcadeStep);
    }

    // 17. Electric Lightning Arc
    private static void runLightningArc(final TextView tv, final String text, final int delayMs, final Runnable onFinish) {
        final int length = text.length();
        final int[] index = {0};
        final Runnable zapStep = new Runnable() {
            @Override
            public void run() {
                if (!tv.isAttachedToWindow()) return;
                if (index[0] <= length) {
                    SpannableString ss = new SpannableString(text);
                    if (index[0] < length) {
                        ss.setSpan(new ForegroundColorSpan(0xFFFFFFFF), index[0], index[0] + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    tv.setText(ss);
                    tv.setShadowLayer(14f, 0, 0, 0xFF00F5D4);
                    index[0]++;
                    MAIN_HANDLER.postDelayed(this, Math.max(22, delayMs));
                } else {
                    tv.setText(text);
                    tv.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
                    tv.setTag(R.id.tag_typing_runnable, null);
                    if (onFinish != null) onFinish.run();
                }
            }
        };
        tv.setTag(R.id.tag_typing_runnable, zapStep);
        MAIN_HANDLER.post(zapStep);
    }

    // 18. Vaporwave Hologram Ghost
    private static void runHologramGhost(final TextView tv, final String text, final Runnable onFinish) {
        tv.setText(text);
        ValueAnimator holoAnim = ValueAnimator.ofFloat(0.3f, 1f, 0.6f, 1f);
        holoAnim.setDuration(950);
        holoAnim.setInterpolator(new LinearInterpolator());
        holoAnim.addUpdateListener(a -> {
            float val = (float) a.getAnimatedValue();
            tv.setAlpha(val);
            tv.setShadowLayer(16f * val, 0, 0, 0xFFFF007F);
        });
        holoAnim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                resetViewTransforms(tv);
                tv.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
                tv.setTag(R.id.tag_typing_animator, null);
                if (onFinish != null) onFinish.run();
            }
        });
        tv.setTag(R.id.tag_typing_animator, holoAnim);
        holoAnim.start();
    }

    /**
     * Applies Universal Typing / Animated Text to all appropriate TextViews in the Activity hierarchy.
     */
    public static void applyUniversalTextAnimation(final android.app.Activity activity) {
        if (activity == null || !isTypingEnabled(activity)) return;
        try {
            android.view.View content = activity.findViewById(android.R.id.content);
            if (content != null) {
                content.postDelayed(() -> applyUniversalTextAnimation(content), 120);
            }
        } catch (Throwable ignored) {}
    }

    public static void applyUniversalTextAnimation(final android.view.View root) {
        if (root == null || !isTypingEnabled(root.getContext())) return;
        List<TextView> targets = new ArrayList<>();
        collectEligibleTextViews(root, targets);

        int count = Math.min(targets.size(), 50);
        for (int i = 0; i < count; i++) {
            final TextView tv = targets.get(i);
            CharSequence cs = tv.getText();
            if (cs == null) continue;
            final String original = cs.toString();
            final long delay = (i % 6) * 110L;
            MAIN_HANDLER.postDelayed(() -> {
                if (tv.isAttachedToWindow() && tv.getVisibility() == View.VISIBLE) {
                    animateText(tv, original);
                }
            }, delay);
        }
    }

    private static void collectEligibleTextViews(android.view.View v, List<TextView> list) {
        if (v == null || list.size() >= 50) return;
        if (v instanceof android.widget.EditText) {
            return; // Never disrupt user typing inputs
        }
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            CharSequence cs = tv.getText();
            if (cs != null) {
                String str = cs.toString().trim();
                // Pick headers, titles, cards, labels between 2 and 90 characters
                if (str.length() >= 2 && str.length() <= 90
                        && !str.startsWith("0x")
                        && !str.contains("<?xml")
                        && !str.contains("class ")
                        && !str.contains("import ")) {
                    list.add(tv);
                }
            }
            return;
        }
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup vg = (android.view.ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collectEligibleTextViews(vg.getChildAt(i), list);
            }
        }
    }
}
