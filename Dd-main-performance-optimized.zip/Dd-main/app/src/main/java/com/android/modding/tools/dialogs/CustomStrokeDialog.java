package com.android.modding.tools.dialogs;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;



public class CustomStrokeDialog extends Dialog {

    public interface OnStrokeAppliedListener {
        void onStrokeApplied(int widthDp, int dashWidthDp, int dashGapDp);
    }

    private final StrokeModel initialStroke;
    private final OnStrokeAppliedListener listener;
    private OnStrokeAppliedListener liveListener;

    private SeekBar seekWidth, seekDashWidth, seekDashGap;
    private TextView tvWidthVal, tvDashWidthVal, tvDashGapVal;

    public CustomStrokeDialog(Context context, StrokeModel initialStroke, OnStrokeAppliedListener listener) {
        super(context, R.style.Theme_MyApplication_Dialog);
        this.initialStroke = initialStroke != null ? initialStroke.copy() : new StrokeModel();
        this.listener = listener;
    }

    public CustomStrokeDialog setLiveListener(OnStrokeAppliedListener liveListener) {
        this.liveListener = liveListener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_custom_stroke);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setLayout((int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.90),
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        seekWidth = findViewById(R.id.seek_stroke_width);
        seekDashWidth = findViewById(R.id.seek_dash_width);
        seekDashGap = findViewById(R.id.seek_dash_gap);

        tvWidthVal = findViewById(R.id.tv_stroke_width_val);
        tvDashWidthVal = findViewById(R.id.tv_dash_width_val);
        tvDashGapVal = findViewById(R.id.tv_dash_gap_val);

        Button btnWidthMinus = findViewById(R.id.btn_stroke_width_minus);
        Button btnWidthPlus = findViewById(R.id.btn_stroke_width_plus);
        Button btnDashWidthMinus = findViewById(R.id.btn_dash_width_minus);
        Button btnDashWidthPlus = findViewById(R.id.btn_dash_width_plus);
        Button btnDashGapMinus = findViewById(R.id.btn_dash_gap_minus);
        Button btnDashGapPlus = findViewById(R.id.btn_dash_gap_plus);

        Button btnApply = findViewById(R.id.btn_stroke_apply);

        // Initial values
        seekWidth.setProgress(initialStroke.getWidthDp());
        seekDashWidth.setProgress(initialStroke.getDashWidthDp());
        seekDashGap.setProgress(initialStroke.getDashGapDp());

        updateLabels();

        // Plus / minus buttons
        btnWidthMinus.setOnClickListener(v -> {
            seekWidth.setProgress(Math.max(0, seekWidth.getProgress() - 1));
            updateLabels();
            notifyLiveChange();
        });
        btnWidthPlus.setOnClickListener(v -> {
            seekWidth.setProgress(Math.min(30, seekWidth.getProgress() + 1));
            updateLabels();
            notifyLiveChange();
        });

        btnDashWidthMinus.setOnClickListener(v -> {
            seekDashWidth.setProgress(Math.max(0, seekDashWidth.getProgress() - 1));
            updateLabels();
            notifyLiveChange();
        });
        btnDashWidthPlus.setOnClickListener(v -> {
            seekDashWidth.setProgress(Math.min(50, seekDashWidth.getProgress() + 1));
            updateLabels();
            notifyLiveChange();
        });

        btnDashGapMinus.setOnClickListener(v -> {
            seekDashGap.setProgress(Math.max(0, seekDashGap.getProgress() - 1));
            updateLabels();
            notifyLiveChange();
        });
        btnDashGapPlus.setOnClickListener(v -> {
            seekDashGap.setProgress(Math.min(50, seekDashGap.getProgress() + 1));
            updateLabels();
            notifyLiveChange();
        });

        SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateLabels();
                notifyLiveChange();
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seekWidth.setOnSeekBarChangeListener(seekListener);
        seekDashWidth.setOnSeekBarChangeListener(seekListener);
        seekDashGap.setOnSeekBarChangeListener(seekListener);

        btnApply.setOnClickListener(v -> {
            if (this.listener != null) {
                this.listener.onStrokeApplied(seekWidth.getProgress(), seekDashWidth.getProgress(), seekDashGap.getProgress());
            }
            dismiss();
        });
    }

    private void notifyLiveChange() {
        if (liveListener != null) {
            liveListener.onStrokeApplied(seekWidth.getProgress(), seekDashWidth.getProgress(), seekDashGap.getProgress());
        }
    }

    private void updateLabels() {
        tvWidthVal.setText(seekWidth.getProgress() + "dp");
        tvDashWidthVal.setText(seekDashWidth.getProgress() + "dp");
        tvDashGapVal.setText(seekDashGap.getProgress() + "dp");
    }
}
