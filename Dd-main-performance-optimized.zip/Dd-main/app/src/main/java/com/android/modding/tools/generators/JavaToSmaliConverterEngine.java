package com.android.modding.tools.generators;

import android.content.Context;

/**
 * Authoritative Java-to-Smali Bytecode Converter Engine.
 * Converts Java source code using the real Android compilation pipeline:
 * Java source → ECJ Java compiler → JVM bytecode (.class) → Android D8 compiler → DEX → Baksmali disassembler → Smali (.smali).
 */
public class JavaToSmaliConverterEngine {

    public static class ConversionOutput {
        public final boolean success;
        public final String smaliCode;
        public final String className;
        public final String packageName;
        public final int fieldsCount;
        public final int methodsCount;
        public final String errorMessage;

        public ConversionOutput(boolean success, String smaliCode, String className,
                                String packageName, int fieldsCount, int methodsCount, String errorMessage) {
            this.success = success;
            this.smaliCode = smaliCode != null ? smaliCode : "";
            this.className = className != null ? className : "UnknownClass";
            this.packageName = packageName != null ? packageName : "";
            this.fieldsCount = fieldsCount;
            this.methodsCount = methodsCount;
            this.errorMessage = errorMessage != null ? errorMessage : "";
        }
    }

    public static ConversionOutput convert(String javaCode) {
        return convert(null, javaCode, "CustomCode.java", null);
    }

    public static ConversionOutput convert(Context context, String javaCode, String fileName, JavaToSmaliToolchain.ProgressListener listener) {
        if (javaCode == null || javaCode.trim().isEmpty()) {
            return new ConversionOutput(false, "", "", "", 0, 0, "Java code is empty.");
        }

        JavaToSmaliToolchain.CompilationResult res = JavaToSmaliToolchain.compile(context, javaCode, fileName, listener);
        if (res.success) {
            return new ConversionOutput(
                    true,
                    res.primarySmaliContent,
                    res.primaryClassName,
                    res.packageName,
                    res.fieldsCount,
                    res.methodsCount,
                    ""
            );
        } else {
            String err = res.errorDetails != null && !res.errorDetails.isEmpty() ? res.errorDetails : res.errorMessage;
            return new ConversionOutput(
                    false,
                    "",
                    res.primaryClassName,
                    res.packageName,
                    0,
                    0,
                    err
            );
        }
    }
}
