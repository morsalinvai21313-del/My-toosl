package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    public static final String EXTRA_OPEN_TRANSITIONS = "extra_open_transitions";
    public static final String EXTRA_OPEN_CONVERTER_ANIMS = "extra_open_converter_anims";
    public static final String EXTRA_OPEN_ABOUT = "extra_open_about";
    private static final String PREF_SETTINGS = "morsalin_app_settings";
    public static final String KEY_CONVERTER_SPEED = "converter_anim_speed"; // 0=Fast, 1=Normal, 2=Cinematic
    public static final String KEY_XML_INDENT = "xml_indent_spaces"; // 4 or 2

    // Developer Social Links provided by user
    private static final String URL_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";
    private static final String URL_GITHUB = "https://github.com/morsalinvai21313-del/Dd";
    private static final String URL_TELEGRAM_CHANNEL = "https://t.me/anonymous_modder_king";
    private static final String URL_YOUTUBE = "https://www.youtube.com/@apk.modding";

    private static final int SCREEN_MAIN = 0;
    private static final int SCREEN_TRANSITIONS = 1;
    private static final int SCREEN_CONVERTER_ANIMS = 2;
    private static final int SCREEN_ABOUT_DEVELOPER = 3;

    private int currentSubScreen = SCREEN_MAIN;

    private ScrollView scrollSettingsMenu;
    private ScrollView scrollTransitionPicker;
    private ScrollView scrollConverterAnimPicker;
    private ScrollView scrollAboutDeveloper;

    private TextView tvHeaderTitle;
    private TextView tvMenuCurrentTransition;
    private TextView tvMenuCurrentConverterAnim;
    private TextView tvMenuConverterSpeed;
    private TextView tvMenuXmlIndent;
    private TextView tvMenuTouchParticles;
    private TextView tvMenuDividerAnim;
    private TextView tvMenuTypingAnim;
    private TextView tvMenuStaggeredEntrance;
    private TextView tvMenuButtonPress;
    private TextView tvMenuAmbientBg;
    private TextView tvMenuAmbientGlow;
    private TextView tvMenuLightingTextAnim;

    // Transition Studio views
    private LinearLayout layoutAnimOptions;
    private TextView tvTransActiveSummary;
    private Button btnTransShuffleOff, btnTransShuffleAll, btnTransShuffleCyber;
    private EditText etCustomTransName;
    private Button btnPickTransForward, btnPickTransBackward, btnSaveCustomTransition;
    private Button btnTransFilterAll, btnTransFilterHacking, btnTransFilterCinematic, btnTransFilterClassic;
    private String currentTransFilter = "ALL";
    private int customForwardIndex = 20; // Default: 21. Cyber Glitch Breach
    private int customBackwardIndex = 16; // Default: 17. Hologram Laser Beam

    // Universal Conversion Visual Animation Studio views
    private LinearLayout layoutConverterAnimOptions;
    private ConversionAnimationView viewSettingsConvPreview;
    private TextView tvConvPreviewTitle, tvConvPreviewBadge;
    private Button btnConvPreviewReplay, btnConvPreviewSwapDir, btnConvPreviewSpeed;
    private Button btnConvShuffleOff, btnConvShuffleAll, btnConvShuffleHacking;
    private EditText etCustomConvName;
    private Button btnPickConvEngine, btnPickConvPalette, btnToggleConvOverdrive, btnSaveCustomConvAnim;
    private Button btnConvFilterAll, btnConvFilterHacking, btnConvFilterCinematic, btnConvFilterCustom;
    private String currentConvFilter = "ALL";
    private boolean previewForwardStream = true;
    private int builderEngineType = ConverterAnimationManager.ENGINE_MATRIX_RAIN;
    private int builderPaletteType = ConverterAnimationManager.PALETTE_CYBER_NEON;
    private boolean builderOverdrive = true;

    // Lazy load flags to eliminate lag when opening Settings
    private boolean transitionListPopulated = false;
    private boolean converterAnimListPopulated = false;

    // About Developer views
    private AnimatedAvatarBorderView viewAvatarSanny;
    private AnimatedAvatarBorderView viewAvatarMorsalin;
    private MovieCreditsTickerView tickerAboutLeft;
    private MovieCreditsTickerView tickerAboutRight;

    private final Handler previewHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        GlobalTouchParticleManager.attach(this);

        bindViews();
        setupMainMenuListeners();
        setupTransitionStudioListeners();
        setupConverterAnimStudioListeners();
        setupAboutDeveloperScreen();

        refreshMenuSummaries();

        if (getIntent().getBooleanExtra(EXTRA_OPEN_TRANSITIONS, false)) {
            showTransitionPicker(false);
        } else if (getIntent().getBooleanExtra(EXTRA_OPEN_CONVERTER_ANIMS, false)) {
            showConverterAnimPicker(false);
        } else if (getIntent().getBooleanExtra(EXTRA_OPEN_ABOUT, false)) {
            MorsalinDialogHelper.showAboutDialog(this);
        } else {
            if (scrollSettingsMenu != null && scrollSettingsMenu.getChildCount() > 0 && scrollSettingsMenu.getChildAt(0) instanceof LinearLayout) {
                StaggeredEntranceAnimationHelper.animateContainer((LinearLayout) scrollSettingsMenu.getChildAt(0), this);
            }
        }
        AmbientGlowAnimationHelper.attachPulseToView(findViewById(R.id.card_touch_playground), this);
    }

    private void bindViews() {
        scrollSettingsMenu = findViewById(R.id.scroll_settings_menu);
        scrollTransitionPicker = findViewById(R.id.scroll_transition_picker);
        scrollConverterAnimPicker = findViewById(R.id.scroll_converter_anim_picker);
        scrollAboutDeveloper = findViewById(R.id.scroll_about_developer);

        tvHeaderTitle = findViewById(R.id.tv_settings_header_title);
        tvMenuCurrentTransition = findViewById(R.id.tv_menu_current_transition);
        tvMenuCurrentConverterAnim = findViewById(R.id.tv_menu_current_converter_anim);
        tvMenuConverterSpeed = findViewById(R.id.tv_menu_converter_speed);
        tvMenuXmlIndent = findViewById(R.id.tv_menu_xml_indent);
        tvMenuTouchParticles = findViewById(R.id.tv_menu_touch_particles);
        tvMenuDividerAnim = findViewById(R.id.tv_menu_divider_anim);
        tvMenuTypingAnim = findViewById(R.id.tv_menu_typing_anim);
        tvMenuStaggeredEntrance = findViewById(R.id.tv_menu_staggered_entrance);
        tvMenuButtonPress = findViewById(R.id.tv_menu_button_press);
        tvMenuAmbientBg = findViewById(R.id.tv_menu_ambient_bg);
        tvMenuAmbientGlow = findViewById(R.id.tv_menu_ambient_glow);
        tvMenuLightingTextAnim = findViewById(R.id.tv_menu_lighting_text_anim);

        // Transition Studio
        layoutAnimOptions = findViewById(R.id.layout_anim_options);
        tvTransActiveSummary = findViewById(R.id.tv_trans_active_summary);
        btnTransShuffleOff = findViewById(R.id.btn_trans_shuffle_off);
        btnTransShuffleAll = findViewById(R.id.btn_trans_shuffle_all);
        btnTransShuffleCyber = findViewById(R.id.btn_trans_shuffle_cyber);
        etCustomTransName = findViewById(R.id.et_custom_trans_name);
        btnPickTransForward = findViewById(R.id.btn_pick_trans_forward);
        btnPickTransBackward = findViewById(R.id.btn_pick_trans_backward);
        btnSaveCustomTransition = findViewById(R.id.btn_save_custom_transition);
        btnTransFilterAll = findViewById(R.id.btn_trans_filter_all);
        btnTransFilterHacking = findViewById(R.id.btn_trans_filter_hacking);
        btnTransFilterCinematic = findViewById(R.id.btn_trans_filter_cinematic);
        btnTransFilterClassic = findViewById(R.id.btn_trans_filter_classic);

        // Conversion Visual Studio
        layoutConverterAnimOptions = findViewById(R.id.layout_converter_anim_options);
        viewSettingsConvPreview = findViewById(R.id.view_settings_conv_preview);
        tvConvPreviewTitle = findViewById(R.id.tv_conv_preview_title);
        tvConvPreviewBadge = findViewById(R.id.tv_conv_preview_badge);
        btnConvPreviewReplay = findViewById(R.id.btn_conv_preview_replay);
        btnConvPreviewSwapDir = findViewById(R.id.btn_conv_preview_swap_dir);
        btnConvPreviewSpeed = findViewById(R.id.btn_conv_preview_speed);
        btnConvShuffleOff = findViewById(R.id.btn_conv_shuffle_off);
        btnConvShuffleAll = findViewById(R.id.btn_conv_shuffle_all);
        btnConvShuffleHacking = findViewById(R.id.btn_conv_shuffle_hacking);
        etCustomConvName = findViewById(R.id.et_custom_conv_name);
        btnPickConvEngine = findViewById(R.id.btn_pick_conv_engine);
        btnPickConvPalette = findViewById(R.id.btn_pick_conv_palette);
        btnToggleConvOverdrive = findViewById(R.id.btn_toggle_conv_overdrive);
        btnSaveCustomConvAnim = findViewById(R.id.btn_save_custom_conv_anim);
        btnConvFilterAll = findViewById(R.id.btn_conv_filter_all);
        btnConvFilterHacking = findViewById(R.id.btn_conv_filter_hacking);
        btnConvFilterCinematic = findViewById(R.id.btn_conv_filter_cinematic);
        btnConvFilterCustom = findViewById(R.id.btn_conv_filter_custom);

        // About Developer
        viewAvatarSanny = findViewById(R.id.view_avatar_sanny);
        viewAvatarMorsalin = findViewById(R.id.view_avatar_morsalin);
        tickerAboutLeft = findViewById(R.id.ticker_about_left);
        tickerAboutRight = findViewById(R.id.ticker_about_right);
    }

    private void setupMainMenuListeners() {
        findViewById(R.id.btn_settings_back).setOnClickListener(v -> handleBackNavigation());

        findViewById(R.id.card_menu_transitions).setOnClickListener(v -> showTransitionPicker(true));

        findViewById(R.id.card_menu_converter_anims).setOnClickListener(v -> showConverterAnimPicker(true));

        findViewById(R.id.card_menu_converter_speed).setOnClickListener(v -> cycleConverterSpeed());

        findViewById(R.id.card_menu_xml_indent).setOnClickListener(v -> {
            SharedPreferences sp = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
            int current = sp.getInt(KEY_XML_INDENT, 4);
            int next = (current == 4) ? 2 : 4;
            sp.edit().putInt(KEY_XML_INDENT, next).apply();
            refreshMenuSummaries();
            MorsalinToast.show(this, R.drawable.ic_cat_layout,
                    "Indentation Updated",
                    "Indentation set to " + next + " spaces.");
        });

        findViewById(R.id.card_menu_touch_particles).setOnClickListener(v -> showTouchParticleDialog());

        findViewById(R.id.card_menu_divider_anims).setOnClickListener(v -> showDividerAnimationDialog());
        findViewById(R.id.card_menu_lighting_text_anims).setOnClickListener(v -> showLightingTextAnimDialog());

        findViewById(R.id.card_menu_staggered_entrance).setOnClickListener(v -> showStaggeredEntranceDialog());

        findViewById(R.id.card_menu_button_press).setOnClickListener(v -> showButtonPressDialog());

        findViewById(R.id.card_menu_ambient_bg).setOnClickListener(v -> showAmbientBgDialog());

        findViewById(R.id.card_menu_ambient_glow).setOnClickListener(v -> showAmbientGlowDialog());

        findViewById(R.id.card_menu_typing_anim).setOnClickListener(v -> showTypingAnimDialog());

        findViewById(R.id.card_touch_playground).setOnClickListener(v -> {
            int style = GlobalTouchParticleManager.getSavedStyle(this);
            String name = (style >= 0 && style < TouchParticleOverlayView.STYLE_NAMES.length)
                    ? TouchParticleOverlayView.STYLE_NAMES[style] : "Active Style";
            MorsalinToast.show(this, R.drawable.ic_settings_anim, "Touch Particle Burst!", name);
        });

        findViewById(R.id.card_menu_reset_defaults).setOnClickListener(v -> {
            TransitionAnimationManager.setSelectedAnimation(this, "anim_slide_horizontal");
            TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_OFF);
            ConverterAnimationManager.resetToDefault(this);
            GlobalTouchParticleManager.setSavedStyle(this, TouchParticleOverlayView.STYLE_GOLDEN_STARS);
            AnimatedDividerManager.setSavedStyle(this, AnimatedDividerManager.STYLE_LIGHT_SWEEP_LTR);
            LightingTextAnimationManager.setSavedStyle(this, LightingTextAnimationManager.STYLE_CYBER_NEON);
            LightingTextAnimationManager.setEnabled(this, false);
            ButtonPressAnimationHelper.setSavedStyle(this, ButtonPressAnimationHelper.STYLE_SPRING_BOUNCE);
            AmbientBackgroundAnimationManager.setSavedStyle(this, AmbientBackgroundAnimationManager.STYLE_CYBER_STARFIELD);
            AmbientGlowAnimationHelper.setSavedStyle(this, AmbientGlowAnimationHelper.STYLE_CYBER_NEON);
            StaggeredEntranceAnimationHelper.setSavedStyle(this, StaggeredEntranceAnimationHelper.STYLE_CASCADE_SLIDE);
            MorsalinTypingTextHelper.setTypingEnabled(this, true);
            GlobalTouchParticleManager.refreshAll(this);

            SharedPreferences sp = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
            sp.edit().putInt(KEY_CONVERTER_SPEED, 1).putInt(KEY_XML_INDENT, 4).apply();
            refreshMenuSummaries();
            populateTransitionList();
            populateConverterAnimList();
            MorsalinToast.show(this, R.drawable.ic_refresh_reset,
                    "Defaults Restored",
                    "All animations & preferences reset to default.");
        });

        findViewById(R.id.card_menu_about_developer).setOnClickListener(v -> MorsalinDialogHelper.showAboutDialog(this));
    }

    private void setupAboutDeveloperScreen() {
        if (viewAvatarSanny != null) {
            viewAvatarSanny.setAvatarList(
                    new int[]{
                            R.drawable.img_avatar_sanny,
                            R.drawable.avatar_sanny_dj_1790834248190,
                            R.drawable.avatar_sanny_modder_1790834263619
                    },
                    0xFFFFB703, 0xFF00E5FF, 0xFFFF2A85
            );
        }
        if (viewAvatarMorsalin != null) {
            viewAvatarMorsalin.setAvatarList(
                    new int[]{
                            R.drawable.img_avatar_morsalin,
                            R.drawable.avatar_morsalin_cyber_1790834216696,
                            R.drawable.avatar_morsalin_neon_1790834232712
                    },
                    0xFF00E5FF, 0xFFFF2A85, 0xFF00FF9D
            );
        }

        // Left Box Topic: Toolkit Capabilities, Visual Engines & Architecture Credits
        if (tickerAboutLeft != null) {
            tickerAboutLeft.setCreditLines(new String[]{
                    "★ TOOLKIT ARCHITECTURE ★",
                    "• 3D & Normal Drawable Studio",
                    "• Multi-Stop Gradient Engine",
                    "• Interactive Layout XML Builder",
                    "• Universal Conversion Engine",
                    "⚡ 17+ Cinematic Visual Shaders",
                    "• Quantum Core & Matrix Rain",
                    "• AI Neural Cortex & Singularity",
                    "• Eldritch Mandala & Mech HUD",
                    "• Crystal Prism & Supernova",
                    "⚡ 25+ Screen Transitions",
                    "• Custom Mix & Match Studio",
                    "• Zero-Error AST Syntax Verifier",
                    "• Auto-Fix & Nullability Engine",
                    "• Real-Time Live XML Renderer",
                    "• Custom Asset Font System",
                    "• One-Click SAF Export & Share",
                    "━━ENGINEERED FOR PRECISION━━",
                    ""
            });
        }

        // Right Box Topic: Developer Story, Vision & Community Credits
        if (tickerAboutRight != null) {
            tickerAboutRight.setCreditLines(new String[]{
                    "★ DEVELOPER CREDITS ★",
                    "🔥 Sanny — Program Creator",
                    "• Core Systems & Modding Logic",
                    "• UI/UX Architecture & Design",
                    "🔥 Morsalin — Lead Modder",
                    "• Graphic Design & Cyber Theme",
                    "• App Modding & Tool Engineering",
                    "★ OUR MISSION & VISION ★",
                    "• Empower Android Modders",
                    "• 100% Offline High-Speed Tools",
                    "• Next-Gen Hacking Visuals",
                    "• Clean & Professional Workflow",
                    "★ OFFICIAL COMMUNITY ★",
                    "• Telegram: @anonymous_modder_king",
                    "• YouTube: @apk.modding",
                    "• GitHub: morsalinvai21313-del",
                    "• Thank You For Using Our App!",
                    "━━THIS TOOLS BY MORSALIN━━",
                    ""
            });
        }

        findViewById(R.id.btn_about_github).setOnClickListener(v -> openExternalLink(URL_GITHUB));
        findViewById(R.id.btn_about_telegram_channel).setOnClickListener(v -> openExternalLink(URL_TELEGRAM_CHANNEL));
        findViewById(R.id.btn_about_youtube).setOnClickListener(v -> openExternalLink(URL_YOUTUBE));
        findViewById(R.id.btn_about_facebook).setOnClickListener(v -> openExternalLink(URL_FACEBOOK));
    }

    private void openExternalLink(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Link", url);
        }
    }

    private void cycleConverterSpeed() {
        SharedPreferences sp = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
        int current = sp.getInt(KEY_CONVERTER_SPEED, 1);
        int next = (current + 1) % 3;
        sp.edit().putInt(KEY_CONVERTER_SPEED, next).apply();
        refreshMenuSummaries();
        String label = next == 0 ? "Fast (Turbo)" : (next == 1 ? "Normal (Balanced)" : "Cinematic (Detailed)");
        MorsalinToast.show(this, R.drawable.ic_code_convert,
                "Animation Speed Updated",
                "Conversion speed set to " + label);
    }

    // =========================================================================
    // SCREEN TRANSITION STUDIO LOGIC
    // =========================================================================
    private void setupTransitionStudioListeners() {
        updateCustomTransBuilderButtons();

        btnTransShuffleOff.setOnClickListener(v -> {
            TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_OFF);
            refreshMenuSummaries();
            populateTransitionList();
            MorsalinToast.show(this, R.drawable.ic_settings_anim, "Fixed Transition Mode",
                    "Using your selected screen transition.");
        });

        btnTransShuffleAll.setOnClickListener(v -> {
            TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_ALL);
            refreshMenuSummaries();
            populateTransitionList();
            MorsalinToast.show(this, R.drawable.ic_settings_anim, "Shuffle All Enabled",
                    "Every screen change will play a random transition!");
        });

        btnTransShuffleCyber.setOnClickListener(v -> {
            TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_CYBER_CINEMA);
            refreshMenuSummaries();
            populateTransitionList();
            MorsalinToast.show(this, R.drawable.ic_settings_anim, "Cyber & Cinema Shuffle",
                    "Randomizing between Hacking & Cinematic transitions!");
        });

        btnPickTransForward.setOnClickListener(v -> showBuiltInTransitionPickerDialog(true));
        btnPickTransBackward.setOnClickListener(v -> showBuiltInTransitionPickerDialog(false));

        btnSaveCustomTransition.setOnClickListener(v -> {
            List<TransitionAnimationManager.AnimItem> builtIns = TransitionAnimationManager.getAnimations();
            TransitionAnimationManager.AnimItem fItem = builtIns.get(customForwardIndex % builtIns.size());
            TransitionAnimationManager.AnimItem bItem = builtIns.get(customBackwardIndex % builtIns.size());
            String customName = etCustomTransName.getText().toString().trim();
            if (customName.isEmpty()) {
                customName = TransitionAnimationManager.stripNumberPrefix(fItem.name).split(" ")[0]
                        + " + " + TransitionAnimationManager.stripNumberPrefix(bItem.name).split(" ")[0];
            }
            TransitionAnimationManager.AnimItem created =
                    TransitionAnimationManager.createCustomTransition(this, customName, fItem.id, bItem.id);
            etCustomTransName.setText("");
            currentTransFilter = "ALL";
            updateTransitionFilterUI();
            refreshMenuSummaries();
            populateTransitionList();
            MorsalinToast.show(this, R.drawable.ic_settings_anim,
                    "Custom Transition Created!",
                    created.name + " is now active across the app.");
        });

        btnTransFilterAll.setOnClickListener(v -> {
            currentTransFilter = "ALL";
            updateTransitionFilterUI();
            populateTransitionList();
        });
        btnTransFilterHacking.setOnClickListener(v -> {
            currentTransFilter = TransitionAnimationManager.CAT_HACKING;
            updateTransitionFilterUI();
            populateTransitionList();
        });
        btnTransFilterCinematic.setOnClickListener(v -> {
            currentTransFilter = TransitionAnimationManager.CAT_CINEMATIC;
            updateTransitionFilterUI();
            populateTransitionList();
        });
        btnTransFilterClassic.setOnClickListener(v -> {
            currentTransFilter = TransitionAnimationManager.CAT_CLASSIC;
            updateTransitionFilterUI();
            populateTransitionList();
        });
    }

    private void showBuiltInTransitionPickerDialog(boolean isForward) {
        List<TransitionAnimationManager.AnimItem> builtIns = TransitionAnimationManager.getAnimations();
        String[] labels = new String[builtIns.size()];
        for (int i = 0; i < builtIns.size(); i++) {
            labels[i] = builtIns.get(i).name;
        }
        new AlertDialog.Builder(this)
                .setTitle(isForward ? "Select Forward Enter Animation" : "Select Back Exit Animation")
                .setItems(labels, (dialog, which) -> {
                    if (isForward) {
                        customForwardIndex = which;
                    } else {
                        customBackwardIndex = which;
                    }
                    updateCustomTransBuilderButtons();
                })
                .show();
    }

    private void updateCustomTransBuilderButtons() {
        List<TransitionAnimationManager.AnimItem> builtIns = TransitionAnimationManager.getAnimations();
        if (builtIns.isEmpty()) return;
        TransitionAnimationManager.AnimItem fItem = builtIns.get(customForwardIndex % builtIns.size());
        TransitionAnimationManager.AnimItem bItem = builtIns.get(customBackwardIndex % builtIns.size());
        btnPickTransForward.setText("Enter: " + TransitionAnimationManager.stripNumberPrefix(fItem.name));
        btnPickTransBackward.setText("Back: " + TransitionAnimationManager.stripNumberPrefix(bItem.name));
    }

    private void updateTransitionFilterUI() {
        styleFilterButton(btnTransFilterAll, "ALL".equals(currentTransFilter), "All");
        styleFilterButton(btnTransFilterHacking, TransitionAnimationManager.CAT_HACKING.equals(currentTransFilter), "💻 Hacking");
        styleFilterButton(btnTransFilterCinematic, TransitionAnimationManager.CAT_CINEMATIC.equals(currentTransFilter), "🎬 Cinema");
        styleFilterButton(btnTransFilterClassic, TransitionAnimationManager.CAT_CLASSIC.equals(currentTransFilter), "⚡ Classic");
    }

    // =========================================================================
    // UNIVERSAL CONVERSION VISUAL ANIMATION STUDIO LOGIC
    // =========================================================================
    private void setupConverterAnimStudioListeners() {
        updateCustomConvBuilderButtons();

        btnConvPreviewReplay.setOnClickListener(v -> triggerLiveConverterPreviewSimulation());

        btnConvPreviewSwapDir.setOnClickListener(v -> {
            previewForwardStream = !previewForwardStream;
            viewSettingsConvPreview.setConversionDirection(previewForwardStream);
            triggerLiveConverterPreviewSimulation();
        });

        btnConvPreviewSpeed.setOnClickListener(v -> {
            cycleConverterSpeed();
            triggerLiveConverterPreviewSimulation();
        });

        btnConvShuffleOff.setOnClickListener(v -> {
            ConverterAnimationManager.setShuffleMode(this, ConverterAnimationManager.SHUFFLE_OFF);
            refreshMenuSummaries();
            populateConverterAnimList();
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Fixed Visual Style",
                    "Conversions will play your selected visual animation.");
        });

        btnConvShuffleAll.setOnClickListener(v -> {
            ConverterAnimationManager.setShuffleMode(this, ConverterAnimationManager.SHUFFLE_ALL);
            refreshMenuSummaries();
            populateConverterAnimList();
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Shuffle All Enabled",
                    "Every conversion will play a random visual animation!");
        });

        btnConvShuffleHacking.setOnClickListener(v -> {
            ConverterAnimationManager.setShuffleMode(this, ConverterAnimationManager.SHUFFLE_HACKING);
            refreshMenuSummaries();
            populateConverterAnimList();
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Hacking Shuffle Mode",
                    "Randomizing between Matrix, Red-Team, Cyberdeck & Katana visuals!");
        });

        btnPickConvEngine.setOnClickListener(v -> {
            String[] engines = new String[17];
            for (int i = 0; i < 17; i++) {
                engines[i] = (i + 1) + ". " + ConverterAnimationManager.getEngineShortName(i);
            }
            new AlertDialog.Builder(this)
                    .setTitle("Choose Visual Animation Engine (17 Styles)")
                    .setItems(engines, (dialog, which) -> {
                        builderEngineType = which;
                        updateCustomConvBuilderButtons();
                        previewDraftCustomConverterAnim();
                    })
                    .show();
        });

        btnPickConvPalette.setOnClickListener(v -> {
            String[] palettes = new String[6];
            for (int i = 0; i < 6; i++) {
                palettes[i] = ConverterAnimationManager.getPaletteShortName(i);
            }
            new AlertDialog.Builder(this)
                    .setTitle("Choose Neon Color Palette")
                    .setItems(palettes, (dialog, which) -> {
                        builderPaletteType = which;
                        updateCustomConvBuilderButtons();
                        previewDraftCustomConverterAnim();
                    })
                    .show();
        });

        btnToggleConvOverdrive.setOnClickListener(v -> {
            builderOverdrive = !builderOverdrive;
            updateCustomConvBuilderButtons();
            previewDraftCustomConverterAnim();
        });

        btnSaveCustomConvAnim.setOnClickListener(v -> {
            String customName = etCustomConvName.getText().toString().trim();
            if (customName.isEmpty()) {
                customName = ConverterAnimationManager.getEngineShortName(builderEngineType)
                        + " (" + ConverterAnimationManager.getPaletteShortName(builderPaletteType).split(" ")[0] + ")";
            }
            ConverterAnimationManager.ConverterAnimItem created =
                    ConverterAnimationManager.createCustomAnimation(
                            this, customName, builderEngineType, builderPaletteType, builderOverdrive
                    );
            etCustomConvName.setText("");
            currentConvFilter = "ALL";
            updateConverterFilterUI();
            refreshMenuSummaries();
            populateConverterAnimList();
            previewConverterAnimationItem(created);
            MorsalinToast.show(this, R.drawable.ic_code_convert,
                    "Custom Visual Animation Added!",
                    created.name + " is now active for all conversions.");
        });

        btnConvFilterAll.setOnClickListener(v -> {
            currentConvFilter = "ALL";
            updateConverterFilterUI();
            populateConverterAnimList();
        });
        btnConvFilterHacking.setOnClickListener(v -> {
            currentConvFilter = ConverterAnimationManager.CAT_HACKING;
            updateConverterFilterUI();
            populateConverterAnimList();
        });
        btnConvFilterCinematic.setOnClickListener(v -> {
            currentConvFilter = ConverterAnimationManager.CAT_CINEMATIC;
            updateConverterFilterUI();
            populateConverterAnimList();
        });
        btnConvFilterCustom.setOnClickListener(v -> {
            currentConvFilter = ConverterAnimationManager.CAT_CUSTOM;
            updateConverterFilterUI();
            populateConverterAnimList();
        });
    }

    private void updateCustomConvBuilderButtons() {
        btnPickConvEngine.setText("Engine: " + ConverterAnimationManager.getEngineShortName(builderEngineType));
        btnPickConvPalette.setText("Theme: " + ConverterAnimationManager.getPaletteShortName(builderPaletteType));
        btnToggleConvOverdrive.setText(builderOverdrive ? "🔥 Overdrive FX: ON" : "⚡ Overdrive FX: OFF");
        btnToggleConvOverdrive.setTextColor(Color.WHITE);
    }

    private void previewDraftCustomConverterAnim() {
        String draftName = etCustomConvName.getText().toString().trim();
        if (draftName.isEmpty()) {
            draftName = "Custom " + ConverterAnimationManager.getEngineShortName(builderEngineType);
        }
        ConverterAnimationManager.ConverterAnimItem draft = new ConverterAnimationManager.ConverterAnimItem(
                "draft_preview",
                draftName,
                "Live Custom Builder Preview",
                ConverterAnimationManager.CAT_CUSTOM,
                "⚡ " + draftName.toUpperCase() + " ⚡",
                builderEngineType,
                builderPaletteType,
                builderOverdrive,
                true
        );
        previewConverterAnimationItem(draft);
    }

    private void previewConverterAnimationItem(ConverterAnimationManager.ConverterAnimItem item) {
        if (viewSettingsConvPreview == null || item == null) return;
        tvConvPreviewTitle.setText("🎬 " + item.name);
        tvConvPreviewBadge.setText(item.category);
        viewSettingsConvPreview.applyAnimationConfig(item);
        viewSettingsConvPreview.setConversionDirection(previewForwardStream);
        viewSettingsConvPreview.startParticleAnimation();
        triggerLiveConverterPreviewSimulation();
    }

    private void triggerLiveConverterPreviewSimulation() {
        if (viewSettingsConvPreview == null) return;
        previewHandler.removeCallbacksAndMessages(null);

        final String[] stepTitles = {
                "Analyzing Input Stream...",
                "Parsing Structure Tree...",
                "Transforming Data Nodes...",
                "Optimizing Target Output...",
                "Verifying Integrity...",
                "Conversion Complete ✓"
        };
        final int[] stepProgress = {16, 34, 55, 74, 92, 100};

        SharedPreferences sp = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
        int speedPref = sp.getInt(KEY_CONVERTER_SPEED, 1);
        final long stepDelayMs = (speedPref == 0) ? 160L : (speedPref == 1 ? 260L : 390L);

        for (int i = 0; i < stepTitles.length; i++) {
            final int idx = i;
            previewHandler.postDelayed(() -> {
                if (isFinishing() || isDestroyed() || viewSettingsConvPreview == null) return;
                viewSettingsConvPreview.updateState(stepProgress[idx], stepTitles[idx]);
            }, i * stepDelayMs);
        }
    }

    private void updateConverterFilterUI() {
        styleFilterButton(btnConvFilterAll, "ALL".equals(currentConvFilter), "All (17)");
        styleFilterButton(btnConvFilterHacking, ConverterAnimationManager.CAT_HACKING.equals(currentConvFilter), "💻 Hacking");
        styleFilterButton(btnConvFilterCinematic, ConverterAnimationManager.CAT_CINEMATIC.equals(currentConvFilter), "🎬 Cinema");
        styleFilterButton(btnConvFilterCustom, ConverterAnimationManager.CAT_CUSTOM.equals(currentConvFilter), "★ Custom");
    }

    private void styleFilterButton(Button btn, boolean active, String baseText) {
        if (btn == null) return;
        btn.setText(active ? "✓ " + baseText : baseText);
        btn.setTextColor(Color.WHITE);
    }

    // =========================================================================
    // SUMMARIES & NAVIGATION
    // =========================================================================
    private void refreshMenuSummaries() {
        TransitionAnimationManager.AnimItem currentAnim = TransitionAnimationManager.getSelectedAnimation(this);
        int transShuffle = TransitionAnimationManager.getShuffleMode(this);

        if (tvMenuCurrentTransition != null) {
            String badge = transShuffle == TransitionAnimationManager.SHUFFLE_ALL
                    ? "Shuffle All ›"
                    : (transShuffle == TransitionAnimationManager.SHUFFLE_CYBER_CINEMA
                    ? "Cyber Shuffle ›"
                    : TransitionAnimationManager.stripNumberPrefix(currentAnim.name));
            tvMenuCurrentTransition.setText(badge);
        }

        if (tvTransActiveSummary != null) {
            String fullTrans = transShuffle == TransitionAnimationManager.SHUFFLE_ALL
                    ? "Mode: 🎲 Auto-Shuffle All (25+ Styles)"
                    : (transShuffle == TransitionAnimationManager.SHUFFLE_CYBER_CINEMA
                    ? "Mode: 🔥 Cyber & Cinematic Shuffle"
                    : "Active: " + currentAnim.name);
            tvTransActiveSummary.setText(fullTrans);
        }

        if (btnTransShuffleOff != null) {
            styleFilterButton(btnTransShuffleOff, transShuffle == TransitionAnimationManager.SHUFFLE_OFF, "Selected");
            styleFilterButton(btnTransShuffleAll, transShuffle == TransitionAnimationManager.SHUFFLE_ALL, "🎲 Shuffle All");
            styleFilterButton(btnTransShuffleCyber, transShuffle == TransitionAnimationManager.SHUFFLE_CYBER_CINEMA, "🔥 Cyber Shuffle");
        }

        ConverterAnimationManager.ConverterAnimItem currentConv = ConverterAnimationManager.getSelectedAnimation(this);
        int convShuffle = ConverterAnimationManager.getShuffleMode(this);

        if (tvMenuCurrentConverterAnim != null) {
            String convBadge = convShuffle == ConverterAnimationManager.SHUFFLE_ALL
                    ? "Shuffle All ›"
                    : (convShuffle == ConverterAnimationManager.SHUFFLE_HACKING
                    ? "Hack Shuffle ›"
                    : TransitionAnimationManager.stripNumberPrefix(currentConv.name));
            tvMenuCurrentConverterAnim.setText(convBadge);
        }

        if (btnConvShuffleOff != null) {
            styleFilterButton(btnConvShuffleOff, convShuffle == ConverterAnimationManager.SHUFFLE_OFF, "Fixed Style");
            styleFilterButton(btnConvShuffleAll, convShuffle == ConverterAnimationManager.SHUFFLE_ALL, "🎲 Shuffle All");
            styleFilterButton(btnConvShuffleHacking, convShuffle == ConverterAnimationManager.SHUFFLE_HACKING, "💻 Shuffle Hack");
        }

        SharedPreferences sp = getSharedPreferences(PREF_SETTINGS, MODE_PRIVATE);
        int speed = sp.getInt(KEY_CONVERTER_SPEED, 1);
        if (tvMenuConverterSpeed != null) {
            String label = speed == 0 ? "Fast" : (speed == 1 ? "Normal" : "Cinematic");
            tvMenuConverterSpeed.setText(label);
        }
        if (btnConvPreviewSpeed != null) {
            String shortSpeed = speed == 0 ? "⚡ Speed: Fast" : (speed == 1 ? "⚖ Speed: Normal" : "🎬 Speed: Cinema");
            btnConvPreviewSpeed.setText(shortSpeed);
        }

        int indent = sp.getInt(KEY_XML_INDENT, 4);
        if (tvMenuXmlIndent != null) {
            tvMenuXmlIndent.setText(indent + " Spaces");
        }

        // Touch particle status
        int particleStyle = GlobalTouchParticleManager.getSavedStyle(this);
        if (tvMenuTouchParticles != null) {
            String pName = (particleStyle >= 0 && particleStyle < TouchParticleOverlayView.STYLE_NAMES.length)
                    ? TouchParticleOverlayView.STYLE_NAMES[particleStyle].split(" ")[0]
                    : "Active";
            tvMenuTouchParticles.setText(pName + " ›");
        }

        // Button Divider Animation status
        if (tvMenuDividerAnim != null) {
            int dividerStyle = AnimatedDividerManager.getSavedStyle(this);
            String dName = AnimatedDividerManager.getStyleShortName(dividerStyle);
            tvMenuDividerAnim.setText(dName + " ›");
        }

        // Lighting Text Animation status
        if (tvMenuLightingTextAnim != null) {
            boolean lightingOn = LightingTextAnimationManager.isEnabled(this);
            if (!lightingOn) {
                tvMenuLightingTextAnim.setText("OFF ›");
            } else {
                int lStyle = LightingTextAnimationManager.getSavedStyle(this);
                String lName = LightingTextAnimationManager.getStyleName(lStyle)
                        .replaceFirst("^\\d+\\.\\s*", "")
                        .split(" ")[0];
                tvMenuLightingTextAnim.setText(lName + " ›");
            }
        }

        // Typing text animation status
        boolean typingOn = MorsalinTypingTextHelper.isTypingEnabled(this);
        int typingStyle = MorsalinTypingTextHelper.getTypingStyle(this);
        boolean loopOn = MorsalinTypingTextHelper.isLoopEnabled(this);
        if (tvMenuTypingAnim != null) {
            String styleShort = MorsalinTypingTextHelper.STYLE_NAMES[typingStyle % MorsalinTypingTextHelper.STYLE_NAMES.length]
                    .replaceFirst("^\\d+\\.\\s*", "")
                    .split(" ")[0];
            String loopBadge = loopOn ? " 🔁" : "";
            String tName = typingOn ? "ON (" + styleShort + loopBadge + ") ›" : "OFF ›";
            tvMenuTypingAnim.setText(tName);
        }

        // Staggered Entrance status
        if (tvMenuStaggeredEntrance != null) {
            int stag = StaggeredEntranceAnimationHelper.getSavedStyle(this);
            String stagName = (stag == StaggeredEntranceAnimationHelper.STYLE_OFF)
                    ? "OFF ›"
                    : StaggeredEntranceAnimationHelper.STYLE_NAMES[stag].split(" ")[0] + " ›";
            tvMenuStaggeredEntrance.setText(stagName);
        }

        // Button Press Micro-Interactions status
        if (tvMenuButtonPress != null) {
            int press = ButtonPressAnimationHelper.getSavedStyle(this);
            String pressName = (press == ButtonPressAnimationHelper.STYLE_OFF)
                    ? "OFF ›"
                    : ButtonPressAnimationHelper.STYLE_NAMES[press].split(" ")[0] + " ›";
            tvMenuButtonPress.setText(pressName);
        }

        // Ambient Live Background status
        if (tvMenuAmbientBg != null) {
            int bg = AmbientBackgroundAnimationManager.getSavedStyle(this);
            String bgName = (bg == AmbientBackgroundAnimationManager.STYLE_NONE)
                    ? "OFF ›"
                    : AmbientBackgroundAnimationManager.STYLE_NAMES[bg].split(" ")[0] + " ›";
            tvMenuAmbientBg.setText(bgName);
        }

        // Ambient Glow status
        if (tvMenuAmbientGlow != null) {
            int glow = AmbientGlowAnimationHelper.getSavedStyle(this);
            String glowName = (glow == AmbientGlowAnimationHelper.STYLE_OFF)
                    ? "OFF ›"
                    : AmbientGlowAnimationHelper.STYLE_NAMES[glow].split(" ")[0] + " ›";
            tvMenuAmbientGlow.setText(glowName);
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void showTouchParticleDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_touch_particles);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_touch_particle_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_particle_dialog);
        int currentSelected = GlobalTouchParticleManager.getSavedStyle(this);

        for (int i = 0; i < TouchParticleOverlayView.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = TouchParticleOverlayView.STYLE_NAMES[i];
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(14f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "APPLY");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                GlobalTouchParticleManager.setSavedStyle(SettingsActivity.this, styleIdx);
                refreshMenuSummaries();
                TouchParticleOverlayView overlay = GlobalTouchParticleManager.getOverlay(SettingsActivity.this);
                if (overlay != null) {
                    overlay.setStyle(styleIdx);
                    overlay.spawnBurst(v.getWidth() / 2f, v.getY() + v.getHeight() / 2f);
                }
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                        "Touch Particle Active", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showDividerAnimationDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_animated_divider);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.94);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_divider_anim_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_divider_dialog);
        int currentSelected = AnimatedDividerManager.getSavedStyle(this);

        for (int i = 0; i < AnimatedDividerManager.TOTAL_STYLES; i++) {
            final int styleIdx = i;
            String styleName = AnimatedDividerManager.getStyleName(i);
            String styleDesc = AnimatedDividerManager.getStyleDescription(i);
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(10));
            card.setLayoutParams(lp);

            LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(14.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            headerRow.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "APPLY");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(isSelected ? Color.parseColor("#00E5FF") : Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4));
            headerRow.addView(tvBadge);

            card.addView(headerRow);

            if (styleDesc != null && !styleDesc.isEmpty()) {
                TextView tvDesc = new TextView(this);
                tvDesc.setText(styleDesc);
                tvDesc.setTextSize(11.5f);
                tvDesc.setTextColor(Color.parseColor("#AAFFFFFF"));
                tvDesc.setPadding(0, dpToPx(2), 0, dpToPx(6));
                card.addView(tvDesc);
            }

            AnimatedDividerView previewDivider = new AnimatedDividerView(this);
            previewDivider.setPreviewStyle(styleIdx);
            LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(8));
            previewLp.setMargins(0, dpToPx(4), 0, dpToPx(2));
            previewDivider.setLayoutParams(previewLp);
            card.addView(previewDivider);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                AnimatedDividerManager.setSavedStyle(SettingsActivity.this, styleIdx);
                refreshMenuSummaries();
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_cat_layout,
                        "Divider Animation Set", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showLightingTextAnimDialog() {
        MorsalinDialogHelper.showLightingTextDialog(this, () -> refreshMenuSummaries());
    }

    private void showTypingAnimDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_typing_text_animation);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.94);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        Button btnMasterToggle = dialog.findViewById(R.id.btn_typing_master_toggle);
        Button btnLoopToggle = dialog.findViewById(R.id.btn_typing_loop_toggle);
        Button btnOpenLighting = dialog.findViewById(R.id.btn_open_lighting_text_from_typing);
        Button btnTestAnim = dialog.findViewById(R.id.btn_test_typing_anim);
        TextView tvPreview = dialog.findViewById(R.id.tv_typing_preview_display);
        TextView tvSpeedVal = dialog.findViewById(R.id.tv_typing_speed_val);
        Button btnSpeedMinus = dialog.findViewById(R.id.btn_speed_minus);
        Button btnSpeedPlus = dialog.findViewById(R.id.btn_speed_plus);
        Button btnCursorSelect = dialog.findViewById(R.id.btn_typing_cursor_select);
        Button btnDelaySelect = dialog.findViewById(R.id.btn_typing_delay_select);
        LinearLayout layoutItems = dialog.findViewById(R.id.layout_typing_style_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_typing_dialog);

        if (btnOpenLighting != null) {
            btnOpenLighting.setOnClickListener(v -> {
                dialog.dismiss();
                showLightingTextAnimDialog();
            });
        }

        final String testSample = "Morsalin XML Creator • Ultra Pro Modding Suite";

        // Master toggle
        updateTypingMasterToggleUi(btnMasterToggle, MorsalinTypingTextHelper.isTypingEnabled(this));
        btnMasterToggle.setOnClickListener(v -> {
            boolean now = !MorsalinTypingTextHelper.isTypingEnabled(SettingsActivity.this);
            MorsalinTypingTextHelper.setTypingEnabled(SettingsActivity.this, now);
            updateTypingMasterToggleUi(btnMasterToggle, now);
            refreshMenuSummaries();
            if (now) {
                MorsalinTypingTextHelper.animateText(tvPreview, testSample);
            } else {
                tvPreview.setText(testSample);
            }
        });

        // Continuous Loop Toggle
        updateTypingLoopToggleUi(btnLoopToggle, MorsalinTypingTextHelper.isLoopEnabled(this));
        btnLoopToggle.setOnClickListener(v -> {
            boolean now = !MorsalinTypingTextHelper.isLoopEnabled(SettingsActivity.this);
            MorsalinTypingTextHelper.setLoopEnabled(SettingsActivity.this, now);
            updateTypingLoopToggleUi(btnLoopToggle, now);
            refreshMenuSummaries();
            MorsalinTypingTextHelper.animateText(tvPreview, testSample);
            MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                    "Loop Mode Updated",
                    now ? "Continuous Infinite Loop (ON)" : "Single Run (OFF)");
        });

        // Speed stepper & display
        updateTypingSpeedDisplay(tvSpeedVal);
        btnSpeedMinus.setOnClickListener(v -> {
            int current = MorsalinTypingTextHelper.getTypingSpeed(SettingsActivity.this);
            int updated = Math.max(10, current - 5);
            MorsalinTypingTextHelper.setTypingSpeed(SettingsActivity.this, updated);
            updateTypingSpeedDisplay(tvSpeedVal);
            MorsalinTypingTextHelper.animateText(tvPreview, testSample);
        });
        btnSpeedPlus.setOnClickListener(v -> {
            int current = MorsalinTypingTextHelper.getTypingSpeed(SettingsActivity.this);
            int updated = Math.min(200, current + 5);
            MorsalinTypingTextHelper.setTypingSpeed(SettingsActivity.this, updated);
            updateTypingSpeedDisplay(tvSpeedVal);
            MorsalinTypingTextHelper.animateText(tvPreview, testSample);
        });

        // Cursor selector
        updateTypingCursorButtonText(btnCursorSelect);
        btnCursorSelect.setOnClickListener(v -> {
            int curCursor = MorsalinTypingTextHelper.getCursorStyle(SettingsActivity.this);
            int nextCursor = (curCursor + 1) % MorsalinTypingTextHelper.CURSOR_NAMES.length;
            MorsalinTypingTextHelper.setCursorStyle(SettingsActivity.this, nextCursor);
            updateTypingCursorButtonText(btnCursorSelect);
            MorsalinTypingTextHelper.animateText(tvPreview, testSample);
        });

        // Loop Delay selector
        final int[] delayOptions = {1000, 1800, 2500, 3500};
        updateTypingDelayButtonText(btnDelaySelect);
        btnDelaySelect.setOnClickListener(v -> {
            int curDelay = MorsalinTypingTextHelper.getLoopDelay(SettingsActivity.this);
            int nextIdx = 1;
            for (int i = 0; i < delayOptions.length; i++) {
                if (delayOptions[i] == curDelay) {
                    nextIdx = (i + 1) % delayOptions.length;
                    break;
                }
            }
            MorsalinTypingTextHelper.setLoopDelay(SettingsActivity.this, delayOptions[nextIdx]);
            updateTypingDelayButtonText(btnDelaySelect);
            MorsalinTypingTextHelper.animateText(tvPreview, testSample);
        });

        // Test Animation button
        btnTestAnim.setOnClickListener(v -> MorsalinTypingTextHelper.animateText(tvPreview, testSample));

        // Populate styles
        populateTypingStyleCards(layoutItems, tvPreview, testSample, btnMasterToggle);

        // Initial preview run
        MorsalinTypingTextHelper.animateText(tvPreview, testSample);

        btnClose.setOnClickListener(v -> {
            dialog.dismiss();
            refreshMenuSummaries();
        });
        dialog.show();
    }

    private void updateTypingMasterToggleUi(Button btn, boolean isEnabled) {
        if (btn == null) return;
        btn.setText(isEnabled ? "⚡ Animation: ON" : "💤 Animation: OFF");
        btn.setTextColor(Color.WHITE);
    }

    private void updateTypingLoopToggleUi(Button btn, boolean isLoop) {
        if (btn == null) return;
        btn.setText(isLoop ? "🔁 Loop: Continuous" : "⏹ Loop: Single Run");
        btn.setTextColor(Color.WHITE);
    }

    private void updateTypingSpeedDisplay(TextView tv) {
        if (tv == null) return;
        int speed = MorsalinTypingTextHelper.getTypingSpeed(this);
        String label = (speed <= 20) ? "Ultra Turbo"
                : (speed <= 40) ? "Fast"
                : (speed <= 70) ? "Normal"
                : (speed <= 110) ? "Cinematic" : "Relaxed";
        tv.setText(speed + " ms (" + label + ")");
    }

    private void updateTypingDelayButtonText(Button btn) {
        if (btn == null) return;
        int delay = MorsalinTypingTextHelper.getLoopDelay(this);
        btn.setText("Pause: " + (delay / 1000f) + "s");
        btn.setTextColor(Color.WHITE);
    }

    private void updateTypingCursorButtonText(Button btn) {
        if (btn == null) return;
        int curCursor = MorsalinTypingTextHelper.getCursorStyle(this);
        int safe = Math.max(0, Math.min(curCursor, MorsalinTypingTextHelper.CURSOR_NAMES.length - 1));
        btn.setText("Cursor: " + MorsalinTypingTextHelper.CURSOR_NAMES[safe]);
        btn.setTextColor(Color.WHITE);
    }

    private void populateTypingStyleCards(LinearLayout layoutItems, TextView tvPreview, String testSample, Button btnMasterToggle) {
        if (layoutItems == null) return;
        layoutItems.removeAllViews();
        int activeStyle = MorsalinTypingTextHelper.getTypingStyle(this);

        for (int i = 0; i < MorsalinTypingTextHelper.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = MorsalinTypingTextHelper.STYLE_NAMES[i];
            String styleDesc = (i < MorsalinTypingTextHelper.STYLE_DESCRIPTIONS.length)
                    ? MorsalinTypingTextHelper.STYLE_DESCRIPTIONS[i] : "";
            boolean isSelected = (styleIdx == activeStyle);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(10), dpToPx(14), dpToPx(10));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            LinearLayout rowTop = new LinearLayout(this);
            rowTop.setOrientation(LinearLayout.HORIZONTAL);
            rowTop.setGravity(android.view.Gravity.CENTER_VERTICAL);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            rowTop.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE 🔁" : "SELECT");
            tvBadge.setTextSize(10.5f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            rowTop.addView(tvBadge);

            card.addView(rowTop);

            if (!styleDesc.isEmpty()) {
                TextView tvDesc = new TextView(this);
                tvDesc.setText(styleDesc);
                tvDesc.setTextSize(11f);
                tvDesc.setTextColor(Color.parseColor("#B0BEC5"));
                tvDesc.setPadding(0, dpToPx(4), 0, 0);
                card.addView(tvDesc);
            }

            card.setOnClickListener(v -> {
                MorsalinTypingTextHelper.setTypingStyle(SettingsActivity.this, styleIdx);
                MorsalinTypingTextHelper.setTypingEnabled(SettingsActivity.this, true);
                updateTypingMasterToggleUi(btnMasterToggle, true);
                refreshMenuSummaries();
                populateTypingStyleCards(layoutItems, tvPreview, testSample, btnMasterToggle);
                MorsalinTypingTextHelper.animateText(tvPreview, testSample);
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_code_convert,
                        "Typing Style Selected", styleName);
            });

            layoutItems.addView(card);
        }
    }

    private void showButtonPressDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_button_press_anim);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_button_press_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_button_press_dialog);
        int currentSelected = ButtonPressAnimationHelper.getSavedStyle(this);

        for (int i = 0; i < ButtonPressAnimationHelper.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = ButtonPressAnimationHelper.STYLE_NAMES[i];
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "SELECT");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                ButtonPressAnimationHelper.setSavedStyle(SettingsActivity.this, styleIdx);
                refreshMenuSummaries();
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                        "Button Interaction Applied", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showAmbientBgDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_ambient_bg_anim);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_ambient_bg_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_ambient_bg_dialog);
        int currentSelected = AmbientBackgroundAnimationManager.getSavedStyle(this);

        for (int i = 0; i < AmbientBackgroundAnimationManager.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = AmbientBackgroundAnimationManager.STYLE_NAMES[i];
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "APPLY");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                AmbientBackgroundAnimationManager.setSavedStyle(SettingsActivity.this, styleIdx);
                GlobalTouchParticleManager.refreshAll(SettingsActivity.this);
                refreshMenuSummaries();
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                        "Ambient Background Set", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showAmbientGlowDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_ambient_glow_anim);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_ambient_glow_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_ambient_glow_dialog);
        int currentSelected = AmbientGlowAnimationHelper.getSavedStyle(this);

        for (int i = 0; i < AmbientGlowAnimationHelper.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = AmbientGlowAnimationHelper.STYLE_NAMES[i];
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "APPLY");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                AmbientGlowAnimationHelper.setSavedStyle(SettingsActivity.this, styleIdx);
                refreshMenuSummaries();
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                        "Ambient Glow Configured", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showStaggeredEntranceDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_staggered_entrance_anim);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout layoutItems = dialog.findViewById(R.id.layout_staggered_entrance_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_staggered_entrance_dialog);
        int currentSelected = StaggeredEntranceAnimationHelper.getSavedStyle(this);

        for (int i = 0; i < StaggeredEntranceAnimationHelper.STYLE_NAMES.length; i++) {
            final int styleIdx = i;
            String styleName = StaggeredEntranceAnimationHelper.STYLE_NAMES[i];
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dpToPx(8));
            card.setLayoutParams(lp);

            TextView tv = new TextView(this);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(this);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "SELECT");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                dialog.dismiss();
                StaggeredEntranceAnimationHelper.setSavedStyle(SettingsActivity.this, styleIdx);
                refreshMenuSummaries();
                MorsalinToast.show(SettingsActivity.this, R.drawable.ic_settings_anim,
                        "Entrance Animation Set", styleName);
            });

            layoutItems.addView(card);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void hideAllSubScreens() {
        scrollSettingsMenu.setVisibility(View.GONE);
        scrollTransitionPicker.setVisibility(View.GONE);
        scrollConverterAnimPicker.setVisibility(View.GONE);
        scrollAboutDeveloper.setVisibility(View.GONE);
    }

    private void showTransitionPicker(boolean animate) {
        currentSubScreen = SCREEN_TRANSITIONS;
        if (viewSettingsConvPreview != null) {
            viewSettingsConvPreview.stopParticleAnimation();
        }
        tvHeaderTitle.setText("Transition Animations");
        hideAllSubScreens();
        scrollTransitionPicker.setVisibility(View.VISIBLE);
        if (!transitionListPopulated) {
            populateTransitionList();
            transitionListPopulated = true;
        }
        if (animate) {
            scrollTransitionPicker.setAlpha(0f);
            scrollTransitionPicker.setTranslationX(60f);
            scrollTransitionPicker.animate().alpha(1f).translationX(0f).setDuration(220).start();
        }
    }

    private void showConverterAnimPicker(boolean animate) {
        currentSubScreen = SCREEN_CONVERTER_ANIMS;
        tvHeaderTitle.setText("Conversion Animations");
        hideAllSubScreens();
        scrollConverterAnimPicker.setVisibility(View.VISIBLE);
        if (!converterAnimListPopulated) {
            populateConverterAnimList();
            converterAnimListPopulated = true;
        }
        if (animate) {
            scrollConverterAnimPicker.setAlpha(0f);
            scrollConverterAnimPicker.setTranslationX(60f);
            scrollConverterAnimPicker.animate().alpha(1f).translationX(0f).setDuration(220).start();
        }
        ConverterAnimationManager.ConverterAnimItem active = ConverterAnimationManager.getSelectedAnimation(this);
        previewConverterAnimationItem(active);
    }

    private void showAboutDeveloperScreen(boolean animate) {
        currentSubScreen = SCREEN_ABOUT_DEVELOPER;
        if (viewSettingsConvPreview != null) {
            viewSettingsConvPreview.stopParticleAnimation();
        }
        tvHeaderTitle.setText("About Developer");
        hideAllSubScreens();
        scrollAboutDeveloper.setVisibility(View.VISIBLE);
        if (animate) {
            scrollAboutDeveloper.setAlpha(0f);
            scrollAboutDeveloper.setTranslationX(60f);
            scrollAboutDeveloper.animate().alpha(1f).translationX(0f).setDuration(220).start();
        }
    }

    private void showMainSettingsMenu() {
        currentSubScreen = SCREEN_MAIN;
        previewHandler.removeCallbacksAndMessages(null);
        if (viewSettingsConvPreview != null) {
            viewSettingsConvPreview.stopParticleAnimation();
        }
        tvHeaderTitle.setText("Settings");
        refreshMenuSummaries();
        hideAllSubScreens();
        scrollSettingsMenu.setVisibility(View.VISIBLE);
        scrollSettingsMenu.setAlpha(1f);
        scrollSettingsMenu.setTranslationX(0f);
    }

    private void handleBackNavigation() {
        if (currentSubScreen != SCREEN_MAIN) {
            showMainSettingsMenu();
        } else {
            finish();
            TransitionAnimationManager.applyBackward(this);
        }
    }

    // =========================================================================
    // POPULATE LISTS
    // =========================================================================
    private void populateTransitionList() {
        if (layoutAnimOptions == null) return;
        layoutAnimOptions.removeAllViews();
        List<TransitionAnimationManager.AnimItem> items = TransitionAnimationManager.getAllAnimations(this);
        TransitionAnimationManager.AnimItem currentSelected = TransitionAnimationManager.getSelectedAnimation(this);

        LayoutInflater inflater = LayoutInflater.from(this);

        for (TransitionAnimationManager.AnimItem item : items) {
            if (!"ALL".equals(currentTransFilter)) {
                if (!currentTransFilter.equals(item.category) && !item.isCustom) {
                    continue;
                }
            }

            View itemView = inflater.inflate(R.layout.item_anim_option, layoutAnimOptions, false);

            RadioButton rbSelect = itemView.findViewById(R.id.rb_anim_select);
            TextView tvName = itemView.findViewById(R.id.tv_anim_name);
            TextView tvBadge = itemView.findViewById(R.id.tv_anim_category_badge);
            TextView tvDesc = itemView.findViewById(R.id.tv_anim_desc);
            Button btnDelete = itemView.findViewById(R.id.btn_delete_custom_anim);
            Button btnTest = itemView.findViewById(R.id.btn_test_preview);

            tvName.setText(item.name);
            tvDesc.setText(item.description);
            tvBadge.setText(item.category);

            tvBadge.setTextColor(Color.WHITE);

            boolean isCurrent = item.id.equals(currentSelected.id);
            rbSelect.setChecked(isCurrent);

            itemView.setBackgroundResource(R.drawable.morsalin_button_bg);
            tvName.setTextColor(Color.WHITE);

            if (item.isCustom) {
                btnDelete.setVisibility(View.VISIBLE);
                btnDelete.setOnClickListener(v -> {
                    TransitionAnimationManager.deleteCustomTransition(this, item.id);
                    refreshMenuSummaries();
                    populateTransitionList();
                    MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Custom Transition Removed",
                            item.name + " was deleted.");
                });
            } else {
                btnDelete.setVisibility(View.GONE);
            }

            itemView.setTag(item.id);

            View.OnClickListener selectListener = v -> {
                TransitionAnimationManager.setSelectedAnimation(this, item.id);
                TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_OFF);
                refreshMenuSummaries();
                updateTransitionSelectionInPlace(item.id);
                MorsalinToast.show(this, R.drawable.ic_settings_anim,
                        "Transition Activated!",
                        item.name + " is now active.");
            };

            itemView.setOnClickListener(selectListener);

            btnTest.setOnClickListener(v -> {
                TransitionAnimationManager.setSelectedAnimation(this, item.id);
                TransitionAnimationManager.setShuffleMode(this, TransitionAnimationManager.SHUFFLE_OFF);
                Intent testIntent = new Intent(this, SettingsActivity.class);
                testIntent.putExtra(EXTRA_OPEN_TRANSITIONS, true);
                finish();
                overridePendingTransition(0, 0);
                startActivity(testIntent);
                overridePendingTransition(item.enterAnim, item.exitAnim);
            });

            layoutAnimOptions.addView(itemView);
        }
    }

    private void populateConverterAnimList() {
        if (layoutConverterAnimOptions == null) return;
        layoutConverterAnimOptions.removeAllViews();
        List<ConverterAnimationManager.ConverterAnimItem> items = ConverterAnimationManager.getAllAnimations(this);
        ConverterAnimationManager.ConverterAnimItem currentSelected = ConverterAnimationManager.getSelectedAnimation(this);

        LayoutInflater inflater = LayoutInflater.from(this);

        for (ConverterAnimationManager.ConverterAnimItem item : items) {
            if (!"ALL".equals(currentConvFilter)) {
                if (!currentConvFilter.equals(item.category)) {
                    continue;
                }
            }

            View itemView = inflater.inflate(R.layout.item_anim_option, layoutConverterAnimOptions, false);

            RadioButton rbSelect = itemView.findViewById(R.id.rb_anim_select);
            TextView tvName = itemView.findViewById(R.id.tv_anim_name);
            TextView tvBadge = itemView.findViewById(R.id.tv_anim_category_badge);
            TextView tvDesc = itemView.findViewById(R.id.tv_anim_desc);
            Button btnDelete = itemView.findViewById(R.id.btn_delete_custom_anim);
            Button btnTest = itemView.findViewById(R.id.btn_test_preview);

            tvName.setText(item.name);
            tvDesc.setText(item.description);
            tvBadge.setText(item.category);

            tvBadge.setTextColor(Color.WHITE);

            boolean isCurrent = item.id.equals(currentSelected.id);
            rbSelect.setChecked(isCurrent);

            itemView.setBackgroundResource(R.drawable.morsalin_button_bg);
            tvName.setTextColor(Color.WHITE);

            if (item.isCustom) {
                btnDelete.setVisibility(View.VISIBLE);
                btnDelete.setOnClickListener(v -> {
                    ConverterAnimationManager.deleteCustomAnimation(this, item.id);
                    refreshMenuSummaries();
                    populateConverterAnimList();
                    previewConverterAnimationItem(ConverterAnimationManager.getSelectedAnimation(this));
                    MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Custom Animation Deleted",
                            item.name + " was removed.");
                });
            } else {
                btnDelete.setVisibility(View.GONE);
            }

            itemView.setTag(item.id);

            View.OnClickListener selectAndPreviewListener = v -> {
                ConverterAnimationManager.setSelectedAnimation(this, item.id);
                ConverterAnimationManager.setShuffleMode(this, ConverterAnimationManager.SHUFFLE_OFF);
                refreshMenuSummaries();
                updateConverterAnimSelectionInPlace(item.id);
                previewConverterAnimationItem(item);
                MorsalinToast.show(this, R.drawable.ic_code_convert,
                        "Conversion Animation Set!",
                        item.name + " is now active.");
            };

            itemView.setOnClickListener(selectAndPreviewListener);

            btnTest.setText("▶ Live");
            btnTest.setOnClickListener(v -> {
                ConverterAnimationManager.setSelectedAnimation(this, item.id);
                ConverterAnimationManager.setShuffleMode(this, ConverterAnimationManager.SHUFFLE_OFF);
                refreshMenuSummaries();
                updateConverterAnimSelectionInPlace(item.id);
                previewConverterAnimationItem(item);
                scrollConverterAnimPicker.smoothScrollTo(0, 0);
            });

            layoutConverterAnimOptions.addView(itemView);
        }
    }

    private void updateTransitionSelectionInPlace(String activeId) {
        if (layoutAnimOptions == null || activeId == null) return;
        int count = layoutAnimOptions.getChildCount();
        for (int i = 0; i < count; i++) {
            View child = layoutAnimOptions.getChildAt(i);
            Object tag = child.getTag();
            if (tag != null) {
                boolean isMatch = tag.equals(activeId);
                RadioButton rb = child.findViewById(R.id.rb_anim_select);
                if (rb != null) {
                    rb.setChecked(isMatch);
                }
            }
        }
    }

    private void updateConverterAnimSelectionInPlace(String activeId) {
        if (layoutConverterAnimOptions == null || activeId == null) return;
        int count = layoutConverterAnimOptions.getChildCount();
        for (int i = 0; i < count; i++) {
            View child = layoutConverterAnimOptions.getChildAt(i);
            Object tag = child.getTag();
            if (tag != null) {
                boolean isMatch = tag.equals(activeId);
                RadioButton rb = child.findViewById(R.id.rb_anim_select);
                if (rb != null) {
                    rb.setChecked(isMatch);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        previewHandler.removeCallbacksAndMessages(null);
        if (viewSettingsConvPreview != null) {
            viewSettingsConvPreview.stopParticleAnimation();
        }
    }

    @Override
    public void onBackPressed() {
        if (currentSubScreen != SCREEN_MAIN) {
            showMainSettingsMenu();
        } else {
            super.onBackPressed();
            TransitionAnimationManager.applyBackward(this);
        }
    }
}
