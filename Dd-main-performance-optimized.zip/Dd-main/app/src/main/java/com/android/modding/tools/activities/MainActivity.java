package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String URL_TELEGRAM = "https://t.me/anonymous_modder_king";
    private static final String URL_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";

    private TextView tvMainAppTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Attach global touch particles and ambient background
        GlobalTouchParticleManager.attach(this);

        tvMainAppTitle = findViewById(R.id.tv_main_app_title);
        if (MorsalinTypingTextHelper.isTypingEnabled(this)) {
            playHeaderTypingAnimation();
        } else if (tvMainAppTitle != null) {
            tvMainAppTitle.setText("Tools King");
        }
        if (AmbientGlowAnimationHelper.isEnabled(this)) {
            AmbientGlowAnimationHelper.attachPulseToView(tvMainAppTitle, this);
        }

        // Staggered entrance animation for category cards
        View cardContainer = findViewById(R.id.layout_main_cards);
        if (cardContainer instanceof android.view.ViewGroup && StaggeredEntranceAnimationHelper.isEnabled(this)) {
            StaggeredEntranceAnimationHelper.animateContainer((android.view.ViewGroup) cardContainer, this);
        }

        initClickListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MorsalinTypingTextHelper.isTypingEnabled(this)) {
            playHeaderTypingAnimation();
        } else if (tvMainAppTitle != null) {
            tvMainAppTitle.setText("Tools King");
        }
    }

    private void playHeaderTypingAnimation() {
        if (tvMainAppTitle != null) {
            MorsalinTypingTextHelper.animateText(tvMainAppTitle, "Tools King");
        }
    }

    private void initClickListeners() {
        // Social Links with smooth icon animation
        View.OnClickListener openTg = v -> animateAndOpenUrl(v, URL_TELEGRAM);
        View.OnClickListener openFb = v -> animateAndOpenUrl(v, URL_FACEBOOK);

        View tgL = findViewById(R.id.btn_social_telegram_left);
        View tgR = findViewById(R.id.btn_social_telegram_right);
        View fbL = findViewById(R.id.btn_social_facebook_left);
        View fbR = findViewById(R.id.btn_social_facebook_right);
        if (tgL != null) tgL.setOnClickListener(openTg);
        if (tgR != null) tgR.setOnClickListener(openTg);
        if (fbL != null) fbL.setOnClickListener(openFb);
        if (fbR != null) fbR.setOnClickListener(openFb);

        // 8 Main Category Cards
        View cardXml = findViewById(R.id.card_cat_xml_creator);
        if (cardXml != null) {
            cardXml.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, XmlCreatorCategoryActivity.class)));
        }

        View cardTools = findViewById(R.id.card_cat_tools_maker);
        if (cardTools != null) {
            cardTools.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, ToolsMakerCategoryActivity.class)));
        }

        View cardDialogMaker = findViewById(R.id.card_home_dialog_maker);
        if (cardDialogMaker != null) {
            cardDialogMaker.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, AdvancedDialogMakerActivity.class)));
        }

        View cardEncrypt = findViewById(R.id.card_cat_encrypt_decrypt);
        if (cardEncrypt != null) {
            cardEncrypt.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, EncryptDecryptCategoryActivity.class)));
        }

        View cardConverter = findViewById(R.id.card_cat_converter);
        if (cardConverter != null) {
            cardConverter.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, CodeEditorCategoryActivity.class)));
        }

        View cardQr = findViewById(R.id.card_cat_qr_scanner);
        if (cardQr != null) {
            cardQr.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, QrScannerActivity.class)));
        }

        View cardJavaToSmali = findViewById(R.id.card_home_java_to_smali);
        if (cardJavaToSmali != null) {
            cardJavaToSmali.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, ClassToSmaliActivity.class)));
        }

        View cardUtilities = findViewById(R.id.card_cat_app_utilities);
        if (cardUtilities != null) {
            cardUtilities.setOnClickListener(v -> launchWithAnimation(v, new Intent(MainActivity.this, AppUtilitiesCategoryActivity.class)));
        }
    }

    private void animateAndOpenUrl(View v, String url) {
        if (v != null) {
            v.animate()
                    .rotationBy(25f)
                    .scaleX(0.88f)
                    .scaleY(0.88f)
                    .setDuration(120)
                    .withEndAction(() -> {
                        v.animate()
                                .rotation(0f)
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .setDuration(160)
                                .start();
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
                            startActivity(intent);
                        } catch (Exception ignored) {}
                    })
                    .start();
        } else {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
                startActivity(intent);
            } catch (Exception ignored) {}
        }
    }

    private void launchWithAnimation(View triggerView, Intent intent) {
        if (triggerView != null && ButtonPressAnimationHelper.isEnabled(this)) {
            triggerView.animate()
                    .scaleX(0.95f)
                    .scaleY(0.95f)
                    .setDuration(60)
                    .withEndAction(() -> triggerView.animate().scaleX(1.0f).scaleY(1.0f).setDuration(60).start())
                    .start();
        }
        startActivity(intent);
        TransitionAnimationManager.applyForward(MainActivity.this);
    }

    private void showImportDialog() {
        Dialog dialog = new Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_import_xml);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90),
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        EditText etXml = dialog.findViewById(R.id.et_import_xml_input);
        Button btnPaste = dialog.findViewById(R.id.btn_import_paste);
        Button btnCancel = dialog.findViewById(R.id.btn_import_cancel);
        Button btnConfirm = dialog.findViewById(R.id.btn_import_confirm);

        if (btnPaste != null) {
            btnPaste.setOnClickListener(v -> {
                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip() != null
                        && clipboard.getPrimaryClip().getItemCount() > 0) {
                    CharSequence text = clipboard.getPrimaryClip().getItemAt(0).getText();
                    if (text != null && text.length() > 0) {
                        etXml.setText(text.toString());
                        MorsalinToast.show(this, R.drawable.ic_content_copy, "Pasted", "XML code pasted from clipboard!");
                    } else {
                        Toast.makeText(this, "Clipboard is empty.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Clipboard is empty.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnConfirm.setOnClickListener(v -> {
            String xml = etXml.getText().toString().trim();
            if (xml.isEmpty()) {
                Toast.makeText(this, "Please paste XML code first.", Toast.LENGTH_SHORT).show();
                return;
            }

            XmlParser.ParseResult result = XmlParser.parseXml(xml);
            if (!result.success) {
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                return;
            }

            dialog.dismiss();

            // Direct user to appropriate editor with the imported XML
            Intent intent;
            String typeName;
            boolean hasGradient = xml.contains("<gradient");
            boolean isMultiLayer = "layer-list".equals(result.rootTag) || (result.layerList != null && result.layerList.size() > 1);

            if (isMultiLayer) {
                intent = new Intent(MainActivity.this, ThreeDEditorActivity.class);
                typeName = "3D / Multi-Layer XML";
            } else if (hasGradient || ("shape".equals(result.rootTag) && result.singleLayer != null && result.singleLayer.isGradient())) {
                intent = new Intent(MainActivity.this, GradientEditorActivity.class);
                typeName = "Gradient XML";
            } else if ("shape".equals(result.rootTag) || ("selector".equals(result.rootTag) && !hasGradient)) {
                intent = new Intent(MainActivity.this, NormalEditorActivity.class);
                typeName = "Normal Shape XML";
            } else if (xml.contains("<LinearLayout") || xml.contains("<RelativeLayout") || xml.contains("<ConstraintLayout") || xml.contains("<FrameLayout")) {
                intent = new Intent(MainActivity.this, LayoutXmlEditorActivity.class);
                typeName = "Layout XML";
            } else {
                intent = new Intent(MainActivity.this, ThreeDEditorActivity.class);
                typeName = "Custom XML";
            }

            intent.putExtra("EXTRA_IMPORTED_XML", xml);
            MorsalinToast.show(this, R.drawable.ic_content_copy, "XML Detected", "Detected " + typeName + "! Opening for review and editing...");
            startActivity(intent);
            TransitionAnimationManager.applyForward(MainActivity.this);
        });

        dialog.show();
    }
}
