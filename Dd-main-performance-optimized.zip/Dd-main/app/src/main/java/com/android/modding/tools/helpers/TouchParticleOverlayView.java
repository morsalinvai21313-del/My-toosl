package com.android.modding.tools.helpers;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * High-performance canvas-based particle burst overlay.
 * Features ultra-dense, refined mini-particles with 15 styles + None.
 */
public class TouchParticleOverlayView extends View {

    public static final int STYLE_NONE = 0;
    public static final int STYLE_GOLDEN_STARS = 1;
    public static final int STYLE_NEON_SPHERES = 2;
    public static final int STYLE_MAGIC_FAIRY_DUST = 3;
    public static final int STYLE_FIRE_EMBERS = 4;
    public static final int STYLE_FLOATING_HEARTS = 5;
    public static final int STYLE_RAINBOW_BUBBLES = 6;
    public static final int STYLE_ELECTRIC_SPARKS = 7;
    public static final int STYLE_COSMIC_GALAXY = 8;
    public static final int STYLE_WATER_SPLASH = 9;
    public static final int STYLE_SPARKLING_CRYSTALS = 10;
    public static final int STYLE_CYBER_MATRIX = 11;
    public static final int STYLE_SAKURA_PETALS = 12;
    public static final int STYLE_FROZEN_ICE = 13;
    public static final int STYLE_STARLIGHT_NOVA = 14;
    public static final int STYLE_NEON_LASERS = 15;
    public static final int STYLE_PHOENIX_VORTEX = 16;
    public static final int STYLE_QUANTUM_PORTAL = 17;
    public static final int STYLE_DIAMOND_SHIMMER = 18;
    public static final int STYLE_CYBER_LIGHTNING = 19;
    public static final int STYLE_DRAGON_ENERGY = 20;

    public static final String[] STYLE_NAMES = {
            "None (Normal)",
            "Golden Sparkles",
            "Neon Spheres",
            "Magic Fairy Dust",
            "Fire & Embers",
            "Romantic Hearts",
            "Rainbow Bubbles",
            "Electric Sparks",
            "Cosmic Galaxy",
            "Water Splash",
            "Sparkling Crystals",
            "Cyber Matrix Rain",
            "Sakura Petals",
            "Frozen Ice Shards",
            "Starlight Supernova",
            "Neon Laser Sparks",
            "Phoenix Flame Vortex",
            "Quantum Portal Rings",
            "Diamond Shimmer Stars",
            "Cyber Glitch Lightning",
            "Dragon Energy Blast"
    };

    private static class Particle {
        float x, y;
        float vx, vy;
        float size;
        float maxSize;
        int color;
        float alpha;
        long birthTime;
        long lifeMs;
        float rotation;
        float rotSpeed;
        int shapeType; // 0=circle, 1=star, 2=heart, 3=spark, 4=diamond, 5=ring, 6=matrix_dash, 7=petal
    }

    private final List<Particle> particles = new ArrayList<>(250);
    private final List<Particle> pool = new ArrayList<>(250);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Random random = new Random();
    private int currentStyle = STYLE_NONE;
    private int ambientStyle = AmbientBackgroundAnimationManager.STYLE_NONE;

    private static class AmbientParticle {
        float x, y;
        float vx, vy;
        float size;
        int color;
        float baseAlpha;
        float pulseSpeed;
        float pulsePhase;
        int shape; // 0=circle, 1=star, 2=matrix_dash, 3=spark, 4=diamond
    }

    private final List<AmbientParticle> ambientParticles = new ArrayList<>(40);

    public TouchParticleOverlayView(Context context) {
        super(context);
        init();
    }

    public TouchParticleOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setWillNotDraw(false);
        paint.setStyle(Paint.Style.FILL);
        currentStyle = GlobalTouchParticleManager.getSavedStyle(getContext());
        ambientStyle = AmbientBackgroundAnimationManager.getSavedStyle(getContext());
        updateEffectVisibility();
    }

    private void updateEffectVisibility() {
        boolean effectsEnabled = currentStyle != STYLE_NONE
                || ambientStyle != AmbientBackgroundAnimationManager.STYLE_NONE;
        setVisibility(effectsEnabled ? View.VISIBLE : View.GONE);
    }

    public void setStyle(int style) {
        int newStyle = Math.max(0, Math.min(style, STYLE_NAMES.length - 1));
        if (currentStyle == newStyle) return;
        currentStyle = newStyle;
        if (currentStyle == STYLE_NONE) {
            particles.clear();
        }
        updateEffectVisibility();
        if (getVisibility() == View.VISIBLE) postInvalidateOnAnimation();
    }

    public int getStyle() {
        return currentStyle;
    }

    public void setAmbientStyle(int style) {
        int newStyle = Math.max(0, Math.min(style, AmbientBackgroundAnimationManager.STYLE_NAMES.length - 1));
        if (ambientStyle == newStyle) return;
        ambientStyle = newStyle;
        ambientParticles.clear();
        if (getWidth() > 0 && getHeight() > 0 && ambientStyle != AmbientBackgroundAnimationManager.STYLE_NONE) {
            initAmbientParticles(getWidth(), getHeight());
        }
        updateEffectVisibility();
        if (getVisibility() == View.VISIBLE) postInvalidateOnAnimation();
    }

    public int getAmbientStyle() {
        return ambientStyle;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0 && ambientStyle != AmbientBackgroundAnimationManager.STYLE_NONE) {
            initAmbientParticles(w, h);
            postInvalidateOnAnimation();
        }
    }

    private void initAmbientParticles(int width, int height) {
        ambientParticles.clear();
        int count = 34;
        for (int i = 0; i < count; i++) {
            AmbientParticle ap = new AmbientParticle();
            resetAmbientParticle(ap, width, height, true);
            ambientParticles.add(ap);
        }
    }

    private void resetAmbientParticle(AmbientParticle ap, int width, int height, boolean randomY) {
        ap.x = random.nextFloat() * width;
        ap.y = randomY ? (random.nextFloat() * height) : (height + 15f);
        ap.pulsePhase = random.nextFloat() * (float) (Math.PI * 2);
        ap.pulseSpeed = 0.025f + random.nextFloat() * 0.045f;

        switch (ambientStyle) {
            case AmbientBackgroundAnimationManager.STYLE_CYBER_STARFIELD:
                ap.shape = random.nextInt(3) == 0 ? 1 : 0;
                ap.size = 2.5f + random.nextFloat() * 3.5f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.25f;
                ap.vy = -0.35f - random.nextFloat() * 0.55f;
                ap.baseAlpha = 0.28f + random.nextFloat() * 0.35f;
                int[] stars = {0xFF00E5FF, 0xFFFFD700, 0xFFFFFFFF, 0xFF7C4DFF};
                ap.color = stars[random.nextInt(stars.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_MATRIX_RAIN:
                ap.shape = 2; // Dash
                ap.size = 3.2f + random.nextFloat() * 3.0f;
                ap.vx = 0;
                ap.vy = 2.5f + random.nextFloat() * 3.5f;
                ap.baseAlpha = 0.20f + random.nextFloat() * 0.32f;
                if (!randomY) ap.y = -20f;
                int[] mats = {0xFF00FF66, 0xFF39FF14, 0xFF00E5FF, 0xFF00CC44};
                ap.color = mats[random.nextInt(mats.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_QUANTUM_ORBS:
                ap.shape = 0; // Soft circle
                ap.size = 6.0f + random.nextFloat() * 12.0f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.45f;
                ap.vy = -0.20f - random.nextFloat() * 0.40f;
                ap.baseAlpha = 0.16f + random.nextFloat() * 0.22f;
                int[] orbs = {0xFF00E5FF, 0xFFE040FB, 0xFF00E676, 0xFF7C4DFF};
                ap.color = orbs[random.nextInt(orbs.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_CYBER_EMBERS:
                ap.shape = 0;
                ap.size = 2.8f + random.nextFloat() * 4.0f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.6f;
                ap.vy = -0.85f - random.nextFloat() * 1.35f;
                ap.baseAlpha = 0.25f + random.nextFloat() * 0.35f;
                int[] embers = {0xFFFF3D00, 0xFFFF9100, 0xFFFFD600, 0xFFFF1744};
                ap.color = embers[random.nextInt(embers.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_FROZEN_SNOW:
                ap.shape = 4; // Diamond shard
                ap.size = 3.0f + random.nextFloat() * 3.5f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.4f;
                ap.vy = 0.65f + random.nextFloat() * 1.15f;
                ap.baseAlpha = 0.25f + random.nextFloat() * 0.32f;
                if (!randomY) ap.y = -15f;
                int[] snow = {0xFFE1F5FE, 0xFFB3E5FC, 0xFFFFFFFF, 0xFF81D4FA};
                ap.color = snow[random.nextInt(snow.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_AURORA_WAVE:
                ap.shape = 3; // Sparkle
                ap.size = 3.5f + random.nextFloat() * 4.5f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.3f;
                ap.vy = -0.30f - random.nextFloat() * 0.45f;
                ap.baseAlpha = 0.22f + random.nextFloat() * 0.30f;
                int[] aurora = {0xFF00E5FF, 0xFF69F0AE, 0xFFE040FB, 0xFF00B0FF};
                ap.color = aurora[random.nextInt(aurora.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_HYPERSPACE_WARP:
                ap.shape = 2; // Fast streaking dash
                ap.size = 4.0f + random.nextFloat() * 6.0f;
                ap.vx = 0f;
                ap.vy = 4.5f + random.nextFloat() * 6.5f;
                ap.baseAlpha = 0.35f + random.nextFloat() * 0.40f;
                if (!randomY) ap.y = -25f;
                int[] warps = {0xFFFFFFFF, 0xFF80D8FF, 0xFF00E5FF, 0xFFB388FF};
                ap.color = warps[random.nextInt(warps.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_HOLO_HEX_GRID:
                ap.shape = 4; // Diamond / tech node
                ap.size = 3.5f + random.nextFloat() * 4.0f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.35f;
                ap.vy = -0.45f - random.nextFloat() * 0.65f;
                ap.baseAlpha = 0.25f + random.nextFloat() * 0.30f;
                int[] hexs = {0xFF00E5FF, 0xFF00B0FF, 0xFF651FFF, 0xFF1DE9B6};
                ap.color = hexs[random.nextInt(hexs.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_CELESTIAL_GOLD:
                ap.shape = 1; // Star
                ap.size = 3.0f + random.nextFloat() * 4.5f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.4f;
                ap.vy = -0.35f - random.nextFloat() * 0.50f;
                ap.baseAlpha = 0.30f + random.nextFloat() * 0.40f;
                int[] golds = {0xFFFFD700, 0xFFFFE082, 0xFFFFAB00, 0xFFFFF8E1};
                ap.color = golds[random.nextInt(golds.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_PLASMA_STORM:
                ap.shape = 3; // Electric sparkle
                ap.size = 3.0f + random.nextFloat() * 5.0f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.8f;
                ap.vy = -0.6f - random.nextFloat() * 0.9f;
                ap.baseAlpha = 0.30f + random.nextFloat() * 0.45f;
                int[] plasmas = {0xFFD500F9, 0xFF00E5FF, 0xFF7C4DFF, 0xFFFFFFFF};
                ap.color = plasmas[random.nextInt(plasmas.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_SAKURA_BREEZE:
                ap.shape = 7; // Petal
                ap.size = 4.0f + random.nextFloat() * 4.5f;
                ap.vx = 0.4f + random.nextFloat() * 0.7f;
                ap.vy = 0.6f + random.nextFloat() * 0.8f;
                ap.baseAlpha = 0.28f + random.nextFloat() * 0.35f;
                if (!randomY) ap.y = -15f;
                int[] petals = {0xFFFF80AB, 0xFFFF4081, 0xFFF8BBD0, 0xFFFFC1E3};
                ap.color = petals[random.nextInt(petals.length)];
                break;

            case AmbientBackgroundAnimationManager.STYLE_SYNTHWAVE_GRID:
                ap.shape = 0; // Glowing orb
                ap.size = 4.5f + random.nextFloat() * 6.5f;
                ap.vx = (random.nextFloat() - 0.5f) * 0.3f;
                ap.vy = -0.40f - random.nextFloat() * 0.60f;
                ap.baseAlpha = 0.25f + random.nextFloat() * 0.35f;
                int[] synths = {0xFFFF007F, 0xFF00F5D4, 0xFF7928CA, 0xFFFFBE0B};
                ap.color = synths[random.nextInt(synths.length)];
                break;

            default:
                ap.baseAlpha = 0f;
                break;
        }
    }

    /**
     * Spawns an ultra-dense burst of refined mini-particles radiating from touch point (x, y).
     */
    public void spawnBurst(float x, float y) {
        if (currentStyle == STYLE_NONE) return;

        // Denser particle count: 52 to 74 particles per touch tap
        int count = 52 + random.nextInt(23);
        long now = SystemClock.uptimeMillis();

        for (int i = 0; i < count; i++) {
            Particle p = obtainParticle();
            p.x = x;
            p.y = y;
            p.birthTime = now;
            p.lifeMs = 380 + random.nextInt(320);
            p.rotation = random.nextFloat() * 360f;
            p.rotSpeed = (random.nextFloat() - 0.5f) * 16f;

            double angle = random.nextDouble() * 2.0 * Math.PI;
            float speed = 2.5f + random.nextFloat() * 10f;
            p.vx = (float) (Math.cos(angle) * speed);
            p.vy = (float) (Math.sin(angle) * speed);

            configureParticleForStyle(p);
            particles.add(p);
        }

        postInvalidateOnAnimation();
    }

    private void configureParticleForStyle(Particle p) {
        switch (currentStyle) {
            case STYLE_GOLDEN_STARS:
                p.shapeType = random.nextInt(3) == 0 ? 1 : 0;
                p.maxSize = 4.5f + random.nextFloat() * 6.5f;
                p.color = random.nextBoolean() ? 0xFFFFD700 : (random.nextBoolean() ? 0xFFFFF176 : 0xFFFFB300);
                p.vy -= 1.8f;
                break;

            case STYLE_NEON_SPHERES:
                p.shapeType = 0;
                p.maxSize = 4.0f + random.nextFloat() * 6.0f;
                int[] neonCols = {0xFF00E5FF, 0xFFE040FB, 0xFF00E676, 0xFFFF007F, 0xFFFFD600};
                p.color = neonCols[random.nextInt(neonCols.length)];
                break;

            case STYLE_MAGIC_FAIRY_DUST:
                p.shapeType = random.nextInt(3) == 0 ? 1 : 0;
                p.maxSize = 3.5f + random.nextFloat() * 5.5f;
                int[] magicCols = {0xFFB388FF, 0xFF80D8FF, 0xFFFF80AB, 0xFFEA80FC, 0xFFFFFFFF, 0xFF00E5FF};
                p.color = magicCols[random.nextInt(magicCols.length)];
                p.vy -= 1.2f;
                break;

            case STYLE_FIRE_EMBERS:
                p.shapeType = 0;
                p.maxSize = 3.8f + random.nextFloat() * 6.2f;
                int[] fireCols = {0xFFFF3D00, 0xFFFF9100, 0xFFFFD600, 0xFFFF1744, 0xFFFF6D00};
                p.color = fireCols[random.nextInt(fireCols.length)];
                p.vy -= 4.5f + random.nextFloat() * 3.5f;
                p.vx *= 0.65f;
                break;

            case STYLE_FLOATING_HEARTS:
                p.shapeType = 2; // Heart
                p.maxSize = 6.0f + random.nextFloat() * 6.5f;
                int[] heartCols = {0xFFFF4081, 0xFFF50057, 0xFFFF80AB, 0xFFFF1744, 0xFFFF80DF};
                p.color = heartCols[random.nextInt(heartCols.length)];
                p.vy -= 2.2f;
                break;

            case STYLE_RAINBOW_BUBBLES:
                p.shapeType = 5; // Ring / bubble
                p.maxSize = 5.0f + random.nextFloat() * 7.5f;
                int[] bubbleCols = {0xCC00E5FF, 0xCC7C4DFF, 0xCC00E676, 0xCCFFD600, 0xCCFF4081, 0xCC00F0FF};
                p.color = bubbleCols[random.nextInt(bubbleCols.length)];
                p.vy -= 1.8f;
                break;

            case STYLE_ELECTRIC_SPARKS:
                p.shapeType = 3; // Sharp spark
                p.maxSize = 4.0f + random.nextFloat() * 6.5f;
                int[] sparkCols = {0xFF00E5FF, 0xFFFFFF00, 0xFFFFFFFF, 0xFF00B0FF, 0xFF00E676};
                p.color = sparkCols[random.nextInt(sparkCols.length)];
                p.vx *= 1.35f;
                p.vy *= 1.35f;
                break;

            case STYLE_COSMIC_GALAXY:
                p.shapeType = random.nextBoolean() ? 1 : 4;
                p.maxSize = 4.2f + random.nextFloat() * 6.2f;
                int[] cosmicCols = {0xFF7C4DFF, 0xFF536DFE, 0xFF69F0AE, 0xFFFF4081, 0xFFFFFFFF, 0xFF00E5FF};
                p.color = cosmicCols[random.nextInt(cosmicCols.length)];
                break;

            case STYLE_WATER_SPLASH:
                p.shapeType = random.nextBoolean() ? 0 : 5;
                p.maxSize = 4.0f + random.nextFloat() * 6.8f;
                int[] waterCols = {0xDD00B0FF, 0xDD40C4FF, 0xDD80D8FF, 0xDDFFFFFF, 0xDD00E5FF};
                p.color = waterCols[random.nextInt(waterCols.length)];
                p.vy += 1.6f;
                break;

            case STYLE_SPARKLING_CRYSTALS:
                p.shapeType = 4; // Diamond
                p.maxSize = 4.8f + random.nextFloat() * 6.8f;
                int[] gemCols = {0xFF00E5FF, 0xFFE040FB, 0xFF00E676, 0xFFFFD700, 0xFFFFFFFF};
                p.color = gemCols[random.nextInt(gemCols.length)];
                break;

            case STYLE_CYBER_MATRIX:
                p.shapeType = 6; // Matrix dash
                p.maxSize = 4.0f + random.nextFloat() * 6.0f;
                int[] matCols = {0xFF00FF66, 0xFF00E5FF, 0xFF39FF14, 0xFFFFFFFF, 0xFF00CC44};
                p.color = matCols[random.nextInt(matCols.length)];
                p.vy += 2.0f + random.nextFloat() * 2f;
                p.vx *= 0.5f;
                break;

            case STYLE_SAKURA_PETALS:
                p.shapeType = 7; // Petal
                p.maxSize = 5.2f + random.nextFloat() * 6.0f;
                int[] petalCols = {0xFFFF80AB, 0xFFFF4081, 0xFFFFB2DD, 0xFFFFE4EC, 0xFFF06292};
                p.color = petalCols[random.nextInt(petalCols.length)];
                p.vy -= 0.5f;
                p.vx += (random.nextFloat() - 0.5f) * 2f;
                break;

            case STYLE_FROZEN_ICE:
                p.shapeType = 4; // Diamond shard
                p.maxSize = 3.8f + random.nextFloat() * 5.8f;
                int[] iceCols = {0xFFE1F5FE, 0xFFB3E5FC, 0xFF81D4FA, 0xFFFFFFFF, 0xFF00E5FF};
                p.color = iceCols[random.nextInt(iceCols.length)];
                p.vy += 0.8f;
                break;

            case STYLE_STARLIGHT_NOVA:
                p.shapeType = random.nextInt(4) == 0 ? 3 : 1;
                p.maxSize = 4.5f + random.nextFloat() * 7.0f;
                int[] novaCols = {0xFFFFEB3B, 0xFF00E5FF, 0xFFFF007F, 0xFFFFFFFF, 0xFF76FF03};
                p.color = novaCols[random.nextInt(novaCols.length)];
                p.vx *= 1.4f;
                p.vy *= 1.4f;
                break;

            case STYLE_NEON_LASERS:
                p.shapeType = 3;
                p.maxSize = 4.0f + random.nextFloat() * 7.5f;
                int[] laserCols = {0xFFFF0055, 0xFF00E5FF, 0xFFFFFF00, 0xFF00FF66};
                p.color = laserCols[random.nextInt(laserCols.length)];
                p.vx *= 1.5f;
                p.vy *= 1.5f;
                break;

            case STYLE_PHOENIX_VORTEX:
                p.shapeType = random.nextInt(3) == 0 ? 3 : 7;
                p.maxSize = 4.8f + random.nextFloat() * 6.5f;
                int[] phoenixCols = {0xFFFF1744, 0xFFFF6D00, 0xFFFFD600, 0xFFFF9100, 0xFFFF3D00};
                p.color = phoenixCols[random.nextInt(phoenixCols.length)];
                p.vx *= 1.25f;
                p.vy -= 2.0f;
                break;

            case STYLE_QUANTUM_PORTAL:
                p.shapeType = random.nextBoolean() ? 5 : 0;
                p.maxSize = 5.2f + random.nextFloat() * 7.0f;
                int[] portalCols = {0xFF00E5FF, 0xFF7C4DFF, 0xFFE040FB, 0xFF00B0FF, 0xFFFFFFFF};
                p.color = portalCols[random.nextInt(portalCols.length)];
                p.vx *= 1.15f;
                p.vy *= 1.15f;
                break;

            case STYLE_DIAMOND_SHIMMER:
                p.shapeType = 4;
                p.maxSize = 4.5f + random.nextFloat() * 6.5f;
                int[] diamondCols = {0xFFE0F7FA, 0xFF80DEEA, 0xFFFFFFFF, 0xFFB2EBF2, 0xFFFFD700};
                p.color = diamondCols[random.nextInt(diamondCols.length)];
                p.vx *= 1.1f;
                p.vy *= 1.1f;
                break;

            case STYLE_CYBER_LIGHTNING:
                p.shapeType = random.nextBoolean() ? 3 : 6;
                p.maxSize = 4.2f + random.nextFloat() * 7.2f;
                int[] lightningCols = {0xFF00E5FF, 0xFF76FF03, 0xFFFFFF00, 0xFFFFFFFF, 0xFF00FFCC};
                p.color = lightningCols[random.nextInt(lightningCols.length)];
                p.vx *= 1.6f;
                p.vy *= 1.6f;
                break;

            case STYLE_DRAGON_ENERGY:
                p.shapeType = random.nextInt(3) == 0 ? 5 : 0;
                p.maxSize = 4.8f + random.nextFloat() * 7.5f;
                int[] dragonCols = {0xFF00E676, 0xFF00FFCC, 0xFFFFD700, 0xFF00B0FF, 0xFFFFFFFF};
                p.color = dragonCols[random.nextInt(dragonCols.length)];
                p.vy -= 1.5f;
                p.vx *= 1.2f;
                break;
        }
        p.size = p.maxSize;
    }

    private Particle obtainParticle() {
        if (!pool.isEmpty()) {
            return pool.remove(pool.size() - 1);
        }
        return new Particle();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();

        // 1. Render Ambient Background Particles (if enabled)
        if (ambientStyle != AmbientBackgroundAnimationManager.STYLE_NONE && w > 0 && h > 0) {
            if (ambientParticles.isEmpty()) {
                initAmbientParticles(w, h);
            }

            for (int i = 0; i < ambientParticles.size(); i++) {
                AmbientParticle ap = ambientParticles.get(i);
                ap.x += ap.vx;
                ap.y += ap.vy;
                ap.pulsePhase += ap.pulseSpeed;

                // Out of screen bounds wrap
                if (ap.y < -30f) {
                    resetAmbientParticle(ap, w, h, false);
                } else if (ap.y > h + 30f) {
                    ap.y = -10f;
                    ap.x = random.nextFloat() * w;
                }
                if (ap.x < -30f) ap.x = w + 10f;
                else if (ap.x > w + 30f) ap.x = -10f;

                float pulse = 0.8f + 0.2f * (float) Math.sin(ap.pulsePhase);
                float a = Math.max(0f, Math.min(1f, ap.baseAlpha * pulse));
                int alphaInt = (int) (a * 255);
                int col = (ap.color & 0x00FFFFFF) | (alphaInt << 24);
                paint.setColor(col);

                canvas.save();
                canvas.translate(ap.x, ap.y);

                switch (ap.shape) {
                    case 1: // Star
                        drawStar(canvas, ap.size);
                        break;
                    case 2: // Matrix Dash
                        canvas.drawRect(-ap.size * 0.4f, -ap.size * 1.6f, ap.size * 0.4f, ap.size * 1.6f, paint);
                        break;
                    case 3: // Sparkle
                        drawSpark(canvas, ap.size);
                        break;
                    case 4: // Diamond
                        drawDiamond(canvas, ap.size);
                        break;
                    case 0: // Soft Circle
                    default:
                        canvas.drawCircle(0, 0, ap.size, paint);
                        break;
                }
                canvas.restore();
            }
        }

        // 2. Render Foreground Touch Tap Burst Particles
        if (!particles.isEmpty()) {
            long now = SystemClock.uptimeMillis();
            for (int i = particles.size() - 1; i >= 0; i--) {
                Particle p = particles.get(i);
                long age = now - p.birthTime;
                if (age >= p.lifeMs) {
                    particles.remove(i);
                    pool.add(p);
                    continue;
                }

                float progress = (float) age / (float) p.lifeMs;
                p.alpha = 1.0f - progress;
                p.size = p.maxSize * (1.0f - (progress * 0.40f));

                // Physics update
                p.x += p.vx;
                p.y += p.vy;
                p.vx *= 0.95f;
                p.vy *= 0.95f;
                if (currentStyle == STYLE_WATER_SPLASH || currentStyle == STYLE_CYBER_MATRIX) {
                    p.vy += 0.45f;
                } else if (currentStyle == STYLE_FIRE_EMBERS) {
                    p.vy -= 0.30f;
                } else if (currentStyle == STYLE_SAKURA_PETALS) {
                    p.vx += (float) Math.sin((age / 80.0)) * 0.4f;
                    p.vy += 0.15f;
                } else if (currentStyle == STYLE_PHOENIX_VORTEX) {
                    p.vx += (float) Math.cos((age / 60.0)) * 0.5f;
                    p.vy -= 0.35f;
                } else if (currentStyle == STYLE_DRAGON_ENERGY) {
                    p.vx += (float) Math.sin((age / 70.0)) * 0.4f;
                    p.vy -= 0.25f;
                } else if (currentStyle == STYLE_CYBER_LIGHTNING) {
                    if (random.nextInt(4) == 0) {
                        p.vx += (random.nextFloat() - 0.5f) * 1.5f;
                        p.vy += (random.nextFloat() - 0.5f) * 1.5f;
                    }
                }
                p.rotation += p.rotSpeed;

                int alphaInt = Math.max(0, Math.min(255, (int) (p.alpha * 255)));
                int col = (p.color & 0x00FFFFFF) | (alphaInt << 24);
                paint.setColor(col);

                canvas.save();
                canvas.translate(p.x, p.y);
                canvas.rotate(p.rotation);

                switch (p.shapeType) {
                    case 1: // Star
                        drawStar(canvas, p.size);
                        break;
                    case 2: // Heart
                        drawHeart(canvas, p.size);
                        break;
                    case 3: // Electric spark
                        drawSpark(canvas, p.size);
                        break;
                    case 4: // Diamond
                        drawDiamond(canvas, p.size);
                        break;
                    case 5: // Ring / Bubble
                        paint.setStyle(Paint.Style.STROKE);
                        paint.setStrokeWidth(Math.max(1.5f, p.size * 0.22f));
                        canvas.drawCircle(0, 0, p.size, paint);
                        paint.setStyle(Paint.Style.FILL);
                        break;
                    case 6: // Matrix dash
                        canvas.drawRect(-p.size * 0.4f, -p.size * 1.5f, p.size * 0.4f, p.size * 1.5f, paint);
                        break;
                    case 7: // Sakura Petal
                        drawPetal(canvas, p.size);
                        break;
                    case 0: // Circle / Sphere
                    default:
                        canvas.drawCircle(0, 0, p.size, paint);
                        break;
                }

                canvas.restore();
            }
        }

        // Continue rendering loop if ambient particles or touch burst active
        if ((ambientStyle != AmbientBackgroundAnimationManager.STYLE_NONE) || !particles.isEmpty()) {
            postInvalidateOnAnimation();
        }
    }

    private void drawStar(Canvas canvas, float radius) {
        path.reset();
        int points = 4;
        float innerRadius = radius * 0.35f;
        for (int i = 0; i < points * 2; i++) {
            float r = (i % 2 == 0) ? radius : innerRadius;
            double angle = i * Math.PI / points;
            float x = (float) (Math.cos(angle) * r);
            float y = (float) (Math.sin(angle) * r);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
        canvas.drawPath(path, paint);
    }

    private void drawHeart(Canvas canvas, float size) {
        path.reset();
        float s = size * 0.8f;
        path.moveTo(0, s * 0.35f);
        path.cubicTo(-s, -s * 0.6f, -s * 0.8f, -s * 1.2f, 0, -s * 0.6f);
        path.cubicTo(s * 0.8f, -s * 1.2f, s, -s * 0.6f, 0, s * 0.35f);
        canvas.drawPath(path, paint);
    }

    private void drawSpark(Canvas canvas, float size) {
        path.reset();
        path.moveTo(0, -size * 1.5f);
        path.lineTo(size * 0.32f, 0);
        path.lineTo(0, size * 1.5f);
        path.lineTo(-size * 0.32f, 0);
        path.close();
        canvas.drawPath(path, paint);
    }

    private void drawDiamond(Canvas canvas, float size) {
        path.reset();
        path.moveTo(0, -size);
        path.lineTo(size * 0.75f, 0);
        path.lineTo(0, size);
        path.lineTo(-size * 0.75f, 0);
        path.close();
        canvas.drawPath(path, paint);
    }

    private void drawPetal(Canvas canvas, float size) {
        path.reset();
        path.moveTo(0, -size * 1.2f);
        path.quadTo(size * 0.7f, 0, 0, size * 1.2f);
        path.quadTo(-size * 0.7f, 0, 0, -size * 1.2f);
        path.close();
        canvas.drawPath(path, paint);
    }
}
