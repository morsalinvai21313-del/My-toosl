package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class StrokeModel implements Serializable {
    private String color = "#00000000";
    private int widthDp = 0;
    private int dashWidthDp = 0;
    private int dashGapDp = 0;

    public StrokeModel() {}

    public StrokeModel(String color, int widthDp, int dashWidthDp, int dashGapDp) {
        this.color = color;
        this.widthDp = widthDp;
        this.dashWidthDp = dashWidthDp;
        this.dashGapDp = dashGapDp;
    }

    public String getColor() {
        return color != null ? color : "#00000000";
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getWidthDp() {
        return widthDp;
    }

    public void setWidthDp(int widthDp) {
        this.widthDp = Math.max(0, widthDp);
    }

    public int getDashWidthDp() {
        return dashWidthDp;
    }

    public void setDashWidthDp(int dashWidthDp) {
        this.dashWidthDp = Math.max(0, dashWidthDp);
    }

    public int getDashGapDp() {
        return dashGapDp;
    }

    public void setDashGapDp(int dashGapDp) {
        this.dashGapDp = Math.max(0, dashGapDp);
    }

    public StrokeModel copy() {
        return new StrokeModel(color, widthDp, dashWidthDp, dashGapDp);
    }
}
