package com.android.modding.tools.helpers;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.Context;
import android.content.SharedPreferences;



import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HistoryManager {

    private static final String PREF_NAME = "morsalin_history_pref";
    private static final String KEY_PROJECTS = "saved_projects";

    private final SharedPreferences prefs;

    public HistoryManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public synchronized void saveProject(XmlProject project) {
        List<XmlProject> projects = getAllProjects();
        // Remove existing if duplicate id
        for (int i = 0; i < projects.size(); i++) {
            if (projects.get(i).getId().equals(project.getId())) {
                projects.remove(i);
                break;
            }
        }
        projects.add(0, project); // add to top
        saveAll(projects);
    }

    public synchronized List<XmlProject> getAllProjects() {
        List<XmlProject> list = new ArrayList<>();
        String jsonStr = prefs.getString(KEY_PROJECTS, null);
        if (jsonStr == null || jsonStr.isEmpty()) {
            return list;
        }

        try {
            JSONArray array = new JSONArray(jsonStr);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                XmlProject p = new XmlProject();
                p.setId(obj.optString("id", String.valueOf(System.currentTimeMillis())));
                p.setName(obj.optString("name", "Untitled"));
                p.setType(obj.optString("type", XmlProject.TYPE_NORMAL));
                p.setTimestamp(obj.optLong("timestamp", System.currentTimeMillis()));
                p.setXmlCode(obj.optString("xmlCode", ""));
                p.setJsonConfig(obj.optString("jsonConfig", ""));
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public synchronized void deleteProject(String id) {
        List<XmlProject> projects = getAllProjects();
        for (int i = 0; i < projects.size(); i++) {
            if (projects.get(i).getId().equals(id)) {
                projects.remove(i);
                break;
            }
        }
        saveAll(projects);
    }

    private void saveAll(List<XmlProject> projects) {
        try {
            JSONArray array = new JSONArray();
            for (XmlProject p : projects) {
                JSONObject obj = new JSONObject();
                obj.put("id", p.getId());
                obj.put("name", p.getName());
                obj.put("type", p.getType());
                obj.put("timestamp", p.getTimestamp());
                obj.put("xmlCode", p.getXmlCode());
                obj.put("jsonConfig", p.getJsonConfig());
                array.put(obj);
            }
            prefs.edit().putString(KEY_PROJECTS, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
