package com.android.modding.tools.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.SocialButtonAnimationHelper;
import com.android.modding.tools.helpers.TransitionAnimationManager;

public class CodeEditorCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_code_editor);

        GlobalTouchParticleManager.attach(this);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_category_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_category_about).setOnClickListener(v -> {
            com.android.modding.tools.dialogs.MorsalinDialogHelper.showAboutDialog(this);
        });

        // Social micro-animations
        SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // Option 1: Text Editor
        findViewById(R.id.btn_tool_text_editor).setOnClickListener(v -> {
            Intent intent = new Intent(this, CodeEditorActivity.class);
            intent.putExtra(CodeEditorActivity.EXTRA_INITIAL_MODE, CodeEditorActivity.MODE_NOTEPAD);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });

        // Option 2: Note Pad
        findViewById(R.id.btn_tool_notepad).setOnClickListener(v -> {
            Intent intent = new Intent(this, CodeEditorActivity.class);
            intent.putExtra(CodeEditorActivity.EXTRA_INITIAL_MODE, CodeEditorActivity.MODE_NOTEPAD);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });

        // Option 3: HTML Editor
        findViewById(R.id.btn_tool_html_editor).setOnClickListener(v -> {
            Intent intent = new Intent(this, CodeEditorActivity.class);
            intent.putExtra(CodeEditorActivity.EXTRA_INITIAL_MODE, CodeEditorActivity.MODE_HTML);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });

        // Option 4: XML Editor
        findViewById(R.id.btn_tool_xml_editor).setOnClickListener(v -> {
            Intent intent = new Intent(this, CodeEditorActivity.class);
            intent.putExtra(CodeEditorActivity.EXTRA_INITIAL_MODE, CodeEditorActivity.MODE_XML);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });

        // Option 5: Dex Editor
        findViewById(R.id.btn_tool_dex_editor).setOnClickListener(v -> {
            Intent intent = new Intent(this, ClassToSmaliActivity.class);
            startActivity(intent);
            TransitionAnimationManager.applyForward(this);
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
