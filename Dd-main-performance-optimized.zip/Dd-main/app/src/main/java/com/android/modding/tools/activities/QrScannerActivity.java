package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinQrGenerator;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraControl;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class QrScannerActivity extends AppCompatActivity {

    private PreviewView cameraPreviewView;
    private View viewLaserLine;
    private View layoutPermissionDenied;
    private Button btnGrantPermission;
    private Button btnTorch;
    private Button btnFlipCamera;
    private Button btnScanGallery;

    private View cardResult;
    private TextView tvResultType;
    private EditText etResultContent;
    private Button btnScanAgain;
    private Button btnActionOpen;
    private Button btnActionCopy;
    private Button btnActionShare;

    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private boolean isTorchOn = false;
    private int lensFacing = CameraSelector.LENS_FACING_BACK;
    private boolean isScanningPaused = false;
    private ExecutorService cameraExecutor;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    layoutPermissionDenied.setVisibility(View.GONE);
                    startCamera();
                } else {
                    layoutPermissionDenied.setVisibility(View.VISIBLE);
                }
            });

    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    decodeImageUri(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_scanner);

        GlobalTouchParticleManager.attach(this);
        cameraExecutor = Executors.newSingleThreadExecutor();

        initViews();
        startLaserAnimation();
        checkAndRequestCamera();
    }

    private void initViews() {
        findViewById(R.id.btn_qr_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        cameraPreviewView = findViewById(R.id.camera_preview_view);
        if (cameraPreviewView != null) {
            cameraPreviewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
            cameraPreviewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
            cameraPreviewView.setBackgroundColor(Color.BLACK);
        }
        viewLaserLine = findViewById(R.id.view_qr_laser_line);
        layoutPermissionDenied = findViewById(R.id.layout_camera_permission_denied);
        btnGrantPermission = findViewById(R.id.btn_grant_camera_permission);
        btnTorch = findViewById(R.id.btn_qr_torch);
        btnFlipCamera = findViewById(R.id.btn_qr_flip_camera);
        btnScanGallery = findViewById(R.id.btn_qr_scan_gallery);
        Button btnSampleCode = findViewById(R.id.btn_qr_sample_code);
        Button btnTorchBottom = findViewById(R.id.btn_qr_torch_bottom);

        cardResult = findViewById(R.id.card_qr_result);
        tvResultType = findViewById(R.id.tv_qr_result_type);
        etResultContent = findViewById(R.id.et_qr_result_content);
        btnScanAgain = findViewById(R.id.btn_qr_scan_again);
        btnActionOpen = findViewById(R.id.btn_qr_action_open);
        btnActionCopy = findViewById(R.id.btn_qr_action_copy);
        btnActionShare = findViewById(R.id.btn_qr_action_share);

        btnGrantPermission.setOnClickListener(v -> checkAndRequestCamera());
        btnTorch.setOnClickListener(v -> toggleTorch());
        if (btnTorchBottom != null) {
            btnTorchBottom.setOnClickListener(v -> toggleTorch());
        }
        btnFlipCamera.setOnClickListener(v -> flipCamera());
        btnScanGallery.setOnClickListener(v -> galleryLauncher.launch("image/*"));
        if (btnSampleCode != null) {
            btnSampleCode.setOnClickListener(v -> loadSampleQr());
        }

        btnScanAgain.setOnClickListener(v -> resumeScanning());

        btnActionCopy.setOnClickListener(v -> {
            String text = etResultContent.getText().toString();
            if (!text.isEmpty()) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("QR Code", text);
                clipboard.setPrimaryClip(clip);
                MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied", "QR content copied to clipboard!");
            }
        });

        btnActionShare.setOnClickListener(v -> {
            String text = etResultContent.getText().toString();
            if (!text.isEmpty()) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(shareIntent, "Share QR Content"));
            }
        });

        btnActionOpen.setOnClickListener(v -> {
            String text = etResultContent.getText().toString().trim();
            if (!text.isEmpty()) {
                if (!text.startsWith("http://") && !text.startsWith("https://")) {
                    text = "https://" + text;
                }
                try {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(text));
                    startActivity(browserIntent);
                } catch (Exception e) {
                    Toast.makeText(this, "Cannot open URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void startLaserAnimation() {
        if (viewLaserLine != null) {
            TranslateAnimation animation = new TranslateAnimation(
                    Animation.RELATIVE_TO_PARENT, 0.0f,
                    Animation.RELATIVE_TO_PARENT, 0.0f,
                    Animation.RELATIVE_TO_PARENT, 0.0f,
                    Animation.RELATIVE_TO_PARENT, 0.95f
            );
            animation.setDuration(2200);
            animation.setRepeatCount(Animation.INFINITE);
            animation.setRepeatMode(Animation.REVERSE);
            animation.setInterpolator(new LinearInterpolator());
            viewLaserLine.startAnimation(animation);
        }
    }

    private void checkAndRequestCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            layoutPermissionDenied.setVisibility(View.GONE);
            startCamera();
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void startCamera() {
        if (cameraPreviewView == null) return;
        cameraPreviewView.post(() -> {
            ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(QrScannerActivity.this);
            cameraProviderFuture.addListener(() -> {
                try {
                    cameraProvider = cameraProviderFuture.get();
                    bindCameraUseCases();
                } catch (ExecutionException | InterruptedException e) {
                    Toast.makeText(QrScannerActivity.this, "Failed to start camera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }, ContextCompat.getMainExecutor(QrScannerActivity.this));
        });
    }

    private void bindCameraUseCases() {
        if (cameraProvider == null) return;
        cameraProvider.unbindAll();

        CameraSelector cameraSelector = null;
        try {
            CameraSelector target = new CameraSelector.Builder().requireLensFacing(lensFacing).build();
            if (cameraProvider.hasCamera(target)) {
                cameraSelector = target;
            } else {
                int oppositeFacing = (lensFacing == CameraSelector.LENS_FACING_BACK)
                        ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
                CameraSelector fallback = new CameraSelector.Builder().requireLensFacing(oppositeFacing).build();
                if (cameraProvider.hasCamera(fallback)) {
                    cameraSelector = fallback;
                    lensFacing = oppositeFacing;
                }
            }
        } catch (Exception e) {
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA;
        }

        if (cameraSelector == null) {
            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Virtual Scanner Active",
                    "No physical camera found. Use 'SAMPLE QR' or 'GALLERY' to scan instantly!");
            return;
        }

        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(cameraPreviewView.getSurfaceProvider());

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeImageProxy);

        try {
            camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Camera Hardware Notice",
                    "Could not access live lens: " + e.getMessage() + ". You can still test with 'SAMPLE QR'!");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            layoutPermissionDenied.setVisibility(View.GONE);
            startCamera();
        }
    }

    private void analyzeImageProxy(@NonNull ImageProxy image) {
        if (isScanningPaused) {
            image.close();
            return;
        }

        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            int width = image.getWidth();
            int height = image.getHeight();
            int rotation = image.getImageInfo().getRotationDegrees();

            byte[] finalBytes = bytes;
            int finalW = width;
            int finalH = height;

            if (rotation == 90) {
                finalBytes = rotateY90(bytes, width, height);
                finalW = height;
                finalH = width;
            } else if (rotation == 270) {
                finalBytes = rotateY270(bytes, width, height);
                finalW = height;
                finalH = width;
            } else if (rotation == 180) {
                finalBytes = rotateY180(bytes, width, height);
            }

            PlanarYUVLuminanceSource source = new PlanarYUVLuminanceSource(
                    finalBytes, finalW, finalH, 0, 0, finalW, finalH, false);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

            MultiFormatReader reader = new MultiFormatReader();
            Result result = null;
            try {
                result = reader.decodeWithState(bitmap);
            } catch (Exception e) {
                // Try fallback without rotation if decoding failed
                if (finalBytes != bytes) {
                    PlanarYUVLuminanceSource rawSource = new PlanarYUVLuminanceSource(
                            bytes, width, height, 0, 0, width, height, false);
                    result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(rawSource)));
                }
            }

            if (result != null && result.getText() != null && !result.getText().isEmpty()) {
                final Result finalResult = result;
                runOnUiThread(() -> onCodeDetected(finalResult.getText(), finalResult.getBarcodeFormat().toString()));
            }
        } catch (Exception ignored) {
            // No barcode found in current frame
        } finally {
            image.close();
        }
    }

    private byte[] rotateY90(byte[] data, int width, int height) {
        byte[] y = new byte[width * height];
        int i = 0;
        for (int x = 0; x < width; x++) {
            for (int r = height - 1; r >= 0; r--) {
                y[i++] = data[r * width + x];
            }
        }
        return y;
    }

    private byte[] rotateY270(byte[] data, int width, int height) {
        byte[] y = new byte[width * height];
        int i = 0;
        for (int x = width - 1; x >= 0; x--) {
            for (int r = 0; r < height; r++) {
                y[i++] = data[r * width + x];
            }
        }
        return y;
    }

    private byte[] rotateY180(byte[] data, int width, int height) {
        byte[] y = new byte[width * height];
        int total = width * height;
        for (int i = 0; i < total; i++) {
            y[i] = data[total - 1 - i];
        }
        return y;
    }

    private void onCodeDetected(String text, String format) {
        if (isScanningPaused) return;
        isScanningPaused = true;

        cardResult.setVisibility(View.VISIBLE);
        cardResult.setAlpha(0f);
        cardResult.animate().alpha(1f).setDuration(250).start();

        tvResultType.setText("DETECTED (" + format + ")");
        etResultContent.setText(text);

        boolean isUrl = text.startsWith("http://") || text.startsWith("https://") || text.contains(".com") || text.contains(".net");
        btnActionOpen.setVisibility(isUrl ? View.VISIBLE : View.GONE);

        MorsalinToast.show(this, R.drawable.ic_code_convert, "QR Code Scanned", "Successfully decoded " + format + "!");
    }

    private void resumeScanning() {
        isScanningPaused = false;
        cardResult.setVisibility(View.GONE);
    }

    private void toggleTorch() {
        if (camera != null && camera.getCameraInfo().hasFlashUnit()) {
            CameraControl control = camera.getCameraControl();
            isTorchOn = !isTorchOn;
            control.enableTorch(isTorchOn);
            btnTorch.setText(isTorchOn ? "Flash ON" : "Flash");
        } else {
            Toast.makeText(this, "Flashlight unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void flipCamera() {
        lensFacing = (lensFacing == CameraSelector.LENS_FACING_BACK)
                ? CameraSelector.LENS_FACING_FRONT
                : CameraSelector.LENS_FACING_BACK;
        bindCameraUseCases();
    }

    private void loadSampleQr() {
        try {
            Bitmap sampleBitmap = MorsalinQrGenerator.generateQrBitmap(
                    "https://t.me/anonymous_modder_king",
                    512,
                    null,
                    0xFF00E5FF,
                    0xFF040E17
            );
            decodeBitmap(sampleBitmap, "Sample QR");
        } catch (Exception e) {
            Toast.makeText(this, "Could not create sample QR: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void decodeBitmap(Bitmap bitmap, String sourceLabel) {
        if (bitmap == null) {
            Toast.makeText(this, "Failed to decode image.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int[] pixels = new int[width * height];
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

            RGBLuminanceSource source = new RGBLuminanceSource(width, height, pixels);
            BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(source));

            MultiFormatReader reader = new MultiFormatReader();
            Result result = reader.decode(binaryBitmap);

            if (result != null && result.getText() != null) {
                MorsalinToast.show(this, R.drawable.ic_code_convert, "QR Decoded Successfully",
                        sourceLabel + " scanned!");
                onCodeDetected(result.getText(), result.getBarcodeFormat().toString());
            } else {
                Toast.makeText(this, "No QR or barcode detected in " + sourceLabel + ".", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error scanning " + sourceLabel + ": " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void decodeImageUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            decodeBitmap(bitmap, "Gallery Image");
        } catch (Exception e) {
            Toast.makeText(this, "Error reading image file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
