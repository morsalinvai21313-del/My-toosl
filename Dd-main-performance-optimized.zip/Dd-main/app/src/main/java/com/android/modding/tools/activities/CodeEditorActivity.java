package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.generators.XmlFormatter;
import com.android.modding.tools.generators.XmlParser;
import com.android.modding.tools.generators.XmlValidator;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.LiveDrawableRenderer;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.MorsalinViewInflater;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.LayerModel;
import com.android.modding.tools.models.StateModel;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class CodeEditorActivity extends AppCompatActivity {

    public static final int MODE_XML = 0;
    public static final int MODE_HTML = 1;
    public static final int MODE_NOTEPAD = 2;
    public static final String EXTRA_INITIAL_MODE = "extra_initial_mode";

    private static final String PREF_CODE = "morsalin_code_editor_prefs";
    private static final String KEY_XML_CODE = "saved_code_xml";
    private static final String KEY_HTML_CODE = "saved_code_html";
    private static final String KEY_NOTEPAD_CODE = "saved_code_notepad";

    private int currentMode = MODE_XML;

    private TextView tvStats;
    private TextView tvLineNumbers;
    private EditText etCode;
    private LinearLayout layoutSnippetChips;

    private String codeXml = "";
    private String codeHtml = "";
    private String codeNotepad = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_editor);

        GlobalTouchParticleManager.attach(this);

        loadSavedCode();
        initViews();
        setupMode(currentMode);
    }

    private void loadSavedCode() {
        SharedPreferences sp = getSharedPreferences(PREF_CODE, Context.MODE_PRIVATE);
        codeXml = sp.getString(KEY_XML_CODE, getDefaultXml());
        codeHtml = sp.getString(KEY_HTML_CODE, getDefaultHtml());
        codeNotepad = sp.getString(KEY_NOTEPAD_CODE, getDefaultNotepad());

        String initialImported = getIntent().getStringExtra("EXTRA_IMPORTED_XML");
        if (initialImported != null && !initialImported.trim().isEmpty()) {
            codeXml = initialImported.trim();
            currentMode = MODE_XML;
        } else if (getIntent().hasExtra(EXTRA_INITIAL_MODE)) {
            currentMode = getIntent().getIntExtra(EXTRA_INITIAL_MODE, MODE_XML);
        }
    }

    private void saveCurrentCodeToPref() {
        SharedPreferences.Editor ed = getSharedPreferences(PREF_CODE, Context.MODE_PRIVATE).edit();
        if (currentMode == MODE_XML) {
            codeXml = etCode.getText().toString();
            ed.putString(KEY_XML_CODE, codeXml);
        } else if (currentMode == MODE_HTML) {
            codeHtml = etCode.getText().toString();
            ed.putString(KEY_HTML_CODE, codeHtml);
        } else {
            codeNotepad = etCode.getText().toString();
            ed.putString(KEY_NOTEPAD_CODE, codeNotepad);
        }
        ed.apply();
    }

    private void initViews() {
        findViewById(R.id.btn_code_editor_back).setOnClickListener(v -> {
            saveCurrentCodeToPref();
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_code_editor_clear).setOnClickListener(v -> {
            etCode.setText("");
            updateStatsAndLineNumbers();
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Editor Cleared", "Buffer emptied.");
        });

        tvStats = findViewById(R.id.tv_code_stats);
        tvLineNumbers = findViewById(R.id.tv_line_numbers);
        etCode = findViewById(R.id.et_code_content);
        layoutSnippetChips = findViewById(R.id.layout_snippet_chips);

        findViewById(R.id.btn_action_format).setOnClickListener(v -> formatCurrentCode());
        findViewById(R.id.btn_action_snippets).setOnClickListener(v -> showTemplatesDialog());
        findViewById(R.id.btn_action_review).setOnClickListener(v -> showLiveReviewDialog());

        findViewById(R.id.btn_code_copy).setOnClickListener(v -> copyCode());
        findViewById(R.id.btn_code_share).setOnClickListener(v -> shareCode());
        findViewById(R.id.btn_code_save).setOnClickListener(v -> exportCodeToFile());

        etCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                updateStatsAndLineNumbers();
            }
        });
    }

    private void switchMode(int newMode) {
        if (currentMode == newMode) return;
        saveCurrentCodeToPref();
        currentMode = newMode;
        setupMode(currentMode);
    }

    private void setupMode(int mode) {
        TextView tvTitle = findViewById(R.id.tv_code_editor_title);
        if (tvTitle != null) {
            if (mode == MODE_XML) {
                tvTitle.setText("XML Editor");
            } else if (mode == MODE_HTML) {
                tvTitle.setText("HTML Web Editor");
            } else {
                tvTitle.setText("Notepad");
            }
        }

        Button btnFormat = findViewById(R.id.btn_action_format);
        if (btnFormat != null) {
            btnFormat.setVisibility(mode == MODE_NOTEPAD ? View.GONE : View.VISIBLE);
        }

        if (mode == MODE_XML) {
            etCode.setText(codeXml);
        } else if (mode == MODE_HTML) {
            etCode.setText(codeHtml);
        } else {
            etCode.setText(codeNotepad);
        }

        buildSnippetChips(mode);
        updateStatsAndLineNumbers();
    }

    private void buildSnippetChips(int mode) {
        layoutSnippetChips.removeAllViews();
        String[] chips;
        String[] snippets;

        if (mode == MODE_XML) {
            chips = new String[]{"<shape>", "<gradient>", "<corners>", "<stroke>", "<solid>", "<Button>", "<TextView>", "<LinearLayout>"};
            snippets = new String[]{
                    "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    android:shape=\"rectangle\">\n</shape>",
                    "<gradient\n    android:angle=\"45\"\n    android:startColor=\"#00E5FF\"\n    android:endColor=\"#7C4DFF\" />",
                    "<corners android:radius=\"16dp\" />",
                    "<stroke\n    android:width=\"2dp\"\n    android:color=\"#00E5FF\" />",
                    "<solid android:color=\"#0D1B2A\" />",
                    "<Button\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"Click Me\" />",
                    "<TextView\n    android:layout_width=\"wrap_content\"\n    android:layout_height=\"wrap_content\"\n    android:text=\"Hello World\" />",
                    "<LinearLayout\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\"\n    android:orientation=\"vertical\">\n</LinearLayout>"
            };
        } else if (mode == MODE_HTML) {
            chips = new String[]{"<!DOCTYPE>", "<div class>", "<style>", "<button>", "<h1>", "<script>", "<p>", "<a>"};
            snippets = new String[]{
                    "<!DOCTYPE html>\n<html>\n<head>\n  <meta charset=\"UTF-8\">\n  <title>Morsalin Studio</title>\n</head>\n<body>\n</body>\n</html>",
                    "<div class=\"card\">\n  <h2>Cyber Card</h2>\n</div>",
                    "<style>\n  body { background: #050C10; color: #00E5FF; font-family: sans-serif; }\n</style>",
                    "<button onclick=\"alert('Action triggered!')\">Click Me</button>",
                    "<h1>Next-Gen Web Preview</h1>",
                    "<script>\n  console.log('Script running smoothly!');\n</script>",
                    "<p>Styled web content rendered in real time.</p>",
                    "<a href=\"https://github.com\">Visit Repository</a>"
            };
        } else {
            chips = new String[]{"TODO Checklist", "Timestamp", "Divider", "Bullet List", "JSON Stub", "Notes Header"};
            snippets = new String[]{
                    "[ ] Task 1: Design Layout\n[ ] Task 2: Implement Logic\n[x] Task 3: Test Animation",
                    "--- Log: " + new java.util.Date() + " ---\n",
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n",
                    "• Point 1\n• Point 2\n• Point 3\n",
                    "{\n  \"status\": \"success\",\n  \"code\": 200\n}",
                    "# PROJECT NOTES & ARCHITECTURE\n=============================\n"
            };
        }

        for (int i = 0; i < chips.length; i++) {
            final String snip = snippets[i];
            Button chip = new Button(this);
            chip.setText(chips[i]);
            chip.setTextSize(11f);
            chip.setTextColor(Color.WHITE);
            chip.setBackgroundResource(R.drawable.dialog_step_button_bg);
            chip.setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4));
            chip.setAllCaps(false);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(30));
            lp.setMarginEnd(dpToPx(6));
            chip.setLayoutParams(lp);

            chip.setOnClickListener(v -> insertSnippetAtCursor(snip));
            layoutSnippetChips.addView(chip);
        }
    }

    private void insertSnippetAtCursor(String text) {
        int start = Math.max(etCode.getSelectionStart(), 0);
        int end = Math.max(etCode.getSelectionEnd(), 0);
        etCode.getText().replace(Math.min(start, end), Math.max(start, end), text, 0, text.length());
        MorsalinToast.show(this, R.drawable.ic_code_convert, "Snippet Inserted", "Added to cursor position.");
    }

    private void updateStatsAndLineNumbers() {
        String content = etCode.getText().toString();
        int lines = 1;
        for (int i = 0; i < content.length(); i++) {
            if (content.charAt(i) == '\n') lines++;
        }

        int words = content.trim().isEmpty() ? 0 : content.trim().split("\\s+").length;
        int chars = content.length();

        tvStats.setText("Lines: " + lines + " • Words: " + words + " • Chars: " + chars);

        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append(i).append("\n");
        }
        tvLineNumbers.setText(sb.toString().trim());
    }

    private void formatCurrentCode() {
        if (currentMode == MODE_XML || currentMode == MODE_HTML) {
            String text = etCode.getText().toString();
            if (text.trim().isEmpty()) return;
            try {
                String formatted = XmlFormatter.formatXml(text);
                etCode.setText(formatted);
                MorsalinToast.show(this, R.drawable.ic_cat_layout,
                        (currentMode == MODE_XML ? "XML Formatted" : "HTML Formatted"),
                        "Indented and structured cleanly.");
            } catch (Exception e) {
                MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Format Warning", e.getMessage());
            }
        }
    }

    private void showTemplatesDialog() {
        String[] titles;
        String[] templates;

        if (currentMode == MODE_XML) {
            titles = new String[]{
                    "Cyber Neon Gradient Card",
                    "3D Layer-List Glass Frame",
                    "Interactive Button Selector",
                    "Linear Card Layout"
            };
            templates = new String[]{
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    android:shape=\"rectangle\">\n    <gradient\n        android:angle=\"135\"\n        android:startColor=\"#00E5FF\"\n        android:centerColor=\"#7C4DFF\"\n        android:endColor=\"#FF007F\"\n        android:type=\"linear\" />\n    <corners android:radius=\"18dp\" />\n    <stroke\n        android:width=\"2dp\"\n        android:color=\"#80FFFFFF\" />\n</shape>",
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<layer-list xmlns:android=\"http://schemas.android.com/apk/res/android\">\n    <item>\n        <shape android:shape=\"rectangle\">\n            <solid android:color=\"#80000000\" />\n            <corners android:radius=\"16dp\" />\n        </shape>\n    </item>\n    <item android:bottom=\"3dp\" android:right=\"3dp\">\n        <shape android:shape=\"rectangle\">\n            <solid android:color=\"#0D1B2A\" />\n            <stroke android:width=\"1.5dp\" android:color=\"#00E5FF\" />\n            <corners android:radius=\"16dp\" />\n        </shape>\n    </item>\n</layer-list>",
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<selector xmlns:android=\"http://schemas.android.com/apk/res/android\">\n    <item android:state_pressed=\"true\">\n        <shape android:shape=\"rectangle\">\n            <solid android:color=\"#00E5FF\" />\n            <corners android:radius=\"12dp\" />\n        </shape>\n    </item>\n    <item>\n        <shape android:shape=\"rectangle\">\n            <solid android:color=\"#1B263B\" />\n            <stroke android:width=\"2dp\" android:color=\"#00E5FF\" />\n            <corners android:radius=\"12dp\" />\n        </shape>\n    </item>\n</selector>",
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    android:layout_width=\"match_parent\"\n    android:layout_height=\"wrap_content\"\n    android:background=\"#0D1B2A\"\n    android:padding=\"16dp\"\n    android:orientation=\"vertical\">\n    <TextView\n        android:layout_width=\"wrap_content\"\n        android:layout_height=\"wrap_content\"\n        android:text=\"Cyber Card Title\"\n        android:textColor=\"#00E5FF\"\n        android:textSize=\"18sp\"\n        android:textStyle=\"bold\" />\n    <TextView\n        android:layout_width=\"wrap_content\"\n        android:layout_height=\"wrap_content\"\n        android:layout_marginTop=\"6dp\"\n        android:text=\"Real-time live XML layout review engine.\"\n        android:textColor=\"#E0E0E0\"\n        android:textSize=\"13sp\" />\n</LinearLayout>"
            };
        } else if (currentMode == MODE_HTML) {
            titles = new String[]{
                    "Cyber Neon Hologram Card (CSS3)",
                    "Matrix Digital Rain Web Canvas",
                    "Interactive Button & Sound FX",
                    "Responsive Dashboard Card"
            };
            templates = new String[]{
                    "<!DOCTYPE html>\n<html>\n<head>\n<style>\n  body { margin:0; background:#050C10; display:flex; justify-content:center; align-items:center; height:100vh; font-family:'Segoe UI',sans-serif; }\n  .card { background:rgba(13,27,42,0.9); border:2px solid #00E5FF; box-shadow:0 0 25px rgba(0,229,255,0.4); border-radius:18px; padding:24px; text-align:center; color:#fff; }\n  h1 { color:#00E5FF; text-shadow:0 0 10px #00E5FF; margin-bottom:8px; font-size:24px; }\n  p { color:#90A4AE; font-size:14px; }\n  button { background:#00E5FF; border:none; padding:10px 24px; color:#000; font-weight:bold; border-radius:20px; cursor:pointer; margin-top:14px; }\n</style>\n</head>\n<body>\n  <div class=\"card\">\n    <h1>MORSALIN CYBER WEB</h1>\n    <p>Real-time interactive HTML5 & CSS3 Preview</p>\n    <button onclick=\"alert('Neon Action Triggered!')\">EXPLORE</button>\n  </div>\n</body>\n</html>",
                    "<!DOCTYPE html>\n<html>\n<head>\n<style>\n  body { margin:0; background:#000; overflow:hidden; font-family:monospace; }\n  #canvas { display:block; }\n</style>\n</head>\n<body>\n<canvas id=\"canvas\"></canvas>\n<script>\n  const c = document.getElementById('canvas');\n  const ctx = c.getContext('2d');\n  c.width = window.innerWidth; c.height = window.innerHeight;\n  const chars = '0123456789ABCDEF$#@%*';\n  const drops = Array(Math.floor(c.width/16)).fill(1);\n  function draw() {\n    ctx.fillStyle = 'rgba(0,0,0,0.08)';\n    ctx.fillRect(0,0,c.width,c.height);\n    ctx.fillStyle = '#00FF66';\n    ctx.font = '14px monospace';\n    for(let i=0; i<drops.length; i++) {\n      const txt = chars[Math.floor(Math.random()*chars.length)];\n      ctx.fillText(txt, i*16, drops[i]*16);\n      if(drops[i]*16 > c.height && Math.random()>0.975) drops[i]=0;\n      drops[i]++;\n    }\n  }\n  setInterval(draw, 40);\n</script>\n</body>\n</html>",
                    "<!DOCTYPE html>\n<html>\n<head>\n<style>\n  body { background:#0A1118; color:#fff; text-align:center; padding:30px; font-family:sans-serif; }\n  .btn { background:linear-gradient(45deg, #FF007F, #7C4DFF); border:none; color:white; padding:14px 28px; font-size:16px; border-radius:30px; box-shadow:0 6px 20px rgba(255,0,127,0.4); cursor:pointer; transition:transform 0.1s; }\n  .btn:active { transform:scale(0.92); }\n  #cnt { font-size:48px; color:#00E5FF; margin:20px 0; font-weight:bold; }\n</style>\n</head>\n<body>\n  <h2>INTERACTIVE JS COUNTER</h2>\n  <div id=\"cnt\">0</div>\n  <button class=\"btn\" onclick=\"add()\">INCREMENT +1</button>\n  <script>\n    let count = 0;\n    function add() {\n      count++;\n      document.getElementById('cnt').innerText = count;\n    }\n  </script>\n</body>\n</html>",
                    "<!DOCTYPE html>\n<html>\n<head>\n<style>\n  body { background:#040E17; color:#E0E0E0; font-family:sans-serif; padding:16px; }\n  .metric-box { background:#0D1B2A; border-left:4px solid #00E5FF; padding:16px; border-radius:8px; margin-bottom:12px; }\n  .val { font-size:24px; font-weight:bold; color:#00E5FF; }\n</style>\n</head>\n<body>\n  <div class=\"metric-box\">\n    <div>Live CPU Efficiency</div>\n    <div class=\"val\">99.8%</div>\n  </div>\n  <div class=\"metric-box\" style=\"border-left-color:#69F0AE;\">\n    <div>AST Syntax Verifier</div>\n    <div class=\"val\" style=\"color:#69F0AE;\">Passed ✓</div>\n  </div>\n</body>\n</html>"
            };
        } else {
            titles = new String[]{
                    "Android Modding Checklist",
                    "Release Notes Template",
                    "Smali Method Stub",
                    "Quick Scratchpad"
            };
            templates = new String[]{
                    "# ANDROID MODDING CHECKLIST\n" +
                            "[x] 1. Decompile APK / Extract classes.dex\n" +
                            "[x] 2. Disassemble into Smali bytecode\n" +
                            "[ ] 3. Locate verification method\n" +
                            "[ ] 4. Inject return-void or const/4 v0, 0x1\n" +
                            "[ ] 5. Recompile, align and sign with debug key\n" +
                            "[ ] 6. Test on target Android version\n",
                    "# VERSION 1.0 RELEASE NOTES\n" +
                            "Date: " + new java.util.Date() + "\n\n" +
                            "### Features Added:\n" +
                            "• Pro Code Studio with Live Review\n" +
                            "• Enhanced QR Camera Scanner\n" +
                            "• Military-Grade AES Image Encryptor\n" +
                            "• 6+ Cinematic Micro-Interactions\n",
                    ".method public static checkLicense(Landroid/content/Context;)Z\n" +
                            "    .registers 2\n" +
                            "    .param p0, \"context\"    # Landroid/content/Context;\n\n" +
                            "    const/4 v0, 0x1\n" +
                            "    return v0\n" +
                            ".end method\n",
                    "// QUICK SCRATCHPAD\n" +
                            "// Keep your code snippets, colors, and notes here.\n" +
                            "Primary Color: #00E5FF\n" +
                            "Accent Color: #7C4DFF\n" +
                            "Key: Morsalin2026\n"
            };
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Pre-built Template")
                .setItems(titles, (dialog, which) -> {
                    etCode.setText(templates[which]);
                    updateStatsAndLineNumbers();
                    MorsalinToast.show(this, R.drawable.ic_code_convert, "Template Loaded", titles[which]);
                })
                .show();
    }

    private void showLiveReviewDialog() {
        String code = etCode.getText().toString().trim();
        if (code.isEmpty()) {
            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Empty Code", "Please enter code first.");
            return;
        }

        Dialog dialog = new Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_code_review);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.94);
            dialog.getWindow().setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        TextView tvTitle = dialog.findViewById(R.id.tv_review_title);
        TextView tvStatus = dialog.findViewById(R.id.tv_review_status);
        Button btnClose = dialog.findViewById(R.id.btn_close_review);
        Button btnCopy = dialog.findViewById(R.id.btn_review_copy);
        Button btnDone = dialog.findViewById(R.id.btn_review_done);

        LinearLayout layoutXml = dialog.findViewById(R.id.layout_review_xml_preview);
        FrameLayout frameXmlDisplay = dialog.findViewById(R.id.frame_review_xml_display);
        View viewXmlDrawable = dialog.findViewById(R.id.view_review_xml_drawable);

        LinearLayout layoutHtml = dialog.findViewById(R.id.layout_review_html_preview);
        WebView webView = dialog.findViewById(R.id.web_view_review);

        LinearLayout layoutNotepad = dialog.findViewById(R.id.layout_review_notepad_summary);
        TextView tvNotepadAnalysis = dialog.findViewById(R.id.tv_notepad_analysis);

        btnClose.setOnClickListener(v -> dialog.dismiss());
        btnDone.setOnClickListener(v -> dialog.dismiss());
        btnCopy.setOnClickListener(v -> copyCode());

        if (currentMode == MODE_XML) {
            tvTitle.setText("Live XML Visual Review");
            layoutXml.setVisibility(View.VISIBLE);
            layoutHtml.setVisibility(View.GONE);
            layoutNotepad.setVisibility(View.GONE);

            XmlParser.ParseResult parseRes = XmlParser.parseXml(code);
            if (parseRes.success) {
                tvStatus.setText("✓ Valid XML Structure • Active Render Engine");
                tvStatus.setTextColor(Color.parseColor("#00E5FF"));

                try {
                    Drawable d = null;
                    if ("selector".equals(parseRes.rootTag) && parseRes.selectorStates != null && !parseRes.selectorStates.isEmpty()) {
                        d = LiveDrawableRenderer.createSelectorDrawable(this, parseRes.selectorStates);
                    } else if ("layer-list".equals(parseRes.rootTag) && parseRes.layerList != null && !parseRes.layerList.isEmpty()) {
                        d = LiveDrawableRenderer.createLayerListDrawable(this, parseRes.layerList);
                    } else if (parseRes.singleLayer != null) {
                        d = LiveDrawableRenderer.createShapeDrawable(this, parseRes.singleLayer);
                    }

                    if (d != null) {
                        viewXmlDrawable.setBackground(d);
                        viewXmlDrawable.setVisibility(View.VISIBLE);
                        tvStatus.setText("✓ Live Drawable Rendered: " + (parseRes.rootTag.isEmpty() ? "Shape" : parseRes.rootTag));
                    } else {
                        tvStatus.setText("✓ XML Validated successfully");
                    }
                } catch (Exception e) {
                    tvStatus.setText("Render Preview Notice: " + e.getMessage());
                }
            } else {
                tvStatus.setText("⚠️ XML Parse Issue: " + parseRes.message);
                tvStatus.setTextColor(Color.parseColor("#FF5252"));
            }

        } else if (currentMode == MODE_HTML) {
            tvTitle.setText("Live Web HTML5 Interactive Review");
            layoutXml.setVisibility(View.GONE);
            layoutHtml.setVisibility(View.VISIBLE);
            layoutNotepad.setVisibility(View.GONE);

            tvStatus.setText("✓ WebView DOM Engine Active • JavaScript Enabled");
            tvStatus.setTextColor(Color.parseColor("#69F0AE"));

            WebSettings ws = webView.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setLoadWithOverviewMode(true);
            ws.setUseWideViewPort(true);

            webView.loadDataWithBaseURL("https://local.morsalin.studio/", code, "text/html", "UTF-8", null);

        } else {
            tvTitle.setText("Notepad Insights & Analysis");
            layoutXml.setVisibility(View.GONE);
            layoutHtml.setVisibility(View.GONE);
            layoutNotepad.setVisibility(View.VISIBLE);

            tvStatus.setText("✓ Plain Text Verified • Ready for Export");
            tvStatus.setTextColor(Color.parseColor("#00E5FF"));

            int words = code.split("\\s+").length;
            int readingSeconds = Math.max(1, (words / 200) * 60);

            String analysis = "• Total Characters: " + code.length() + "\n" +
                    "• Total Words: " + words + "\n" +
                    "• Estimated Reading Time: ~" + readingSeconds + " sec\n" +
                    "• Character Encoding: UTF-8\n" +
                    "• Storage Size: " + code.getBytes(StandardCharsets.UTF_8).length + " bytes\n" +
                    "• Status: Clean In-Memory Buffer\n";

            tvNotepadAnalysis.setText(analysis);
        }

        dialog.show();
    }

    private void copyCode() {
        String code = etCode.getText().toString();
        if (code.isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("morsalin_code", code));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Code Copied!", "Copied to clipboard successfully.");
        }
    }

    private void shareCode() {
        String code = etCode.getText().toString();
        if (code.isEmpty()) return;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType(currentMode == MODE_HTML ? "text/html" : "text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, code);
        startActivity(Intent.createChooser(shareIntent, "Share Code"));
    }

    private void exportCodeToFile() {
        String code = etCode.getText().toString();
        if (code.isEmpty()) return;

        String ext = currentMode == MODE_XML ? ".xml" : (currentMode == MODE_HTML ? ".html" : ".txt");
        String mime = currentMode == MODE_XML ? "text/xml" : (currentMode == MODE_HTML ? "text/html" : "text/plain");
        String fileName = "Code_" + System.currentTimeMillis() + ext;

        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/CodeStudio", fileName, mime, code.getBytes(StandardCharsets.UTF_8));

        MorsalinToast.show(this, R.drawable.ic_download,
                res.success ? "File Saved" : "Save Status", res.message);
    }

    private String getDefaultXml() {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
                "    android:shape=\"rectangle\">\n" +
                "    <gradient\n" +
                "        android:angle=\"45\"\n" +
                "        android:startColor=\"#00E5FF\"\n" +
                "        android:centerColor=\"#7C4DFF\"\n" +
                "        android:endColor=\"#FF007F\"\n" +
                "        android:type=\"linear\" />\n" +
                "    <corners android:radius=\"16dp\" />\n" +
                "    <stroke\n" +
                "        android:width=\"2dp\"\n" +
                "        android:color=\"#80FFFFFF\" />\n" +
                "</shape>";
    }

    private String getDefaultHtml() {
        return "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "<style>\n" +
                "  body {\n" +
                "    background: #050C10;\n" +
                "    color: #00E5FF;\n" +
                "    font-family: -apple-system, sans-serif;\n" +
                "    padding: 24px;\n" +
                "    display: flex;\n" +
                "    flex-direction: column;\n" +
                "    align-items: center;\n" +
                "  }\n" +
                "  .card {\n" +
                "    background: rgba(13, 27, 42, 0.95);\n" +
                "    border: 2px solid #00E5FF;\n" +
                "    border-radius: 18px;\n" +
                "    padding: 20px;\n" +
                "    width: 90%;\n" +
                "    max-width: 320px;\n" +
                "    box-shadow: 0 0 25px rgba(0, 229, 255, 0.35);\n" +
                "    text-align: center;\n" +
                "  }\n" +
                "  h2 { margin: 0; color: #00E5FF; text-shadow: 0 0 10px #00E5FF; }\n" +
                "  p { color: #B0BEC5; font-size: 13.5px; }\n" +
                "  .btn {\n" +
                "    background: linear-gradient(45deg, #00E5FF, #7C4DFF);\n" +
                "    border: none;\n" +
                "    color: #fff;\n" +
                "    padding: 10px 22px;\n" +
                "    font-weight: bold;\n" +
                "    border-radius: 20px;\n" +
                "    cursor: pointer;\n" +
                "  }\n" +
                "</style>\n" +
                "</head>\n" +
                "<body>\n" +
                "  <div class=\"card\">\n" +
                "    <h2>MORSALIN WEB STUDIO</h2>\n" +
                "    <p>Live interactive HTML/CSS/JS preview in real time.</p>\n" +
                "    <button class=\"btn\" onclick=\"alert('Interactive Web Review Verified!')\">TEST SCRIPT</button>\n" +
                "  </div>\n" +
                "</body>\n" +
                "</html>";
    }

    private String getDefaultNotepad() {
        return "# MORSALIN NOTEPAD & CODE SCRATCHPAD\n" +
                "====================================\n\n" +
                "[x] 1. XML Drawable & Layout Studio verified\n" +
                "[x] 2. Interactive HTML Web Review active\n" +
                "[x] 3. Scratchpad persistent auto-save active\n\n" +
                "Notes:\n" +
                "• All code is auto-saved as you type.\n" +
                "• Click 'EXPORT' below to save directly to Downloads.\n";
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveCurrentCodeToPref();
    }

    @Override
    public void onBackPressed() {
        saveCurrentCodeToPref();
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
