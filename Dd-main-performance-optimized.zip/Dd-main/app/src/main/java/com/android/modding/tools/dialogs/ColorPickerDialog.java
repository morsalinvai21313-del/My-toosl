package com.android.modding.tools.dialogs;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class ColorPickerDialog extends Dialog {

    public interface OnColorSelectedListener {
        void onColorSelected(String hexColor);
    }

    private final String initialHex;
    private final OnColorSelectedListener listener;
    private OnColorSelectedListener liveListener;

    private View viewColorPreview;
    private SeekBar seekAlpha, seekRed, seekGreen, seekBlue;
    private TextView tvAlphaVal, tvRedVal, tvGreenVal, tvBlueVal;
    private boolean isUpdatingFromCode = false;

    public ColorPickerDialog(Context context, String initialHex, OnColorSelectedListener listener) {
        super(context, R.style.Theme_MyApplication_Dialog);
        this.initialHex = initialHex != null && !initialHex.isEmpty() ? initialHex : "#00FFE6";
        this.listener = listener;
    }

    public ColorPickerDialog(Context context, String initialHex, OnColorSelectedListener liveListener, OnColorSelectedListener finalListener) {
        super(context, R.style.Theme_MyApplication_Dialog);
        this.initialHex = initialHex != null && !initialHex.isEmpty() ? initialHex : "#00FFE6";
        this.liveListener = liveListener;
        this.listener = finalListener;
    }

    public ColorPickerDialog setLiveListener(OnColorSelectedListener liveListener) {
        this.liveListener = liveListener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_color_picker);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.90);
            getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        viewColorPreview = findViewById(R.id.view_color_preview);

        seekAlpha = findViewById(R.id.seek_alpha);
        seekRed = findViewById(R.id.seek_red);
        seekGreen = findViewById(R.id.seek_green);
        seekBlue = findViewById(R.id.seek_blue);

        tvAlphaVal = findViewById(R.id.tv_alpha_val);
        tvRedVal = findViewById(R.id.tv_red_val);
        tvGreenVal = findViewById(R.id.tv_green_val);
        tvBlueVal = findViewById(R.id.tv_blue_val);

        Button btnAlphaMinus = findViewById(R.id.btn_alpha_minus);
        Button btnAlphaPlus = findViewById(R.id.btn_alpha_plus);
        Button btnRedMinus = findViewById(R.id.btn_red_minus);
        Button btnRedPlus = findViewById(R.id.btn_red_plus);
        Button btnGreenMinus = findViewById(R.id.btn_green_minus);
        Button btnGreenPlus = findViewById(R.id.btn_green_plus);
        Button btnBlueMinus = findViewById(R.id.btn_blue_minus);
        Button btnBluePlus = findViewById(R.id.btn_blue_plus);

        Button btnSet = findViewById(R.id.btn_set_color);

        // Stepper buttons (step by 1)
        btnAlphaMinus.setOnClickListener(v -> {
            seekAlpha.setProgress(Math.max(0, seekAlpha.getProgress() - 1));
            updateFromSliders();
        });
        btnAlphaPlus.setOnClickListener(v -> {
            seekAlpha.setProgress(Math.min(255, seekAlpha.getProgress() + 1));
            updateFromSliders();
        });
        btnRedMinus.setOnClickListener(v -> {
            seekRed.setProgress(Math.max(0, seekRed.getProgress() - 1));
            updateFromSliders();
        });
        btnRedPlus.setOnClickListener(v -> {
            seekRed.setProgress(Math.min(255, seekRed.getProgress() + 1));
            updateFromSliders();
        });
        btnGreenMinus.setOnClickListener(v -> {
            seekGreen.setProgress(Math.max(0, seekGreen.getProgress() - 1));
            updateFromSliders();
        });
        btnGreenPlus.setOnClickListener(v -> {
            seekGreen.setProgress(Math.min(255, seekGreen.getProgress() + 1));
            updateFromSliders();
        });
        btnBlueMinus.setOnClickListener(v -> {
            seekBlue.setProgress(Math.max(0, seekBlue.getProgress() - 1));
            updateFromSliders();
        });
        btnBluePlus.setOnClickListener(v -> {
            seekBlue.setProgress(Math.min(255, seekBlue.getProgress() + 1));
            updateFromSliders();
        });

        SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    updateFromSliders();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seekAlpha.setOnSeekBarChangeListener(seekListener);
        seekRed.setOnSeekBarChangeListener(seekListener);
        seekGreen.setOnSeekBarChangeListener(seekListener);
        seekBlue.setOnSeekBarChangeListener(seekListener);

        btnSet.setOnClickListener(v -> {
            String finalHex = getCurrentHex();
            if (listener != null) {
                listener.onColorSelected(finalHex);
            }
            dismiss();
        });

        // Initialize with initial hex
        parseAndSetColor(initialHex);
    }

    private void parseAndSetColor(String hex) {
        int color = LiveDrawableRenderer.parseColorSafe(hex, Color.CYAN);
        updateSlidersFromColor(color);
    }

    private void updateSlidersFromColor(int color) {
        isUpdatingFromCode = true;
        int a = Color.alpha(color);
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);

        seekAlpha.setProgress(a);
        seekRed.setProgress(r);
        seekGreen.setProgress(g);
        seekBlue.setProgress(b);

        tvAlphaVal.setText(String.valueOf(a));
        tvRedVal.setText(String.valueOf(r));
        tvGreenVal.setText(String.valueOf(g));
        tvBlueVal.setText(String.valueOf(b));

        updatePreviewCircle(color);
        isUpdatingFromCode = false;
    }

    private void updateFromSliders() {
        int a = seekAlpha.getProgress();
        int r = seekRed.getProgress();
        int g = seekGreen.getProgress();
        int b = seekBlue.getProgress();

        tvAlphaVal.setText(String.valueOf(a));
        tvRedVal.setText(String.valueOf(r));
        tvGreenVal.setText(String.valueOf(g));
        tvBlueVal.setText(String.valueOf(b));

        int color = Color.argb(a, r, g, b);
        updatePreviewCircle(color);
        notifyLiveChange();
    }

    private void updatePreviewCircle(int color) {
        if (viewColorPreview != null) {
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            gd.setColor(color);
            viewColorPreview.setBackground(gd);
        }
    }

    private String getCurrentHex() {
        int a = seekAlpha.getProgress();
        int r = seekRed.getProgress();
        int g = seekGreen.getProgress();
        int b = seekBlue.getProgress();

        if (a == 255) {
            return String.format("#%02X%02X%02X", r, g, b);
        } else {
            return String.format("#%02X%02X%02X%02X", a, r, g, b);
        }
    }

    private void notifyLiveChange() {
        if (liveListener != null) {
            liveListener.onColorSelected(getCurrentHex());
        }
    }
}
