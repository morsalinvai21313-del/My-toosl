package com.android.modding.tools.dialogmaker;

import org.json.JSONObject;

import java.io.Serializable;

/**
 * Universal Dialog Configuration Model.
 * Supports all 12 customization areas:
 * 1. Dialog Basic (Width, Height, Bg Color, Gradient, Border Color, Border Width, Corner/Shape, Padding, Position)
 * 2. Title (Text, Color, Size, Font, Alignment, Background)
 * 3. Message (Text, Color, Size, Font, Alignment, Line Spacing)
 * 4. Icon / Image (Select, Size, Position, Background, Profile Image)
 * 5. Buttons (1, 2, 3 buttons, Text, Color, Bg, Border, Size, Width, Height, Position, Font, Action)
 * 6. Button Action (Dismiss, Open URL, Open Activity, Custom Action)
 * 7. Animation (Enter, Exit, Button Animation, Duration, Type)
 * 8. Live Preview matching output
 * 9. Color Selector
 * 10. Background Selector
 * 11. Font Selector
 * 12. Structured Builder UI
 */
public class DialogConfig implements Serializable {

    public static final String TYPE_SIMPLE_SMALI = "Simple Smali Dialog";
    public static final String TYPE_COLORFUL = "Colorful Dialog";
    public static final String TYPE_PROFILE = "Profile Dialog";
    public static final String TYPE_NOTICE = "Notice Dialog";
    public static final String TYPE_CUSTOM = "Custom Dialog";

    public static final String ACTION_DISMISS = "Dismiss Dialog";
    public static final String ACTION_OPEN_URL = "Open Web URL";
    public static final String ACTION_OPEN_ACTIVITY = "Open Activity";
    public static final String ACTION_CUSTOM = "Custom Action";
    public static final String ACTION_SHOW_TOAST = "Show Toast";
    public static final String ACTION_COPY_TEXT = "Copy Text";

    // Dialog Meta
    public String dialogType = TYPE_CUSTOM;
    public String dialogName = "Custom_Dialog";

    // 1. Dialog Basic
    public int widthPct = 90; // 70..100%
    public String heightMode = "WRAP"; // WRAP, CUSTOM
    public int heightDp = 320;
    public int paddingDp = 18;
    public int elevationDp = 12;
    public int cornerRadiusDp = 18;
    public int borderWidthDp = 2;
    public String bgHex = "#0C2230";
    public boolean isGradient = false;
    public String bgGradientEndHex = "#16283D";
    public String borderHex = "#00E5FF";
    public String btnBgHex = "#122C3D";
    public boolean cancelable = true;
    public String dialogPosition = "CENTER"; // CENTER, TOP, BOTTOM
    public String shapeType = "ROUNDED"; // ROUNDED, RECTANGLE, PILL

    // 2. Title
    public boolean titleVisible = true;
    public String titleText = "Dialog Title";
    public String titleColorHex = "#00E5FF";
    public int titleSizeSp = 18;
    public String titleFont = "DEFAULT"; // DEFAULT, MONOSPACE, SANS_SERIF, SERIF, COMIC_NEUE
    public String titleAlignment = "CENTER"; // CENTER, LEFT, RIGHT
    public String titleBgHex = "";
    public boolean titleBold = true;

    // Subtitle / Bio / Badge
    public boolean subtitleVisible = true;
    public String subtitleText = "Version 2.5 Pro";
    public String subtitleColorHex = "#00FF88";
    public int subtitleSizeSp = 13;

    // 3. Message
    public boolean messageVisible = true;
    public String messageText = "This is a customizable Android Dialog built with 100% programmatic DEX.";
    public String messageColorHex = "#FFFFFF";
    public int messageSizeSp = 14;
    public String messageFont = "DEFAULT"; // DEFAULT, MONOSPACE, SANS_SERIF, SERIF, COMIC_NEUE
    public String messageAlignment = "CENTER"; // CENTER, LEFT, RIGHT
    public float messageLineSpacing = 1.15f; // 1.0f, 1.2f, 1.5f

    // 4. Icon / Image
    public boolean hasImage = false;
    public String imageKind = "NONE"; // NONE, ICON, AVATAR, BANNER
    public String iconName = "SHIELD"; // SHIELD, CODE, SAVE, REFRESH, STAR, HEART, WARNING, BELL, TROPHY, CHECK
    public int iconResIndex = 0; // index in icon options
    public int imageSizeDp = 48; // 32, 48, 64, 80
    public String imagePosition = "TOP"; // TOP, CENTER, START
    public String imageBgHex = "";
    public String avatarPreset = "Morsalin Cyber"; // Morsalin Cyber, Morsalin Neon, Sanny DJ, Sanny Modder, Custom
    public String avatarShape = "CIRCLE"; // CIRCLE, ROUNDED, SQUARE
    public String avatarBorderHex = "#00E5FF";
    public int avatarBorderWidthDp = 3;
    public int avatarSizeDp = 72; // 40dp .. 140dp
    public String avatarBorderStyle = "SOLID"; // SOLID, DOTTED, DASHED, GLOW
    public String customImageUri = "";
    public boolean hasCustomAvatar = false;
    public byte[] customAvatarBytes = null;

    // Force Update Mode & Countdown Timer (বাধ্যতামূলক আপডেট ও টাইমার)
    public boolean isForceUpdate = false; // When true: cancelable=false, no exit button, back button blocked
    public boolean hasCountdownTimer = false;
    public int countdownSeconds = 15; // 5, 10, 15, 30, 60 seconds

    // Don't Show Again Checkbox Feature
    public boolean hasDontShowAgain = false;
    public String dontShowAgainText = "Don't show this again";
    public String dontShowAgainColorHex = "#94A3B8";

    // Notice Badge
    public boolean hasNoticeBadge = false;
    public String noticeBadgeText = "IMPORTANT NOTICE";
    public String noticeBadgeBgHex = "#FF1744";
    public String noticeBadgeTextHex = "#FFFFFF";

    // 5. Buttons (1..3)
    public int buttonCount = 2;
    public String btnOrientation = "HORIZONTAL"; // HORIZONTAL, VERTICAL
    public String btnPosition = "SPACE_BETWEEN"; // END, CENTER, SPACE_BETWEEN

    // Button 1
    public String btn1Text = "Cancel";
    public String btn1ColorHex = "#FFFFFF";
    public String btn1BgHex = "#122C3D";
    public String btn1BorderHex = "#00E5FF";
    public int btn1BorderWidthDp = 1;
    public int btn1SizeSp = 13;
    public String btn1Font = "DEFAULT";
    public String btn1Action = ACTION_DISMISS;
    public String btn1Url = "";

    // Button 2
    public String btn2Text = "Details";
    public String btn2ColorHex = "#FFFFFF";
    public String btn2BgHex = "#122C3D";
    public String btn2BorderHex = "#00E5FF";
    public int btn2BorderWidthDp = 1;
    public int btn2SizeSp = 13;
    public String btn2Font = "DEFAULT";
    public String btn2Action = ACTION_OPEN_URL;
    public String btn2Url = "https://t.me/anonymous_modder_king";

    // Button 3 (Confirm / Primary)
    public String btn3Text = "Confirm";
    public String btn3ColorHex = "#00E5FF";
    public String btn3BgHex = "#0C2230";
    public String btn3BorderHex = "#00E5FF";
    public int btn3BorderWidthDp = 1;
    public int btn3SizeSp = 13;
    public String btn3Font = "DEFAULT";
    public String btn3Action = ACTION_DISMISS;
    public String btn3Url = "";

    // 7. Animation
    public String openAnimMode = "Zoom"; // Zoom, Scale, Fade, Slide, Bounce
    public String closeAnimMode = "Fade";
    public String btnAnimMode = "None"; // None, Pulse, Bounce
    public int animDurationMs = 350;

    public DialogConfig() {
    }

    public String getPrimaryAssetFileName() {
        if (TYPE_PROFILE.equalsIgnoreCase(dialogType) || "AVATAR".equalsIgnoreCase(imageKind)) {
            return "morsalin_avatar.png";
        } else if (TYPE_NOTICE.equalsIgnoreCase(dialogType)) {
            return "notice_alert_icon.png";
        } else if (TYPE_COLORFUL.equalsIgnoreCase(dialogType)) {
            return "neon_dialog_icon.png";
        } else {
            return "dialog_icon.png";
        }
    }

    public String getBadgeAssetFileName() {
        if (TYPE_PROFILE.equalsIgnoreCase(dialogType)) {
            return "profile_badge.png";
        } else if (TYPE_NOTICE.equalsIgnoreCase(dialogType)) {
            return "notice_badge.png";
        }
        return null;
    }

    public static DialogConfig createSimpleSmaliDefault() {
        DialogConfig c = new DialogConfig();
        c.dialogType = TYPE_SIMPLE_SMALI;
        c.dialogName = "Simple_Smali_Dialog";
        c.bgHex = "#0F1A24";
        c.isGradient = false;
        c.borderHex = "#00E5FF";
        c.btnBgHex = "#162736";
        c.cornerRadiusDp = 14;
        c.borderWidthDp = 2;
        c.paddingDp = 16;
        c.widthPct = 88;
        c.dialogPosition = "CENTER";
        c.titleVisible = true;
        c.titleText = "Notice";
        c.titleColorHex = "#00E5FF";
        c.titleFont = "SANS_SERIF";
        c.subtitleVisible = false;
        c.subtitleText = "";
        c.messageVisible = true;
        c.messageText = "Operation finished successfully. Press OK to proceed.";
        c.messageColorHex = "#E2E8F0";
        c.hasImage = true;
        c.iconName = "SHIELD";
        c.iconResIndex = 0;
        c.hasNoticeBadge = false;
        c.buttonCount = 2;
        c.btn1Text = "Cancel";
        c.btn1Action = ACTION_DISMISS;
        c.btn1Url = "";
        c.btn2Text = "OK";
        c.btn2Action = ACTION_DISMISS;
        c.btn2Url = "";
        c.btn3Text = "OK";
        c.btn3Action = ACTION_DISMISS;
        c.btn3Url = "";
        return c;
    }

    public static DialogConfig createColorfulDefault() {
        DialogConfig c = new DialogConfig();
        c.dialogType = TYPE_COLORFUL;
        c.dialogName = "Colorful_Dialog";
        c.bgHex = "#120B24";
        c.isGradient = true;
        c.bgGradientEndHex = "#280A48";
        c.borderHex = "#FF007F";
        c.btnBgHex = "#26134B";
        c.cornerRadiusDp = 22;
        c.borderWidthDp = 3;
        c.paddingDp = 20;
        c.elevationDp = 16;
        c.widthPct = 90;
        c.dialogPosition = "CENTER";
        c.titleVisible = true;
        c.titleText = "Neon Cyber Alert";
        c.titleColorHex = "#00F0FF";
        c.titleFont = "MONOSPACE";
        c.subtitleVisible = true;
        c.subtitleText = "⚡ Ultra Glowing Interface";
        c.subtitleColorHex = "#FF007F";
        c.messageVisible = true;
        c.messageText = "High-voltage gradient styling with dynamic glow borders and fluid animations.";
        c.messageColorHex = "#F1F5F9";
        c.hasImage = true;
        c.imageKind = "ICON";
        c.iconResIndex = 1; // CODE / SHIELD
        c.buttonCount = 2;
        c.btn1Text = "Dismiss";
        c.btn1Action = ACTION_DISMISS;
        c.btn1ColorHex = "#94A3B8";
        c.btn1BgHex = "#1E1435";
        c.btn3Text = "Explore Neon";
        c.btn3Action = ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.btn3ColorHex = "#00F0FF";
        c.btn3BgHex = "#2A0845";
        return c;
    }

    public static DialogConfig createProfileDefault() {
        DialogConfig c = new DialogConfig();
        c.dialogType = TYPE_PROFILE;
        c.dialogName = "Profile_Dialog";
        c.bgHex = "#0A1926";
        c.isGradient = true;
        c.bgGradientEndHex = "#112638";
        c.borderHex = "#00FFB2";
        c.btnBgHex = "#112638";
        c.cornerRadiusDp = 20;
        c.borderWidthDp = 2;
        c.paddingDp = 20;
        c.widthPct = 90;
        c.dialogPosition = "CENTER";
        c.hasImage = true;
        c.imageKind = "AVATAR";
        c.avatarPreset = "Morsalin Cyber";
        c.avatarShape = "CIRCLE";
        c.avatarBorderHex = "#00FFB2";
        c.avatarBorderWidthDp = 3;
        c.hasNoticeBadge = true;
        c.noticeBadgeText = "👑 VIP MODDER";
        c.noticeBadgeBgHex = "#00FFB2";
        c.noticeBadgeTextHex = "#0A1926";
        c.titleVisible = true;
        c.titleText = "Anonymous Modder";
        c.titleColorHex = "#FFFFFF";
        c.subtitleVisible = true;
        c.subtitleText = "Android Security & Reverse Engineer";
        c.subtitleColorHex = "#00FFB2";
        c.messageVisible = true;
        c.messageText = "Follow official Telegram and Facebook channels for the latest APK modding tools and XML creators.";
        c.messageColorHex = "#CBD5E1";
        c.buttonCount = 3;
        c.btn1Text = "Close";
        c.btn1Action = ACTION_DISMISS;
        c.btn2Text = "Facebook";
        c.btn2Action = ACTION_OPEN_URL;
        c.btn2Url = "https://www.facebook.com/share/19bhVG8oJF/";
        c.btn3Text = "Telegram";
        c.btn3Action = ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.btn3ColorHex = "#00FFB2";
        return c;
    }

    public static DialogConfig createNoticeDefault() {
        DialogConfig c = new DialogConfig();
        c.dialogType = TYPE_NOTICE;
        c.dialogName = "Notice_Dialog";
        c.bgHex = "#1A1708";
        c.isGradient = true;
        c.bgGradientEndHex = "#2E2608";
        c.borderHex = "#FFB703";
        c.btnBgHex = "#2E2608";
        c.cornerRadiusDp = 18;
        c.borderWidthDp = 2;
        c.paddingDp = 18;
        c.widthPct = 92;
        c.dialogPosition = "CENTER";
        c.hasImage = true;
        c.imageKind = "ICON";
        c.iconResIndex = 0;
        c.hasNoticeBadge = true;
        c.hasDontShowAgain = true;
        c.dontShowAgainText = "Don't show this again";
        c.dontShowAgainColorHex = "#FFD166";
        c.noticeBadgeText = "🚨 CRITICAL UPDATE";
        c.noticeBadgeBgHex = "#FFB703";
        c.noticeBadgeTextHex = "#1A1708";
        c.titleVisible = true;
        c.titleText = "Security Update Available";
        c.titleColorHex = "#FFB703";
        c.subtitleVisible = true;
        c.subtitleText = "Build 3.4.0 • 100% Patch Applied";
        c.subtitleColorHex = "#FFD166";
        c.messageVisible = true;
        c.messageText = "A critical stability patch is ready to install. Please update your environment to ensure uninterrupted modding capabilities.";
        c.messageColorHex = "#FFFFFF";
        c.buttonCount = 2;
        c.btn1Text = "Remind Later";
        c.btn1Action = ACTION_DISMISS;
        c.btn3Text = "Update Now";
        c.btn3Action = ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.btn3ColorHex = "#FFB703";
        return c;
    }

    public static DialogConfig createCustomDefault() {
        DialogConfig c = new DialogConfig();
        c.dialogType = TYPE_CUSTOM;
        c.dialogName = "Custom_Dialog";
        c.bgHex = "#0C2230";
        c.isGradient = true;
        c.bgGradientEndHex = "#142F42";
        c.borderHex = "#00E5FF";
        c.btnBgHex = "#122C3D";
        c.cornerRadiusDp = 18;
        c.borderWidthDp = 2;
        c.paddingDp = 18;
        c.elevationDp = 12;
        c.widthPct = 90;
        c.dialogPosition = "CENTER";
        c.hasImage = true;
        c.imageKind = "ICON";
        c.iconResIndex = 0;
        c.titleVisible = true;
        c.titleText = "Update Available";
        c.titleColorHex = "#00E5FF";
        c.subtitleVisible = true;
        c.subtitleText = "Version 2.5 Pro Build";
        c.subtitleColorHex = "#00FF88";
        c.messageVisible = true;
        c.messageText = "Would you like to apply the new configuration now?";
        c.messageColorHex = "#FFFFFF";
        c.buttonCount = 2;
        c.btn1Text = "Later";
        c.btn1Action = ACTION_DISMISS;
        c.btn2Text = "Details";
        c.btn2Action = ACTION_OPEN_URL;
        c.btn2Url = "https://www.youtube.com/@apk.modding";
        c.btn3Text = "Confirm";
        c.btn3Action = ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.btn3ColorHex = "#00E5FF";
        return c;
    }

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("dialogType", dialogType);
            o.put("dialogName", dialogName);
            o.put("widthPct", widthPct);
            o.put("heightMode", heightMode);
            o.put("heightDp", heightDp);
            o.put("paddingDp", paddingDp);
            o.put("elevationDp", elevationDp);
            o.put("cornerRadiusDp", cornerRadiusDp);
            o.put("borderWidthDp", borderWidthDp);
            o.put("bgHex", bgHex);
            o.put("isGradient", isGradient);
            o.put("bgGradientEndHex", bgGradientEndHex);
            o.put("borderHex", borderHex);
            o.put("btnBgHex", btnBgHex);
            o.put("cancelable", cancelable);
            o.put("dialogPosition", dialogPosition);
            o.put("shapeType", shapeType);
            o.put("openAnimMode", openAnimMode);
            o.put("closeAnimMode", closeAnimMode);
            o.put("btnAnimMode", btnAnimMode);
            o.put("animDurationMs", animDurationMs);
            o.put("titleVisible", titleVisible);
            o.put("titleText", titleText);
            o.put("titleColorHex", titleColorHex);
            o.put("titleSizeSp", titleSizeSp);
            o.put("titleFont", titleFont);
            o.put("titleAlignment", titleAlignment);
            o.put("titleBgHex", titleBgHex);
            o.put("titleBold", titleBold);
            o.put("subtitleVisible", subtitleVisible);
            o.put("subtitleText", subtitleText);
            o.put("subtitleColorHex", subtitleColorHex);
            o.put("subtitleSizeSp", subtitleSizeSp);
            o.put("messageVisible", messageVisible);
            o.put("messageText", messageText);
            o.put("messageColorHex", messageColorHex);
            o.put("messageSizeSp", messageSizeSp);
            o.put("messageFont", messageFont);
            o.put("messageAlignment", messageAlignment);
            o.put("messageLineSpacing", (double) messageLineSpacing);
            o.put("hasImage", hasImage);
            o.put("imageKind", imageKind);
            o.put("iconName", iconName);
            o.put("iconResIndex", iconResIndex);
            o.put("imageSizeDp", imageSizeDp);
            o.put("imagePosition", imagePosition);
            o.put("imageBgHex", imageBgHex);
            o.put("avatarPreset", avatarPreset);
            o.put("avatarShape", avatarShape);
            o.put("avatarBorderHex", avatarBorderHex);
            o.put("avatarBorderWidthDp", avatarBorderWidthDp);
            o.put("avatarSizeDp", avatarSizeDp);
            o.put("avatarBorderStyle", avatarBorderStyle);
            o.put("customImageUri", customImageUri);
            o.put("isForceUpdate", isForceUpdate);
            o.put("hasCountdownTimer", hasCountdownTimer);
            o.put("countdownSeconds", countdownSeconds);
            o.put("hasDontShowAgain", hasDontShowAgain);
            o.put("dontShowAgainText", dontShowAgainText);
            o.put("dontShowAgainColorHex", dontShowAgainColorHex);
            o.put("hasNoticeBadge", hasNoticeBadge);
            o.put("noticeBadgeText", noticeBadgeText);
            o.put("noticeBadgeBgHex", noticeBadgeBgHex);
            o.put("noticeBadgeTextHex", noticeBadgeTextHex);
            o.put("buttonCount", buttonCount);
            o.put("btnOrientation", btnOrientation);
            o.put("btnPosition", btnPosition);
            o.put("btn1Text", btn1Text);
            o.put("btn1ColorHex", btn1ColorHex);
            o.put("btn1BgHex", btn1BgHex);
            o.put("btn1BorderHex", btn1BorderHex);
            o.put("btn1BorderWidthDp", btn1BorderWidthDp);
            o.put("btn1SizeSp", btn1SizeSp);
            o.put("btn1Font", btn1Font);
            o.put("btn1Action", btn1Action);
            o.put("btn1Url", btn1Url);
            o.put("btn2Text", btn2Text);
            o.put("btn2ColorHex", btn2ColorHex);
            o.put("btn2BgHex", btn2BgHex);
            o.put("btn2BorderHex", btn2BorderHex);
            o.put("btn2BorderWidthDp", btn2BorderWidthDp);
            o.put("btn2SizeSp", btn2SizeSp);
            o.put("btn2Font", btn2Font);
            o.put("btn2Action", btn2Action);
            o.put("btn2Url", btn2Url);
            o.put("btn3Text", btn3Text);
            o.put("btn3ColorHex", btn3ColorHex);
            o.put("btn3BgHex", btn3BgHex);
            o.put("btn3BorderHex", btn3BorderHex);
            o.put("btn3BorderWidthDp", btn3BorderWidthDp);
            o.put("btn3SizeSp", btn3SizeSp);
            o.put("btn3Font", btn3Font);
            o.put("btn3Action", btn3Action);
            o.put("btn3Url", btn3Url);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static DialogConfig fromJson(String json) {
        DialogConfig c = new DialogConfig();
        if (json == null || json.trim().isEmpty()) return c;
        try {
            JSONObject o = new JSONObject(json);
            c.dialogType = o.optString("dialogType", c.dialogType);
            c.dialogName = o.optString("dialogName", c.dialogName);
            c.widthPct = o.optInt("widthPct", c.widthPct);
            c.heightMode = o.optString("heightMode", c.heightMode);
            c.heightDp = o.optInt("heightDp", c.heightDp);
            c.paddingDp = o.optInt("paddingDp", c.paddingDp);
            c.elevationDp = o.optInt("elevationDp", c.elevationDp);
            c.cornerRadiusDp = o.optInt("cornerRadiusDp", c.cornerRadiusDp);
            c.borderWidthDp = o.optInt("borderWidthDp", c.borderWidthDp);
            c.bgHex = o.optString("bgHex", c.bgHex);
            c.isGradient = o.optBoolean("isGradient", c.isGradient);
            c.bgGradientEndHex = o.optString("bgGradientEndHex", c.bgGradientEndHex);
            c.borderHex = o.optString("borderHex", c.borderHex);
            c.btnBgHex = o.optString("btnBgHex", c.btnBgHex);
            c.cancelable = o.optBoolean("cancelable", c.cancelable);
            c.dialogPosition = o.optString("dialogPosition", c.dialogPosition);
            c.shapeType = o.optString("shapeType", c.shapeType);
            c.openAnimMode = o.optString("openAnimMode", c.openAnimMode);
            c.closeAnimMode = o.optString("closeAnimMode", c.closeAnimMode);
            c.btnAnimMode = o.optString("btnAnimMode", c.btnAnimMode);
            c.animDurationMs = o.optInt("animDurationMs", c.animDurationMs);
            c.titleVisible = o.optBoolean("titleVisible", c.titleVisible);
            c.titleText = o.optString("titleText", c.titleText);
            c.titleColorHex = o.optString("titleColorHex", c.titleColorHex);
            c.titleSizeSp = o.optInt("titleSizeSp", c.titleSizeSp);
            c.titleFont = o.optString("titleFont", c.titleFont);
            c.titleAlignment = o.optString("titleAlignment", c.titleAlignment);
            c.titleBgHex = o.optString("titleBgHex", c.titleBgHex);
            c.titleBold = o.optBoolean("titleBold", c.titleBold);
            c.subtitleVisible = o.optBoolean("subtitleVisible", c.subtitleVisible);
            c.subtitleText = o.optString("subtitleText", c.subtitleText);
            c.subtitleColorHex = o.optString("subtitleColorHex", c.subtitleColorHex);
            c.subtitleSizeSp = o.optInt("subtitleSizeSp", c.subtitleSizeSp);
            c.messageVisible = o.optBoolean("messageVisible", c.messageVisible);
            c.messageText = o.optString("messageText", c.messageText);
            c.messageColorHex = o.optString("messageColorHex", c.messageColorHex);
            c.messageSizeSp = o.optInt("messageSizeSp", c.messageSizeSp);
            c.messageFont = o.optString("messageFont", c.messageFont);
            c.messageAlignment = o.optString("messageAlignment", c.messageAlignment);
            c.messageLineSpacing = (float) o.optDouble("messageLineSpacing", c.messageLineSpacing);
            c.hasImage = o.optBoolean("hasImage", c.hasImage);
            c.imageKind = o.optString("imageKind", c.imageKind);
            c.iconName = o.optString("iconName", c.iconName);
            c.iconResIndex = o.optInt("iconResIndex", c.iconResIndex);
            c.imageSizeDp = o.optInt("imageSizeDp", c.imageSizeDp);
            c.imagePosition = o.optString("imagePosition", c.imagePosition);
            c.imageBgHex = o.optString("imageBgHex", c.imageBgHex);
            c.avatarPreset = o.optString("avatarPreset", c.avatarPreset);
            c.avatarShape = o.optString("avatarShape", c.avatarShape);
            c.avatarBorderHex = o.optString("avatarBorderHex", c.avatarBorderHex);
            c.avatarBorderWidthDp = o.optInt("avatarBorderWidthDp", c.avatarBorderWidthDp);
            c.avatarSizeDp = o.optInt("avatarSizeDp", c.avatarSizeDp);
            c.avatarBorderStyle = o.optString("avatarBorderStyle", c.avatarBorderStyle);
            c.customImageUri = o.optString("customImageUri", c.customImageUri);
            c.isForceUpdate = o.optBoolean("isForceUpdate", c.isForceUpdate);
            c.hasCountdownTimer = o.optBoolean("hasCountdownTimer", c.hasCountdownTimer);
            c.countdownSeconds = o.optInt("countdownSeconds", c.countdownSeconds);
            c.hasDontShowAgain = o.optBoolean("hasDontShowAgain", c.hasDontShowAgain);
            c.dontShowAgainText = o.optString("dontShowAgainText", c.dontShowAgainText);
            c.dontShowAgainColorHex = o.optString("dontShowAgainColorHex", c.dontShowAgainColorHex);
            c.hasNoticeBadge = o.optBoolean("hasNoticeBadge", c.hasNoticeBadge);
            c.noticeBadgeText = o.optString("noticeBadgeText", c.noticeBadgeText);
            c.noticeBadgeBgHex = o.optString("noticeBadgeBgHex", c.noticeBadgeBgHex);
            c.noticeBadgeTextHex = o.optString("noticeBadgeTextHex", c.noticeBadgeTextHex);
            c.buttonCount = o.optInt("buttonCount", c.buttonCount);
            c.btnOrientation = o.optString("btnOrientation", c.btnOrientation);
            c.btnPosition = o.optString("btnPosition", c.btnPosition);
            c.btn1Text = o.optString("btn1Text", c.btn1Text);
            c.btn1ColorHex = o.optString("btn1ColorHex", c.btn1ColorHex);
            c.btn1BgHex = o.optString("btn1BgHex", c.btn1BgHex);
            c.btn1BorderHex = o.optString("btn1BorderHex", c.btn1BorderHex);
            c.btn1BorderWidthDp = o.optInt("btn1BorderWidthDp", c.btn1BorderWidthDp);
            c.btn1SizeSp = o.optInt("btn1SizeSp", c.btn1SizeSp);
            c.btn1Font = o.optString("btn1Font", c.btn1Font);
            c.btn1Action = o.optString("btn1Action", c.btn1Action);
            c.btn1Url = o.optString("btn1Url", c.btn1Url);
            c.btn2Text = o.optString("btn2Text", c.btn2Text);
            c.btn2ColorHex = o.optString("btn2ColorHex", c.btn2ColorHex);
            c.btn2BgHex = o.optString("btn2BgHex", c.btn2BgHex);
            c.btn2BorderHex = o.optString("btn2BorderHex", c.btn2BorderHex);
            c.btn2BorderWidthDp = o.optInt("btn2BorderWidthDp", c.btn2BorderWidthDp);
            c.btn2SizeSp = o.optInt("btn2SizeSp", c.btn2SizeSp);
            c.btn2Font = o.optString("btn2Font", c.btn2Font);
            c.btn2Action = o.optString("btn2Action", c.btn2Action);
            c.btn2Url = o.optString("btn2Url", c.btn2Url);
            c.btn3Text = o.optString("btn3Text", c.btn3Text);
            c.btn3ColorHex = o.optString("btn3ColorHex", c.btn3ColorHex);
            c.btn3BgHex = o.optString("btn3BgHex", c.btn3BgHex);
            c.btn3BorderHex = o.optString("btn3BorderHex", c.btn3BorderHex);
            c.btn3BorderWidthDp = o.optInt("btn3BorderWidthDp", c.btn3BorderWidthDp);
            c.btn3SizeSp = o.optInt("btn3SizeSp", c.btn3SizeSp);
            c.btn3Font = o.optString("btn3Font", c.btn3Font);
            c.btn3Action = o.optString("btn3Action", c.btn3Action);
            c.btn3Url = o.optString("btn3Url", c.btn3Url);
        } catch (Exception ignored) {}
        return c;
    }
}
