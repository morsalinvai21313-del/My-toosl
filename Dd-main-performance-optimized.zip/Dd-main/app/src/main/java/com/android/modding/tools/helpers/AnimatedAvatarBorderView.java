package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;

/**
 * High-Performance Circular Developer Avatar View with:
 * 1. Continuous 60-FPS rotating multi-ring neon cyber border with orbiting plasma nodes.
 * 2. Butter-smooth zero-lag vertical slide slideshow transitioning through multiple profile photos in unison.
 * Pre-scales and pre-crops bitmaps to avoid on-the-fly resizing and GC jank.
 */
public class AnimatedAvatarBorderView extends View {

    private Paint avatarPaint;
    private Paint incomingAvatarPaint;
    private Paint glowPaint;
    private Paint ringPaint;
    private Paint arcPaint;
    private Paint dotPaint;

    private final RectF outerArcRect = new RectF();
    private final Path clipCirclePath = new Path();

    private ValueAnimator borderAnimator;
    private ValueAnimator slideAnimator;
    private float phase = 0f;
    private float slideProgress = 0f;
    private boolean isSliding = false;

    private int primaryColor = 0xFF00E5FF;
    private int secondaryColor = 0xFF0096C7;
    private int accentColor = 0xFF48CAE4;

    private final List<Integer> rawDrawableResIds = new ArrayList<>();
    private final List<Bitmap> optimizedCircularBitmaps = new ArrayList<>();
    private int currentIdx = 0;
    private int nextIdx = 0;

    private RadialGradient cachedAuraGradient = null;
    private SweepGradient cachedSweepGradient = null;
    private float cachedCx = 0f;
    private float cachedCy = 0f;
    private float cachedAvatarR = 0f;
    private float cachedOuterRingR = 0f;
    private float cachedInnerRingR = 0f;

    private final Handler slideshowHandler = new Handler(Looper.getMainLooper());
    private static final long SLIDE_INTERVAL_MS = 3400L;

    private final Runnable slideshowRunnable = new Runnable() {
        @Override
        public void run() {
            if (optimizedCircularBitmaps.size() > 1 && isAttachedToWindow()) {
                triggerNextSlide();
                slideshowHandler.postDelayed(this, SLIDE_INTERVAL_MS);
            }
        }
    };

    public AnimatedAvatarBorderView(Context context) {
        super(context);
        init();
    }

    public AnimatedAvatarBorderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AnimatedAvatarBorderView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        avatarPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        incomingAvatarPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);

        ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringPaint.setStyle(Paint.Style.STROKE);

        arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotPaint.setStyle(Paint.Style.FILL);
    }

    public void setAvatarResource(int drawableResId, int primary, int secondary, int accent) {
        setAvatarList(new int[]{drawableResId}, primary, secondary, accent);
    }

    public void setAvatarList(int[] drawableResIds, int primary, int secondary, int accent) {
        this.primaryColor = primary;
        this.secondaryColor = secondary;
        this.accentColor = accent;

        rawDrawableResIds.clear();
        if (drawableResIds != null) {
            for (int id : drawableResIds) {
                rawDrawableResIds.add(id);
            }
        }

        currentIdx = 0;
        nextIdx = 0;
        isSliding = false;

        // Reset gradient caches so they recalculate with the new colors
        cachedAuraGradient = null;
        cachedSweepGradient = null;

        prepareOptimizedBitmaps();
        invalidate();
        resetSlideshowTimer();
    }

    private void prepareOptimizedBitmaps() {
        optimizedCircularBitmaps.clear();
        int targetSize = (cachedAvatarR > 0) ? (int) (cachedAvatarR * 2f) : 220;
        if (targetSize <= 10) targetSize = 220;

        for (int resId : rawDrawableResIds) {
            try {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeResource(getResources(), resId, opts);

                int inSample = 1;
                while (opts.outWidth / (inSample * 2) >= targetSize && opts.outHeight / (inSample * 2) >= targetSize) {
                    inSample *= 2;
                }

                opts.inJustDecodeBounds = false;
                opts.inSampleSize = inSample;
                opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                Bitmap raw = BitmapFactory.decodeResource(getResources(), resId, opts);

                if (raw != null) {
                    Bitmap circleBmp = createCroppedCircularBitmap(raw, targetSize);
                    optimizedCircularBitmaps.add(circleBmp);
                    if (circleBmp != raw && !raw.isRecycled()) {
                        raw.recycle();
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    private Bitmap createCroppedCircularBitmap(Bitmap src, int targetSize) {
        Bitmap output = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(output);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float radius = targetSize / 2f;

        // Draw solid circle mask
        c.drawCircle(radius, radius, radius, p);

        // Draw scaled bitmap clipped by SRC_IN
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        float scale = Math.max((float) targetSize / src.getWidth(), (float) targetSize / src.getHeight());
        float dx = (targetSize - src.getWidth() * scale) / 2f;
        float dy = (targetSize - src.getHeight() * scale) / 2f;

        android.graphics.Matrix m = new android.graphics.Matrix();
        m.setScale(scale, scale);
        m.postTranslate(dx, dy);

        c.drawBitmap(src, m, p);
        return output;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        cachedCx = w / 2f;
        cachedCy = h / 2f;
        float maxR = Math.min(w, h) / 2f;

        cachedAvatarR = maxR - 9.5f * density;
        cachedInnerRingR = cachedAvatarR + 2.6f * density;
        cachedOuterRingR = cachedAvatarR + 6.4f * density;

        clipCirclePath.reset();
        clipCirclePath.addCircle(cachedCx, cachedCy, cachedAvatarR, Path.Direction.CW);

        outerArcRect.set(
                cachedCx - cachedOuterRingR, cachedCy - cachedOuterRingR,
                cachedCx + cachedOuterRingR, cachedCy + cachedOuterRingR
        );

        // Cache shaders for 60 FPS rendering
        cachedAuraGradient = new RadialGradient(
                cachedCx, cachedCy, maxR,
                new int[]{
                        (primaryColor & 0x00FFFFFF) | 0x33000000,
                        (secondaryColor & 0x00FFFFFF) | 0x12000000,
                        0x00000000
                },
                new float[]{0.55f, 0.85f, 1f},
                Shader.TileMode.CLAMP
        );

        cachedSweepGradient = new SweepGradient(
                cachedCx, cachedCy,
                new int[]{primaryColor, accentColor, secondaryColor, primaryColor},
                new float[]{0f, 0.35f, 0.7f, 1f}
        );

        // Re-crop bitmaps if view size is resolved
        if (optimizedCircularBitmaps.isEmpty() && !rawDrawableResIds.isEmpty()) {
            prepareOptimizedBitmaps();
        }
    }

    private void resetSlideshowTimer() {
        slideshowHandler.removeCallbacks(slideshowRunnable);
        if (optimizedCircularBitmaps.size() > 1 || rawDrawableResIds.size() > 1) {
            slideshowHandler.postDelayed(slideshowRunnable, SLIDE_INTERVAL_MS);
        }
    }

    public void triggerNextSlide() {
        if (optimizedCircularBitmaps.size() <= 1 || isSliding) return;

        nextIdx = (currentIdx + 1) % optimizedCircularBitmaps.size();
        isSliding = true;
        slideProgress = 0f;

        if (slideAnimator != null) {
            slideAnimator.cancel();
        }
        slideAnimator = ValueAnimator.ofFloat(0f, 1f);
        slideAnimator.setDuration(520);
        slideAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        slideAnimator.addUpdateListener(a -> {
            slideProgress = (float) a.getAnimatedValue();
            invalidate();
        });
        slideAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                currentIdx = nextIdx;
                isSliding = false;
                slideProgress = 0f;
                invalidate();
            }
        });
        slideAnimator.start();
    }

    private void startBorderAnimation() {
        if (borderAnimator != null && borderAnimator.isRunning()) return;
        borderAnimator = ValueAnimator.ofFloat(0f, 1f);
        borderAnimator.setDuration(2600);
        borderAnimator.setRepeatCount(ValueAnimator.INFINITE);
        borderAnimator.setInterpolator(new LinearInterpolator());
        borderAnimator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        borderAnimator.start();
    }

    private void stopBorderAnimation() {
        if (borderAnimator != null) {
            borderAnimator.cancel();
            borderAnimator = null;
        }
        if (slideAnimator != null) {
            slideAnimator.cancel();
            slideAnimator = null;
        }
        slideshowHandler.removeCallbacks(slideshowRunnable);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startBorderAnimation();
        resetSlideshowTimer();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopBorderAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float cx = cachedCx;
        float cy = cachedCy;
        float avatarR = cachedAvatarR;
        float diameter = avatarR * 2f;

        // 1. Pulsing ambient neon aura behind avatar
        if (cachedAuraGradient != null) {
            glowPaint.setShader(cachedAuraGradient);
            canvas.drawCircle(cx, cy, Math.min(w, h) / 2f, glowPaint);
        }

        // 2. Ultra-Fast Circular clipped avatar images (Pre-cropped 1:1 bit blit with zero GC)
        if (avatarR > 4f) {
            canvas.save();
            canvas.clipPath(clipCirclePath);

            // Dark backdrop
            dotPaint.setColor(0xFF06121B);
            canvas.drawCircle(cx, cy, avatarR, dotPaint);

            if (!optimizedCircularBitmaps.isEmpty()) {
                Bitmap curBmp = optimizedCircularBitmaps.get(currentIdx % optimizedCircularBitmaps.size());
                float bmpLeft = cx - curBmp.getWidth() / 2f;
                float bmpTop = cy - curBmp.getHeight() / 2f;

                if (!isSliding || optimizedCircularBitmaps.size() <= 1) {
                    avatarPaint.setAlpha(255);
                    canvas.drawBitmap(curBmp, bmpLeft, bmpTop, avatarPaint);
                } else {
                    Bitmap nextBmp = optimizedCircularBitmaps.get(nextIdx % optimizedCircularBitmaps.size());

                    // Current image slides UP and fades out
                    float curYOffset = -slideProgress * diameter;
                    avatarPaint.setAlpha((int) (255 * (1f - slideProgress)));
                    canvas.drawBitmap(curBmp, bmpLeft, bmpTop + curYOffset, avatarPaint);

                    // Incoming next image slides UP from bottom and fades in
                    float nextYOffset = (1f - slideProgress) * diameter;
                    incomingAvatarPaint.setAlpha((int) (255 * slideProgress));
                    canvas.drawBitmap(nextBmp, bmpLeft, bmpTop + nextYOffset, incomingAvatarPaint);
                }
            }

            canvas.restore();
        }

        // 3. Inner Rotating SweepGradient Neon Ring
        if (cachedSweepGradient != null) {
            canvas.save();
            canvas.rotate(phase * 360f, cx, cy);
            ringPaint.setStrokeWidth(3.2f * density);
            ringPaint.setShader(cachedSweepGradient);
            canvas.drawCircle(cx, cy, cachedInnerRingR, ringPaint);
            ringPaint.setShader(null);
            canvas.restore();
        }

        // 4. Outer Counter-Rotating Segmented Arcs
        arcPaint.setStrokeWidth(2.4f * density);
        arcPaint.setColor(primaryColor);
        float rotOuter = -phase * 360f;
        for (int i = 0; i < 4; i++) {
            canvas.drawArc(outerArcRect, rotOuter + i * 90f, 44f, false, arcPaint);
        }

        // 5. Orbiting Glowing Energy Nodes on perimeter
        dotPaint.setColor(Color.WHITE);
        for (int k = 0; k < 3; k++) {
            double angleRad = Math.toRadians(phase * 360f * 1.5f + k * 120f);
            float nx = cx + (float) Math.cos(angleRad) * cachedOuterRingR;
            float ny = cy + (float) Math.sin(angleRad) * cachedOuterRingR;
            canvas.drawCircle(nx, ny, 2.6f * density, dotPaint);
        }
    }
}
