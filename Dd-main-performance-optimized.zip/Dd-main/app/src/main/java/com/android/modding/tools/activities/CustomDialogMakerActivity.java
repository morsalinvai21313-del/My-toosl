package com.android.modding.tools.activities;

import com.android.modding.tools.dialogmaker.DialogConfig;

/**
 * Custom Dialog Master Maker.
 * Comprehensive suite granting modders full manual control over every layout, style, and Dalvik option.
 */
public class CustomDialogMakerActivity extends BaseDialogMakerActivity {

    @Override
    protected DialogConfig getInitialConfig() {
        return DialogConfig.createCustomDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Custom Dialog Master Maker";
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("⚡ MASTER BUILDER PRESETS");
        }
        if (btnPreset1 != null) {
            btnPreset1.setText("Balanced Dark");
            btnPreset1.setOnClickListener(v -> applyPreset(createBalancedDarkPreset(), "Balanced Dark"));
        }
        if (btnPreset2 != null) {
            btnPreset2.setText("Glass Cyan");
            btnPreset2.setOnClickListener(v -> applyPreset(createGlassCyanPreset(), "Glass Cyan"));
        }
        if (btnPreset3 != null) {
            btnPreset3.setText("Stealth Black");
            btnPreset3.setOnClickListener(v -> applyPreset(createStealthBlackPreset(), "Stealth Black"));
        }
        if (btnPreset4 != null) {
            btnPreset4.setText("Gold Luxury");
            btnPreset4.setOnClickListener(v -> applyPreset(createGoldLuxuryPreset(), "Gold Luxury"));
        }
    }

    private DialogConfig createBalancedDarkPreset() {
        DialogConfig c = DialogConfig.createCustomDefault();
        c.bgHex = "#0C2230";
        c.isGradient = true;
        c.bgGradientEndHex = "#142F42";
        c.borderHex = "#00E5FF";
        c.titleText = "Custom Dialog";
        c.messageText = "Tailored layout with custom padding, borders, and animations.";
        c.buttonCount = 2;
        c.btn1Text = "Cancel";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Apply";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.openAnimMode = "Zoom";
        return c;
    }

    private DialogConfig createGlassCyanPreset() {
        DialogConfig c = DialogConfig.createCustomDefault();
        c.bgHex = "#0A2540";
        c.isGradient = true;
        c.bgGradientEndHex = "#004B6E";
        c.borderHex = "#00FFFF";
        c.titleColorHex = "#00FFFF";
        c.titleText = "Glassmorphism UI";
        c.messageText = "Translucent cyan overlay with vivid contrast accents.";
        c.buttonCount = 2;
        c.btn1Text = "Dismiss";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Proceed";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.openAnimMode = "Origami";
        return c;
    }

    private DialogConfig createStealthBlackPreset() {
        DialogConfig c = DialogConfig.createCustomDefault();
        c.bgHex = "#080808";
        c.isGradient = false;
        c.borderHex = "#00FF66";
        c.titleColorHex = "#00FF66";
        c.titleText = "Stealth Mode";
        c.messageText = "Minimalist pitch-black surface with hyper-crisp neon edges.";
        c.buttonCount = 1;
        c.btn3Text = "Acknowledge";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.openAnimMode = "Matrix Drop";
        return c;
    }

    private DialogConfig createGoldLuxuryPreset() {
        DialogConfig c = DialogConfig.createCustomDefault();
        c.bgHex = "#1A1505";
        c.isGradient = true;
        c.bgGradientEndHex = "#2E2408";
        c.borderHex = "#FFD700";
        c.titleColorHex = "#FFD700";
        c.subtitleColorHex = "#FFE57F";
        c.titleText = "Gold Edition";
        c.subtitleText = "Premium Gold Styling";
        c.messageText = "Opulent golden aesthetics designed for prestige VIP dialogs.";
        c.buttonCount = 2;
        c.btn1Text = "Decline";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Claim VIP";
        c.btn3Action = DialogConfig.ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Flip 3D";
        return c;
    }
}
