package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;









import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ThreeDEditorActivity extends AppCompatActivity {

    public static final String XML_INITIAL_PLACEHOLDER =
            "<!-- XML will be generated here when you select colors or configure layers -->";

    private final Map<String, StateModel> stateMap = new HashMap<>();
    private String currentState = StateModel.STATE_NORMAL;
    private int activeLayerIndex = 0;

    // Sticky Preview Views
    private FrameLayout boxFrameNormal, boxFrameChecked, boxFramePressed;
    private FrameLayout cardNormal, cardChecked, cardPressed;
    private TextView tvPreviewNormalLabel, tvPreviewCheckedLabel, tvPreviewPressedLabel;

    // State Tabs
    private Button tabNormal, tabChecked, tabPressed;

    // Fixed 4 Layers
    private Button btnLayer1, btnLayer2, btnLayer3, btnLayer4;
    private TextView tvActiveLayerTitle;

    // Color UI Controls
    private TextView tvStartColorHex, tvCenterColorHex, tvEndColorHex, tvStrokeColorHex;
    private LinearLayout layoutCenterColor;
    private Button btnPickStartColor, btnPickCenterColor, btnPickEndColor, btnPickStrokeColor;
    private CheckBox cbThreeColor;

    // Gradient Type
    private Button btnTypeLinear, btnTypeRadial, btnTypeSweep;
    private LinearLayout layoutLinearOptions, layoutRadialOptions, layoutRadiusRow;
    private TextView tvAngleVal, tvRadiusVal, tvCenterXVal, tvCenterYVal;
    private SeekBar seekAngle, seekRadius, seekCenterX, seekCenterY;

    // Code & Scrolling
    private TextView etGeneratedXml;
    private ScrollView scrollCodeVertical;
    private HorizontalScrollView scrollCodeHorizontal;
    private HistoryManager historyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3d_editor);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);

        initBlank3dStates();
        initViews();

        String importedXml = getIntent().getStringExtra("EXTRA_IMPORTED_XML");
        if (importedXml != null && !importedXml.trim().isEmpty()) {
            loadImportedXml(importedXml.trim());
        } else {
            updateLayerButtons();
            updateUiForActiveLayer();
            updateStateFrameSelection();
            updatePreviewAndXml();
        }
    }

    /**
     * Initializes all 3D states completely blank (no pre-filled colors, no auto-generated XML).
     * Just like Normal and Gradient editors, XML is only generated once the user configures layers!
     */
    private void initBlank3dStates() {
        stateMap.clear();

        // Normal State: starts blank & inactive
        StateModel normal = new StateModel(StateModel.STATE_NORMAL);
        normal.setActive(false);
        normal.getLayers().clear();
        for (int i = 1; i <= 4; i++) {
            LayerModel l = new LayerModel("Layer " + i);
            l.setGradient(true);
            l.getGradient().setStartColor("#00000000");
            l.getGradient().setCenterColor("#00000000");
            l.getGradient().setEndColor("#00000000");
            l.getGradient().setAngle(90);
            l.getGradient().setUseCenterColor(false);
            l.setInsets(new InsetsModel(0, 0, 0, 0));
            l.getCorners().setCorners(0, 0, 0, 0, false);
            l.getStroke().setColor("#00000000");
            l.getStroke().setWidthDp(0);
            normal.getLayers().add(l);
        }
        stateMap.put(StateModel.STATE_NORMAL, normal);

        // Checked State: starts blank & inactive
        StateModel checked = new StateModel(StateModel.STATE_CHECKED);
        checked.setActive(false);
        checked.getLayers().clear();
        for (int i = 1; i <= 4; i++) {
            LayerModel l = new LayerModel("Layer " + i);
            l.setGradient(true);
            l.getGradient().setStartColor("#00000000");
            l.getGradient().setCenterColor("#00000000");
            l.getGradient().setEndColor("#00000000");
            l.getGradient().setAngle(90);
            l.getGradient().setUseCenterColor(false);
            l.setInsets(new InsetsModel(0, 0, 0, 0));
            l.getCorners().setCorners(0, 0, 0, 0, false);
            l.getStroke().setColor("#00000000");
            l.getStroke().setWidthDp(0);
            checked.getLayers().add(l);
        }
        stateMap.put(StateModel.STATE_CHECKED, checked);

        // Pressed State: starts blank & inactive
        StateModel pressed = new StateModel(StateModel.STATE_PRESSED);
        pressed.setActive(false);
        pressed.getLayers().clear();
        for (int i = 1; i <= 4; i++) {
            LayerModel l = new LayerModel("Layer " + i);
            l.setGradient(true);
            l.getGradient().setStartColor("#00000000");
            l.getGradient().setCenterColor("#00000000");
            l.getGradient().setEndColor("#00000000");
            l.getGradient().setAngle(90);
            l.getGradient().setUseCenterColor(false);
            l.setInsets(new InsetsModel(0, 0, 0, 0));
            l.getCorners().setCorners(0, 0, 0, 0, false);
            l.getStroke().setColor("#00000000");
            l.getStroke().setWidthDp(0);
            pressed.getLayers().add(l);
        }
        stateMap.put(StateModel.STATE_PRESSED, pressed);
    }

    private void loadImportedXml(String xml) {
        XmlParser.ParseResult result = XmlParser.parseXml(xml);
        if (!result.success) return;

        if (result.selectorStates != null && !result.selectorStates.isEmpty()) {
            stateMap.clear();
            for (Map.Entry<String, StateModel> entry : result.selectorStates.entrySet()) {
                StateModel sm = entry.getValue();
                while (sm.getLayers().size() < 4) {
                    LayerModel extra = new LayerModel("Layer " + (sm.getLayers().size() + 1));
                    extra.setSolidColor("#00000000");
                    extra.getStroke().setColor("#00000000");
                    extra.getStroke().setWidthDp(0);
                    sm.getLayers().add(extra);
                }
                stateMap.put(entry.getKey(), sm);
            }
            if (!stateMap.containsKey(StateModel.STATE_NORMAL)) {
                StateModel normal = new StateModel(StateModel.STATE_NORMAL);
                normal.setActive(true);
                for (int i = 1; i <= 4; i++) {
                    normal.getLayers().add(new LayerModel("Layer " + i));
                }
                stateMap.put(StateModel.STATE_NORMAL, normal);
            }
        } else if (result.layerList != null && !result.layerList.isEmpty()) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            for (int i = 0; i < Math.min(4, result.layerList.size()); i++) {
                normal.getLayers().add(result.layerList.get(i));
            }
            while (normal.getLayers().size() < 4) {
                LayerModel extra = new LayerModel("Layer " + (normal.getLayers().size() + 1));
                extra.setSolidColor("#00000000");
                extra.getStroke().setColor("#00000000");
                extra.getStroke().setWidthDp(0);
                normal.getLayers().add(extra);
            }
            stateMap.put(StateModel.STATE_NORMAL, normal);
        } else if (result.singleLayer != null) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            normal.getLayers().add(result.singleLayer);
            while (normal.getLayers().size() < 4) {
                LayerModel extra = new LayerModel("Layer " + (normal.getLayers().size() + 1));
                extra.setSolidColor("#00000000");
                extra.getStroke().setColor("#00000000");
                extra.getStroke().setWidthDp(0);
                normal.getLayers().add(extra);
            }
            stateMap.put(StateModel.STATE_NORMAL, normal);
        }

        currentState = StateModel.STATE_NORMAL;
        activeLayerIndex = 0;
        updateLayerButtons();
        updateStateFrameSelection();
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });
        findViewById(R.id.btn_reset).setOnClickListener(v -> showResetDialog());

        boxFrameNormal = findViewById(R.id.box_frame_normal);
        boxFrameChecked = findViewById(R.id.box_frame_checked);
        boxFramePressed = findViewById(R.id.box_frame_pressed);

        cardNormal = findViewById(R.id.card_preview_normal);
        cardChecked = findViewById(R.id.card_preview_checked);
        cardPressed = findViewById(R.id.card_preview_pressed);

        tvPreviewNormalLabel = findViewById(R.id.tv_preview_normal_label);
        tvPreviewCheckedLabel = findViewById(R.id.tv_preview_checked_label);
        tvPreviewPressedLabel = findViewById(R.id.tv_preview_pressed_label);

        tabNormal = findViewById(R.id.tab_edit_normal);
        tabChecked = findViewById(R.id.tab_edit_checked);
        tabPressed = findViewById(R.id.tab_edit_pressed);

        btnLayer1 = findViewById(R.id.btn_layer_1);
        btnLayer2 = findViewById(R.id.btn_layer_2);
        btnLayer3 = findViewById(R.id.btn_layer_3);
        btnLayer4 = findViewById(R.id.btn_layer_4);

        btnLayer1.setOnClickListener(v -> selectLayer(0));
        btnLayer2.setOnClickListener(v -> selectLayer(1));
        btnLayer3.setOnClickListener(v -> selectLayer(2));
        btnLayer4.setOnClickListener(v -> selectLayer(3));

        tvActiveLayerTitle = findViewById(R.id.tv_active_layer_title);

        tvStartColorHex = findViewById(R.id.tv_start_color_hex);
        tvCenterColorHex = findViewById(R.id.tv_center_color_hex);
        tvEndColorHex = findViewById(R.id.tv_end_color_hex);
        tvStrokeColorHex = findViewById(R.id.tv_stroke_color_hex);

        layoutCenterColor = findViewById(R.id.layout_center_color);
        btnPickStartColor = findViewById(R.id.btn_pick_start_color);
        btnPickCenterColor = findViewById(R.id.btn_pick_center_color);
        btnPickEndColor = findViewById(R.id.btn_pick_end_color);
        btnPickStrokeColor = findViewById(R.id.btn_pick_stroke_color);
        cbThreeColor = findViewById(R.id.cb_three_color_gradient);

        btnTypeLinear = findViewById(R.id.btn_type_linear);
        btnTypeRadial = findViewById(R.id.btn_type_radial);
        btnTypeSweep = findViewById(R.id.btn_type_sweep);

        layoutLinearOptions = findViewById(R.id.layout_linear_options);
        layoutRadialOptions = findViewById(R.id.layout_radial_options);
        layoutRadiusRow = findViewById(R.id.layout_radius_row);

        tvAngleVal = findViewById(R.id.tv_angle_val);
        tvRadiusVal = findViewById(R.id.tv_radius_val);
        tvCenterXVal = findViewById(R.id.tv_center_x_val);
        tvCenterYVal = findViewById(R.id.tv_center_y_val);

        seekAngle = findViewById(R.id.seek_angle);
        seekRadius = findViewById(R.id.seek_radius);
        seekCenterX = findViewById(R.id.seek_center_x);
        seekCenterY = findViewById(R.id.seek_center_y);

        scrollCodeVertical = findViewById(R.id.scroll_code_vertical);
        scrollCodeHorizontal = findViewById(R.id.scroll_code_horizontal);
        etGeneratedXml = findViewById(R.id.et_generated_xml);

        // Enable smooth, isolated scrolling inside the code box
        XmlFormatter.enableCodeBoxScroll(etGeneratedXml, scrollCodeVertical, scrollCodeHorizontal);

        // State Tab and Preview Card Clicks
        tabNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        tabChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        tabPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        cardNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        cardChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        cardPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        // 3-Color Checkbox: only toggles active state, never injects random colors!
        cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ensureCurrentStateActive();
            getActiveLayer().getGradient().setUseCenterColor(isChecked);
            updateUiForActiveLayer();
            updatePreviewAndXml();
        });

        // Color Picker Listeners with live instant preview
        btnPickStartColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getStartColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#00FFFF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickCenterColor.setOnClickListener(v -> {
            if (!cbThreeColor.isChecked()) return;
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getCenterColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#FF007F";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setCenterColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setCenterColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickEndColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            GradientModel g = layer.getGradient();
            String initial = g.getEndColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#00E5FF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        btnPickStrokeColor.setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            StrokeModel s = layer.getStroke();
            String initial = s.getColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#00FFFF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        s.setColor(color);
                        if (s.getWidthDp() == 0) s.setWidthDp(1);
                        updateUiForActiveLayer();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        s.setColor(color);
                        if (s.getWidthDp() == 0) s.setWidthDp(1);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        // Gradient Type Buttons
        btnTypeLinear.setOnClickListener(v -> setGradientType(GradientModel.TYPE_LINEAR));
        btnTypeRadial.setOnClickListener(v -> setGradientType(GradientModel.TYPE_RADIAL));
        btnTypeSweep.setOnClickListener(v -> setGradientType(GradientModel.TYPE_SWEEP));

        // Stepper buttons for angle
        findViewById(R.id.btn_angle_minus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int newAngle = Math.max(0, seekAngle.getProgress() - 15);
            seekAngle.setProgress(newAngle);
            getActiveLayer().getGradient().setAngle(newAngle);
            tvAngleVal.setText(newAngle + "°");
            updatePreviewAndXml();
        });
        findViewById(R.id.btn_angle_plus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int newAngle = Math.min(360, seekAngle.getProgress() + 15);
            seekAngle.setProgress(newAngle);
            getActiveLayer().getGradient().setAngle(newAngle);
            tvAngleVal.setText(newAngle + "°");
            updatePreviewAndXml();
        });

        // Sliders with live preview
        seekAngle.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getActiveLayer().getGradient().setAngle(progress);
                    tvAngleVal.setText(progress + "°");
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getActiveLayer().getGradient().setGradientRadiusDp(progress);
                    tvRadiusVal.setText(progress + "dp");
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekCenterX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getActiveLayer().getGradient().setCenterX(val);
                    tvCenterXVal.setText(String.format(java.util.Locale.US, "%.2f", val));
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekCenterY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getActiveLayer().getGradient().setCenterY(val);
                    tvCenterYVal.setText(String.format(java.util.Locale.US, "%.2f", val));
                    updatePreviewAndXml();
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Dialogs with live preview
        findViewById(R.id.btn_set_custom_corners).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomCornersDialog dialog = new CustomCornersDialog(this, layer.getCorners(),
                    (tl, tr, bl, br, linked) -> {
                        ensureCurrentStateActive();
                        layer.getCorners().setCorners(tl, tr, bl, br, linked);
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((tl, tr, bl, br, linked) -> {
                ensureCurrentStateActive();
                layer.getCorners().setCorners(tl, tr, bl, br, linked);
                updatePreviewOnly();
            });
            dialog.show();
        });

        findViewById(R.id.btn_set_custom_stroke).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomStrokeDialog dialog = new CustomStrokeDialog(this, layer.getStroke(),
                    (widthDp, dashWidthDp, dashGapDp) -> {
                        ensureCurrentStateActive();
                        layer.getStroke().setWidthDp(widthDp);
                        layer.getStroke().setDashWidthDp(dashWidthDp);
                        layer.getStroke().setDashGapDp(dashGapDp);
                        updateUiForActiveLayer();
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((widthDp, dashWidthDp, dashGapDp) -> {
                ensureCurrentStateActive();
                layer.getStroke().setWidthDp(widthDp);
                layer.getStroke().setDashWidthDp(dashWidthDp);
                layer.getStroke().setDashGapDp(dashGapDp);
                updatePreviewOnly();
            });
            dialog.show();
        });

        findViewById(R.id.btn_set_custom_insets).setOnClickListener(v -> {
            LayerModel layer = getActiveLayer();
            CustomInsetsDialog dialog = new CustomInsetsDialog(this, layer.getInsets(),
                    (left, top, right, bottom, linked) -> {
                        ensureCurrentStateActive();
                        layer.getInsets().setInsets(left, top, right, bottom, linked);
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((left, top, right, bottom, linked) -> {
                ensureCurrentStateActive();
                layer.getInsets().setInsets(left, top, right, bottom, linked);
                updatePreviewOnly();
            });
            dialog.show();
        });

        // Bottom Action Buttons
        findViewById(R.id.btn_copy_code).setOnClickListener(v -> copyXmlToClipboard());
        findViewById(R.id.btn_save_history).setOnClickListener(v -> saveToHistory());
        findViewById(R.id.btn_download_xml).setOnClickListener(v -> downloadXmlFile());
        findViewById(R.id.btn_share_export).setOnClickListener(v -> shareXml());
    }

    private void selectLayer(int index) {
        activeLayerIndex = index;
        updateLayerButtons();
        updateUiForActiveLayer();
    }

    private void updateLayerButtons() {
        if (btnLayer1 != null) btnLayer1.setSelected(activeLayerIndex == 0);
        if (btnLayer2 != null) btnLayer2.setSelected(activeLayerIndex == 1);
        if (btnLayer3 != null) btnLayer3.setSelected(activeLayerIndex == 2);
        if (btnLayer4 != null) btnLayer4.setSelected(activeLayerIndex == 3);
    }

    private void switchState(String stateKey) {
        currentState = stateKey;
        activeLayerIndex = 0;
        updateStateFrameSelection();
        updateLayerButtons();
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    private void updateStateFrameSelection() {
        boolean isNorm = StateModel.STATE_NORMAL.equals(currentState);
        boolean isChk = StateModel.STATE_CHECKED.equals(currentState);
        boolean isPrs = StateModel.STATE_PRESSED.equals(currentState);

        boxFrameNormal.setBackgroundResource(isNorm ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFrameChecked.setBackgroundResource(isChk ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFramePressed.setBackgroundResource(isPrs ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);

        tabNormal.setSelected(isNorm);
        tabChecked.setSelected(isChk);
        tabPressed.setSelected(isPrs);
    }

    private void setGradientType(String type) {
        ensureCurrentStateActive();
        getActiveLayer().getGradient().setType(type);
        updateUiForActiveLayer();
        updatePreviewAndXml();
    }

    private void ensureCurrentStateActive() {
        StateModel state = getCurrentStateModel();
        if (!state.isActive()) {
            state.setActive(true);
        }
    }

    private StateModel getCurrentStateModel() {
        StateModel state = stateMap.get(currentState);
        if (state == null) {
            state = new StateModel(currentState);
            state.setActive(false);
            for (int i = 1; i <= 4; i++) {
                state.getLayers().add(new LayerModel("Layer " + i));
            }
            stateMap.put(currentState, state);
        }
        return state;
    }

    private LayerModel getActiveLayer() {
        List<LayerModel> layers = getCurrentStateModel().getLayers();
        while (layers.size() < 4) {
            layers.add(new LayerModel("Layer " + (layers.size() + 1)));
        }
        if (activeLayerIndex < 0 || activeLayerIndex >= layers.size()) {
            activeLayerIndex = 0;
        }
        return layers.get(activeLayerIndex);
    }

    private void updateUiForActiveLayer() {
        LayerModel layer = getActiveLayer();
        GradientModel g = layer.getGradient();

        tvActiveLayerTitle.setText(currentState.toUpperCase() + " • " + layer.getName());

        boolean hasStart = g.getStartColor() != null && !g.getStartColor().isEmpty() && !g.getStartColor().equals("#00000000");
        boolean hasCenter = g.getCenterColor() != null && !g.getCenterColor().isEmpty() && !g.getCenterColor().equals("#00000000");
        boolean hasEnd = g.getEndColor() != null && !g.getEndColor().isEmpty() && !g.getEndColor().equals("#00000000");

        applyColorBadge(tvStartColorHex, hasStart ? g.getStartColor() : null, "None");
        applyColorBadge(tvEndColorHex, hasEnd ? g.getEndColor() : null, "None");

        StrokeModel stroke = layer.getStroke();
        boolean hasStroke = stroke != null && stroke.getWidthDp() > 0 && stroke.getColor() != null && !stroke.getColor().equals("#00000000");
        if (hasStroke) {
            applyColorBadge(tvStrokeColorHex, stroke.getColor(), "None (0dp)");
            tvStrokeColorHex.setText(stroke.getColor() + " (" + stroke.getWidthDp() + "dp)");
        } else {
            tvStrokeColorHex.setText("None (0dp)");
            tvStrokeColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvStrokeColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        boolean is3Color = g.isUseCenterColor();
        cbThreeColor.setOnCheckedChangeListener(null);
        cbThreeColor.setChecked(is3Color);
        cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ensureCurrentStateActive();
            getActiveLayer().getGradient().setUseCenterColor(isChecked);
            updateUiForActiveLayer();
            updatePreviewAndXml();
        });

        if (is3Color) {
            layoutCenterColor.setAlpha(1.0f);
            btnPickCenterColor.setEnabled(true);
            btnPickCenterColor.setText(R.string.action_pick_color);
            applyColorBadge(tvCenterColorHex, hasCenter ? g.getCenterColor() : null, "None");
        } else {
            layoutCenterColor.setAlpha(0.35f);
            btnPickCenterColor.setEnabled(false);
            btnPickCenterColor.setText("DISABLED");
            tvCenterColorHex.setText("Disabled");
            tvCenterColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvCenterColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        btnTypeLinear.setSelected(GradientModel.TYPE_LINEAR.equals(g.getType()));
        btnTypeRadial.setSelected(GradientModel.TYPE_RADIAL.equals(g.getType()));
        btnTypeSweep.setSelected(GradientModel.TYPE_SWEEP.equals(g.getType()));

        if (GradientModel.TYPE_LINEAR.equals(g.getType())) {
            layoutLinearOptions.setVisibility(View.VISIBLE);
            layoutRadialOptions.setVisibility(View.GONE);
            seekAngle.setProgress(g.getAngle());
            tvAngleVal.setText(g.getAngle() + "°");
        } else if (GradientModel.TYPE_RADIAL.equals(g.getType())) {
            layoutLinearOptions.setVisibility(View.GONE);
            layoutRadialOptions.setVisibility(View.VISIBLE);
            layoutRadiusRow.setVisibility(View.VISIBLE);
            seekRadius.setProgress(g.getGradientRadiusDp());
            tvRadiusVal.setText(g.getGradientRadiusDp() + "dp");
            seekCenterX.setProgress((int) (g.getCenterX() * 100));
            seekCenterY.setProgress((int) (g.getCenterY() * 100));
            tvCenterXVal.setText(String.format(java.util.Locale.US, "%.2f", g.getCenterX()));
            tvCenterYVal.setText(String.format(java.util.Locale.US, "%.2f", g.getCenterY()));
        } else {
            layoutLinearOptions.setVisibility(View.GONE);
            layoutRadialOptions.setVisibility(View.VISIBLE);
            layoutRadiusRow.setVisibility(View.GONE);
            seekCenterX.setProgress((int) (g.getCenterX() * 100));
            seekCenterY.setProgress((int) (g.getCenterY() * 100));
            tvCenterXVal.setText(String.format(java.util.Locale.US, "%.2f", g.getCenterX()));
            tvCenterYVal.setText(String.format(java.util.Locale.US, "%.2f", g.getCenterY()));
        }
    }

    private void applyColorBadge(TextView tv, String hexColor, String defaultLabel) {
        tv.setBackgroundResource(R.drawable.morsalin_code_bg);
        if (hexColor == null || hexColor.isEmpty() || hexColor.equals("#00000000")) {
            tv.setText(defaultLabel);
            tv.setTextColor(getColor(R.color.morsalin_text_muted));
        } else {
            tv.setText(hexColor);
            tv.setTextColor(getColor(R.color.morsalin_cyan));
        }
    }

    private boolean isLightColor(int color) {
        if (Color.alpha(color) < 80) return false;
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0;
        return darkness < 0.45;
    }

    private void updatePreviewOnly() {
        StateModel cur = getCurrentStateModel();
        if (cur.isActive()) {
            if (StateModel.STATE_NORMAL.equals(currentState)) {
                cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewNormalLabel.setVisibility(View.GONE);
            } else if (StateModel.STATE_CHECKED.equals(currentState)) {
                cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewCheckedLabel.setVisibility(View.GONE);
            } else if (StateModel.STATE_PRESSED.equals(currentState)) {
                cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, cur.getLayers()));
                tvPreviewPressedLabel.setVisibility(View.GONE);
            }
        }
    }

    private void updatePreviewAndXml() {
        boolean hasAnyActive = false;
        for (StateModel sm : stateMap.values()) {
            if (sm.isActive()) {
                hasAnyActive = true;
                break;
            }
        }

        // Normal State Preview
        StateModel normal = stateMap.get(StateModel.STATE_NORMAL);
        if (normal != null && normal.isActive()) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, normal.getLayers()));
            tvPreviewNormalLabel.setVisibility(View.GONE);
        } else {
            cardNormal.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewNormalLabel.setText("Normal\n(Not Set)");
            tvPreviewNormalLabel.setVisibility(View.VISIBLE);
        }

        // Checked State Preview
        StateModel checked = stateMap.get(StateModel.STATE_CHECKED);
        if (checked != null && checked.isActive()) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, checked.getLayers()));
            tvPreviewCheckedLabel.setVisibility(View.GONE);
        } else {
            cardChecked.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewCheckedLabel.setText("Checked\n(Not Set)");
            tvPreviewCheckedLabel.setVisibility(View.VISIBLE);
        }

        // Pressed State Preview
        StateModel pressed = stateMap.get(StateModel.STATE_PRESSED);
        if (pressed != null && pressed.isActive()) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, pressed.getLayers()));
            tvPreviewPressedLabel.setVisibility(View.GONE);
        } else {
            cardPressed.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
            tvPreviewPressedLabel.setText("Pressed\n(Not Set)");
            tvPreviewPressedLabel.setVisibility(View.VISIBLE);
        }

        // Generate Selector XML
        if (!hasAnyActive) {
            etGeneratedXml.setText(XML_INITIAL_PLACEHOLDER);
        } else {
            String xml = XmlGenerator.generateSelectorXml(stateMap);
            xml = XmlFormatter.formatXml(xml);
            etGeneratedXml.setText(xml);
        }
    }

    private void copyXmlToClipboard() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_content_copy, "No XML Yet", "Configure a 3D layer or color first.");
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("3D Shape XML", xml);
        cm.setPrimaryClip(clip);
        MorsalinToast.showCopy(this, "3D Shape Selector XML");
    }

    private void saveToHistory() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_save, "No XML Yet", "Configure a 3D layer or color first.");
            return;
        }
        XmlProject project = new XmlProject(
                "3D Shape " + System.currentTimeMillis() % 1000,
                XmlProject.TYPE_3D,
                xml
        );
        historyManager.saveProject(project);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Project successfully added to History.");
    }

    private void downloadXmlFile() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_download, "No XML Yet", "Configure a 3D layer or color first.");
            return;
        }
        FileExporter.exportXmlToFile(this, "MS MORSALIN_BG.xml", xml);
        MorsalinToast.showDownload(this, "MS MORSALIN_BG.xml");
    }

    private void shareXml() {
        String xml = etGeneratedXml.getText().toString();
        if (XML_INITIAL_PLACEHOLDER.equals(xml)) {
            MorsalinToast.show(this, R.drawable.ic_share, "No XML Yet", "Configure a 3D layer or color first.");
            return;
        }
        ShareHelper.shareXmlText(this, xml, "Share 3D Shape XML");
    }

    private void showResetDialog() {
        MorsalinDialogHelper.showResetDialog(
                this,
                "Reset 3D Shape",
                "Are you sure you want to reset all 3D layers to default blank state?",
                () -> {
                    initBlank3dStates();
                    currentState = StateModel.STATE_NORMAL;
                    activeLayerIndex = 0;
                    updateStateFrameSelection();
                    updateLayerButtons();
                    updateUiForActiveLayer();
                    updatePreviewAndXml();
                    MorsalinToast.show(this, R.drawable.ic_refresh, "Shape Reset", "Reset to initial blank state.");
                }
        );
    }
}
