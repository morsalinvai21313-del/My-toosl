package com.android.modding.tools.toastmaker;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**
 * Universal Configuration model for Toast Maker.
 * Holds all customization attributes: visual styling, text, duration, gravity,
 * animations, badge symbols, Base64 obfuscation, colors, and audio assets.
 */
public class ToastConfig implements Serializable {

    public static final String TYPE_SIMPLE = "Simple Smali Toast";
    public static final String TYPE_BASE64 = "Base64 Smali Toast";
    public static final String TYPE_COLORFUL = "Colorful Toast Maker";
    public static final String TYPE_ANIMATED = "Animated Toast Maker";
    public static final String TYPE_IMAGE = "Image / Badge Toast";

    public String toastType = TYPE_SIMPLE;
    public String toastName = "Morsalin_Custom_Toast";
    public String titleText = "";
    public String messageText = "Welcome to Modded App by Morsalin!";
    public boolean isTitleVisible = false;
    public boolean isBase64 = false;
    public boolean durationLong = true;

    // Gravity: 0 = Bottom, 1 = Center, 2 = Top
    public int gravity = 0;
    public int yOffsetDp = 64;
    public int xOffsetDp = 0;

    // Styling
    public String bgHex = "#1A1D2E";
    public boolean isGradient = false;
    public String bgGradientEndHex = "#00E5FF";
    public int gradientOrientation = 0; // 0=LEFT_RIGHT, 1=TOP_BOTTOM, 2=TL_BR

    public String textColorHex = "#FFFFFF";
    public String titleColorHex = "#00E5FF";
    public String borderHex = "#00E5FF";
    public int borderWidthDp = 2;
    public int cornerRadiusDp = 18;
    public int paddingHorizontalDp = 18;
    public int paddingVerticalDp = 12;
    public int widthPct = 85;
    public int elevationDp = 8;

    // Animation
    public String animMode = "Bounce";
    public int animDurationMs = 500;

    // Badge / Icon
    public String iconType = "NONE";
    public String iconEmoji = "";
    public String iconBgHex = "#26C6DA";

    // Custom Gallery Photo Asset
    public byte[] customImageBytes = null;
    public boolean hasCustomImage = false;
    public String customImageName = "toast_icon.png";

    // Audio & Assets
    public boolean hasSoundEffect = true;
    public String soundAssetName = "toast_chime.wav";

    // Backwards compatibility aliases
    public boolean isLongDuration = true;
    public String strokeColorHex = "#00E5FF";
    public int strokeWidthDp = 2;
    public String symbolIcon = "";
    public boolean hasBadge = false;
    public boolean isBase64Encoded = false;
    public String base64Payload = "";

    public ToastConfig() {}

    public ToastConfig(String toastType) {
        this.toastType = toastType;
    }

    public static ToastConfig createSimpleDefault() {
        ToastConfig c = new ToastConfig(TYPE_SIMPLE);
        c.toastName = "Morsalin_Simple_Toast";
        c.messageText = "Welcome to Modded App by Morsalin!";
        c.bgHex = "#1E2235";
        c.borderHex = "#00E5FF";
        c.strokeColorHex = "#00E5FF";
        c.borderWidthDp = 2;
        c.strokeWidthDp = 2;
        c.cornerRadiusDp = 16;
        c.textColorHex = "#FFFFFF";
        c.durationLong = true;
        c.isLongDuration = true;
        c.gravity = 0;
        c.yOffsetDp = 64;
        c.animMode = "Fade";
        c.animDurationMs = 400;
        return c;
    }

    public static ToastConfig createBase64Default() {
        ToastConfig c = new ToastConfig(TYPE_BASE64);
        c.toastName = "Morsalin_Base64_Toast";
        c.messageText = "Modded by Morsalin • VIP Active";
        c.isBase64 = true;
        c.isBase64Encoded = true;
        c.bgHex = "#131722";
        c.isGradient = true;
        c.bgGradientEndHex = "#00E5FF";
        c.borderHex = "#00E5FF";
        c.strokeColorHex = "#00E5FF";
        c.borderWidthDp = 2;
        c.strokeWidthDp = 2;
        c.cornerRadiusDp = 18;
        c.textColorHex = "#E0F7FA";
        c.animMode = "Cyber Glitch";
        c.animDurationMs = 500;
        return c;
    }

    public static ToastConfig createColorfulDefault() {
        ToastConfig c = new ToastConfig(TYPE_COLORFUL);
        c.toastName = "Morsalin_Colorful_Toast";
        c.messageText = "Cyber Mod Activated Successfully!";
        c.isGradient = false;
        c.bgHex = "#FF1744";
        c.bgGradientEndHex = "#D50000";
        c.gradientOrientation = 0;
        c.borderHex = "#00E5FF";
        c.strokeColorHex = "#00E5FF";
        c.borderWidthDp = 2;
        c.strokeWidthDp = 2;
        c.cornerRadiusDp = 28;
        c.textColorHex = "#FFFFFF";
        c.animMode = "Bounce";
        c.animDurationMs = 500;
        return c;
    }

    public static ToastConfig createAnimatedDefault() {
        ToastConfig c = new ToastConfig(TYPE_ANIMATED);
        c.toastName = "Morsalin_Animated_Toast";
        c.messageText = "Animated Notification by Morsalin";
        c.isLongDuration = true;
        c.durationLong = true;
        c.gravity = 1;
        c.bgHex = "#F0181D26";
        c.isGradient = false;
        c.bgGradientEndHex = "#16213E";
        c.borderHex = "#00E5FF";
        c.strokeColorHex = "#00E5FF";
        c.borderWidthDp = 1;
        c.strokeWidthDp = 1;
        c.cornerRadiusDp = 26;
        c.textColorHex = "#00E5FF";
        c.animMode = "Zoom";
        c.animDurationMs = 500;
        return c;
    }

    public static ToastConfig createImageDefault() {
        ToastConfig c = new ToastConfig(TYPE_IMAGE);
        c.toastName = "Morsalin_Badge_Toast";
        c.isTitleVisible = true;
        c.titleText = "VIP ACTIVATED";
        c.messageText = "Modded by Morsalin • All Features Unlocked";
        c.iconType = "CROWN";
        c.iconEmoji = "👑";
        c.symbolIcon = "👑";
        c.hasBadge = true;
        c.iconBgHex = "#FFD700";
        c.bgHex = "#1C1427";
        c.isGradient = true;
        c.bgGradientEndHex = "#401850";
        c.borderHex = "#FFD700";
        c.strokeColorHex = "#FFD700";
        c.borderWidthDp = 2;
        c.strokeWidthDp = 2;
        c.cornerRadiusDp = 22;
        c.titleColorHex = "#FFD700";
        c.textColorHex = "#F3E5F5";
        c.animMode = "Slide";
        c.animDurationMs = 500;
        return c;
    }

    public ToastConfig copy() {
        ToastConfig c = new ToastConfig();
        c.toastType = this.toastType;
        c.toastName = this.toastName;
        c.messageText = this.messageText;
        c.titleText = this.titleText;
        c.isTitleVisible = this.isTitleVisible;
        c.isBase64 = this.isBase64;
        c.isBase64Encoded = this.isBase64Encoded;
        c.durationLong = this.durationLong;
        c.isLongDuration = this.isLongDuration;
        c.gravity = this.gravity;
        c.yOffsetDp = this.yOffsetDp;
        c.xOffsetDp = this.xOffsetDp;
        c.bgHex = this.bgHex;
        c.isGradient = this.isGradient;
        c.bgGradientEndHex = this.bgGradientEndHex;
        c.gradientOrientation = this.gradientOrientation;
        c.textColorHex = this.textColorHex;
        c.titleColorHex = this.titleColorHex;
        c.borderHex = this.borderHex;
        c.strokeColorHex = this.strokeColorHex;
        c.borderWidthDp = this.borderWidthDp;
        c.strokeWidthDp = this.strokeWidthDp;
        c.cornerRadiusDp = this.cornerRadiusDp;
        c.paddingHorizontalDp = this.paddingHorizontalDp;
        c.paddingVerticalDp = this.paddingVerticalDp;
        c.widthPct = this.widthPct;
        c.elevationDp = this.elevationDp;
        c.animMode = this.animMode;
        c.animDurationMs = this.animDurationMs;
        c.iconType = this.iconType;
        c.iconEmoji = this.iconEmoji;
        c.symbolIcon = this.symbolIcon;
        c.hasBadge = this.hasBadge;
        c.iconBgHex = this.iconBgHex;
        c.hasSoundEffect = this.hasSoundEffect;
        c.soundAssetName = this.soundAssetName;
        c.hasCustomImage = this.hasCustomImage;
        c.customImageName = this.customImageName;
        c.customImageBytes = this.customImageBytes != null ? this.customImageBytes.clone() : null;
        return c;
    }

    public String toJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("toastType", toastType);
            obj.put("toastName", toastName);
            obj.put("messageText", messageText);
            obj.put("titleText", titleText);
            obj.put("isTitleVisible", isTitleVisible);
            obj.put("isBase64", isBase64);
            obj.put("durationLong", durationLong);
            obj.put("gravity", gravity);
            obj.put("yOffsetDp", yOffsetDp);
            obj.put("bgHex", bgHex);
            obj.put("isGradient", isGradient);
            obj.put("bgGradientEndHex", bgGradientEndHex);
            obj.put("gradientOrientation", gradientOrientation);
            obj.put("textColorHex", textColorHex);
            obj.put("titleColorHex", titleColorHex);
            obj.put("borderHex", borderHex);
            obj.put("borderWidthDp", borderWidthDp);
            obj.put("cornerRadiusDp", cornerRadiusDp);
            obj.put("paddingHorizontalDp", paddingHorizontalDp);
            obj.put("paddingVerticalDp", paddingVerticalDp);
            obj.put("widthPct", widthPct);
            obj.put("elevationDp", elevationDp);
            obj.put("animMode", animMode);
            obj.put("animDurationMs", animDurationMs);
            obj.put("iconType", iconType);
            obj.put("iconEmoji", iconEmoji);
            obj.put("iconBgHex", iconBgHex);
            obj.put("hasSoundEffect", hasSoundEffect);
            obj.put("soundAssetName", soundAssetName);
            obj.put("hasCustomImage", hasCustomImage);
            obj.put("customImageName", customImageName);
            if (hasCustomImage && customImageBytes != null && customImageBytes.length <= 65536) {
                obj.put("customImageBase64", android.util.Base64.encodeToString(customImageBytes, android.util.Base64.NO_WRAP));
            }
            // Legacy aliases
            obj.put("isLongDuration", durationLong);
            obj.put("strokeColorHex", borderHex);
            obj.put("strokeWidthDp", borderWidthDp);
            obj.put("symbolIcon", iconEmoji);
            obj.put("hasBadge", !"NONE".equals(iconType));
            obj.put("isBase64Encoded", isBase64);
            return obj.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static ToastConfig fromJson(String json) {
        ToastConfig c = createSimpleDefault();
        if (json == null || json.trim().isEmpty()) return c;
        try {
            JSONObject obj = new JSONObject(json);
            if (obj.has("toastType")) c.toastType = obj.getString("toastType");
            if (obj.has("toastName")) c.toastName = obj.getString("toastName");
            if (obj.has("messageText")) c.messageText = obj.getString("messageText");
            if (obj.has("titleText")) c.titleText = obj.getString("titleText");
            if (obj.has("isTitleVisible")) c.isTitleVisible = obj.getBoolean("isTitleVisible");
            if (obj.has("isBase64")) c.isBase64 = obj.getBoolean("isBase64");
            else if (obj.has("isBase64Encoded")) c.isBase64 = obj.getBoolean("isBase64Encoded");
            if (obj.has("durationLong")) c.durationLong = obj.getBoolean("durationLong");
            else if (obj.has("isLongDuration")) c.durationLong = obj.getBoolean("isLongDuration");
            if (obj.has("gravity")) c.gravity = obj.getInt("gravity");
            if (obj.has("yOffsetDp")) c.yOffsetDp = obj.getInt("yOffsetDp");
            if (obj.has("bgHex")) c.bgHex = obj.getString("bgHex");
            if (obj.has("isGradient")) c.isGradient = obj.getBoolean("isGradient");
            if (obj.has("bgGradientEndHex")) c.bgGradientEndHex = obj.getString("bgGradientEndHex");
            if (obj.has("gradientOrientation")) c.gradientOrientation = obj.getInt("gradientOrientation");
            if (obj.has("textColorHex")) c.textColorHex = obj.getString("textColorHex");
            if (obj.has("titleColorHex")) c.titleColorHex = obj.getString("titleColorHex");
            if (obj.has("borderHex")) {
                c.borderHex = obj.getString("borderHex");
                c.strokeColorHex = c.borderHex;
            } else if (obj.has("strokeColorHex")) {
                c.borderHex = obj.getString("strokeColorHex");
                c.strokeColorHex = c.borderHex;
            }
            if (obj.has("borderWidthDp")) {
                c.borderWidthDp = obj.getInt("borderWidthDp");
                c.strokeWidthDp = c.borderWidthDp;
            } else if (obj.has("strokeWidthDp")) {
                c.borderWidthDp = obj.getInt("strokeWidthDp");
                c.strokeWidthDp = c.borderWidthDp;
            }
            if (obj.has("cornerRadiusDp")) c.cornerRadiusDp = obj.getInt("cornerRadiusDp");
            if (obj.has("paddingHorizontalDp")) c.paddingHorizontalDp = obj.getInt("paddingHorizontalDp");
            if (obj.has("paddingVerticalDp")) c.paddingVerticalDp = obj.getInt("paddingVerticalDp");
            if (obj.has("widthPct")) c.widthPct = obj.getInt("widthPct");
            if (obj.has("elevationDp")) c.elevationDp = obj.getInt("elevationDp");
            if (obj.has("animMode")) c.animMode = obj.getString("animMode");
            if (obj.has("animDurationMs")) c.animDurationMs = obj.getInt("animDurationMs");
            if (obj.has("iconType")) c.iconType = obj.getString("iconType");
            if (obj.has("iconEmoji")) {
                c.iconEmoji = obj.getString("iconEmoji");
                c.symbolIcon = c.iconEmoji;
            } else if (obj.has("symbolIcon")) {
                c.iconEmoji = obj.getString("symbolIcon");
                c.symbolIcon = c.iconEmoji;
            }
            if (obj.has("iconBgHex")) c.iconBgHex = obj.getString("iconBgHex");
            if (obj.has("hasSoundEffect")) c.hasSoundEffect = obj.getBoolean("hasSoundEffect");
            if (obj.has("soundAssetName")) c.soundAssetName = obj.getString("soundAssetName");
            if (obj.has("hasCustomImage")) c.hasCustomImage = obj.getBoolean("hasCustomImage");
            if (obj.has("customImageName")) c.customImageName = obj.getString("customImageName");
            if (obj.has("customImageBase64")) {
                try {
                    c.customImageBytes = android.util.Base64.decode(obj.getString("customImageBase64"), android.util.Base64.NO_WRAP);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        c.isLongDuration = c.durationLong;
        c.isBase64Encoded = c.isBase64;
        c.strokeColorHex = c.borderHex;
        c.strokeWidthDp = c.borderWidthDp;
        c.symbolIcon = c.iconEmoji;
        c.hasBadge = !"NONE".equals(c.iconType);
        return c;
    }
}
