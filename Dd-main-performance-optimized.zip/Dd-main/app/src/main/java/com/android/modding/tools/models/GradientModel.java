package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class GradientModel implements Serializable {
    public static final String TYPE_LINEAR = "linear";
    public static final String TYPE_RADIAL = "radial";
    public static final String TYPE_SWEEP = "sweep";

    private String type = TYPE_LINEAR;
    private String startColor = "#FF00FF";
    private String centerColor = "#0000FF";
    private String endColor = "#00FFFF";
    private boolean useCenterColor = false;
    private int angle = 270; // 0, 45, 90, 135, 180, 225, 270, 315
    private int gradientRadiusDp = 50;
    private float centerX = 0.5f;
    private float centerY = 0.5f;

    public GradientModel() {}

    public String getType() {
        return type != null ? type : TYPE_LINEAR;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStartColor() {
        return startColor != null ? startColor : "#FF00FF";
    }

    public void setStartColor(String startColor) {
        this.startColor = startColor;
    }

    public String getCenterColor() {
        return centerColor != null ? centerColor : "#0000FF";
    }

    public void setCenterColor(String centerColor) {
        this.centerColor = centerColor;
    }

    public String getEndColor() {
        return endColor != null ? endColor : "#00FFFF";
    }

    public void setEndColor(String endColor) {
        this.endColor = endColor;
    }

    public boolean isUseCenterColor() {
        return useCenterColor;
    }

    public void setUseCenterColor(boolean useCenterColor) {
        this.useCenterColor = useCenterColor;
    }

    public int getAngle() {
        return angle;
    }

    public void setAngle(int angle) {
        this.angle = angle;
    }

    /**
     * Android XML gradient angles must be multiples of 45: 0, 45, 90, 135, 180, 225, 270, 315
     */
    public int getNormalizedAngle() {
        int rounded = Math.round(angle / 45.0f) * 45;
        rounded = ((rounded % 360) + 360) % 360;
        return rounded;
    }

    public int getGradientRadiusDp() {
        return gradientRadiusDp;
    }

    public void setGradientRadiusDp(int gradientRadiusDp) {
        this.gradientRadiusDp = Math.max(1, gradientRadiusDp);
    }

    public float getCenterX() {
        return centerX;
    }

    public void setCenterX(float centerX) {
        this.centerX = Math.max(0.0f, Math.min(1.0f, centerX));
    }

    public float getCenterY() {
        return centerY;
    }

    public void setCenterY(float centerY) {
        this.centerY = Math.max(0.0f, Math.min(1.0f, centerY));
    }

    public GradientModel copy() {
        GradientModel copy = new GradientModel();
        copy.type = this.type;
        copy.startColor = this.startColor;
        copy.centerColor = this.centerColor;
        copy.endColor = this.endColor;
        copy.useCenterColor = this.useCenterColor;
        copy.angle = this.angle;
        copy.gradientRadiusDp = this.gradientRadiusDp;
        copy.centerX = this.centerX;
        copy.centerY = this.centerY;
        return copy;
    }
}
