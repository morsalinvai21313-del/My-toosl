package com.android.modding.tools.activities;

import android.view.View;
import com.android.modding.tools.dialogmaker.DialogConfig;

/**
 * Notice Alert Dialog Maker.
 * Designed for app update notices, security advisories, maintenance alerts, and reminder popups.
 */
public class NoticeDialogMakerActivity extends BaseDialogMakerActivity {

    @Override
    protected DialogConfig getInitialConfig() {
        return DialogConfig.createNoticeDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Notice Alert Dialog Maker";
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("⚡ NOTICE ALERT PRESETS");
        }
        if (btnPreset1 != null) {
            btnPreset1.setText("Force Update 🔒");
            btnPreset1.setOnClickListener(v -> applyPreset(createForceUpdatePreset(), "Mandatory Force Update (No Exit)"));
        }
        if (btnPreset2 != null) {
            btnPreset2.setText("Update 🚀");
            btnPreset2.setOnClickListener(v -> applyPreset(createUpdateAvailablePreset(), "App Update"));
        }
        if (btnPreset3 != null) {
            btnPreset3.setText("Maintenance ⚙️");
            btnPreset3.setOnClickListener(v -> applyPreset(createMaintenancePreset(), "System Maintenance"));
        }
        if (btnPreset4 != null) {
            btnPreset4.setText("Security 🚨");
            btnPreset4.setOnClickListener(v -> applyPreset(createCriticalAlertPreset(), "Critical Alert"));
        }
    }

    @Override
    protected void setupCustomMakerOptions() {
        if (layoutProfilePhotoSection != null) layoutProfilePhotoSection.setVisibility(View.GONE);
        if (layoutVectorIconSection != null) layoutVectorIconSection.setVisibility(View.VISIBLE);
        if (layoutNoticeUpdateSection != null) layoutNoticeUpdateSection.setVisibility(View.VISIBLE);
        if (tvEmblemSectionTitle != null) tvEmblemSectionTitle.setText("4. NOTICE BADGE & ALERT EMBLEM");
    }

    private DialogConfig createForceUpdatePreset() {
        DialogConfig c = DialogConfig.createNoticeDefault();
        c.isForceUpdate = true;
        c.cancelable = false;
        c.hasCountdownTimer = true;
        c.countdownSeconds = 15;
        c.noticeBadgeText = "🚨 MANDATORY UPDATE (NO EXIT)";
        c.noticeBadgeBgHex = "#FF1744";
        c.noticeBadgeTextHex = "#FFFFFF";
        c.borderHex = "#FF1744";
        c.hasImage = true;
        c.iconName = "WARNING";
        c.iconResIndex = 6;
        c.titleText = "Update Required Immediately";
        c.titleColorHex = "#FF5252";
        c.subtitleText = "Notice: Exit is Blocked Until Updated";
        c.subtitleColorHex = "#FF8A80";
        c.messageText = "This version of the application is no longer supported. You must install the mandatory update to continue.";
        c.hasDontShowAgain = false;
        c.buttonCount = 1;
        c.btn3Text = "UPDATE APP NOW";
        c.btn3Action = DialogConfig.ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Bounce";
        return c;
    }

    private DialogConfig createCriticalAlertPreset() {
        DialogConfig c = DialogConfig.createNoticeDefault();
        c.noticeBadgeText = "🚨 CRITICAL SECURITY ALERT";
        c.noticeBadgeBgHex = "#FF1744";
        c.noticeBadgeTextHex = "#FFFFFF";
        c.borderHex = "#FF1744";
        c.hasImage = true;
        c.iconName = "WARNING";
        c.iconResIndex = 6;
        c.titleText = "Urgent Patch Required";
        c.titleColorHex = "#FF5252";
        c.subtitleText = "Vulnerability Detected in Build";
        c.subtitleColorHex = "#FF8A80";
        c.messageText = "A critical security patch must be installed immediately to prevent service disruptions.";
        c.hasDontShowAgain = false;
        c.buttonCount = 2;
        c.btn1Text = "Later";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Patch Now";
        c.btn3Action = DialogConfig.ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Bounce";
        return c;
    }

    private DialogConfig createUpdateAvailablePreset() {
        DialogConfig c = DialogConfig.createNoticeDefault();
        c.noticeBadgeText = "🚀 NEW UPDATE AVAILABLE";
        c.noticeBadgeBgHex = "#FFB703";
        c.noticeBadgeTextHex = "#1A1708";
        c.borderHex = "#FFB703";
        c.hasImage = true;
        c.iconName = "BELL";
        c.iconResIndex = 7;
        c.titleText = "Version 3.5 Ready";
        c.titleColorHex = "#FFB703";
        c.subtitleText = "Major Features & Performance Fixes";
        c.subtitleColorHex = "#FFD166";
        c.messageText = "Upgrade to the latest release for improved Dalvik compilation speeds and enhanced Smali generators.";
        c.hasDontShowAgain = true;
        c.dontShowAgainText = "Don't show this update notice again";
        c.buttonCount = 2;
        c.btn1Text = "Remind Later";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Update Now";
        c.btn3Action = DialogConfig.ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Zoom";
        return c;
    }

    private DialogConfig createMaintenancePreset() {
        DialogConfig c = DialogConfig.createNoticeDefault();
        c.noticeBadgeText = "⚙️ SERVER MAINTENANCE";
        c.noticeBadgeBgHex = "#00E5FF";
        c.noticeBadgeTextHex = "#040E17";
        c.borderHex = "#00E5FF";
        c.hasImage = true;
        c.iconName = "SHIELD";
        c.iconResIndex = 0;
        c.titleText = "Scheduled Downtime";
        c.titleColorHex = "#00E5FF";
        c.subtitleText = "Expected Duration: 2 Hours";
        c.subtitleColorHex = "#80EAFF";
        c.messageText = "Our backend database will be undergoing routine upgrades tonight from 02:00 UTC to 04:00 UTC.";
        c.hasDontShowAgain = true;
        c.dontShowAgainText = "I have read and acknowledged this";
        c.buttonCount = 1;
        c.btn3Text = "I Understand";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.openAnimMode = "Slide";
        return c;
    }

    private DialogConfig createChangelogPreset() {
        DialogConfig c = DialogConfig.createNoticeDefault();
        c.noticeBadgeText = "✨ RELEASE ANNOUNCEMENT";
        c.noticeBadgeBgHex = "#00FF88";
        c.noticeBadgeTextHex = "#051A10";
        c.borderHex = "#00FF88";
        c.hasImage = true;
        c.iconName = "STAR";
        c.iconResIndex = 4;
        c.titleText = "What's New in v3.5";
        c.titleColorHex = "#00FF88";
        c.subtitleText = "Zero-XML Engine & Pure DEX";
        c.messageText = "Enjoy brand-new dialog templates, high-speed DEX packaging, and instant 1-line Smali hooks.";
        c.hasDontShowAgain = true;
        c.dontShowAgainText = "Don't show again until next release";
        c.buttonCount = 2;
        c.btn1Text = "Dismiss";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "View Changelog";
        c.btn3Action = DialogConfig.ACTION_OPEN_URL;
        c.btn3Url = "https://t.me/anonymous_modder_king";
        c.openAnimMode = "Hologram";
        return c;
    }
}
