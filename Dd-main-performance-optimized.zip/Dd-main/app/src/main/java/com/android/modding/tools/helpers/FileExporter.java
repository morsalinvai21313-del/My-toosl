package com.android.modding.tools.helpers;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class FileExporter {

    public static class ExportResult {
        public final boolean success;
        public final String filePath;
        public final String message;

        public ExportResult(boolean success, String filePath, String message) {
            this.success = success;
            this.filePath = filePath;
            this.message = message;
        }
    }

    /**
     * Exports XML code to a file in the device's Downloads or Documents directory.
     */
    public static ExportResult exportXmlToFile(Context context, String fileName, String xmlContent) {
        if (fileName == null || fileName.trim().isEmpty()) {
            fileName = "MS MORSALIN_BG.xml";
        }
        if (!fileName.toLowerCase().endsWith(".xml")) {
            fileName += ".xml";
        }

        try {
            byte[] bytes = xmlContent != null ? xmlContent.getBytes(java.nio.charset.StandardCharsets.UTF_8) : new byte[0];
            String guideName = fileName.replace(".xml", "") + "_XML_GUIDE.txt";
            String guideText = GeneratedPackageExporter.buildXmlDrawableGuide(fileName, xmlContent);
            GeneratedPackageExporter.saveSingleFileToDownloads(
                    context, "MorsalinXML", guideName, "text/plain",
                    guideText.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/xml");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MorsalinXML");

                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream os = context.getContentResolver().openOutputStream(uri)) {
                        if (os != null) {
                            os.write(bytes);
                            os.flush();
                            return new ExportResult(true, "Downloads/MorsalinXML/" + fileName,
                                    "Saved to Downloads/MorsalinXML/" + fileName);
                        }
                    }
                }
            }

            // Fallback for older devices or if MediaStore insert fails
            File docsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (docsDir == null) {
                docsDir = context.getFilesDir();
            }
            File file = new File(docsDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(bytes);
                fos.flush();
            }
            return new ExportResult(true, file.getAbsolutePath(), "Saved to " + file.getName());

        } catch (Exception e) {
            return new ExportResult(false, null, "Failed to export: " + e.getMessage());
        }
    }

    /**
     * Exports arbitrary text / Smali code to a file in Downloads/MorsalinSmali.
     */
    public static ExportResult exportText(Context context, String text, String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            fileName = "Morsalin_Export.smali";
        }

        try {
            byte[] bytes = text != null ? text.getBytes(java.nio.charset.StandardCharsets.UTF_8) : new byte[0];
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MorsalinSmali");

                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream os = context.getContentResolver().openOutputStream(uri)) {
                        if (os != null) {
                            os.write(bytes);
                            os.flush();
                            if (context instanceof android.app.Activity) {
                                MorsalinToast.show((android.app.Activity) context, R.drawable.ic_download, "Saved!", "File saved to Downloads/MorsalinSmali/" + fileName);
                            }
                            return new ExportResult(true, "Downloads/MorsalinSmali/" + fileName, "Saved to Downloads/MorsalinSmali/" + fileName);
                        }
                    }
                }
            }

            File dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = context.getFilesDir();
            File file = new File(dir, fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(bytes);
                fos.flush();
            }
            if (context instanceof android.app.Activity) {
                MorsalinToast.show((android.app.Activity) context, R.drawable.ic_download, "Saved!", "File saved to " + file.getName());
            }
            return new ExportResult(true, file.getAbsolutePath(), "Saved to " + file.getName());
        } catch (Exception e) {
            if (context instanceof android.app.Activity) {
                MorsalinToast.show((android.app.Activity) context, R.drawable.ic_download, "Export Error", e.getMessage());
            }
            return new ExportResult(false, null, "Failed to export: " + e.getMessage());
        }
    }
}
