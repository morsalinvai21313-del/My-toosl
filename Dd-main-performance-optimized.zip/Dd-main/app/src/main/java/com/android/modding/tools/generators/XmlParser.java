package com.android.modding.tools.generators;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.graphics.Color;







import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XmlParser {

    public static class ParseResult {
        public String rootTag = "";
        public LayerModel singleLayer = new LayerModel("Imported");
        public List<LayerModel> layerList = new ArrayList<>();
        public Map<String, StateModel> selectorStates = new HashMap<>();
        public boolean success = false;
        public String message = "";
    }

    public static ParseResult parseXml(String xmlString) {
        ParseResult result = new ParseResult();
        if (xmlString == null || xmlString.trim().isEmpty()) {
            result.message = "XML string is empty.";
            return result;
        }

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlString));

            int eventType = parser.getEventType();
            LayerModel currentLayer = null;
            String currentSelectorState = StateModel.STATE_NORMAL;
            int selectorItemDepth = -1;
            int currentDepth = 0;
            InsetsModel currentInsets = null;

            while (eventType != XmlPullParser.END_DOCUMENT) {
                String tagName = parser.getName();

                if (eventType == XmlPullParser.START_TAG) {
                    currentDepth++;
                    if (result.rootTag.isEmpty()) {
                        result.rootTag = tagName;
                    }

                    if ("shape".equals(tagName)) {
                        if (currentLayer == null) {
                            currentLayer = new LayerModel("Layer " + (result.layerList.size() + 1));
                        }
                        String shapeAttr = getAttribute(parser, "shape");
                        if (shapeAttr != null) {
                            currentLayer.setShapeType(shapeAttr);
                        }
                    } else if ("solid".equals(tagName)) {
                        if (currentLayer != null) {
                            String color = getAttribute(parser, "color");
                            if (color != null) {
                                currentLayer.setSolidColor(color);
                                currentLayer.setGradient(false);
                            }
                        }
                    } else if ("gradient".equals(tagName)) {
                        if (currentLayer != null) {
                            currentLayer.setGradient(true);
                            GradientModel g = currentLayer.getGradient();
                            String type = getAttribute(parser, "type");
                            if (type != null) g.setType(type);
                            String start = getAttribute(parser, "startColor");
                            if (start != null) g.setStartColor(start);
                            String center = getAttribute(parser, "centerColor");
                            if (center != null) {
                                g.setCenterColor(center);
                                g.setUseCenterColor(true);
                            }
                            String end = getAttribute(parser, "endColor");
                            if (end != null) g.setEndColor(end);
                            String angle = getAttribute(parser, "angle");
                            if (angle != null) {
                                try {
                                    g.setAngle(Integer.parseInt(angle.replace("deg", "").trim()));
                                } catch (Exception ignored) {}
                            }
                            String radius = getAttribute(parser, "gradientRadius");
                            if (radius != null) {
                                try {
                                    g.setGradientRadiusDp(Integer.parseInt(radius.replaceAll("[^0-9]", "")));
                                } catch (Exception ignored) {}
                            }
                            String cx = getAttribute(parser, "centerX");
                            if (cx != null) {
                                try {
                                    g.setCenterX(Float.parseFloat(cx));
                                } catch (Exception ignored) {}
                            }
                            String cy = getAttribute(parser, "centerY");
                            if (cy != null) {
                                try {
                                    g.setCenterY(Float.parseFloat(cy));
                                } catch (Exception ignored) {}
                            }
                        }
                    } else if ("corners".equals(tagName)) {
                        if (currentLayer != null) {
                            CornersModel c = currentLayer.getCorners();
                            String radius = getAttribute(parser, "radius");
                            if (radius != null) {
                                int r = parseDp(radius);
                                c.setTopLeftDp(r);
                                c.setTopRightDp(r);
                                c.setBottomLeftDp(r);
                                c.setBottomRightDp(r);
                                c.setLinked(true);
                            } else {
                                String tl = getAttribute(parser, "topLeftRadius");
                                if (tl != null) c.setTopLeftDp(parseDp(tl));
                                String tr = getAttribute(parser, "topRightRadius");
                                if (tr != null) c.setTopRightDp(parseDp(tr));
                                String bl = getAttribute(parser, "bottomLeftRadius");
                                if (bl != null) c.setBottomLeftDp(parseDp(bl));
                                String br = getAttribute(parser, "bottomRightRadius");
                                if (br != null) c.setBottomRightDp(parseDp(br));
                            }
                        }
                    } else if ("stroke".equals(tagName)) {
                        if (currentLayer != null) {
                            StrokeModel s = currentLayer.getStroke();
                            String color = getAttribute(parser, "color");
                            if (color != null) s.setColor(color);
                            String width = getAttribute(parser, "width");
                            if (width != null) s.setWidthDp(parseDp(width));
                            String dashW = getAttribute(parser, "dashWidth");
                            if (dashW != null) s.setDashWidthDp(parseDp(dashW));
                            String dashG = getAttribute(parser, "dashGap");
                            if (dashG != null) s.setDashGapDp(parseDp(dashG));
                        }
                    } else if ("item".equals(tagName)) {
                        String pressed = getAttribute(parser, "state_pressed");
                        String checked = getAttribute(parser, "state_checked");
                        String focused = getAttribute(parser, "state_focused");
                        String selected = getAttribute(parser, "state_selected");

                        if ("true".equalsIgnoreCase(pressed)) {
                            currentSelectorState = StateModel.STATE_PRESSED;
                            selectorItemDepth = currentDepth;
                        } else if ("true".equalsIgnoreCase(checked)) {
                            currentSelectorState = StateModel.STATE_CHECKED;
                            selectorItemDepth = currentDepth;
                        } else if ("true".equalsIgnoreCase(focused)) {
                            currentSelectorState = StateModel.STATE_FOCUSED;
                            selectorItemDepth = currentDepth;
                        } else if ("true".equalsIgnoreCase(selected)) {
                            currentSelectorState = StateModel.STATE_SELECTED;
                            selectorItemDepth = currentDepth;
                        } else if (pressed == null && checked == null && focused == null && selected == null && selectorItemDepth == -1) {
                            currentSelectorState = StateModel.STATE_NORMAL;
                            selectorItemDepth = currentDepth;
                        }

                        // Check insets
                        String left = getAttribute(parser, "left");
                        String top = getAttribute(parser, "top");
                        String right = getAttribute(parser, "right");
                        String bottom = getAttribute(parser, "bottom");
                        if (left != null || top != null || right != null || bottom != null) {
                            currentInsets = new InsetsModel(
                                    left != null ? parseDp(left) : 0,
                                    top != null ? parseDp(top) : 0,
                                    right != null ? parseDp(right) : 0,
                                    bottom != null ? parseDp(bottom) : 0
                            );
                        }
                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if ("shape".equals(tagName)) {
                        if (currentLayer != null) {
                            if (currentInsets != null) {
                                currentLayer.setInsets(currentInsets);
                                currentInsets = null;
                            }
                            result.singleLayer = currentLayer.copy();
                            result.layerList.add(currentLayer.copy());

                            StateModel state = result.selectorStates.get(currentSelectorState);
                            if (state == null) {
                                state = new StateModel(currentSelectorState);
                                state.setActive(true);
                                state.getLayers().clear();
                                result.selectorStates.put(currentSelectorState, state);
                            }
                            state.getLayers().add(currentLayer);
                            currentLayer = null;
                        }
                    } else if ("item".equals(tagName)) {
                        if (currentDepth == selectorItemDepth) {
                            currentSelectorState = StateModel.STATE_NORMAL;
                            selectorItemDepth = -1;
                        }
                        currentInsets = null;
                    }
                    currentDepth--;
                }

                eventType = parser.next();
            }

            result.success = true;
            result.message = "Parsed successfully! Detected: <" + result.rootTag + "> with "
                    + result.layerList.size() + " layer(s).";
        } catch (Exception e) {
            result.success = false;
            result.message = "Failed to parse XML: " + e.getMessage();
        }

        return result;
    }

    private static String getAttribute(XmlPullParser parser, String name) {
        String val = parser.getAttributeValue("http://schemas.android.com/apk/res/android", name);
        if (val == null) {
            val = parser.getAttributeValue(null, name);
        }
        if (val == null) {
            val = parser.getAttributeValue(null, "android:" + name);
        }
        return val;
    }

    private static int parseDp(String val) {
        if (val == null) return 0;
        try {
            return Integer.parseInt(val.replaceAll("[^0-9-]", ""));
        } catch (Exception e) {
            return 0;
        }
    }
}
