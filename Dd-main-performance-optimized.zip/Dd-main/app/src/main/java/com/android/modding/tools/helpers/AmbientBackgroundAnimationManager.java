package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Manages Ambient Live Background visual effects across the entire app.
 * Provides Starfield, Matrix Rain, Quantum Orbs, Cyber Embers, Frosted Snow, and Aurora Wave.
 */
public class AmbientBackgroundAnimationManager {

    private static final String PREF_NAME = "morsalin_settings";
    public static final String KEY_AMBIENT_BG_STYLE = "key_ambient_bg_style";

    public static final int STYLE_NONE = 0;
    public static final int STYLE_CYBER_STARFIELD = 1;
    public static final int STYLE_MATRIX_RAIN = 2;
    public static final int STYLE_QUANTUM_ORBS = 3;
    public static final int STYLE_CYBER_EMBERS = 4;
    public static final int STYLE_FROZEN_SNOW = 5;
    public static final int STYLE_AURORA_WAVE = 6;
    public static final int STYLE_HYPERSPACE_WARP = 7;
    public static final int STYLE_HOLO_HEX_GRID = 8;
    public static final int STYLE_CELESTIAL_GOLD = 9;
    public static final int STYLE_PLASMA_STORM = 10;
    public static final int STYLE_SAKURA_BREEZE = 11;
    public static final int STYLE_SYNTHWAVE_GRID = 12;

    public static final String[] STYLE_NAMES = {
            "None (Normal Background)",
            "Cyber Starfield",
            "Matrix Digital Rain",
            "Floating Quantum Orbs",
            "Cyberpunk Embers",
            "Frosted Snow Crystals",
            "Digital Aurora Wave",
            "Hyperspace Warp Streaks",
            "Holographic Hex Matrix",
            "Golden Celestial Dust",
            "Electric Plasma Storm",
            "Sakura Blossom Breeze",
            "Synthwave Horizon Grid"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Standard background without animated particles",
            "Subtle floating neon stars with soft glow",
            "Downward falling matrix code stream",
            "Smooth ambient quantum orbs drifting across screen",
            "Warm glowing embers floating upwards",
            "Delicate frozen snow crystals falling gently",
            "Digital chromatic aurora wave across the top",
            "Cosmic hyperspace speed streaks with luminous trails",
            "Cyan and violet cybernetic tech nodes drifting in space",
            "Sparkling celestial golden dust dancing in the air",
            "Electrified plasma violet and cyan lightning sparks",
            "Gentle floating sakura blossom petals in wind",
            "Retro synthwave neon pink & cyan grid shimmer"
    };

    private static int cachedStyle = -1;

    public static int getSavedStyle(Context context) {
        if (cachedStyle >= 0) return cachedStyle;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cachedStyle = sp.getInt(KEY_AMBIENT_BG_STYLE, STYLE_NONE);
        return cachedStyle;
    }

    public static void setSavedStyle(Context context, int style) {
        cachedStyle = style;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_AMBIENT_BG_STYLE, style).apply();
    }

    public static boolean isEnabled(Context context) {
        return getSavedStyle(context) != STYLE_NONE;
    }
}
