package com.android.modding.tools.activities;

import com.android.modding.tools.toastmaker.ToastConfig;

/**
 * Animated Toast Maker.
 * Focused on advanced dynamic motion physics (Bounce, Cyber Glitch, 3D Flip, Warp)
 * compiled into zero-XML Dalvik classes.dex executables and packages.
 */
public class AnimatedToastActivity extends BaseToastMakerActivity {

    @Override
    protected ToastConfig getInitialConfig() {
        return ToastConfig.createAnimatedDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Animated Toast Maker";
    }

    @Override
    protected boolean showGalleryPickerSection() {
        return false;
    }

    @Override
    protected boolean showEmblemSection() {
        return false;
    }

    @Override
    protected boolean showTitleInput() {
        return false;
    }

    @Override
    protected boolean showAnimationSection() {
        return true;
    }

    @Override
    protected boolean showBase64Section() {
        return false;
    }

    @Override
    protected boolean showGradientSection() {
        return true;
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("🎬 DYNAMIC MOTION QUICK PRESETS");
        }

        if (btnPreset1 != null) {
            btnPreset1.setText("Super Bounce");
            btnPreset1.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createAnimatedDefault();
                p.toastName = "Anim_Super_Bounce";
                p.messageText = "Dynamic Elastic Physics Triggered!";
                p.bgHex = "#16213E";
                p.borderHex = "#00FFF5";
                p.animMode = "Bounce";
                p.animDurationMs = 650;
                applyPreset(p, "Super Bounce");
            });
        }

        if (btnPreset2 != null) {
            btnPreset2.setText("Cyber Glitch");
            btnPreset2.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createAnimatedDefault();
                p.toastName = "Anim_Cyber_Glitch";
                p.messageText = "System Overclock Mode Active [0x7FF]";
                p.bgHex = "#0F0F1B";
                p.borderHex = "#E94560";
                p.animMode = "Cyber Glitch";
                p.animDurationMs = 500;
                applyPreset(p, "Cyber Glitch");
            });
        }

        if (btnPreset3 != null) {
            btnPreset3.setText("Origami Warp");
            btnPreset3.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createAnimatedDefault();
                p.toastName = "Anim_Origami_Warp";
                p.messageText = "Spatial Folding Dimensional Alert";
                p.bgHex = "#2B0938";
                p.borderHex = "#FF007F";
                p.animMode = "Origami";
                p.animDurationMs = 600;
                applyPreset(p, "Origami Warp");
            });
        }

        if (btnPreset4 != null) {
            btnPreset4.setText("Vortex Spin");
            btnPreset4.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createAnimatedDefault();
                p.toastName = "Anim_Vortex_Spin";
                p.messageText = "High-Velocity Acceleration Ready";
                p.bgHex = "#001E28";
                p.borderHex = "#00E5FF";
                p.animMode = "Vortex";
                p.animDurationMs = 550;
                applyPreset(p, "Vortex Spin");
            });
        }
    }
}
