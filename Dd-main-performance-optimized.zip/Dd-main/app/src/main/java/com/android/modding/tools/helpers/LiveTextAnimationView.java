package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

/**
 * Custom live 60fps canvas renderer for Text Animation Maker.
 * Supports 16 effects: Typing, Letter-by-letter, Fade, Wave, Bounce, Shake,
 * Flicker, Glow, Neon, RGB, Gradient, Zoom, Rotate, Slide, Character Reveal, Word Reveal.
 */
public class LiveTextAnimationView extends View {

    private String text = "MORSALIN XML CREATOR";
    private String effectType = "Typing";
    private float textSizeSp = 24f;
    private int primaryColor = Color.parseColor("#00E5FF");
    private int secondaryColor = Color.parseColor("#FF007F");
    private int strokeColor = Color.parseColor("#FFFFFF");
    private int glowColor = Color.parseColor("#00FF88");
    private float strokeWidthPx = 0f;
    private float glowRadiusPx = 12f;
    private boolean useGradient = true;
    private int textStyle = Typeface.BOLD;
    private int durationMs = 1600;

    private final TextPaint fillPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint strokePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix gradientMatrix = new Matrix();
    private LinearGradient linearGradient;

    private ValueAnimator animator;
    private float progress = 0f; // 0..1 repeating

    public LiveTextAnimationView(Context context) {
        super(context);
        init();
    }

    public LiveTextAnimationView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LiveTextAnimationView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        startAnimationLoop();
    }

    public void configure(
            String text,
            String effectType,
            float textSizeSp,
            int primaryColor,
            int secondaryColor,
            int strokeColor,
            int glowColor,
            float strokeWidthPx,
            float glowRadiusPx,
            boolean useGradient,
            int textStyle,
            int durationMs
    ) {
        this.text = (text == null || text.isEmpty()) ? "MORSALIN XML" : text;
        this.effectType = effectType != null ? effectType : "Typing";
        this.textSizeSp = textSizeSp;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
        this.strokeColor = strokeColor;
        this.glowColor = glowColor;
        this.strokeWidthPx = strokeWidthPx;
        this.glowRadiusPx = glowRadiusPx;
        this.useGradient = useGradient;
        this.textStyle = textStyle;
        this.durationMs = Math.max(300, durationMs);
        linearGradient = null;
        if (animator != null) {
            animator.setDuration(this.durationMs);
        }
        invalidate();
    }

    public void startAnimationLoop() {
        if (animator != null) {
            animator.cancel();
        }
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(durationMs);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.RESTART);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public void pauseOrResume() {
        if (animator == null) {
            startAnimationLoop();
            return;
        }
        if (animator.isPaused()) {
            animator.resume();
        } else if (animator.isRunning()) {
            animator.pause();
        } else {
            animator.start();
        }
    }

    public boolean isPausedState() {
        return animator != null && animator.isPaused();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) {
            animator.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().scaledDensity;
        float pxSize = textSizeSp * density;

        Typeface tf = MorsalinViewInflater.getAppTypeface(getContext(), (textStyle & Typeface.BOLD) != 0);
        Typeface styledTf = Typeface.create(tf, textStyle);

        fillPaint.setTypeface(styledTf);
        fillPaint.setTextSize(pxSize);
        fillPaint.setStyle(Paint.Style.FILL);

        strokePaint.setTypeface(styledTf);
        strokePaint.setTextSize(pxSize);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(strokeWidthPx);
        strokePaint.setColor(strokeColor);

        // Setup color / shader / glow
        if ("RGB".equals(effectType)) {
            float hue = (progress * 360f) % 360f;
            int rgbColor = Color.HSVToColor(new float[]{hue, 0.9f, 1f});
            fillPaint.setShader(null);
            fillPaint.setColor(rgbColor);
        } else if (useGradient || "Gradient".equals(effectType)) {
            if (linearGradient == null) {
                linearGradient = new LinearGradient(0, 0, w * 0.6f, 0,
                        new int[]{primaryColor, secondaryColor, primaryColor},
                        null, Shader.TileMode.MIRROR);
            }
            gradientMatrix.reset();
            gradientMatrix.setTranslate(w * progress * 1.5f, 0);
            linearGradient.setLocalMatrix(gradientMatrix);
            fillPaint.setShader(linearGradient);
            fillPaint.setColor(primaryColor);
        } else {
            fillPaint.setShader(null);
            fillPaint.setColor(primaryColor);
        }

        float activeGlow = glowRadiusPx;
        if ("Glow".equals(effectType) || "Neon".equals(effectType)) {
            float pulse = (float) (0.5 + 0.5 * Math.sin(progress * Math.PI * 2));
            activeGlow = Math.max(8f, glowRadiusPx) * (0.45f + 0.85f * pulse);
        }
        if (activeGlow > 0.5f) {
            fillPaint.setShadowLayer(activeGlow, 0f, 0f, "Neon".equals(effectType) ? primaryColor : glowColor);
        } else {
            fillPaint.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT);
        }

        // Determine displayed string or per-character drawing
        String renderText = text;
        if ("Typing".equals(effectType)) {
            int count = Math.max(1, Math.round(text.length() * Math.min(1f, progress * 1.18f)));
            renderText = text.substring(0, Math.min(text.length(), count)) + (progress < 0.9f ? "▌" : "");
        } else if ("Word Reveal".equals(effectType)) {
            String[] words = text.split("\\s+");
            int showWords = Math.max(1, Math.round(words.length * Math.min(1f, progress * 1.2f)));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(words.length, showWords); i++) {
                if (i > 0) sb.append(" ");
                sb.append(words[i]);
            }
            renderText = sb.toString();
        }

        Paint.FontMetrics fm = fillPaint.getFontMetrics();
        float baseCenterY = (h / 2f) - ((fm.descent + fm.ascent) / 2f);

        if ("Wave".equals(effectType) || "Bounce".equals(effectType)
                || "Letter-by-letter".equals(effectType) || "Character Reveal".equals(effectType)) {
            drawPerCharacterEffect(canvas, renderText, w, baseCenterY);
            return;
        }

        canvas.save();
        float centerX = w / 2f;
        float centerY = h / 2f;

        if ("Fade".equals(effectType)) {
            int alpha = (int) (55 + 200 * (0.5 + 0.5 * Math.sin(progress * Math.PI * 2)));
            fillPaint.setAlpha(alpha);
            strokePaint.setAlpha(alpha);
        } else if ("Flicker".equals(effectType) || "Neon".equals(effectType)) {
            boolean dip = (progress > 0.18f && progress < 0.22f) || (progress > 0.62f && progress < 0.65f);
            int alpha = dip ? 75 : 255;
            fillPaint.setAlpha(alpha);
            strokePaint.setAlpha(alpha);
        } else if ("Shake".equals(effectType)) {
            float dx = (float) (Math.sin(progress * Math.PI * 12) * 14f);
            canvas.translate(dx, 0f);
        } else if ("Zoom".equals(effectType)) {
            float s = (float) (0.75f + 0.35f * Math.sin(progress * Math.PI * 2));
            canvas.scale(s, s, centerX, centerY);
        } else if ("Rotate".equals(effectType)) {
            float deg = (float) (Math.sin(progress * Math.PI * 2) * 14f);
            canvas.rotate(deg, centerX, centerY);
        } else if ("Slide".equals(effectType)) {
            float slideX = (1f - Math.min(1f, progress * 1.4f)) * (-w * 0.45f);
            canvas.translate(slideX, 0f);
        }

        float textWidth = fillPaint.measureText(renderText);
        float startX = (w - textWidth) / 2f;
        if (strokeWidthPx > 0.5f) {
            canvas.drawText(renderText, startX, baseCenterY, strokePaint);
        }
        canvas.drawText(renderText, startX, baseCenterY, fillPaint);
        canvas.restore();
    }

    private void drawPerCharacterEffect(Canvas canvas, String str, int w, float baseCenterY) {
        float totalW = fillPaint.measureText(str);
        float x = (w - totalW) / 2f;
        int len = str.length();

        for (int i = 0; i < len; i++) {
            String ch = String.valueOf(str.charAt(i));
            float charW = fillPaint.measureText(ch);
            float offsetY = 0f;
            int alpha = 255;
            float scale = 1f;

            if ("Wave".equals(effectType)) {
                offsetY = (float) (Math.sin((progress * Math.PI * 2) + (i * 0.55f)) * 16f);
            } else if ("Bounce".equals(effectType)) {
                offsetY = (float) (-Math.abs(Math.sin((progress * Math.PI * 2) + (i * 0.4f))) * 22f);
            } else if ("Letter-by-letter".equals(effectType)) {
                float charProg = (progress * 1.35f) - (i / (float) Math.max(1, len));
                if (charProg < 0f) {
                    alpha = 0;
                    offsetY = 20f;
                } else if (charProg < 0.25f) {
                    float t = charProg / 0.25f;
                    alpha = (int) (255 * t);
                    offsetY = (1f - t) * 20f;
                }
            } else if ("Character Reveal".equals(effectType)) {
                float charProg = (progress * 1.35f) - (i / (float) Math.max(1, len));
                if (charProg < 0f) {
                    alpha = 0;
                    scale = 0.2f;
                } else if (charProg < 0.25f) {
                    float t = charProg / 0.25f;
                    alpha = (int) (255 * t);
                    scale = 0.2f + 0.8f * t;
                }
            }

            fillPaint.setAlpha(alpha);
            strokePaint.setAlpha(alpha);

            canvas.save();
            if (scale != 1f) {
                canvas.scale(scale, scale, x + charW / 2f, baseCenterY);
            }
            if (strokeWidthPx > 0.5f && alpha > 0) {
                canvas.drawText(ch, x, baseCenterY + offsetY, strokePaint);
            }
            if (alpha > 0) {
                canvas.drawText(ch, x, baseCenterY + offsetY, fillPaint);
            }
            canvas.restore();
            x += charW;
        }
        fillPaint.setAlpha(255);
        strokePaint.setAlpha(255);
    }
}
