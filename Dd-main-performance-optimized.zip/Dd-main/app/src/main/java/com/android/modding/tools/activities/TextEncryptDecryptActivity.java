package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class TextEncryptDecryptActivity extends AppCompatActivity {

    private static final int ALGO_AES = 0;
    private static final int ALGO_BASE64 = 1;
    private static final int ALGO_HEX = 2;
    private static final int ALGO_XOR = 3;

    private int currentAlgo = ALGO_AES;

    private EditText etInput;
    private EditText etKey;
    private Button btnAlgoAes, btnAlgoBase64, btnAlgoHex, btnAlgoXor;

    private View cardResult;
    private TextView tvResultBadge;
    private TextView tvResultStats;
    private EditText etOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_encrypt_decrypt);

        GlobalTouchParticleManager.attach(this);
        initViews();
        updateAlgoButtons();
    }

    private void initViews() {
        findViewById(R.id.btn_ted_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_ted_reset).setOnClickListener(v -> clearAll());

        etInput = findViewById(R.id.et_ted_input);
        etKey = findViewById(R.id.et_ted_key);

        btnAlgoAes = findViewById(R.id.btn_algo_aes);
        btnAlgoBase64 = findViewById(R.id.btn_algo_base64);
        btnAlgoHex = findViewById(R.id.btn_algo_hex);
        btnAlgoXor = findViewById(R.id.btn_algo_xor);

        btnAlgoAes.setOnClickListener(v -> { currentAlgo = ALGO_AES; updateAlgoButtons(); });
        btnAlgoBase64.setOnClickListener(v -> { currentAlgo = ALGO_BASE64; updateAlgoButtons(); });
        btnAlgoHex.setOnClickListener(v -> { currentAlgo = ALGO_HEX; updateAlgoButtons(); });
        btnAlgoXor.setOnClickListener(v -> { currentAlgo = ALGO_XOR; updateAlgoButtons(); });

        findViewById(R.id.btn_ted_encrypt).setOnClickListener(v -> processCrypto(true));
        findViewById(R.id.btn_ted_decrypt).setOnClickListener(v -> processCrypto(false));

        Button btnSample = findViewById(R.id.btn_ted_sample_text);
        if (btnSample != null) {
            btnSample.setOnClickListener(v -> loadSampleText());
        }

        cardResult = findViewById(R.id.card_ted_result);
        tvResultBadge = findViewById(R.id.tv_ted_result_badge);
        tvResultStats = findViewById(R.id.tv_ted_result_stats);
        etOutput = findViewById(R.id.et_ted_output);

        findViewById(R.id.btn_ted_copy).setOnClickListener(v -> copyResult());
        findViewById(R.id.btn_ted_share).setOnClickListener(v -> shareResult());
        findViewById(R.id.btn_ted_save).setOnClickListener(v -> saveResult());
    }

    private void updateAlgoButtons() {
        styleAlgoBtn(btnAlgoAes, currentAlgo == ALGO_AES);
        styleAlgoBtn(btnAlgoBase64, currentAlgo == ALGO_BASE64);
        styleAlgoBtn(btnAlgoHex, currentAlgo == ALGO_HEX);
        styleAlgoBtn(btnAlgoXor, currentAlgo == ALGO_XOR);
    }

    private void styleAlgoBtn(Button btn, boolean selected) {
        if (btn == null) return;
        btn.setBackgroundResource(R.drawable.morsalin_button_bg);
        if (selected) {
            btn.setTextColor(Color.parseColor("#00E5FF"));
            btn.setAlpha(1.0f);
        } else {
            btn.setTextColor(Color.WHITE);
            btn.setAlpha(0.65f);
        }
    }

    private void processCrypto(boolean encrypt) {
        String text = etInput.getText().toString();
        if (text.isEmpty()) {
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Empty Input", "Please enter text first.");
            return;
        }

        String key = etKey.getText().toString();
        if (key.isEmpty()) key = "Morsalin2026";

        try {
            String result;
            String algoName;

            switch (currentAlgo) {
                case ALGO_AES:
                    algoName = "AES-256";
                    result = encrypt ? encryptAes(text, key) : decryptAes(text, key);
                    break;
                case ALGO_BASE64:
                    algoName = "Base64";
                    result = encrypt ? Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP)
                            : new String(Base64.decode(text.trim(), Base64.DEFAULT), StandardCharsets.UTF_8);
                    break;
                case ALGO_HEX:
                    algoName = "Hex";
                    result = encrypt ? bytesToHex(text.getBytes(StandardCharsets.UTF_8))
                            : new String(hexToBytes(text.trim()), StandardCharsets.UTF_8);
                    break;
                case ALGO_XOR:
                default:
                    algoName = "XOR";
                    result = xorCipher(text, key);
                    break;
            }

            cardResult.setVisibility(View.VISIBLE);
            tvResultBadge.setText(encrypt ? "RESULT: ENCRYPTED" : "RESULT: DECRYPTED");
            tvResultBadge.setTextColor(Color.parseColor(encrypt ? "#69F0AE" : "#00E5FF"));
            tvResultStats.setText(algoName + " • " + result.length() + " chars");
            etOutput.setText(result);

            MorsalinToast.show(this, R.drawable.ic_code_convert,
                    encrypt ? "Encrypted Successfully!" : "Decrypted Successfully!",
                    algoName + " processing completed.");

        } catch (Exception e) {
            String errorMsg = e.getMessage();
            if (errorMsg != null && (errorMsg.contains("WRONG_FINAL_BLOCK_LENGTH") || errorMsg.contains("bad padding") || errorMsg.contains("Pad block corrupted"))) {
                errorMsg = "Incorrect security key or corrupt encrypted payload.";
            } else if (errorMsg != null && errorMsg.contains("bad base-64")) {
                errorMsg = "Input is not valid Base64 encoded text.";
            } else if (errorMsg == null || errorMsg.isEmpty()) {
                errorMsg = "Check passphrase key & matching algorithm.";
            }
            MorsalinToast.show(this, R.drawable.ic_refresh_reset,
                    (encrypt ? "Encryption Failed" : "Decryption Failed"), errorMsg);
        }
    }

    private void loadSampleText() {
        if (etInput == null) return;
        String sample = "Hello World! This is a confidential security message created with Morsalin XML Creator.";
        etInput.setText(sample);
        if (etKey != null && etKey.getText().toString().isEmpty()) {
            etKey.setText("Morsalin2026");
        }
        MorsalinToast.show(this, R.drawable.ic_cat_layout, "Sample Loaded", "Sample text ready to encrypt or test!");
    }

    private String encryptAes(String plainText, String keyStr) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = sha.digest(keyStr.getBytes(StandardCharsets.UTF_8));
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
        byte[] cipherBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        byte[] combined = new byte[iv.length + cipherBytes.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherBytes, 0, combined, iv.length, cipherBytes.length);

        return Base64.encodeToString(combined, Base64.NO_WRAP);
    }

    private String decryptAes(String cipherText, String keyStr) throws Exception {
        byte[] combined = Base64.decode(cipherText.trim(), Base64.DEFAULT);
        if (combined.length < 17) throw new IllegalArgumentException("Invalid encrypted payload.");

        byte[] iv = Arrays.copyOfRange(combined, 0, 16);
        byte[] cipherBytes = Arrays.copyOfRange(combined, 16, combined.length);

        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = sha.digest(keyStr.getBytes(StandardCharsets.UTF_8));
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
        byte[] plainBytes = cipher.doFinal(cipherBytes);

        return new String(plainBytes, StandardCharsets.UTF_8);
    }

    private String xorCipher(String text, String key) {
        StringBuilder sb = new StringBuilder();
        byte[] keyBytes = key.getBytes(StandardCharsets.UTF_8);
        byte[] textBytes = text.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < textBytes.length; i++) {
            sb.append((char) (textBytes[i] ^ keyBytes[i % keyBytes.length]));
        }
        return sb.toString();
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private byte[] hexToBytes(String hex) {
        String clean = hex.replaceAll("\\s+", "");
        int len = clean.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(clean.charAt(i), 16) << 4)
                    + Character.digit(clean.charAt(i + 1), 16));
        }
        return data;
    }

    private void copyResult() {
        String out = etOutput.getText().toString();
        if (out.isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("crypto_result", out));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied", "Result copied to clipboard!");
        }
    }

    private void shareResult() {
        String out = etOutput.getText().toString();
        if (out.isEmpty()) return;
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, out);
        startActivity(Intent.createChooser(intent, "Share Result"));
    }

    private void saveResult() {
        String out = etOutput.getText().toString();
        if (out.isEmpty()) return;
        String fileName = "Crypto_" + System.currentTimeMillis() + ".txt";
        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/Encrypted", fileName, "text/plain", out.getBytes(StandardCharsets.UTF_8));
        MorsalinToast.show(this, R.drawable.ic_download,
                res.success ? "File Saved" : "Save Warning", res.message);
    }

    private void clearAll() {
        etInput.setText("");
        etOutput.setText("");
        cardResult.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
