package com.android.modding.tools.helpers;

import com.android.modding.tools.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TransitionAnimationManager {

    private static final String PREF_NAME = "morsalin_anim_prefs";
    private static final String KEY_SELECTED_ANIM = "selected_anim_id";
    private static final String KEY_SHUFFLE_MODE = "transition_shuffle_mode"; // 0=Off, 1=All, 2=Cyber/Cinematic
    private static final String KEY_CUSTOM_TRANSITIONS = "custom_transitions_json";

    public static final String ANIM_NONE = "anim_none";
    public static final int SHUFFLE_OFF = 0;
    public static final int SHUFFLE_ALL = 1;
    public static final int SHUFFLE_CYBER_CINEMA = 2;

    public static final String CAT_CLASSIC = "CLASSIC";
    public static final String CAT_CINEMATIC = "CINEMATIC";
    public static final String CAT_HACKING = "HACKING";
    public static final String CAT_CUSTOM = "CUSTOM";

    private static final Random RANDOM = new Random();
    // Cache custom transition JSON parsing; screen navigation can resolve transitions frequently.
    private static volatile String cachedCustomTransitionsRaw;
    private static volatile List<AnimItem> cachedCustomTransitions = new ArrayList<>();

    public static class AnimItem {
        public final String id;
        public final String name;
        public final String description;
        public final String category;
        public final int enterAnim;
        public final int exitAnim;
        public final int popEnterAnim;
        public final int popExitAnim;
        public final boolean isCustom;

        public AnimItem(String id, String name, String description,
                        int enterAnim, int exitAnim, int popEnterAnim, int popExitAnim) {
            this(id, name, description, CAT_CLASSIC, enterAnim, exitAnim, popEnterAnim, popExitAnim, false);
        }

        public AnimItem(String id, String name, String description, String category,
                        int enterAnim, int exitAnim, int popEnterAnim, int popExitAnim, boolean isCustom) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.category = category;
            this.enterAnim = enterAnim;
            this.exitAnim = exitAnim;
            this.popEnterAnim = popEnterAnim;
            this.popExitAnim = popExitAnim;
            this.isCustom = isCustom;
        }
    }

    private static final List<AnimItem> BUILTIN_ANIM_LIST = new ArrayList<>();

    static {
        BUILTIN_ANIM_LIST.add(new AnimItem(
                ANIM_NONE,
                "0. None (Disabled / Normal)",
                "Standard instant transition without animations",
                CAT_CLASSIC,
                0, 0, 0, 0,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_slide_horizontal",
                "1. Slide Horizontal (Classic)",
                "Smooth glide from right with slide back to left",
                CAT_CLASSIC,
                R.anim.slide_in_right, R.anim.slide_out_left,
                R.anim.slide_in_left, R.anim.slide_out_right,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_slide_vertical",
                "2. Slide Vertical (Modern Rise)",
                "Rising bottom sheet feel with smooth descent",
                CAT_CLASSIC,
                R.anim.anim_slide_up_in, R.anim.anim_slide_up_out,
                R.anim.anim_slide_down_in, R.anim.anim_slide_down_out,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_zoom_fade",
                "3. Fluid Zoom & Fade",
                "Cinematic scale-in with soft alpha transition",
                CAT_CINEMATIC,
                R.anim.anim_zoom_in, R.anim.anim_zoom_out,
                R.anim.anim_zoom_back_in, R.anim.anim_zoom_back_out,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_bounce_pop",
                "4. Bounce & Pop (Playful)",
                "Bouncy spring pop effect with overshoot curve",
                CAT_CLASSIC,
                R.anim.anim_bounce_enter, R.anim.anim_bounce_exit,
                R.anim.anim_bounce_back_enter, R.anim.anim_bounce_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_flip_card",
                "5. 3D Card Flip Horizontal",
                "Futuristic 3D axis card rotation transition",
                CAT_CINEMATIC,
                R.anim.anim_flip_enter, R.anim.anim_flip_exit,
                R.anim.anim_flip_back_enter, R.anim.anim_flip_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_diagonal",
                "6. Diagonal Glide",
                "Dynamic corner-to-corner angled sweep",
                CAT_CLASSIC,
                R.anim.anim_diag_enter, R.anim.anim_diag_exit,
                R.anim.anim_diag_back_enter, R.anim.anim_diag_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_expand_center",
                "7. Elastic Center Expand",
                "Scales smoothly from the focal center outward",
                CAT_CLASSIC,
                R.anim.anim_expand_enter, R.anim.anim_expand_exit,
                R.anim.anim_expand_back_enter, R.anim.anim_expand_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_rotate_fall",
                "8. Rotate & Cascade",
                "Curved pivot tilt rotation with subtle perspective",
                CAT_CINEMATIC,
                R.anim.anim_rotate_enter, R.anim.anim_rotate_exit,
                R.anim.anim_rotate_back_enter, R.anim.anim_rotate_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_shutter",
                "9. Shutter Split",
                "Vertical aperture slit expansion reveal",
                CAT_HACKING,
                R.anim.anim_shutter_enter, R.anim.anim_shutter_exit,
                R.anim.anim_shutter_back_enter, R.anim.anim_shutter_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_cinema_depth",
                "10. Cinema Depth Parallax",
                "Layered depth parallax with multi-scale depth",
                CAT_CINEMATIC,
                R.anim.anim_cinema_enter, R.anim.anim_cinema_exit,
                R.anim.anim_cinema_back_enter, R.anim.anim_cinema_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_vortex_spin",
                "11. Cyber Vortex Spin",
                "Dynamic spiral rotation with neon scale zoom",
                CAT_HACKING,
                R.anim.anim_vortex_enter, R.anim.anim_vortex_exit,
                R.anim.anim_vortex_back_enter, R.anim.anim_vortex_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_warp_drive",
                "12. Quantum Hyper Warp",
                "High-speed hyperspace zoom-through portal effect",
                CAT_CINEMATIC,
                R.anim.anim_warp_enter, R.anim.anim_warp_exit,
                R.anim.anim_warp_back_enter, R.anim.anim_warp_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_vflip_card",
                "13. 3D Vertical Flip",
                "Vertical tumbling card rotation around horizontal axis",
                CAT_CINEMATIC,
                R.anim.anim_vflip_enter, R.anim.anim_vflip_exit,
                R.anim.anim_vflip_back_enter, R.anim.anim_vflip_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_pendulum_swing",
                "14. Pendulum Arc Swing",
                "Top-pivoted gravity swing with smooth overshoot",
                CAT_CLASSIC,
                R.anim.anim_pendulum_enter, R.anim.anim_pendulum_exit,
                R.anim.anim_pendulum_back_enter, R.anim.anim_pendulum_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_origami_unfold",
                "15. Origami Unfold",
                "Crisp edge-hinged paper unfold with alpha reveal",
                CAT_CINEMATIC,
                R.anim.anim_origami_enter, R.anim.anim_origami_exit,
                R.anim.anim_origami_back_enter, R.anim.anim_origami_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_gravity_drop",
                "16. Gravity Bounce Drop",
                "Sky-drop entrance with playful physics bounce",
                CAT_CLASSIC,
                R.anim.anim_gravity_enter, R.anim.anim_gravity_exit,
                R.anim.anim_gravity_back_enter, R.anim.anim_gravity_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_hologram_beam",
                "17. Hologram Laser Beam",
                "Sci-fi horizontal beam projection & vertical expand",
                CAT_HACKING,
                R.anim.anim_hologram_enter, R.anim.anim_hologram_exit,
                R.anim.anim_hologram_back_enter, R.anim.anim_hologram_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_boomerang_swoop",
                "18. Boomerang Arc Swoop",
                "Curved diagonal swoop with tilted momentum",
                CAT_CINEMATIC,
                R.anim.anim_boomerang_enter, R.anim.anim_boomerang_exit,
                R.anim.anim_boomerang_back_enter, R.anim.anim_boomerang_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_velvet_dissolve",
                "19. Velvet Silk Dissolve",
                "Ultra-smooth luxury micro-scale cross dissolve",
                CAT_CINEMATIC,
                R.anim.anim_velvet_enter, R.anim.anim_velvet_exit,
                R.anim.anim_velvet_back_enter, R.anim.anim_velvet_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_rocket_boost",
                "20. Rocket Boost Launch",
                "High-velocity vertical propulsion with stretch curve",
                CAT_CINEMATIC,
                R.anim.anim_rocket_enter, R.anim.anim_rocket_exit,
                R.anim.anim_rocket_back_enter, R.anim.anim_rocket_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_cyber_glitch",
                "21. Cyber Glitch Breach (Hacking)",
                "High-frequency cyberdeck snap shift with tactical scale pulse",
                CAT_HACKING,
                R.anim.anim_cyber_glitch_enter, R.anim.anim_cyber_glitch_exit,
                R.anim.anim_cyber_glitch_back_enter, R.anim.anim_cyber_glitch_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_matrix_drop",
                "22. Matrix Terminal Drop (Root CLI)",
                "Top-down hacker console cascade reveal with vertical scan",
                CAT_HACKING,
                R.anim.anim_matrix_drop_enter, R.anim.anim_matrix_drop_exit,
                R.anim.anim_matrix_drop_back_enter, R.anim.anim_matrix_drop_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_singularity_pull",
                "23. Gargantua Singularity Vortex",
                "Deep-space gravitational spiral pull and cosmic expansion",
                CAT_CINEMATIC,
                R.anim.anim_singularity_enter, R.anim.anim_singularity_exit,
                R.anim.anim_singularity_back_enter, R.anim.anim_singularity_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_katana_slash",
                "24. Cyber Katana Diagonal Slash",
                "Razor-sharp diagonal neon blade sweep with angled momentum",
                CAT_HACKING,
                R.anim.anim_katana_slash_enter, R.anim.anim_katana_slash_exit,
                R.anim.anim_katana_slash_back_enter, R.anim.anim_katana_slash_back_exit,
                false
        ));

        BUILTIN_ANIM_LIST.add(new AnimItem(
                "anim_portal_unfold",
                "25. Holographic Portal Unfold",
                "Multi-axis sci-fi quantum portal beam expansion reveal",
                CAT_HACKING,
                R.anim.anim_portal_unfold_enter, R.anim.anim_portal_unfold_exit,
                R.anim.anim_portal_unfold_back_enter, R.anim.anim_portal_unfold_back_exit,
                false
        ));
    }

    public static List<AnimItem> getAnimations() {
        return BUILTIN_ANIM_LIST;
    }

    public static List<AnimItem> getAllAnimations(Context context) {
        List<AnimItem> all = new ArrayList<>(BUILTIN_ANIM_LIST);
        if (context != null) {
            all.addAll(getCustomTransitions(context));
        }
        return all;
    }

    public static List<AnimItem> getCustomTransitions(Context context) {
        if (context == null) return new ArrayList<>();
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_TRANSITIONS, "[]");
        List<AnimItem> cached = cachedCustomTransitions;
        if (raw.equals(cachedCustomTransitionsRaw)) {
            return new ArrayList<>(cached);
        }

        synchronized (TransitionAnimationManager.class) {
            if (raw.equals(cachedCustomTransitionsRaw)) {
                return new ArrayList<>(cachedCustomTransitions);
            }
            List<AnimItem> list = new ArrayList<>();
            try {
                JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = obj.optString("id", "custom_trans_" + i);
                String name = obj.optString("name", "Custom Transition");
                String forwardId = obj.optString("forwardId", "anim_cyber_glitch");
                String backwardId = obj.optString("backwardId", "anim_hologram_beam");
                AnimItem fItem = findBuiltInById(forwardId);
                AnimItem bItem = findBuiltInById(backwardId);
                String desc = "Custom Mix: Enter [" + stripNumberPrefix(fItem.name)
                        + "] • Back [" + stripNumberPrefix(bItem.name) + "]";
                    list.add(new AnimItem(
                            id,
                            "★ " + name,
                            desc,
                            CAT_CUSTOM,
                            fItem.enterAnim, fItem.exitAnim,
                            bItem.popEnterAnim, bItem.popExitAnim,
                            true
                    ));
                }
            } catch (Exception ignored) {}
            cachedCustomTransitions = list;
            cachedCustomTransitionsRaw = raw;
            return new ArrayList<>(list);
        }
    }

    public static AnimItem createCustomTransition(Context context, String customName, String forwardAnimId, String backwardAnimId) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_TRANSITIONS, "[]");
        String newId = "custom_trans_" + System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(raw);
            JSONObject obj = new JSONObject();
            obj.put("id", newId);
            obj.put("name", customName);
            obj.put("forwardId", forwardAnimId);
            obj.put("backwardId", backwardAnimId);
            arr.put(obj);
            sp.edit().putString(KEY_CUSTOM_TRANSITIONS, arr.toString())
                    .putString(KEY_SELECTED_ANIM, newId)
                    .putInt(KEY_SHUFFLE_MODE, SHUFFLE_OFF)
                    .apply();
        } catch (Exception ignored) {}
        return getSelectedAnimation(context);
    }

    public static void deleteCustomTransition(Context context, String customId) {
        if (context == null || customId == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_CUSTOM_TRANSITIONS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            JSONArray updated = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (!customId.equals(obj.optString("id"))) {
                    updated.put(obj);
                }
            }
            SharedPreferences.Editor editor = sp.edit().putString(KEY_CUSTOM_TRANSITIONS, updated.toString());
            if (customId.equals(sp.getString(KEY_SELECTED_ANIM, ""))) {
                editor.putString(KEY_SELECTED_ANIM, "anim_slide_horizontal");
            }
            editor.apply();
        } catch (Exception ignored) {}
    }

    public static String stripNumberPrefix(String title) {
        if (title == null) return "";
        return title.replaceFirst("^\\d+\\.\\s*", "").replaceFirst("^★\\s*", "");
    }

    private static AnimItem findBuiltInById(String id) {
        for (AnimItem item : BUILTIN_ANIM_LIST) {
            if (item.id.equals(id)) return item;
        }
        return BUILTIN_ANIM_LIST.get(0);
    }

    public static int getShuffleMode(Context context) {
        if (context == null) return SHUFFLE_OFF;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sp.getInt(KEY_SHUFFLE_MODE, SHUFFLE_OFF);
    }

    public static void setShuffleMode(Context context, int mode) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_SHUFFLE_MODE, mode).apply();
    }

    public static AnimItem getSelectedAnimation(Context context) {
        if (context == null) return BUILTIN_ANIM_LIST.get(0);
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String selectedId = sp.getString(KEY_SELECTED_ANIM, ANIM_NONE);
        // The built-in list is immutable after class initialization; search it first to
        // avoid allocating a combined list and parsing custom JSON on every screen launch.
        for (AnimItem item : BUILTIN_ANIM_LIST) {
            if (item.id.equals(selectedId)) return item;
        }
        for (AnimItem item : getCustomTransitions(context)) {
            if (item.id.equals(selectedId)) return item;
        }
        return BUILTIN_ANIM_LIST.get(0);
    }

    public static void setSelectedAnimation(Context context, String animId) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_SELECTED_ANIM, animId).apply();
    }

    private static AnimItem resolveActiveTransition(Context context) {
        int shuffle = getShuffleMode(context);
        List<AnimItem> all = getAllAnimations(context);
        if (shuffle == SHUFFLE_ALL && !all.isEmpty()) {
            return all.get(RANDOM.nextInt(all.size()));
        } else if (shuffle == SHUFFLE_CYBER_CINEMA) {
            List<AnimItem> pool = new ArrayList<>();
            for (AnimItem item : all) {
                if (CAT_HACKING.equals(item.category) || CAT_CINEMATIC.equals(item.category) || item.isCustom) {
                    pool.add(item);
                }
            }
            if (!pool.isEmpty()) {
                return pool.get(RANDOM.nextInt(pool.size()));
            }
        }
        return getSelectedAnimation(context);
    }

    public static void applyForward(Activity activity) {
        if (activity == null) return;
        try {
            AnimItem item = resolveActiveTransition(activity);
            if (item != null && !ANIM_NONE.equals(item.id) && item.enterAnim != 0 && item.exitAnim != 0) {
                activity.overridePendingTransition(item.enterAnim, item.exitAnim);
            }
        } catch (Exception ignored) {}
    }

    public static void applyBackward(Activity activity) {
        if (activity == null) return;
        try {
            AnimItem item = resolveActiveTransition(activity);
            if (item != null && !ANIM_NONE.equals(item.id) && item.popEnterAnim != 0 && item.popExitAnim != 0) {
                activity.overridePendingTransition(item.popEnterAnim, item.popExitAnim);
            }
        } catch (Exception ignored) {}
    }
}
