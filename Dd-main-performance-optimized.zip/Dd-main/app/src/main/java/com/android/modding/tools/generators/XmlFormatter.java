package com.android.modding.tools.generators;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.view.MotionEvent;
import android.view.View;

public class XmlFormatter {

    /**
     * Pretty formats and indents XML cleanly with 4 spaces per nesting level.
     * Accurately handles multiline tags, self-closing tags (/>), and comments without runaway indentation.
     */
    public static String formatXml(String input) {
        if (input == null || input.trim().isEmpty()) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String[] lines = input.split("\n");
        int indentLevel = 0;
        final String INDENT = "    ";
        boolean inTagAttributes = false;

        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty()) {
                continue;
            }

            // XML declaration always at root
            if (line.startsWith("<?")) {
                result.append(line).append("\n");
                continue;
            }

            // Standalone closing tag </tag>
            if (line.startsWith("</")) {
                indentLevel = Math.max(0, indentLevel - 1);
                inTagAttributes = false;
            } else if (line.equals("/>") || line.startsWith("/>")) {
                if (inTagAttributes) {
                    indentLevel = Math.max(0, indentLevel - 1);
                    inTagAttributes = false;
                }
            }

            for (int i = 0; i < indentLevel; i++) {
                result.append(INDENT);
            }
            result.append(line).append("\n");

            // Check if line opens a multiline tag or element
            if (line.startsWith("<") && !line.startsWith("<!--") && !line.startsWith("</")) {
                if (line.endsWith("/>")) {
                    // Self-closing on single line: indent stays unchanged
                    inTagAttributes = false;
                } else if (line.endsWith(">")) {
                    // Regular opening tag <tag> or <tag attr="val">
                    if (!line.contains("</")) {
                        indentLevel++;
                    }
                    inTagAttributes = false;
                } else {
                    // Multiline opening tag like <gradient or <stroke
                    indentLevel++;
                    inTagAttributes = true;
                }
            } else if (inTagAttributes) {
                if (line.endsWith("/>")) {
                    indentLevel = Math.max(0, indentLevel - 1);
                    inTagAttributes = false;
                } else if (line.endsWith(">")) {
                    inTagAttributes = false;
                }
            }
        }

        return result.toString().trim();
    }

    /**
     * Prevents parent ScrollViews from intercepting touch events when scrolling inside the code box.
     * Ensures both vertical and horizontal dragging scrolls the code box content cleanly without crashes.
     */
    public static void enableCodeBoxScroll(final View codeView, final View verticalScroll, final View horizontalScroll) {
        View.OnTouchListener listener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                    android.view.ViewParent parent = v.getParent();
                    while (parent != null) {
                        parent.requestDisallowInterceptTouchEvent(true);
                        parent = parent.getParent();
                    }
                } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    android.view.ViewParent parent = v.getParent();
                    while (parent != null) {
                        parent.requestDisallowInterceptTouchEvent(false);
                        parent = parent.getParent();
                    }
                }
                return false;
            }
        };

        if (codeView != null) {
            codeView.setOnTouchListener(listener);
        }
        if (verticalScroll != null) {
            verticalScroll.setOnTouchListener(listener);
        }
        if (horizontalScroll != null) {
            horizontalScroll.setOnTouchListener(listener);
        }
    }

    public static void enableCodeBoxScroll(final View codeView) {
        if (codeView == null) return;
        View parent1 = (codeView.getParent() instanceof View) ? (View) codeView.getParent() : null;
        View parent2 = (parent1 != null && parent1.getParent() instanceof View) ? (View) parent1.getParent() : null;
        enableCodeBoxScroll(codeView, parent1, parent2);
    }
}
