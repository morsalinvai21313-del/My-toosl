package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Endless Movie-Credits Vertical Scrolling Text Box View.
 * Renders a dark navy container with rounded cyan border matching the app theme
 * where lines of text scroll smoothly and continuously from bottom to top in an infinite loop.
 */
public class MovieCreditsTickerView extends View {

    private Paint bgPaint;
    private Paint borderPaint;
    private Paint titlePaint;
    private Paint linePaint;
    private Paint highlightPaint;
    private final RectF boxRect = new RectF();
    private final Path clipPath = new Path();

    private String[] creditLines = new String[0];
    private float scrollOffsetPx = 0f;
    private ValueAnimator scrollAnimator;
    private long lastFrameTimeMs = 0L;

    public MovieCreditsTickerView(Context context) {
        super(context);
        init(context);
    }

    public MovieCreditsTickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MovieCreditsTickerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        float density = getResources().getDisplayMetrics().density;

        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setStyle(Paint.Style.FILL);
        bgPaint.setColor(0xFF06121B); // Matches exact dark navy background of other boxes

        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(2f * density);
        borderPaint.setColor(0xFF00E5FF); // Clean neon cyan matching other boxes

        Typeface boldTf = MorsalinViewInflater.getAppTypeface(context, true);
        Typeface regTf = MorsalinViewInflater.getAppTypeface(context, false);

        titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setTypeface(boldTf);
        titlePaint.setTextSize(12.5f * density);
        titlePaint.setColor(0xFF00E5FF);
        titlePaint.setTextAlign(Paint.Align.CENTER);

        highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        highlightPaint.setTypeface(boldTf);
        highlightPaint.setTextSize(11.8f * density);
        highlightPaint.setColor(0xFF00E5FF);
        highlightPaint.setTextAlign(Paint.Align.CENTER);

        linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        linePaint.setTypeface(regTf);
        linePaint.setTextSize(11.5f * density);
        linePaint.setColor(0xFFFFFFFF);
        linePaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setCreditLines(String[] lines) {
        if (lines != null) {
            this.creditLines = lines;
        }
        invalidate();
    }

    private void startEndlessScroll() {
        if (scrollAnimator != null && scrollAnimator.isRunning()) return;
        lastFrameTimeMs = System.currentTimeMillis();
        scrollAnimator = ValueAnimator.ofFloat(0f, 1f);
        scrollAnimator.setDuration(1000);
        scrollAnimator.setRepeatCount(ValueAnimator.INFINITE);
        scrollAnimator.setInterpolator(new LinearInterpolator());
        scrollAnimator.addUpdateListener(animation -> {
            long now = System.currentTimeMillis();
            long dt = Math.min(50L, Math.max(1L, now - lastFrameTimeMs));
            lastFrameTimeMs = now;
            float density = getResources().getDisplayMetrics().density;

            // Smooth movie-credits upward speed (~28 dp per second)
            scrollOffsetPx += (28f * density) * (dt / 1000f);
            invalidate();
        });
        scrollAnimator.start();
    }

    private void stopEndlessScroll() {
        if (scrollAnimator != null) {
            scrollAnimator.cancel();
            scrollAnimator = null;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startEndlessScroll();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopEndlessScroll();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float pad = 1.5f * density;
        float cornerRadius = 6f * density;
        boxRect.set(pad, pad, w - pad, h - pad);

        // 1. Dark navy background matching the exact theme color with rounded corners
        canvas.drawRoundRect(boxRect, cornerRadius, cornerRadius, bgPaint);

        if (creditLines != null && creditLines.length > 0) {
            float lineStep = 22f * density;
            float totalBlockHeight = creditLines.length * lineStep;
            if (totalBlockHeight > 1f) {
                scrollOffsetPx = scrollOffsetPx % totalBlockHeight;
            }

            canvas.save();
            clipPath.reset();
            clipPath.addRoundRect(
                    boxRect.left + 3f * density, boxRect.top + 3f * density,
                    boxRect.right - 3f * density, boxRect.bottom - 3f * density,
                    cornerRadius, cornerRadius, Path.Direction.CW
            );
            canvas.clipPath(clipPath);

            float cx = w / 2f;
            float startY = h - scrollOffsetPx;

            // Draw two consecutive cycles so the loop from bottom to top is 100% seamless
            for (int cycle = -1; cycle <= 1; cycle++) {
                float cycleBaseY = startY + cycle * totalBlockHeight;
                for (int i = 0; i < creditLines.length; i++) {
                    float y = cycleBaseY + i * lineStep;
                    if (y < -lineStep || y > h + lineStep) continue;

                    String text = creditLines[i];
                    if (text == null || text.isEmpty()) continue;

                    Paint activePaint;
                    if (text.startsWith("★") || text.startsWith("━━")) {
                        activePaint = titlePaint;
                    } else if (text.startsWith("⚡") || text.startsWith("🔥")) {
                        activePaint = highlightPaint;
                    } else {
                        activePaint = linePaint;
                    }

                    // Soft alpha fade near the very top & bottom edges
                    int alpha = 255;
                    float fadeZone = 24f * density;
                    if (y < fadeZone) {
                        alpha = Math.max(0, Math.min(255, (int) ((y / fadeZone) * 255f)));
                    } else if (y > h - fadeZone) {
                        alpha = Math.max(0, Math.min(255, (int) (((h - y) / fadeZone) * 255f)));
                    }
                    activePaint.setAlpha(alpha);
                    canvas.drawText(text, cx, y, activePaint);
                }
            }
            canvas.restore();
        }

        // Draw neon cyan rounded border matching other boxes
        canvas.drawRoundRect(boxRect, cornerRadius, cornerRadius, borderPaint);
    }
}
