package com.android.modding.tools;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.View;

import com.android.modding.tools.helpers.LightingTextHelper;

/**
 * Custom Application class that automatically attaches the Lighting Text Animation
 * to all UI text elements across all activities upon launch and resume,
 * while automatically excluding code and XML generation views.
 */
public class MorsalinApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

            @Override
            public void onActivityStarted(Activity activity) {}

            @Override
            public void onActivityResumed(Activity activity) {
                if (com.android.modding.tools.helpers.LightingTextAnimationManager.isEnabled(activity)) {
                    View content = activity.findViewById(android.R.id.content);
                    if (content != null) {
                        content.post(() -> LightingTextHelper.applyToViewTree(content));
                    }
                }
            }

            @Override
            public void onActivityPaused(Activity activity) {}

            @Override
            public void onActivityStopped(Activity activity) {}

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

            @Override
            public void onActivityDestroyed(Activity activity) {}
        });
    }
}
