package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;








import java.util.HashMap;
import java.util.Map;

public class GradientEditorActivity extends AppCompatActivity {

    private static final String XML_INITIAL_PLACEHOLDER =
            "<!-- XML will be generated here when you select colors or configure layers -->";

    private final Map<String, StateModel> stateMap = new HashMap<>();
    private String currentState = StateModel.STATE_NORMAL;

    // Sticky Preview Views
    private FrameLayout boxFrameNormal;
    private FrameLayout boxFrameChecked;
    private FrameLayout boxFramePressed;

    private FrameLayout cardNormal;
    private FrameLayout cardChecked;
    private FrameLayout cardPressed;

    private TextView tvPreviewNormalLabel;
    private TextView tvPreviewCheckedLabel;
    private TextView tvPreviewPressedLabel;

    private Button tabNormal;
    private Button tabChecked;
    private Button tabPressed;

    // Color Pickers & Hex Labels
    private TextView tvStartColorHex;
    private TextView tvCenterColorHex;
    private TextView tvEndColorHex;
    private TextView tvStrokeColorHex;

    private LinearLayout layoutCenterColor;
    private Button btnPickCenterColor;
    private CheckBox cbThreeColor;

    // Gradient Types
    private Button btnTypeLinear;
    private Button btnTypeRadial;
    private Button btnTypeSweep;

    private LinearLayout layoutLinearOptions;
    private LinearLayout layoutRadialOptions;
    private LinearLayout layoutRadiusRow;

    private TextView tvAngleVal;
    private TextView tvRadiusVal;
    private TextView tvCenterXVal;
    private TextView tvCenterYVal;

    private SeekBar seekAngle;
    private SeekBar seekRadius;
    private SeekBar seekCenterX;
    private SeekBar seekCenterY;

    // Code & Scrolling
    private HorizontalScrollView scrollCodeHorizontal;
    private ScrollView scrollCodeVertical;
    private TextView etGeneratedXml;

    private HistoryManager historyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gradient_editor);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);

        initBlankStates();
        String importedXml = getIntent().getStringExtra("EXTRA_IMPORTED_XML");
        if (importedXml != null && !importedXml.trim().isEmpty()) {
            loadImportedXml(importedXml.trim());
        }
        initViews();
        switchState(StateModel.STATE_NORMAL);
    }

    private void loadImportedXml(String xml) {
        XmlParser.ParseResult result = XmlParser.parseXml(xml);
        if (!result.success) return;

        if (result.selectorStates != null && !result.selectorStates.isEmpty()) {
            stateMap.clear();
            stateMap.putAll(result.selectorStates);
            for (StateModel sm : stateMap.values()) {
                sm.setActive(true);
                for (LayerModel l : sm.getLayers()) {
                    l.setGradient(true);
                }
            }
        } else if (result.singleLayer != null) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            result.singleLayer.setGradient(true);
            normal.getLayers().add(result.singleLayer);
            stateMap.put(StateModel.STATE_NORMAL, normal);
        } else if (result.layerList != null && !result.layerList.isEmpty()) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            LayerModel l = result.layerList.get(0);
            l.setGradient(true);
            normal.getLayers().add(l);
            stateMap.put(StateModel.STATE_NORMAL, normal);
        }
    }

    /**
     * Initializes all states completely blank (no pre-filled colors, no XML).
     * Only when user selects colors or configures options, the gradient and XML are generated!
     */
    private void initBlankStates() {
        stateMap.clear();

        // Normal State (Starts completely blank and inactive)
        StateModel normal = new StateModel(StateModel.STATE_NORMAL);
        normal.setActive(false);
        LayerModel lNormal = normal.getLayers().get(0);
        lNormal.setGradient(true);
        GradientModel gn = lNormal.getGradient();
        gn.setType(GradientModel.TYPE_LINEAR);
        gn.setStartColor("#00000000");
        gn.setCenterColor("#00000000");
        gn.setEndColor("#00000000");
        gn.setUseCenterColor(false);
        gn.setAngle(270);
        lNormal.getCorners().setCorners(0, 0, 0, 0, false);
        lNormal.getStroke().setColor("#00000000");
        lNormal.getStroke().setWidthDp(0);
        stateMap.put(StateModel.STATE_NORMAL, normal);

        // Checked State (Starts blank and inactive)
        StateModel checked = new StateModel(StateModel.STATE_CHECKED);
        checked.setActive(false);
        LayerModel lChecked = checked.getLayers().get(0);
        lChecked.setGradient(true);
        GradientModel gc = lChecked.getGradient();
        gc.setType(GradientModel.TYPE_LINEAR);
        gc.setStartColor("#00000000");
        gc.setCenterColor("#00000000");
        gc.setEndColor("#00000000");
        gc.setUseCenterColor(false);
        gc.setAngle(270);
        lChecked.getCorners().setCorners(0, 0, 0, 0, false);
        lChecked.getStroke().setColor("#00000000");
        lChecked.getStroke().setWidthDp(0);
        stateMap.put(StateModel.STATE_CHECKED, checked);

        // Pressed State (Starts blank and inactive)
        StateModel pressed = new StateModel(StateModel.STATE_PRESSED);
        pressed.setActive(false);
        LayerModel lPressed = pressed.getLayers().get(0);
        lPressed.setGradient(true);
        GradientModel gp = lPressed.getGradient();
        gp.setType(GradientModel.TYPE_LINEAR);
        gp.setStartColor("#00000000");
        gp.setCenterColor("#00000000");
        gp.setEndColor("#00000000");
        gp.setUseCenterColor(false);
        gp.setAngle(270);
        lPressed.getCorners().setCorners(0, 0, 0, 0, false);
        lPressed.getStroke().setColor("#00000000");
        lPressed.getStroke().setWidthDp(0);
        stateMap.put(StateModel.STATE_PRESSED, pressed);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });
        findViewById(R.id.btn_reset).setOnClickListener(v -> showResetDialog());

        boxFrameNormal = findViewById(R.id.box_frame_normal);
        boxFrameChecked = findViewById(R.id.box_frame_checked);
        boxFramePressed = findViewById(R.id.box_frame_pressed);

        cardNormal = findViewById(R.id.card_preview_normal);
        cardChecked = findViewById(R.id.card_preview_checked);
        cardPressed = findViewById(R.id.card_preview_pressed);

        tvPreviewNormalLabel = findViewById(R.id.tv_preview_normal_label);
        tvPreviewCheckedLabel = findViewById(R.id.tv_preview_checked_label);
        tvPreviewPressedLabel = findViewById(R.id.tv_preview_pressed_label);

        // Labels are always visible centered inside the preview boxes
        tvPreviewNormalLabel.setVisibility(View.VISIBLE);
        tvPreviewCheckedLabel.setVisibility(View.VISIBLE);
        tvPreviewPressedLabel.setVisibility(View.VISIBLE);

        tabNormal = findViewById(R.id.tab_edit_normal);
        tabChecked = findViewById(R.id.tab_edit_checked);
        tabPressed = findViewById(R.id.tab_edit_pressed);

        tvStartColorHex = findViewById(R.id.tv_start_color_hex);
        tvCenterColorHex = findViewById(R.id.tv_center_color_hex);
        tvEndColorHex = findViewById(R.id.tv_end_color_hex);
        tvStrokeColorHex = findViewById(R.id.tv_stroke_color_hex);

        layoutCenterColor = findViewById(R.id.layout_center_color);
        btnPickCenterColor = findViewById(R.id.btn_pick_center_color);
        cbThreeColor = findViewById(R.id.cb_three_color_gradient);

        btnTypeLinear = findViewById(R.id.btn_type_linear);
        btnTypeRadial = findViewById(R.id.btn_type_radial);
        btnTypeSweep = findViewById(R.id.btn_type_sweep);

        layoutLinearOptions = findViewById(R.id.layout_linear_options);
        layoutRadialOptions = findViewById(R.id.layout_radial_options);
        layoutRadiusRow = findViewById(R.id.layout_radius_row);

        tvAngleVal = findViewById(R.id.tv_angle_val);
        tvRadiusVal = findViewById(R.id.tv_radius_val);
        tvCenterXVal = findViewById(R.id.tv_center_x_val);
        tvCenterYVal = findViewById(R.id.tv_center_y_val);

        seekAngle = findViewById(R.id.seek_angle);
        seekRadius = findViewById(R.id.seek_radius);
        seekCenterX = findViewById(R.id.seek_center_x);
        seekCenterY = findViewById(R.id.seek_center_y);

        scrollCodeHorizontal = findViewById(R.id.scroll_code_horizontal);
        scrollCodeVertical = findViewById(R.id.scroll_code_vertical);
        etGeneratedXml = findViewById(R.id.et_generated_xml);

        // Enable smooth, isolated scrolling inside the code box
        XmlFormatter.enableCodeBoxScroll(etGeneratedXml, scrollCodeVertical, scrollCodeHorizontal);

        // State Tab and Preview Card Clicks
        tabNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        tabChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        tabPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        cardNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        cardChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        cardPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        // 3-Color Gradient Checkbox
        if (cbThreeColor != null) {
            cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
                ensureCurrentStateActive();
                getCurrentLayer().getGradient().setUseCenterColor(isChecked);
                updateUiForCurrentState();
                updatePreviewAndXml();
            });
        }

        // Color Picker Listeners with LIVE instant preview
        findViewById(R.id.btn_pick_start_color).setOnClickListener(v -> {
            GradientModel g = getCurrentLayer().getGradient();
            String initial = g.getStartColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#FF007F";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForCurrentState();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setStartColor(color);
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    });
            dialog.show();
        });

        if (btnPickCenterColor != null) {
            btnPickCenterColor.setOnClickListener(v -> {
                if (!cbThreeColor.isChecked()) return;
                GradientModel g = getCurrentLayer().getGradient();
                String initial = g.getCenterColor();
                if (initial == null || initial.equals("#00000000")) {
                    initial = "#0055FF";
                }
                ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                        color -> {
                            ensureCurrentStateActive();
                            g.setCenterColor(color);
                            updateUiForCurrentState();
                            updatePreviewOnly();
                        },
                        color -> {
                            ensureCurrentStateActive();
                            g.setCenterColor(color);
                            updateUiForCurrentState();
                            updatePreviewAndXml();
                        });
                dialog.show();
            });
        }

        findViewById(R.id.btn_pick_end_color).setOnClickListener(v -> {
            GradientModel g = getCurrentLayer().getGradient();
            String initial = g.getEndColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#00FFFF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForCurrentState();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        g.setEndColor(color);
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    });
            dialog.show();
        });

        // Gradient Type Buttons
        btnTypeLinear.setOnClickListener(v -> setGradientType(GradientModel.TYPE_LINEAR));
        btnTypeRadial.setOnClickListener(v -> setGradientType(GradientModel.TYPE_RADIAL));
        btnTypeSweep.setOnClickListener(v -> setGradientType(GradientModel.TYPE_SWEEP));

        // Angle Controls with live update
        seekAngle.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getCurrentLayer().getGradient().setAngle(progress);
                    tvAngleVal.setText(progress + "°");
                    updatePreviewAndXml();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.btn_angle_minus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int cur = seekAngle.getProgress();
            int next = Math.max(0, cur - 15);
            seekAngle.setProgress(next);
            getCurrentLayer().getGradient().setAngle(next);
            tvAngleVal.setText(next + "°");
            updatePreviewAndXml();
        });

        findViewById(R.id.btn_angle_plus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int cur = seekAngle.getProgress();
            int next = Math.min(360, cur + 15);
            seekAngle.setProgress(next);
            getCurrentLayer().getGradient().setAngle(next);
            tvAngleVal.setText(next + "°");
            updatePreviewAndXml();
        });

        // Radial Radius Controls
        seekRadius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    getCurrentLayer().getGradient().setGradientRadiusDp(progress);
                    tvRadiusVal.setText(progress + "dp");
                    updatePreviewAndXml();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.btn_radius_minus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int cur = seekRadius.getProgress();
            int next = Math.max(1, cur - 5);
            seekRadius.setProgress(next);
            getCurrentLayer().getGradient().setGradientRadiusDp(next);
            tvRadiusVal.setText(next + "dp");
            updatePreviewAndXml();
        });

        findViewById(R.id.btn_radius_plus).setOnClickListener(v -> {
            ensureCurrentStateActive();
            int cur = seekRadius.getProgress();
            int next = Math.min(200, cur + 5);
            seekRadius.setProgress(next);
            getCurrentLayer().getGradient().setGradientRadiusDp(next);
            tvRadiusVal.setText(next + "dp");
            updatePreviewAndXml();
        });

        // Center X & Center Y
        seekCenterX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getCurrentLayer().getGradient().setCenterX(val);
                    tvCenterXVal.setText(String.format("%.2f", val));
                    updatePreviewAndXml();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekCenterY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    ensureCurrentStateActive();
                    float val = progress / 100f;
                    getCurrentLayer().getGradient().setCenterY(val);
                    tvCenterYVal.setText(String.format("%.2f", val));
                    updatePreviewAndXml();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Stroke Color Picker with live updates
        findViewById(R.id.btn_pick_stroke_color).setOnClickListener(v -> {
            StrokeModel stroke = getCurrentLayer().getStroke();
            String initial = stroke.getColor();
            if (initial == null || initial.equals("#00000000")) {
                initial = "#00FFFF";
            }
            ColorPickerDialog dialog = new ColorPickerDialog(this, initial,
                    color -> {
                        ensureCurrentStateActive();
                        stroke.setColor(color);
                        if (stroke.getWidthDp() == 0) {
                            stroke.setWidthDp(2);
                        }
                        updateUiForCurrentState();
                        updatePreviewOnly();
                    },
                    color -> {
                        ensureCurrentStateActive();
                        stroke.setColor(color);
                        if (stroke.getWidthDp() == 0) {
                            stroke.setWidthDp(2);
                        }
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    });
            dialog.show();
        });

        // Custom Stroke Dialog with live preview
        findViewById(R.id.btn_set_custom_stroke).setOnClickListener(v -> {
            StrokeModel stroke = getCurrentLayer().getStroke();
            StrokeModel original = stroke.copy();
            CustomStrokeDialog dialog = new CustomStrokeDialog(this, stroke, (width, dashW, dashG) -> {
                ensureCurrentStateActive();
                stroke.setWidthDp(width);
                stroke.setDashWidthDp(dashW);
                stroke.setDashGapDp(dashG);
                updateUiForCurrentState();
                updatePreviewAndXml();
            });
            dialog.setLiveListener((width, dashW, dashG) -> {
                ensureCurrentStateActive();
                stroke.setWidthDp(width);
                stroke.setDashWidthDp(dashW);
                stroke.setDashGapDp(dashG);
                updatePreviewOnly();
            });
            dialog.setOnCancelListener(d -> {
                stroke.setWidthDp(original.getWidthDp());
                stroke.setColor(original.getColor());
                stroke.setDashWidthDp(original.getDashWidthDp());
                stroke.setDashGapDp(original.getDashGapDp());
                updateUiForCurrentState();
                updatePreviewAndXml();
            });
            dialog.show();
        });

        // Custom Corners Dialog with live preview
        findViewById(R.id.btn_set_custom_corners).setOnClickListener(v -> {
            CornersModel corners = getCurrentLayer().getCorners();
            CornersModel original = corners.copy();
            CustomCornersDialog dialog = new CustomCornersDialog(this, corners, (tl, tr, bl, br, unified) -> {
                ensureCurrentStateActive();
                corners.setCorners(tl, tr, bl, br, unified);
                updatePreviewAndXml();
            });
            dialog.setLiveListener((tl, tr, bl, br, unified) -> {
                ensureCurrentStateActive();
                corners.setCorners(tl, tr, bl, br, unified);
                updatePreviewOnly();
            });
            dialog.setOnCancelListener(d -> {
                corners.setTopLeftDp(original.getTopLeftDp());
                corners.setTopRightDp(original.getTopRightDp());
                corners.setBottomLeftDp(original.getBottomLeftDp());
                corners.setBottomRightDp(original.getBottomRightDp());
                corners.setLinked(original.isLinked());
                updatePreviewAndXml();
            });
            dialog.show();
        });

        // Action Buttons
        findViewById(R.id.btn_copy_code).setOnClickListener(v -> copyCode());
        findViewById(R.id.btn_save_history).setOnClickListener(v -> saveHistory());
        findViewById(R.id.btn_download_xml).setOnClickListener(v -> downloadXml());
        findViewById(R.id.btn_share_export).setOnClickListener(v -> shareExport());
    }

    private void switchState(String stateKey) {
        this.currentState = stateKey;

        // Visual frame selection
        boxFrameNormal.setBackgroundResource(StateModel.STATE_NORMAL.equals(stateKey) ?
                R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFrameChecked.setBackgroundResource(StateModel.STATE_CHECKED.equals(stateKey) ?
                R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFramePressed.setBackgroundResource(StateModel.STATE_PRESSED.equals(stateKey) ?
                R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);

        // Tab selection styles keeping morsalin_button_bg intact
        tabNormal.setSelected(StateModel.STATE_NORMAL.equals(stateKey));
        tabChecked.setSelected(StateModel.STATE_CHECKED.equals(stateKey));
        tabPressed.setSelected(StateModel.STATE_PRESSED.equals(stateKey));

        updateUiForCurrentState();
        updatePreviewAndXml();
    }

    private void setGradientType(String type) {
        ensureCurrentStateActive();
        getCurrentLayer().getGradient().setType(type);
        updateUiForCurrentState();
        updatePreviewAndXml();
    }

    private void updatePreviewOnly() {
        StateModel sNormal = stateMap.get(StateModel.STATE_NORMAL);
        StateModel sChecked = stateMap.get(StateModel.STATE_CHECKED);
        StateModel sPressed = stateMap.get(StateModel.STATE_PRESSED);

        if (StateModel.STATE_NORMAL.equals(currentState) && isStateConfigured(sNormal)) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sNormal.getLayers()));
        } else if (StateModel.STATE_CHECKED.equals(currentState) && isStateConfigured(sChecked)) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sChecked.getLayers()));
        } else if (StateModel.STATE_PRESSED.equals(currentState) && isStateConfigured(sPressed)) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sPressed.getLayers()));
        }
    }

    private void ensureCurrentStateActive() {
        StateModel sm = getCurrentStateModel();
        if (!sm.isActive()) {
            sm.setActive(true);
        }
    }

    private boolean isStateConfigured(StateModel sm) {
        if (sm == null || !sm.isActive()) return false;
        LayerModel l = sm.getLayers().get(0);
        GradientModel g = l.getGradient();
        boolean hasStart = g.getStartColor() != null && !g.getStartColor().equals("#00000000");
        boolean hasEnd = g.getEndColor() != null && !g.getEndColor().equals("#00000000");
        boolean hasStroke = l.getStroke() != null && l.getStroke().getWidthDp() > 0;
        boolean hasCorners = l.getCorners() != null && (l.getCorners().getTopLeftDp() > 0
                || l.getCorners().getTopRightDp() > 0
                || l.getCorners().getBottomLeftDp() > 0
                || l.getCorners().getBottomRightDp() > 0);
        return hasStart || hasEnd || hasStroke || hasCorners;
    }

    private void updateUiForCurrentState() {
        LayerModel layer = getCurrentLayer();
        GradientModel g = layer.getGradient();
        StrokeModel stroke = layer.getStroke();

        boolean hasStart = g.getStartColor() != null && !g.getStartColor().isEmpty() && !g.getStartColor().equals("#00000000");
        boolean hasCenter = g.getCenterColor() != null && !g.getCenterColor().isEmpty() && !g.getCenterColor().equals("#00000000");
        boolean hasEnd = g.getEndColor() != null && !g.getEndColor().isEmpty() && !g.getEndColor().equals("#00000000");

        // Color Hexes: Only show hex if explicitly chosen, otherwise "None"
        applyColorBadge(tvStartColorHex, hasStart ? g.getStartColor() : null, "None");
        applyColorBadge(tvEndColorHex, hasEnd ? g.getEndColor() : null, "None");

        boolean useCenter = g.isUseCenterColor();
        if (cbThreeColor != null) {
            cbThreeColor.setOnCheckedChangeListener(null);
            cbThreeColor.setChecked(useCenter);
            cbThreeColor.setOnCheckedChangeListener((buttonView, isChecked) -> {
                ensureCurrentStateActive();
                getCurrentLayer().getGradient().setUseCenterColor(isChecked);
                updateUiForCurrentState();
                updatePreviewAndXml();
            });
        }

        if (useCenter) {
            layoutCenterColor.setAlpha(1.0f);
            btnPickCenterColor.setEnabled(true);
            btnPickCenterColor.setText(R.string.action_pick_color);
            applyColorBadge(tvCenterColorHex, hasCenter ? g.getCenterColor() : null, "None");
        } else {
            layoutCenterColor.setAlpha(0.35f);
            btnPickCenterColor.setEnabled(false);
            btnPickCenterColor.setText("DISABLED");
            tvCenterColorHex.setText("Disabled");
            tvCenterColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvCenterColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        // Stroke
        if (stroke.getWidthDp() > 0 && !stroke.getColor().equals("#00000000")) {
            applyColorBadge(tvStrokeColorHex, stroke.getColor(), "None (0dp)");
            tvStrokeColorHex.setText(stroke.getColor() + " (" + stroke.getWidthDp() + "dp)");
        } else {
            tvStrokeColorHex.setText("None (0dp)");
            tvStrokeColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvStrokeColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }

        // Gradient Type Selection styling keeping morsalin_button_bg
        String type = g.getType();
        btnTypeLinear.setSelected(GradientModel.TYPE_LINEAR.equals(type));
        btnTypeRadial.setSelected(GradientModel.TYPE_RADIAL.equals(type));
        btnTypeSweep.setSelected(GradientModel.TYPE_SWEEP.equals(type));

        // Angle vs Radius visibility
        if (GradientModel.TYPE_LINEAR.equals(type)) {
            layoutLinearOptions.setVisibility(View.VISIBLE);
            layoutRadialOptions.setVisibility(View.GONE);
            seekAngle.setProgress(g.getAngle());
            tvAngleVal.setText(g.getAngle() + "°");
        } else {
            layoutLinearOptions.setVisibility(View.GONE);
            layoutRadialOptions.setVisibility(View.VISIBLE);
            layoutRadiusRow.setVisibility(GradientModel.TYPE_RADIAL.equals(type) ? View.VISIBLE : View.GONE);
            seekRadius.setProgress(g.getGradientRadiusDp());
            tvRadiusVal.setText(g.getGradientRadiusDp() + "dp");
            seekCenterX.setProgress(Math.round(g.getCenterX() * 100));
            tvCenterXVal.setText(String.format("%.2f", g.getCenterX()));
            seekCenterY.setProgress(Math.round(g.getCenterY() * 100));
            tvCenterYVal.setText(String.format("%.2f", g.getCenterY()));
        }
    }

    private void applyColorBadge(TextView tv, String hexColor, String defaultLabel) {
        tv.setBackgroundResource(R.drawable.morsalin_code_bg);
        if (hexColor == null || hexColor.isEmpty() || hexColor.equals("#00000000")) {
            tv.setText(defaultLabel);
            tv.setTextColor(getColor(R.color.morsalin_text_muted));
        } else {
            tv.setText(hexColor);
            tv.setTextColor(getColor(R.color.morsalin_cyan));
        }
    }

    private boolean isLightColor(int color) {
        if (Color.alpha(color) < 80) return false;
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0;
        return darkness < 0.45;
    }

    private void updatePreviewAndXml() {
        StateModel sNormal = stateMap.get(StateModel.STATE_NORMAL);
        StateModel sChecked = stateMap.get(StateModel.STATE_CHECKED);
        StateModel sPressed = stateMap.get(StateModel.STATE_PRESSED);

        // Update Normal Preview Card
        if (isStateConfigured(sNormal)) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sNormal.getLayers()));
        } else {
            cardNormal.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Update Checked Preview Card
        if (isStateConfigured(sChecked)) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sChecked.getLayers()));
        } else {
            cardChecked.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Update Pressed Preview Card
        if (isStateConfigured(sPressed)) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, sPressed.getLayers()));
        } else {
            cardPressed.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Generate XML
        boolean hasAnyActive = isStateConfigured(sNormal)
                || isStateConfigured(sChecked)
                || isStateConfigured(sPressed);

        if (!hasAnyActive) {
            etGeneratedXml.setText(XML_INITIAL_PLACEHOLDER);
            return;
        }

        boolean hasMultipleStates = isStateConfigured(sChecked) || isStateConfigured(sPressed);
        String xml;
        if (hasMultipleStates) {
            xml = XmlGenerator.generateSelectorXml(stateMap);
        } else {
            StateModel activeModel = isStateConfigured(sNormal) ? sNormal : getCurrentStateModel();
            if (activeModel.getLayers().size() == 1) {
                xml = XmlGenerator.generateShapeXml(activeModel.getLayers().get(0));
            } else {
                xml = XmlGenerator.generateLayerListXml(activeModel.getLayers());
            }
        }

        String formatted = XmlFormatter.formatXml(xml);
        etGeneratedXml.setText(formatted);
    }

    private StateModel getCurrentStateModel() {
        StateModel sm = stateMap.get(currentState);
        if (sm == null) {
            sm = new StateModel(currentState);
            sm.setActive(false);
            stateMap.put(currentState, sm);
        }
        return sm;
    }

    private LayerModel getCurrentLayer() {
        return getCurrentStateModel().getLayers().get(0);
    }

    private void showResetDialog() {
        MorsalinDialogHelper.showResetDialog(
                this,
                "Reset Gradient",
                "Reset all gradients, colors, corners, and strokes to blank?",
                () -> {
                    initBlankStates();
                    switchState(StateModel.STATE_NORMAL);
                    MorsalinToast.show(this, R.drawable.ic_refresh, "Reset Complete", "All layers and colors reset to blank.");
                }
        );
    }

    private void copyCode() {
        String code = etGeneratedXml.getText().toString();
        if (code.isEmpty() || code.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_content_copy, "No XML Yet", "Select colors first to generate XML.");
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Gradient XML", code);
        cm.setPrimaryClip(clip);
        MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied to Clipboard", "XML code copied successfully!");
    }

    private void saveHistory() {
        String code = etGeneratedXml.getText().toString();
        if (code.isEmpty() || code.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_save, "No XML Yet", "Select colors first to generate XML.");
            return;
        }
        XmlProject project = new XmlProject(
                "Gradient Shape " + (System.currentTimeMillis() % 1000),
                XmlProject.TYPE_GRADIENT,
                code
        );
        historyManager.saveProject(project);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Your gradient project has been saved.");
    }

    private void downloadXml() {
        String code = etGeneratedXml.getText().toString();
        if (code.isEmpty() || code.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_download, "No XML Yet", "Select colors first to generate XML.");
            return;
        }
        FileExporter.exportXmlToFile(this, "MS MORSALIN_BG.xml", code);
        MorsalinToast.showDownload(this, "MS MORSALIN_BG.xml");
    }

    private void shareExport() {
        String code = etGeneratedXml.getText().toString();
        if (code.isEmpty() || code.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_share, "No XML Yet", "Select colors first to generate XML.");
            return;
        }
        ShareHelper.shareXmlText(this, code, "Share Gradient XML Code");
    }
}
