package com.android.modding.tools.dialogmaker;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.ConverterAnimationManager;

import java.util.concurrent.atomic.AtomicBoolean;

import com.android.modding.tools.toastmaker.ToastConfig;
import com.android.modding.tools.toastmaker.ToastPackageBuilder;

/**
 * Full-Screen High-Tech Animated Compilation Overlay.
 * Appears prominently on screen during Dialog & Toast Dalvik compilation,
 * displaying a 60fps Stark HUD / holographic canvas, live 5-stage progress,
 * and seamlessly dismisses when compilation completes at 100%.
 */
public class FullScreenGenerationOverlayHelper {

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public interface BuildTask {
        DialogPackageBuilder.BuildResult execute();
    }

    public interface OnBuildCompleteListener {
        void onComplete(DialogPackageBuilder.BuildResult result);
    }

    public interface ToastBuildTask {
        ToastPackageBuilder.BuildResult execute();
    }

    public interface OnToastBuildCompleteListener {
        void onComplete(ToastPackageBuilder.BuildResult result);
    }

    public static void showAndExecute(
            Activity activity,
            String optionName,
            DialogConfig config,
            BuildTask buildTask,
            OnBuildCompleteListener listener
    ) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_fullscreen_generation);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.argb(250, 3, 11, 18)));
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        }

        TextView tvBadge = dialog.findViewById(R.id.tv_gen_badge);
        TextView tvTitle = dialog.findViewById(R.id.tv_gen_target_title);
        TextView tvSubtitle = dialog.findViewById(R.id.tv_gen_subtitle);
        ConversionAnimationView animView = dialog.findViewById(R.id.gen_anim_view);
        TextView tvStageCounter = dialog.findViewById(R.id.tv_gen_stage_counter);
        TextView tvPercentage = dialog.findViewById(R.id.tv_gen_percentage);
        ProgressBar progressBar = dialog.findViewById(R.id.progress_bar_gen);
        TextView tvStatus = dialog.findViewById(R.id.tv_gen_status);
        View layoutSuccess = dialog.findViewById(R.id.layout_gen_success);
        TextView tvSpecs = dialog.findViewById(R.id.tv_gen_specs);

        String cleanTitle = optionName != null && !optionName.trim().isEmpty() ? optionName : "Dialog Package";
        if (tvTitle != null) {
            tvTitle.setText("⚡ " + cleanTitle.toUpperCase());
        }
        if (tvSubtitle != null) {
            tvSubtitle.setText("Compiling Pure Dalvik classes.dex • ZERO-XML Architecture");
        }

        // Configure futuristic animation HUD
        if (animView != null) {
            ConverterAnimationManager.ConverterAnimItem animItem = new ConverterAnimationManager.ConverterAnimItem(
                    "dialog_hud", "Holo-UI Dialog Assembler", "Assembling dynamic dialog framework",
                    ConverterAnimationManager.CAT_CINEMATIC, "⚡ STARK HOLO-UI DIALOG ASSEMBLER ⚡",
                    ConverterAnimationManager.ENGINE_JARVIS_HUD, ConverterAnimationManager.PALETTE_CYBER_NEON, false, false);
            animView.applyAnimationConfig(animItem);
            animView.setLanguages(config != null && config.dialogType != null ? config.dialogType.toUpperCase() : "DIALOG", "CLASSES.DEX");
            animView.updateState(12, "Initializing Dalvik Compiler...");
            animView.startAnimationLoop();
        }

        dialog.show();

        final String[] stages = new String[]{
                "Stage 1/5 • Analyzing View Tree, Colors & Corner Radii...",
                "Stage 2/5 • Generating Pure Java Bytecode & Dynamic Listeners...",
                "Stage 3/5 • Compiling Dalvik classes.dex via D8 Engine...",
                "Stage 4/5 • Verifying Adler32, SHA-1 Checksums & Magic Header...",
                "Stage 5/5 • Generating hook.smali & Packaging Zero-XML Bundle..."
        };

        final AtomicBoolean buildFinished = new AtomicBoolean(false);
        final AtomicBoolean animFinished = new AtomicBoolean(false);
        final DialogPackageBuilder.BuildResult[] resultHolder = new DialogPackageBuilder.BuildResult[1];

        // Background compilation thread
        new Thread(() -> {
            try {
                if (buildTask != null) {
                    resultHolder[0] = buildTask.execute();
                }
            } catch (Throwable t) {
                resultHolder[0] = DialogPackageBuilder.BuildResult.failure("Compilation error: " + t.getMessage());
            }
            buildFinished.set(true);

            MAIN_HANDLER.post(() -> {
                if (animFinished.get()) {
                    finishAndDismiss(dialog, animView, layoutSuccess, resultHolder[0], listener);
                }
            });
        }).start();

        // Stage 1
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 1/5");
            if (tvPercentage != null) tvPercentage.setText("20%");
            if (progressBar != null) progressBar.setProgress(20);
            if (tvStatus != null) tvStatus.setText(stages[0]);
            if (animView != null) animView.updateState(20, stages[0]);
        }, 150);

        // Stage 2
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 2/5");
            if (tvPercentage != null) tvPercentage.setText("45%");
            if (progressBar != null) progressBar.setProgress(45);
            if (tvStatus != null) tvStatus.setText(stages[1]);
            if (animView != null) animView.updateState(45, stages[1]);
        }, 450);

        // Stage 3
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 3/5");
            if (tvPercentage != null) tvPercentage.setText("70%");
            if (progressBar != null) progressBar.setProgress(70);
            if (tvStatus != null) tvStatus.setText(stages[2]);
            if (animView != null) animView.updateState(70, stages[2]);
        }, 850);

        // Stage 4
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 4/5");
            if (tvPercentage != null) tvPercentage.setText("90%");
            if (progressBar != null) progressBar.setProgress(90);
            if (tvStatus != null) tvStatus.setText(stages[3]);
            if (animView != null) animView.updateState(90, stages[3]);
        }, 1250);

        // Stage 5 (100% Completed)
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 5/5");
            if (tvPercentage != null) tvPercentage.setText("100%");
            if (progressBar != null) progressBar.setProgress(100);
            if (tvStatus != null) tvStatus.setText(stages[4]);
            if (animView != null) animView.updateState(100, "✓ Complete: classes.dex & hook.smali Ready!");

            animFinished.set(true);

            if (buildFinished.get()) {
                finishAndDismiss(dialog, animView, layoutSuccess, resultHolder[0], listener);
            }
        }, 1600);
    }

    private static void finishAndDismiss(
            Dialog dialog,
            ConversionAnimationView animView,
            View layoutSuccess,
            DialogPackageBuilder.BuildResult result,
            OnBuildCompleteListener listener
    ) {
        if (layoutSuccess != null) {
            layoutSuccess.setVisibility(View.VISIBLE);
            layoutSuccess.setAlpha(0f);
            layoutSuccess.animate().alpha(1f).setDuration(200).start();
        }

        MAIN_HANDLER.postDelayed(() -> {
            try {
                if (animView != null) {
                    animView.stopAnimationLoop();
                }
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            } catch (Throwable ignored) {}

            if (listener != null) {
                listener.onComplete(result);
            }
        }, 400);
    }

    public static void showAndExecuteToast(
            Activity activity,
            String optionName,
            ToastConfig config,
            ToastBuildTask buildTask,
            OnToastBuildCompleteListener listener
    ) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_fullscreen_generation);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.argb(250, 3, 11, 18)));
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        }

        TextView tvBadge = dialog.findViewById(R.id.tv_gen_badge);
        TextView tvTitle = dialog.findViewById(R.id.tv_gen_target_title);
        TextView tvSubtitle = dialog.findViewById(R.id.tv_gen_subtitle);
        ConversionAnimationView animView = dialog.findViewById(R.id.gen_anim_view);
        TextView tvStageCounter = dialog.findViewById(R.id.tv_gen_stage_counter);
        TextView tvPercentage = dialog.findViewById(R.id.tv_gen_percentage);
        ProgressBar progressBar = dialog.findViewById(R.id.progress_bar_gen);
        TextView tvStatus = dialog.findViewById(R.id.tv_gen_status);
        View layoutSuccess = dialog.findViewById(R.id.layout_gen_success);
        TextView tvSpecs = dialog.findViewById(R.id.tv_gen_specs);

        String cleanTitle = optionName != null && !optionName.trim().isEmpty() ? optionName : "Toast Package";
        if (tvBadge != null) {
            tvBadge.setText("⚡ MORSALIN TOAST ENGINE ⚡");
        }
        if (tvTitle != null) {
            tvTitle.setText("⚡ " + cleanTitle.toUpperCase());
        }
        if (tvSubtitle != null) {
            tvSubtitle.setText("Compiling Pure Dalvik classes.dex • Standalone Binary");
        }

        // Configure futuristic animation HUD
        if (animView != null) {
            ConverterAnimationManager.ConverterAnimItem animItem = new ConverterAnimationManager.ConverterAnimItem(
                    "toast_hud", "Toast Hologram Assembler", "Assembling dynamic toast framework",
                    ConverterAnimationManager.CAT_CINEMATIC, "⚡ STARK TOAST DALVIK ASSEMBLER ⚡",
                    ConverterAnimationManager.ENGINE_JARVIS_HUD, ConverterAnimationManager.PALETTE_CYBER_NEON, false, false);
            animView.applyAnimationConfig(animItem);
            animView.setLanguages(config != null && config.toastType != null ? config.toastType.toUpperCase() : "TOAST", "CLASSES.DEX");
            animView.updateState(15, "Initializing Dalvik Compiler...");
            animView.startAnimationLoop();
        }

        dialog.show();

        final String[] stages = new String[]{
                "Stage 1/5 • Analyzing View Properties, Colors & Shapes...",
                "Stage 2/5 • Generating Pure Java Bytecode & Dynamic Listeners...",
                "Stage 3/5 • Compiling Dalvik classes.dex via D8 Engine...",
                "Stage 4/5 • Verifying Adler32, SHA-1 Checksums & Magic Header...",
                "Stage 5/5 • Generating hook.smali & Bundling Audio Assets..."
        };

        final AtomicBoolean buildFinished = new AtomicBoolean(false);
        final AtomicBoolean animFinished = new AtomicBoolean(false);
        final ToastPackageBuilder.BuildResult[] resultHolder = new ToastPackageBuilder.BuildResult[1];

        // Background compilation thread
        new Thread(() -> {
            try {
                if (buildTask != null) {
                    resultHolder[0] = buildTask.execute();
                }
            } catch (Throwable t) {
                resultHolder[0] = ToastPackageBuilder.BuildResult.failure("Compilation error: " + t.getMessage());
            }
            buildFinished.set(true);

            MAIN_HANDLER.post(() -> {
                if (animFinished.get()) {
                    finishAndDismissToast(dialog, animView, layoutSuccess, resultHolder[0], listener);
                }
            });
        }).start();

        // Stage 1
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 1/5");
            if (tvPercentage != null) tvPercentage.setText("20%");
            if (progressBar != null) progressBar.setProgress(20);
            if (tvStatus != null) tvStatus.setText(stages[0]);
            if (animView != null) animView.updateState(20, stages[0]);
        }, 150);

        // Stage 2
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 2/5");
            if (tvPercentage != null) tvPercentage.setText("45%");
            if (progressBar != null) progressBar.setProgress(45);
            if (tvStatus != null) tvStatus.setText(stages[1]);
            if (animView != null) animView.updateState(45, stages[1]);
        }, 500);

        // Stage 3
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 3/5");
            if (tvPercentage != null) tvPercentage.setText("70%");
            if (progressBar != null) progressBar.setProgress(70);
            if (tvStatus != null) tvStatus.setText(stages[2]);
            if (animView != null) animView.updateState(70, stages[2]);
        }, 850);

        // Stage 4
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 4/5");
            if (tvPercentage != null) tvPercentage.setText("90%");
            if (progressBar != null) progressBar.setProgress(90);
            if (tvStatus != null) tvStatus.setText(stages[3]);
            if (animView != null) animView.updateState(90, stages[3]);
        }, 1250);

        // Stage 5 (100% Completed)
        MAIN_HANDLER.postDelayed(() -> {
            if (!dialog.isShowing()) return;
            if (tvStageCounter != null) tvStageCounter.setText("STAGE 5/5");
            if (tvPercentage != null) tvPercentage.setText("100%");
            if (progressBar != null) progressBar.setProgress(100);
            if (tvStatus != null) tvStatus.setText(stages[4]);
            if (animView != null) animView.updateState(100, "✓ Complete: classes.dex & hook.smali Ready!");

            animFinished.set(true);

            if (buildFinished.get()) {
                finishAndDismissToast(dialog, animView, layoutSuccess, resultHolder[0], listener);
            }
        }, 1600);
    }

    private static void finishAndDismissToast(
            Dialog dialog,
            ConversionAnimationView animView,
            View layoutSuccess,
            ToastPackageBuilder.BuildResult result,
            OnToastBuildCompleteListener listener
    ) {
        if (layoutSuccess != null) {
            layoutSuccess.setVisibility(View.VISIBLE);
            layoutSuccess.setAlpha(0f);
            layoutSuccess.animate().alpha(1f).setDuration(200).start();
        }

        MAIN_HANDLER.postDelayed(() -> {
            try {
                if (animView != null) {
                    animView.stopAnimationLoop();
                }
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            } catch (Throwable ignored) {}

            if (listener != null) {
                listener.onComplete(result);
            }
        }, 400);
    }

    public interface ClassToSmaliTask {
        com.android.modding.tools.helpers.ClassToSmaliProcessor.ConversionResult execute(
                com.android.modding.tools.generators.JavaToSmaliToolchain.ProgressListener listener);
    }

    public interface OnClassToSmaliCompleteListener {
        void onComplete(com.android.modding.tools.helpers.ClassToSmaliProcessor.ConversionResult result);
    }

    public static void showAndExecuteClassToSmali(
            Activity activity,
            String sourceName,
            ClassToSmaliTask task,
            OnClassToSmaliCompleteListener listener
    ) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_fullscreen_generation);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.argb(250, 3, 11, 18)));
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        }

        TextView tvBadge = dialog.findViewById(R.id.tv_gen_badge);
        TextView tvTitle = dialog.findViewById(R.id.tv_gen_target_title);
        TextView tvSubtitle = dialog.findViewById(R.id.tv_gen_subtitle);
        ConversionAnimationView animView = dialog.findViewById(R.id.gen_anim_view);
        TextView tvStageCounter = dialog.findViewById(R.id.tv_gen_stage_counter);
        TextView tvPercentage = dialog.findViewById(R.id.tv_gen_percentage);
        ProgressBar progressBar = dialog.findViewById(R.id.progress_bar_gen);
        TextView tvStatus = dialog.findViewById(R.id.tv_gen_status);
        View layoutSuccess = dialog.findViewById(R.id.layout_gen_success);
        TextView tvSpecs = dialog.findViewById(R.id.tv_gen_specs);

        String cleanTitle = sourceName != null && !sourceName.trim().isEmpty() ? sourceName : "Java to Smali";
        if (tvBadge != null) {
            tvBadge.setText("⚡ DALVIK / SMALI MATRIX ⚡");
        }
        if (tvTitle != null) {
            tvTitle.setText("⚡ " + cleanTitle.toUpperCase());
        }
        if (tvSubtitle != null) {
            tvSubtitle.setText("Compiling Java to Dalvik Bytecode • Baksmali Disassembler");
        }

        if (animView != null) {
            animView.loadSelectedFromPrefs();
            animView.setLanguages("JAVA", "SMALI");
            animView.updateState(10, "Initializing compilation workspace...");
            animView.startAnimationLoop();
        }

        dialog.show();

        final com.android.modding.tools.helpers.ClassToSmaliProcessor.ConversionResult[] resultHolder =
                new com.android.modding.tools.helpers.ClassToSmaliProcessor.ConversionResult[1];

        com.android.modding.tools.generators.JavaToSmaliToolchain.ProgressListener progressListener = (percent, stage) -> {
            MAIN_HANDLER.post(() -> {
                if (!dialog.isShowing()) return;
                if (tvPercentage != null) tvPercentage.setText(percent + "%");
                if (progressBar != null) progressBar.setProgress(percent);
                if (tvStatus != null) tvStatus.setText(stage);
                if (animView != null) animView.updateState(percent, stage);
                if (tvStageCounter != null) {
                    int st = Math.min(5, Math.max(1, (percent / 20) + 1));
                    tvStageCounter.setText("STAGE " + st + "/5");
                }
            });
        };

        new Thread(() -> {
            try {
                if (task != null) {
                    resultHolder[0] = task.execute(progressListener);
                }
            } catch (Throwable t) {
                resultHolder[0] = com.android.modding.tools.helpers.ClassToSmaliProcessor.ConversionResult.failure(
                        "Conversion Failed", t.getMessage(), null);
            }

            MAIN_HANDLER.post(() -> {
                if (tvPercentage != null) tvPercentage.setText("100%");
                if (progressBar != null) progressBar.setProgress(100);
                if (tvStatus != null) tvStatus.setText("✓ Compilation & Disassembly Finished!");
                if (animView != null) animView.updateState(100, "Ready!");
                if (layoutSuccess != null) {
                    layoutSuccess.setVisibility(View.VISIBLE);
                    layoutSuccess.setAlpha(0f);
                    layoutSuccess.animate().alpha(1f).setDuration(200).start();
                }

                MAIN_HANDLER.postDelayed(() -> {
                    try {
                        if (animView != null) animView.stopAnimationLoop();
                        if (dialog.isShowing()) dialog.dismiss();
                    } catch (Throwable ignored) {}

                    if (listener != null) {
                        listener.onComplete(resultHolder[0]);
                    }
                }, 400);
            });
        }).start();
    }
}
