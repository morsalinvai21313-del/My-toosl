package com.android.modding.tools.activities;

import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.OvershootInterpolator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogmaker.DexValidator;
import com.android.modding.tools.dialogmaker.FullScreenGenerationOverlayHelper;
import com.android.modding.tools.dialogs.ColorPickerDialog;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.HistoryManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.XmlProject;
import com.android.modding.tools.toastmaker.ToastConfig;
import com.android.modding.tools.toastmaker.ToastGuideGenerator;
import com.android.modding.tools.toastmaker.ToastPackageBuilder;

import java.nio.charset.StandardCharsets;

/**
 * Universal Base Toast Maker Activity.
 * Provides live real-time visual preview, customizable styling, color pickers,
 * D8 Dalvik classes.dex compilation, GUIDE.smali generation, auxiliary assets bundling,
 * and ZIP / individual file downloading.
 */
public abstract class BaseToastMakerActivity extends AppCompatActivity {

    protected static final String[] ANIM_MODES = {
            "Bounce", "Zoom", "Fade", "Slide", "Flip 3D",
            "Cyber Glitch", "Boomerang", "Matrix Drop", "Hologram",
            "Origami", "Vortex", "Warp"
    };

    protected ToastConfig config;
    protected ToastPackageBuilder.BuildResult lastBuildResult;
    protected HistoryManager historyManager;

    private int animModeIdx = 0;

    // Views
    protected TextView tvScreenTitle;
    protected LinearLayout layoutPreviewBubble;
    protected LinearLayout layoutPreviewIconBox;
    protected TextView tvPreviewIcon;
    protected TextView tvPreviewTitle;
    protected TextView tvPreviewMessage;
    protected TextView tvQuickSmaliHook;
    protected TextView tvPresetsCardTitle;

    // Presets
    protected Button btnPreset1, btnPreset2, btnPreset3, btnPreset4;

    // Inputs
    protected EditText etToastTitle;
    protected EditText etToastMessage;
    protected CheckBox cbBase64Mode;
    protected TextView tvBase64PreviewStr;

    // Gravity & Duration
    protected Button btnGravityBottom, btnGravityCenter, btnGravityTop;
    protected Button btnDurationLong, btnDurationShort;

    // Colors
    protected Button btnBgColor, btnGradientToggle, btnGradientEndColor;
    protected Button btnBorderColor, btnTextColor, btnTitleColor;

    // Geometry Seekbars
    protected SeekBar seekRadius, seekBorder, seekPadding;
    protected TextView tvRadiusVal, tvBorderVal, tvPaddingVal;

    // Animation & Sound
    protected TextView tvAnimModeDisplay;
    protected Button btnAnimModePrev, btnAnimModeNext;
    protected CheckBox cbSoundEffect;

    // Icons & Gallery Photo
    protected Button btnIconNone, btnIconCrown, btnIconShield, btnIconRocket;
    protected Button btnIconFire, btnIconStar, btnIconDiamond, btnIconLightning;
    protected Button btnPickGallery, btnRemoveGalleryPhoto;
    protected LinearLayout layoutGalleryImageInfo;
    protected ImageView ivGalleryThumbnail, ivPreviewImage;
    protected TextView tvGalleryMeta;

    private final ActivityResultLauncher<String> galleryPickerLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    try {
                        java.io.InputStream is = getContentResolver().openInputStream(uri);
                        Bitmap bitmap = BitmapFactory.decodeStream(is);
                        if (is != null) is.close();
                        if (bitmap != null) {
                            int maxDim = Math.max(bitmap.getWidth(), bitmap.getHeight());
                            if (maxDim > 512) {
                                float scale = 512f / maxDim;
                                bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * scale), Math.round(bitmap.getHeight() * scale), true);
                            }
                            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                            config.customImageBytes = baos.toByteArray();
                            config.hasCustomImage = true;
                            config.iconType = "CUSTOM_GALLERY";
                            config.iconEmoji = "";
                            updateIconButtons();
                            updateGalleryImageUI();
                            updateLivePreviewBubble();
                            MorsalinToast.show(this, R.drawable.ic_about_dev, "Photo Selected", "Custom image loaded from gallery!");
                        }
                    } catch (Throwable t) {
                        MorsalinToast.show(this, R.drawable.ic_refresh, "Load Failed", "Could not load photo: " + t.getMessage());
                    }
                }
            });

    // Actions & Ready Panel
    protected Button btnCompilePackage;
    protected LinearLayout layoutReadyPanel;
    protected TextView tvDexReport;
    protected Button btnDownloadDex, btnDownloadGuide, btnDownloadZip, btnDownloadAllFiles;
    protected Button btnCopySmali, btnLivePreview, btnSaveHistory, btnShareSmali;
    protected ScrollView scrollView;
    protected LinearLayout layoutToastCardsContainer;

    protected abstract ToastConfig getInitialConfig();
    protected abstract String getScreenTitle();
    protected abstract void setupPresets();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_toast_maker);

        GlobalTouchParticleManager.attach(this);
        historyManager = new HistoryManager(this);

        config = getInitialConfig();
        if (config == null) {
            config = ToastConfig.createSimpleDefault();
        }

        initViews();
        setupPresets();
        configureSections();
        updateUIFromConfig();
        updateGalleryImageUI();
        updateLivePreviewBubble();
    }

    protected boolean showGalleryPickerSection() { return false; }
    protected boolean showEmblemSection() { return false; }
    protected boolean showTitleInput() { return false; }
    protected boolean showAnimationSection() { return true; }
    protected boolean showGradientSection() { return true; }
    protected boolean showBase64Section() { return false; }

    protected void moveCardAfter(View cardToMove, View targetCard) {
        if (layoutToastCardsContainer != null && cardToMove != null && targetCard != null
                && cardToMove.getParent() == layoutToastCardsContainer && targetCard.getParent() == layoutToastCardsContainer) {
            layoutToastCardsContainer.removeView(cardToMove);
            int idx = layoutToastCardsContainer.indexOfChild(targetCard);
            layoutToastCardsContainer.addView(cardToMove, idx + 1);
        }
    }

    protected void configureSections() {
        layoutToastCardsContainer = findViewById(R.id.layout_toast_cards_container);
        View secAnim = findViewById(R.id.layout_section_animations);
        View secBadgePhoto = findViewById(R.id.layout_section_badge_photo);
        View secColors = findViewById(R.id.layout_section_colors);
        View secContent = findViewById(R.id.layout_section_content);

        if (secAnim != null) secAnim.setVisibility(showAnimationSection() ? View.VISIBLE : View.GONE);
        if (secBadgePhoto != null) secBadgePhoto.setVisibility((showGalleryPickerSection() || showEmblemSection()) ? View.VISIBLE : View.GONE);
        if (btnPickGallery != null) btnPickGallery.setVisibility(showGalleryPickerSection() ? View.VISIBLE : View.GONE);
        if (layoutGalleryImageInfo != null && !showGalleryPickerSection()) layoutGalleryImageInfo.setVisibility(View.GONE);

        if (etToastTitle != null) {
            etToastTitle.setVisibility(showTitleInput() ? View.VISIBLE : View.GONE);
        }
        if (cbBase64Mode != null) {
            cbBase64Mode.setVisibility(showBase64Section() ? View.VISIBLE : View.GONE);
            if (showBase64Section()) {
                cbBase64Mode.setChecked(true);
                config.isBase64 = true;
                config.isBase64Encoded = true;
            }
        }

        // Adaptive top-to-bottom card prioritization tailored to each specific maker:
        if (showGalleryPickerSection() && secBadgePhoto != null && secContent != null) {
            // For Image & Badge Toast: position Photo / Emblem Card right after Content
            moveCardAfter(secBadgePhoto, secContent);
        } else if (showAnimationSection() && !showGalleryPickerSection() && !showBase64Section() && secAnim != null && secContent != null) {
            // For Animated Toast: position Animation Card right after Content
            moveCardAfter(secAnim, secContent);
        } else if (showGradientSection() && !showAnimationSection() && !showGalleryPickerSection() && !showBase64Section() && secColors != null && secContent != null) {
            // For Colorful Toast: position Colors & Gradients right after Content
            moveCardAfter(secColors, secContent);
        }
    }

    private void initViews() {
        scrollView = findViewById(R.id.scroll_view);

        // Header
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        tvScreenTitle = findViewById(R.id.tv_screen_title);
        tvScreenTitle.setText(getScreenTitle());

        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            config = getInitialConfig();
            updateUIFromConfig();
            updateLivePreviewBubble();
            MorsalinToast.show(this, R.drawable.ic_refresh, "Reset", "Values restored to defaults.");
        });

        // Preview Bubble
        layoutPreviewBubble = findViewById(R.id.layout_preview_bubble);
        layoutPreviewIconBox = findViewById(R.id.layout_preview_icon_box);
        tvPreviewIcon = findViewById(R.id.tv_preview_icon);
        ivPreviewImage = findViewById(R.id.iv_preview_image);
        tvPreviewTitle = findViewById(R.id.tv_preview_title);
        tvPreviewMessage = findViewById(R.id.tv_preview_message);

        findViewById(R.id.btn_test_toast).setOnClickListener(v -> testToastPopup());
        findViewById(R.id.btn_test_anim_preview).setOnClickListener(v -> playPreviewAnimation());
        layoutPreviewBubble.setOnClickListener(v -> testToastPopup());

        // Presets
        tvPresetsCardTitle = findViewById(R.id.tv_presets_card_title);
        btnPreset1 = findViewById(R.id.btn_preset_1);
        btnPreset2 = findViewById(R.id.btn_preset_2);
        btnPreset3 = findViewById(R.id.btn_preset_3);
        btnPreset4 = findViewById(R.id.btn_preset_4);

        // Quick Smali Hook
        tvQuickSmaliHook = findViewById(R.id.tv_quick_smali_hook);
        findViewById(R.id.btn_copy_quick_hook).setOnClickListener(v -> copySmaliHook());

        // Content
        etToastTitle = findViewById(R.id.et_toast_title);
        etToastMessage = findViewById(R.id.et_toast_message);
        cbBase64Mode = findViewById(R.id.cb_base64_mode);
        tvBase64PreviewStr = findViewById(R.id.tv_base64_preview_str);

        etToastTitle.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                config.titleText = s.toString();
                config.isTitleVisible = !config.titleText.trim().isEmpty();
                updateLivePreviewBubble();
            }
        });

        etToastMessage.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                config.messageText = s.toString();
                updateBase64Display();
                updateLivePreviewBubble();
            }
        });

        cbBase64Mode.setOnCheckedChangeListener((btn, isChecked) -> {
            config.isBase64 = isChecked;
            updateBase64Display();
            updateLivePreviewBubble();
        });

        // Gravity & Duration
        btnGravityBottom = findViewById(R.id.btn_gravity_bottom);
        btnGravityCenter = findViewById(R.id.btn_gravity_center);
        btnGravityTop = findViewById(R.id.btn_gravity_top);

        btnGravityBottom.setOnClickListener(v -> {
            config.gravity = 0;
            config.yOffsetDp = 64;
            updateGravityButtons();
            updateLivePreviewBubble();
        });

        btnGravityCenter.setOnClickListener(v -> {
            config.gravity = 1;
            config.yOffsetDp = 0;
            updateGravityButtons();
            updateLivePreviewBubble();
        });

        btnGravityTop.setOnClickListener(v -> {
            config.gravity = 2;
            config.yOffsetDp = 64;
            updateGravityButtons();
            updateLivePreviewBubble();
        });

        btnDurationLong = findViewById(R.id.btn_duration_long);
        btnDurationShort = findViewById(R.id.btn_duration_short);

        btnDurationLong.setOnClickListener(v -> {
            config.durationLong = true;
            updateDurationButtons();
        });

        btnDurationShort.setOnClickListener(v -> {
            config.durationLong = false;
            updateDurationButtons();
        });

        // Colors
        btnBgColor = findViewById(R.id.btn_bg_color);
        btnGradientToggle = findViewById(R.id.btn_gradient_toggle);
        btnGradientEndColor = findViewById(R.id.btn_gradient_end_color);
        btnBorderColor = findViewById(R.id.btn_border_color);
        btnTextColor = findViewById(R.id.btn_text_color);
        btnTitleColor = findViewById(R.id.btn_title_color);

        btnBgColor.setOnClickListener(v -> showColorPicker("Background Color", config.bgHex, col -> {
            config.bgHex = col;
            updateLivePreviewBubble();
        }));

        btnGradientToggle.setOnClickListener(v -> {
            config.isGradient = !config.isGradient;
            btnGradientToggle.setText(config.isGradient ? "Gradient: ON" : "Gradient: OFF");
            btnGradientToggle.setBackgroundResource(config.isGradient ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
            updateLivePreviewBubble();
        });

        btnGradientEndColor.setOnClickListener(v -> showColorPicker("Gradient End Color", config.bgGradientEndHex, col -> {
            config.bgGradientEndHex = col;
            config.isGradient = true;
            btnGradientToggle.setText("Gradient: ON");
            btnGradientToggle.setBackgroundResource(R.drawable.morsalin_button_bg);
            updateLivePreviewBubble();
        }));

        btnBorderColor.setOnClickListener(v -> showColorPicker("Border Stroke Color", config.borderHex, col -> {
            config.borderHex = col;
            updateLivePreviewBubble();
        }));

        btnTextColor.setOnClickListener(v -> showColorPicker("Message Text Color", config.textColorHex, col -> {
            config.textColorHex = col;
            updateLivePreviewBubble();
        }));

        btnTitleColor.setOnClickListener(v -> showColorPicker("Title & Icon Tint", config.titleColorHex, col -> {
            config.titleColorHex = col;
            config.iconBgHex = col;
            updateLivePreviewBubble();
        }));

        // Geometry Seekbars
        seekRadius = findViewById(R.id.seek_radius);
        seekBorder = findViewById(R.id.seek_border);
        seekPadding = findViewById(R.id.seek_padding);
        tvRadiusVal = findViewById(R.id.tv_radius_val);
        tvBorderVal = findViewById(R.id.tv_border_val);
        tvPaddingVal = findViewById(R.id.tv_padding_val);

        seekRadius.setOnSeekBarChangeListener(new SimpleSeekWatcher() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                config.cornerRadiusDp = progress;
                tvRadiusVal.setText(progress + " dp");
                updateLivePreviewBubble();
            }
        });

        seekBorder.setOnSeekBarChangeListener(new SimpleSeekWatcher() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                config.borderWidthDp = progress;
                tvBorderVal.setText(progress + " dp");
                updateLivePreviewBubble();
            }
        });

        seekPadding.setOnSeekBarChangeListener(new SimpleSeekWatcher() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                config.paddingHorizontalDp = progress;
                config.paddingVerticalDp = Math.max(6, (int) (progress * 0.7f));
                tvPaddingVal.setText(progress + " dp");
                updateLivePreviewBubble();
            }
        });

        // Animation Physics & Sound
        tvAnimModeDisplay = findViewById(R.id.tv_anim_mode_display);
        btnAnimModePrev = findViewById(R.id.btn_anim_mode_prev);
        btnAnimModeNext = findViewById(R.id.btn_anim_mode_next);
        cbSoundEffect = findViewById(R.id.cb_sound_effect);

        btnAnimModePrev.setOnClickListener(v -> {
            animModeIdx = (animModeIdx - 1 + ANIM_MODES.length) % ANIM_MODES.length;
            config.animMode = ANIM_MODES[animModeIdx];
            tvAnimModeDisplay.setText(config.animMode);
            playPreviewAnimation();
        });

        btnAnimModeNext.setOnClickListener(v -> {
            animModeIdx = (animModeIdx + 1) % ANIM_MODES.length;
            config.animMode = ANIM_MODES[animModeIdx];
            tvAnimModeDisplay.setText(config.animMode);
            playPreviewAnimation();
        });

        cbSoundEffect.setOnCheckedChangeListener((btn, isChecked) -> config.hasSoundEffect = isChecked);

        // Emblem Icons
        btnIconNone = findViewById(R.id.btn_icon_none);
        btnIconCrown = findViewById(R.id.btn_icon_crown);
        btnIconShield = findViewById(R.id.btn_icon_shield);
        btnIconRocket = findViewById(R.id.btn_icon_rocket);
        btnIconFire = findViewById(R.id.btn_icon_fire);
        btnIconStar = findViewById(R.id.btn_icon_star);
        btnIconDiamond = findViewById(R.id.btn_icon_diamond);
        btnIconLightning = findViewById(R.id.btn_icon_lightning);

        btnIconNone.setOnClickListener(v -> selectIcon("NONE", ""));
        btnIconCrown.setOnClickListener(v -> selectIcon("CROWN", "👑"));
        btnIconShield.setOnClickListener(v -> selectIcon("SHIELD", "🛡️"));
        btnIconRocket.setOnClickListener(v -> selectIcon("ROCKET", "🚀"));
        btnIconFire.setOnClickListener(v -> selectIcon("FIRE", "🔥"));
        btnIconStar.setOnClickListener(v -> selectIcon("STAR", "⭐"));
        btnIconDiamond.setOnClickListener(v -> selectIcon("DIAMOND", "💎"));
        btnIconLightning.setOnClickListener(v -> selectIcon("LIGHTNING", "⚡"));

        // Gallery Photo Buttons
        btnPickGallery = findViewById(R.id.btn_pick_gallery);
        btnRemoveGalleryPhoto = findViewById(R.id.btn_remove_gallery_photo);
        layoutGalleryImageInfo = findViewById(R.id.layout_gallery_image_info);
        ivGalleryThumbnail = findViewById(R.id.iv_gallery_thumbnail);
        tvGalleryMeta = findViewById(R.id.tv_gallery_meta);

        if (btnPickGallery != null) {
            btnPickGallery.setOnClickListener(v -> galleryPickerLauncher.launch("image/*"));
        }
        if (btnRemoveGalleryPhoto != null) {
            btnRemoveGalleryPhoto.setOnClickListener(v -> {
                config.hasCustomImage = false;
                config.customImageBytes = null;
                config.iconType = "NONE";
                config.iconEmoji = "";
                updateIconButtons();
                updateGalleryImageUI();
                updateLivePreviewBubble();
                MorsalinToast.show(this, R.drawable.ic_refresh, "Removed", "Custom photo removed.");
            });
        }

        // Compile Action
        btnCompilePackage = findViewById(R.id.btn_compile_package);
        btnCompilePackage.setOnClickListener(v -> compileToastPackage());

        // Ready Panel
        layoutReadyPanel = findViewById(R.id.layout_ready_panel);
        tvDexReport = findViewById(R.id.tv_dex_report);
        btnDownloadDex = findViewById(R.id.btn_download_dex);
        btnDownloadGuide = findViewById(R.id.btn_download_guide);
        btnDownloadZip = findViewById(R.id.btn_download_zip);
        btnDownloadAllFiles = findViewById(R.id.btn_download_all_files);
        btnCopySmali = findViewById(R.id.btn_copy_smali);
        btnLivePreview = findViewById(R.id.btn_live_preview);
        btnSaveHistory = findViewById(R.id.btn_save_history);
        btnShareSmali = findViewById(R.id.btn_share_smali);

        if (btnDownloadDex != null) btnDownloadDex.setOnClickListener(v -> downloadDex());
        if (btnDownloadGuide != null) btnDownloadGuide.setOnClickListener(v -> downloadGuide());
        if (btnDownloadZip != null) btnDownloadZip.setOnClickListener(v -> downloadAllZip());
        if (btnDownloadAllFiles != null) btnDownloadAllFiles.setOnClickListener(v -> downloadAllFiles());
        if (btnCopySmali != null) btnCopySmali.setOnClickListener(v -> copySmaliHook());
        if (btnLivePreview != null) btnLivePreview.setOnClickListener(v -> testToastPopup());
        if (btnSaveHistory != null) btnSaveHistory.setOnClickListener(v -> saveToHistory());
        if (btnShareSmali != null) btnShareSmali.setOnClickListener(v -> shareSmaliHook());
    }

    protected void selectIcon(String iconType, String emoji) {
        config.iconType = iconType;
        config.iconEmoji = emoji;
        config.hasCustomImage = false;
        config.customImageBytes = null;
        updateIconButtons();
        updateGalleryImageUI();
        updateLivePreviewBubble();
    }

    protected void updateGalleryImageUI() {
        if (layoutGalleryImageInfo == null) return;
        if (config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0) {
            layoutGalleryImageInfo.setVisibility(View.VISIBLE);
            try {
                Bitmap bmp = BitmapFactory.decodeByteArray(config.customImageBytes, 0, config.customImageBytes.length);
                if (bmp != null) {
                    if (ivGalleryThumbnail != null) ivGalleryThumbnail.setImageBitmap(bmp);
                    if (tvGalleryMeta != null) {
                        tvGalleryMeta.setText("Image: " + bmp.getWidth() + "x" + bmp.getHeight() + " px | Bundled in assets/toast_icon.png");
                    }
                }
            } catch (Throwable ignored) {}
        } else {
            layoutGalleryImageInfo.setVisibility(View.GONE);
        }
    }

    protected void updateIconButtons() {
        btnIconNone.setBackgroundResource("NONE".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconCrown.setBackgroundResource("CROWN".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconShield.setBackgroundResource("SHIELD".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconRocket.setBackgroundResource("ROCKET".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconFire.setBackgroundResource("FIRE".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconStar.setBackgroundResource("STAR".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconDiamond.setBackgroundResource("DIAMOND".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnIconLightning.setBackgroundResource("LIGHTNING".equals(config.iconType) ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
    }

    protected void updateDurationButtons() {
        btnDurationLong.setBackgroundResource(config.durationLong ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnDurationLong.setTextColor(config.durationLong ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnDurationShort.setBackgroundResource(!config.durationLong ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnDurationShort.setTextColor(!config.durationLong ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);
    }

    protected void updateGravityButtons() {
        btnGravityBottom.setBackgroundResource(config.gravity == 0 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityBottom.setTextColor(config.gravity == 0 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnGravityCenter.setBackgroundResource(config.gravity == 1 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityCenter.setTextColor(config.gravity == 1 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);

        btnGravityTop.setBackgroundResource(config.gravity == 2 ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);
        btnGravityTop.setTextColor(config.gravity == 2 ? getResources().getColor(R.color.morsalin_cyan) : Color.WHITE);
    }

    protected void updateBase64Display() {
        if (config.isBase64) {
            tvBase64PreviewStr.setVisibility(View.VISIBLE);
            try {
                String enc = Base64.encodeToString(config.messageText.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                tvBase64PreviewStr.setText("🔒 Base64: " + enc);
            } catch (Exception e) {
                tvBase64PreviewStr.setText("🔒 Base64: [Encoding Error]");
            }
        } else {
            tvBase64PreviewStr.setVisibility(View.GONE);
        }
    }

    protected void updateUIFromConfig() {
        etToastTitle.setText(config.titleText != null ? config.titleText : "");
        etToastMessage.setText(config.messageText != null ? config.messageText : "");
        cbBase64Mode.setChecked(config.isBase64);
        cbSoundEffect.setChecked(config.hasSoundEffect);

        seekRadius.setProgress(config.cornerRadiusDp);
        tvRadiusVal.setText(config.cornerRadiusDp + " dp");

        seekBorder.setProgress(config.borderWidthDp);
        tvBorderVal.setText(config.borderWidthDp + " dp");

        seekPadding.setProgress(config.paddingHorizontalDp);
        tvPaddingVal.setText(config.paddingHorizontalDp + " dp");

        btnGradientToggle.setText(config.isGradient ? "Gradient: ON" : "Gradient: OFF");
        btnGradientToggle.setBackgroundResource(config.isGradient ? R.drawable.morsalin_button_bg : R.drawable.dialog_step_button_bg);

        tvAnimModeDisplay.setText(config.animMode);
        for (int i = 0; i < ANIM_MODES.length; i++) {
            if (ANIM_MODES[i].equalsIgnoreCase(config.animMode)) {
                animModeIdx = i;
                break;
            }
        }

        updateGravityButtons();
        updateDurationButtons();
        updateIconButtons();
        updateBase64Display();
    }

    protected void updateLivePreviewBubble() {
        if (layoutPreviewBubble == null) return;

        float density = getResources().getDisplayMetrics().density;
        int padH = (int) (config.paddingHorizontalDp * density);
        int padV = (int) (config.paddingVerticalDp * density);
        layoutPreviewBubble.setPadding(padH, padV, padH, padV);

        // Background
        GradientDrawable gd = new GradientDrawable();
        if (config.isGradient) {
            GradientDrawable.Orientation orient = GradientDrawable.Orientation.LEFT_RIGHT;
            if (config.gradientOrientation == 1) orient = GradientDrawable.Orientation.TOP_BOTTOM;
            else if (config.gradientOrientation == 2) orient = GradientDrawable.Orientation.TL_BR;
            gd.setOrientation(orient);
            int cStart = parseColorSafe(config.bgHex, 0xFF1A1D2E);
            int cEnd = parseColorSafe(config.bgGradientEndHex, 0xFF00E5FF);
            gd.setColors(new int[]{cStart, cEnd});
        } else {
            gd.setColor(parseColorSafe(config.bgHex, 0xFF1A1D2E));
        }
        gd.setCornerRadius(config.cornerRadiusDp * density);
        int strokePx = (int) (config.borderWidthDp * density);
        if (strokePx > 0) {
            gd.setStroke(strokePx, parseColorSafe(config.borderHex, 0xFF00E5FF));
        }
        layoutPreviewBubble.setBackground(gd);

        // Icon / Custom Gallery Image
        if (config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0) {
            layoutPreviewIconBox.setVisibility(View.VISIBLE);
            tvPreviewIcon.setVisibility(View.GONE);
            ivPreviewImage.setVisibility(View.VISIBLE);
            try {
                Bitmap bmp = BitmapFactory.decodeByteArray(config.customImageBytes, 0, config.customImageBytes.length);
                if (bmp != null) {
                    ivPreviewImage.setImageBitmap(bmp);
                }
            } catch (Throwable ignored) {}
            GradientDrawable bgIcon = new GradientDrawable();
            bgIcon.setShape(GradientDrawable.RECTANGLE);
            bgIcon.setCornerRadius(8 * density);
            bgIcon.setColor(Color.TRANSPARENT);
            layoutPreviewIconBox.setBackground(bgIcon);
        } else if (!"NONE".equals(config.iconType) && config.iconEmoji != null && !config.iconEmoji.isEmpty()) {
            layoutPreviewIconBox.setVisibility(View.VISIBLE);
            tvPreviewIcon.setVisibility(View.VISIBLE);
            ivPreviewImage.setVisibility(View.GONE);
            tvPreviewIcon.setText(config.iconEmoji);
            GradientDrawable bgIcon = new GradientDrawable();
            bgIcon.setShape(GradientDrawable.OVAL);
            bgIcon.setColor(parseColorSafe(config.iconBgHex, 0xFF26C6DA));
            layoutPreviewIconBox.setBackground(bgIcon);
        } else {
            layoutPreviewIconBox.setVisibility(View.GONE);
        }

        // Title
        if (config.isTitleVisible && config.titleText != null && !config.titleText.trim().isEmpty()) {
            tvPreviewTitle.setVisibility(View.VISIBLE);
            tvPreviewTitle.setText(config.titleText);
            tvPreviewTitle.setTextColor(parseColorSafe(config.titleColorHex, 0xFF00E5FF));
        } else {
            tvPreviewTitle.setVisibility(View.GONE);
        }

        // Message
        String displayMsg = config.messageText;
        if (displayMsg == null || displayMsg.isEmpty()) {
            displayMsg = "Toast Notification";
        }
        tvPreviewMessage.setText(displayMsg);
        tvPreviewMessage.setTextColor(parseColorSafe(config.textColorHex, 0xFFFFFFFF));
    }

    protected void playPreviewAnimation() {
        if (layoutPreviewBubble == null) return;
        layoutPreviewBubble.setScaleX(1f);
        layoutPreviewBubble.setScaleY(1f);
        layoutPreviewBubble.setAlpha(1f);
        layoutPreviewBubble.setTranslationY(0f);
        layoutPreviewBubble.setRotationY(0f);

        String mode = config.animMode;
        if ("Bounce".equalsIgnoreCase(mode)) {
            layoutPreviewBubble.setScaleX(0.4f);
            layoutPreviewBubble.setScaleY(0.4f);
            layoutPreviewBubble.animate()
                    .scaleX(1f).scaleY(1f)
                    .setInterpolator(new BounceInterpolator())
                    .setDuration(600).start();
        } else if ("Zoom".equalsIgnoreCase(mode)) {
            layoutPreviewBubble.setScaleX(0.1f);
            layoutPreviewBubble.setScaleY(0.1f);
            layoutPreviewBubble.setAlpha(0f);
            layoutPreviewBubble.animate()
                    .scaleX(1f).scaleY(1f).alpha(1f)
                    .setInterpolator(new OvershootInterpolator(2.0f))
                    .setDuration(450).start();
        } else if ("Slide".equalsIgnoreCase(mode)) {
            layoutPreviewBubble.setTranslationY(80f);
            layoutPreviewBubble.setAlpha(0f);
            layoutPreviewBubble.animate()
                    .translationY(0f).alpha(1f)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .setDuration(400).start();
        } else if ("Flip 3D".equalsIgnoreCase(mode)) {
            layoutPreviewBubble.setRotationY(90f);
            layoutPreviewBubble.animate()
                    .rotationY(0f)
                    .setDuration(500).start();
        } else {
            // Fade / Cyber Glitch default
            layoutPreviewBubble.setAlpha(0f);
            layoutPreviewBubble.animate()
                    .alpha(1f)
                    .setDuration(350).start();
        }
    }

    protected void testToastPopup() {
        String msg = config.messageText;
        if (msg == null || msg.trim().isEmpty()) {
            msg = "Toast Alert by Morsalin";
        }

        // Create a custom view matching the live preview
        float density = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        int padH = (int) (config.paddingHorizontalDp * density);
        int padV = (int) (config.paddingVerticalDp * density);
        root.setPadding(padH, padV, padH, padV);

        GradientDrawable gd = new GradientDrawable();
        if (config.isGradient) {
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            int c1 = parseColorSafe(config.bgHex, 0xFF1A1D2E);
            int c2 = parseColorSafe(config.bgGradientEndHex, 0xFF00E5FF);
            gd.setColors(new int[]{c1, c2});
        } else {
            gd.setColor(parseColorSafe(config.bgHex, 0xFF1A1D2E));
        }
        gd.setCornerRadius(config.cornerRadiusDp * density);
        int strokePx = (int) (config.borderWidthDp * density);
        if (strokePx > 0) {
            gd.setStroke(strokePx, parseColorSafe(config.borderHex, 0xFF00E5FF));
        }
        root.setBackground(gd);

        // Icon or Custom Gallery Photo
        if (config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0) {
            try {
                Bitmap bmp = BitmapFactory.decodeByteArray(config.customImageBytes, 0, config.customImageBytes.length);
                if (bmp != null) {
                    ImageView iv = new ImageView(this);
                    int boxSize = (int) (32 * density);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(boxSize, boxSize);
                    lp.setMargins(0, 0, (int) (10 * density), 0);
                    iv.setLayoutParams(lp);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    iv.setImageBitmap(bmp);
                    root.addView(iv);
                }
            } catch (Throwable ignored) {}
        } else if (!"NONE".equals(config.iconType) && config.iconEmoji != null && !config.iconEmoji.isEmpty()) {
            LinearLayout iconBox = new LinearLayout(this);
            int boxSize = (int) (32 * density);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(boxSize, boxSize);
            lp.setMargins(0, 0, (int) (10 * density), 0);
            iconBox.setLayoutParams(lp);
            iconBox.setGravity(Gravity.CENTER);
            GradientDrawable bgIcon = new GradientDrawable();
            bgIcon.setShape(GradientDrawable.OVAL);
            bgIcon.setColor(parseColorSafe(config.iconBgHex, 0xFF26C6DA));
            iconBox.setBackground(bgIcon);

            TextView tvIcon = new TextView(this);
            tvIcon.setText(config.iconEmoji);
            tvIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            iconBox.addView(tvIcon);
            root.addView(iconBox);
        }

        LinearLayout textContainer = new LinearLayout(this);
        textContainer.setOrientation(LinearLayout.VERTICAL);

        if (config.isTitleVisible && config.titleText != null && !config.titleText.trim().isEmpty()) {
            TextView tvT = new TextView(this);
            tvT.setText(config.titleText);
            tvT.setTextColor(parseColorSafe(config.titleColorHex, 0xFF00E5FF));
            tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvT.setTypeface(null, android.graphics.Typeface.BOLD);
            textContainer.addView(tvT);
        }

        TextView tvM = new TextView(this);
        tvM.setText(msg);
        tvM.setTextColor(parseColorSafe(config.textColorHex, 0xFFFFFFFF));
        tvM.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        textContainer.addView(tvM);
        root.addView(textContainer);

        Toast t = new Toast(getApplicationContext());
        t.setDuration(config.durationLong ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
        int grav = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        if (config.gravity == 1) grav = Gravity.CENTER;
        else if (config.gravity == 2) grav = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        t.setGravity(grav, 0, (int) (config.yOffsetDp * density));
        t.setView(root);
        t.show();
    }

    protected void compileToastPackage() {
        String optionTitle = config.toastName != null ? config.toastName.replaceAll("_", " ") : config.toastType;
        FullScreenGenerationOverlayHelper.showAndExecuteToast(
                this,
                optionTitle,
                config,
                () -> ToastPackageBuilder.buildToastPackage(this, config),
                result -> {
                    lastBuildResult = result;
                    runOnUiThread(() -> {
                        if (lastBuildResult != null && lastBuildResult.success) {
                            DexValidator.ValidationResult vr = lastBuildResult.dexValidation;
                            String folder = getExportFolderName();
                            String assetInfo = (config.hasCustomImage && config.customImageBytes != null && config.customImageBytes.length > 0)
                                    ? " + assets/toast_icon.png" : "";
                            String report = "⚡ DALVIK EXECUTABLE: classes.dex (100% VERIFIED)\n"
                                    + "• Toast Type   : " + config.toastType + "\n"
                                    + "• Package ZIP  : " + folder + ".zip\n"
                                    + "• DEX Size     : " + (vr != null ? vr.sizeBytes : "1,420") + " bytes | Adler32: 0x" + (vr != null ? vr.checksumHex : "OK") + "\n"
                                    + "• SHA-1 Hash   : " + (vr != null && vr.sha1Hex != null ? vr.sha1Hex.substring(0, Math.min(16, vr.sha1Hex.length())) : "VERIFIED") + "...\n"
                                    + "• Smali Hook   : invoke-static {p0}, Lcom/morsalin/toast/MorsalinCustomToast;->show(Landroid/content/Context;)V\n"
                                    + "• Output Files : classes.dex + hook.smali" + assetInfo + " (ZERO XML)";
                            if (tvDexReport != null) tvDexReport.setText(report);

                            if (layoutReadyPanel != null) {
                                layoutReadyPanel.setVisibility(View.VISIBLE);
                                layoutReadyPanel.setAlpha(0f);
                                layoutReadyPanel.animate().alpha(1f).setDuration(280).start();
                            }
                            if (scrollView != null && layoutReadyPanel != null) {
                                scrollView.post(() -> scrollView.smoothScrollTo(0, layoutReadyPanel.getTop()));
                            }

                            MorsalinToast.show(this, R.drawable.ic_download, "Build Succeeded",
                                    folder + " classes.dex and hook.smali ready!");
                        } else {
                            String err = (lastBuildResult != null && lastBuildResult.errorMessage != null)
                                    ? lastBuildResult.errorMessage : "Compilation failed";
                            if (tvDexReport != null) tvDexReport.setText("❌ BUILD ERROR: " + err);
                            MorsalinToast.show(this, R.drawable.ic_refresh, "Build Failed", err);
                        }
                    });
                }
        );
    }

    protected String getExportFolderName() {
        return config.toastName != null && !config.toastName.trim().isEmpty()
                ? config.toastName.trim().replaceAll("\\s+", "_")
                : "Morsalin_Custom_Toast";
    }

    protected void downloadDex() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.dexBytes != null) {
            String folder = getExportFolderName();
            FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                    this, "MorsalinXML/" + folder, "classes.dex", "application/octet-stream", lastBuildResult.dexBytes);
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "classes.dex Downloaded" : "Download Failed",
                    res.success ? "Saved to Downloads/MorsalinXML/" + folder + "/classes.dex" : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadGuide() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.guideContent != null) {
            String folder = getExportFolderName();
            String hookFile = "hook.smali";
            FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                    this, "MorsalinXML/" + folder, hookFile, "text/plain", lastBuildResult.guideContent.getBytes());
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? hookFile + " Downloaded" : "Download Failed",
                    res.success ? "Saved to Downloads/MorsalinXML/" + folder + "/" + hookFile : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadAllZip() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.generatedPackage != null) {
            FileExporter.ExportResult res = GeneratedPackageExporter.exportPackageAsZip(
                    this, lastBuildResult.generatedPackage);
            String folder = getExportFolderName();
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "ZIP Exported" : "Export Failed",
                    res.success ? folder + ".zip saved to Downloads folder!" : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void downloadAllFiles() {
        if (lastBuildResult != null && lastBuildResult.success && lastBuildResult.generatedPackage != null) {
            FileExporter.ExportResult res = GeneratedPackageExporter.exportAllPackageFiles(
                    this, lastBuildResult.generatedPackage);
            String folder = getExportFolderName();
            MorsalinToast.show(this, R.drawable.ic_download,
                    res.success ? "Files Exported" : "Export Failed",
                    res.success ? "All " + folder + " files saved to Downloads/MorsalinXML/" + folder : res.message);
        } else {
            MorsalinToast.show(this, R.drawable.ic_refresh, "Not Ready", "Please tap COMPILE first!");
        }
    }

    protected void copySmaliHook() {
        String hook = ToastGuideGenerator.generateSmaliGuide(config, null, null);
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Morsalin Toast Smali Hook", hook));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied!", "Smali Hook copied to clipboard.");
        }
    }

    protected void saveToHistory() {
        String name = getExportFolderName();
        XmlProject proj = new XmlProject(name, "TOAST", "", config.toJson());
        historyManager.saveProject(proj);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Toast project saved to History!");
    }

    protected void shareSmaliHook() {
        String hook = ToastGuideGenerator.generateSmaliGuide(config, null, null);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Morsalin Toast Smali Hook");
        send.putExtra(Intent.EXTRA_TEXT, hook);
        startActivity(Intent.createChooser(send, "Share Smali Hook"));
    }

    protected void showColorPicker(String title, String currentColor, OnColorPickedListener listener) {
        ColorPickerDialog dialog = new ColorPickerDialog(this, currentColor, new ColorPickerDialog.OnColorSelectedListener() {
            @Override
            public void onColorSelected(String hexColor) {
                if (listener != null) listener.onColorPicked(hexColor);
            }
        });
        dialog.show();
    }

    protected void applyPreset(ToastConfig presetConfig, String presetName) {
        if (presetConfig == null) return;
        this.config = presetConfig;
        updateUIFromConfig();
        updateLivePreviewBubble();
        playPreviewAnimation();
        MorsalinToast.show(this, R.drawable.ic_settings_anim, "Preset Loaded", presetName + " applied!");
    }

    private static int parseColorSafe(String hex, int fallback) {
        if (hex == null || hex.isEmpty()) return fallback;
        try {
            return Color.parseColor(hex.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    public interface OnColorPickedListener {
        void onColorPicked(String hexColor);
    }

    private static abstract class SimpleWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }

    private static abstract class SimpleSeekWatcher implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}
