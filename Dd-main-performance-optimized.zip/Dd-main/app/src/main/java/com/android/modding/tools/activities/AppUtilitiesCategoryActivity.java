package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.SocialButtonAnimationHelper;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.generators.XmlParser;

import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AppUtilitiesCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_app_utilities);

        GlobalTouchParticleManager.attach(this);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_category_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        View.OnClickListener openAbout = v -> {
            com.android.modding.tools.dialogs.MorsalinDialogHelper.showAboutDialog(this);
        };

        findViewById(R.id.btn_category_about).setOnClickListener(openAbout);

        // Social micro-animations
        SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // 4 Utility actions
        findViewById(R.id.btn_util_history).setOnClickListener(v -> launchTool(HistoryActivity.class));

        findViewById(R.id.btn_util_import).setOnClickListener(v -> showImportDialog());

        findViewById(R.id.btn_util_presets).setOnClickListener(v -> launchTool(PresetsActivity.class));

        findViewById(R.id.btn_util_settings).setOnClickListener(v -> launchTool(SettingsActivity.class));
    }

    private void launchTool(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    private void showImportDialog() {
        Dialog dialog = new Dialog(this, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_import_xml);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.90),
                    LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        EditText etXml = dialog.findViewById(R.id.et_import_xml_input);
        Button btnPaste = dialog.findViewById(R.id.btn_import_paste);
        Button btnCancel = dialog.findViewById(R.id.btn_import_cancel);
        Button btnConfirm = dialog.findViewById(R.id.btn_import_confirm);

        if (btnPaste != null) {
            btnPaste.setOnClickListener(v -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip() != null
                        && clipboard.getPrimaryClip().getItemCount() > 0) {
                    CharSequence text = clipboard.getPrimaryClip().getItemAt(0).getText();
                    if (text != null && text.length() > 0) {
                        etXml.setText(text.toString());
                        MorsalinToast.show(this, R.drawable.ic_content_copy, "Pasted", "XML code pasted from clipboard!");
                    } else {
                        Toast.makeText(this, "Clipboard is empty.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Clipboard is empty.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnConfirm != null) {
            btnConfirm.setOnClickListener(v -> {
                String xml = etXml.getText().toString().trim();
                if (xml.isEmpty()) {
                    Toast.makeText(this, "Please paste XML code first.", Toast.LENGTH_SHORT).show();
                    return;
                }

                XmlParser.ParseResult result = XmlParser.parseXml(xml);
                if (!result.success) {
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                    return;
                }

                dialog.dismiss();

                Intent intent;
                String typeName;
                boolean hasGradient = xml.contains("<gradient");
                boolean isMultiLayer = "layer-list".equals(result.rootTag) || (result.layerList != null && result.layerList.size() > 1);

                if (isMultiLayer) {
                    intent = new Intent(this, ThreeDEditorActivity.class);
                    typeName = "3D / Multi-Layer XML";
                } else if (hasGradient || ("shape".equals(result.rootTag) && result.singleLayer != null && result.singleLayer.isGradient())) {
                    intent = new Intent(this, GradientEditorActivity.class);
                    typeName = "Gradient XML";
                } else if ("shape".equals(result.rootTag) || ("selector".equals(result.rootTag) && !hasGradient)) {
                    intent = new Intent(this, NormalEditorActivity.class);
                    typeName = "Normal Shape XML";
                } else if (xml.contains("<LinearLayout") || xml.contains("<RelativeLayout") || xml.contains("<ConstraintLayout") || xml.contains("<FrameLayout")) {
                    intent = new Intent(this, LayoutXmlEditorActivity.class);
                    typeName = "Layout XML";
                } else {
                    intent = new Intent(this, ThreeDEditorActivity.class);
                    typeName = "Custom XML";
                }

                intent.putExtra("EXTRA_IMPORTED_XML", xml);
                MorsalinToast.show(this, R.drawable.ic_content_copy, "XML Detected", "Detected " + typeName + "! Opening for review and editing...");
                startActivity(intent);
                TransitionAnimationManager.applyForward(this);
            });
        }

        dialog.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
