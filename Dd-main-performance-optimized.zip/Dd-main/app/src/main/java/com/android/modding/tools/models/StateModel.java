package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StateModel implements Serializable {
    public static final String STATE_NORMAL = "normal";
    public static final String STATE_CHECKED = "checked";
    public static final String STATE_PRESSED = "pressed";
    public static final String STATE_FOCUSED = "focused";
    public static final String STATE_SELECTED = "selected";
    public static final String STATE_DISABLED = "disabled";

    private String stateName = STATE_NORMAL;
    private boolean active = true;
    private List<LayerModel> layers = new ArrayList<>();

    public StateModel() {
        layers.add(new LayerModel("Layer 1"));
    }

    public StateModel(String stateName) {
        this.stateName = stateName;
        layers.add(new LayerModel("Layer 1"));
    }

    public String getStateName() {
        return stateName != null ? stateName : STATE_NORMAL;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public List<LayerModel> getLayers() {
        if (layers == null) layers = new ArrayList<>();
        return layers;
    }

    public void setLayers(List<LayerModel> layers) {
        this.layers = layers;
    }

    public StateModel copy() {
        StateModel copy = new StateModel(stateName);
        copy.active = this.active;
        copy.layers = new ArrayList<>();
        if (this.layers != null) {
            for (LayerModel layer : this.layers) {
                copy.layers.add(layer.copy());
            }
        }
        return copy;
    }
}
