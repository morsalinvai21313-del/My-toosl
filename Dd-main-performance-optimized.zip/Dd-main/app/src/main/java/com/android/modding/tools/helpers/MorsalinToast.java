package com.android.modding.tools.helpers;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

public class MorsalinToast {

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static View currentToastView = null;
    private static Runnable dismissRunnable = null;

    public static void show(Activity activity, String message) {
        show(activity, R.drawable.ic_settings_anim, "Notification", message);
    }

    public static void show(Activity activity, String title, String message) {
        show(activity, R.drawable.ic_settings_anim, title, message);
    }

    public static void show(Activity activity, int iconRes, String title, String message) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;

        MAIN_HANDLER.post(() -> {
            ViewGroup decorView = (ViewGroup) activity.findViewById(android.R.id.content);
            if (decorView == null) return;

            // Remove previous active notification immediately
            if (currentToastView != null) {
                if (dismissRunnable != null) {
                    MAIN_HANDLER.removeCallbacks(dismissRunnable);
                }
                decorView.removeView(currentToastView);
                currentToastView = null;
            }

            LayoutInflater inflater = LayoutInflater.from(activity);
            View view = inflater.inflate(R.layout.view_morsalin_notification, decorView, false);

            ImageView ivIcon = view.findViewById(R.id.iv_notif_icon);
            TextView tvTitle = view.findViewById(R.id.tv_notif_title);
            TextView tvMessage = view.findViewById(R.id.tv_notif_message);

            if (iconRes != 0) {
                ivIcon.setImageResource(iconRes);
            }
            tvTitle.setText(title != null ? title : "Notification");
            tvMessage.setText(message != null ? message : "");

            // Initial animation state: pushed down and invisible
            view.setTranslationY(200f);
            view.setAlpha(0f);

            decorView.addView(view);
            currentToastView = view;

            // Entrance animation: pop up smoothly
            view.animate()
                    .translationY(0f)
                    .alpha(1f)
                    .setDuration(320)
                    .setInterpolator(new OvershootInterpolator(1.1f))
                    .start();

            view.setOnClickListener(v -> dismissToast(decorView, view));

            dismissRunnable = () -> dismissToast(decorView, view);
            MAIN_HANDLER.postDelayed(dismissRunnable, 3500);
        });
    }

    private static void dismissToast(ViewGroup parent, View view) {
        if (view == null || parent == null) return;
        view.animate()
                .translationY(180f)
                .alpha(0f)
                .setDuration(240)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(() -> {
                    parent.removeView(view);
                    if (currentToastView == view) {
                        currentToastView = null;
                    }
                })
                .start();
    }

    public static void showCopy(Activity activity, String message) {
        show(activity, R.drawable.ic_content_copy, "Copied to Clipboard!", message);
    }

    public static void showDownload(Activity activity, String message) {
        show(activity, R.drawable.ic_download, "XML Export Downloaded!", message);
    }

    public static void showSave(Activity activity, String message) {
        show(activity, R.drawable.ic_save, "Saved to Project History!", message);
    }

    public static void showReset(Activity activity, String message) {
        show(activity, R.drawable.ic_refresh, "Configuration Reset", message);
    }

    public static void showSuccess(Activity activity, String title, String message) {
        show(activity, R.drawable.ic_content_copy, title, message);
    }
}
