package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class LayerModel implements Serializable {
    public static final String SHAPE_RECTANGLE = "rectangle";
    public static final String SHAPE_OVAL = "oval";
    public static final String SHAPE_LINE = "line";
    public static final String SHAPE_RING = "ring";

    private String name = "Layer 1";
    private boolean enabled = true;
    private boolean isGradient = false;
    private String solidColor = "#00000000";
    private String shapeType = SHAPE_RECTANGLE;

    private GradientModel gradient = new GradientModel();
    private StrokeModel stroke = new StrokeModel();
    private CornersModel corners = new CornersModel();
    private InsetsModel insets = new InsetsModel();

    public LayerModel() {}

    public LayerModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name != null ? name : "Layer";
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isGradient() {
        return isGradient;
    }

    public void setGradient(boolean gradient) {
        isGradient = gradient;
    }

    public String getSolidColor() {
        return solidColor != null ? solidColor : "#00000000";
    }

    public void setSolidColor(String solidColor) {
        this.solidColor = solidColor;
    }

    public String getShapeType() {
        return shapeType != null ? shapeType : SHAPE_RECTANGLE;
    }

    public void setShapeType(String shapeType) {
        this.shapeType = shapeType;
    }

    public GradientModel getGradient() {
        if (gradient == null) gradient = new GradientModel();
        return gradient;
    }

    public void setGradient(GradientModel gradient) {
        this.gradient = gradient;
    }

    public StrokeModel getStroke() {
        if (stroke == null) stroke = new StrokeModel();
        return stroke;
    }

    public void setStroke(StrokeModel stroke) {
        this.stroke = stroke;
    }

    public CornersModel getCorners() {
        if (corners == null) corners = new CornersModel();
        return corners;
    }

    public void setCorners(CornersModel corners) {
        this.corners = corners;
    }

    public InsetsModel getInsets() {
        if (insets == null) insets = new InsetsModel();
        return insets;
    }

    public void setInsets(InsetsModel insets) {
        this.insets = insets;
    }

    public LayerModel copy() {
        LayerModel copy = new LayerModel(name);
        copy.enabled = this.enabled;
        copy.isGradient = this.isGradient;
        copy.solidColor = this.solidColor;
        copy.shapeType = this.shapeType;
        copy.gradient = this.gradient != null ? this.gradient.copy() : new GradientModel();
        copy.stroke = this.stroke != null ? this.stroke.copy() : new StrokeModel();
        copy.corners = this.corners != null ? this.corners.copy() : new CornersModel();
        copy.insets = this.insets != null ? this.insets.copy() : new InsetsModel();
        return copy;
    }
}
