package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/**
 * Manages Ambient Neon Glow & Shimmer Border animation for cards and headers.
 */
public class AmbientGlowAnimationHelper {

    private static final String PREF_NAME = "morsalin_settings";
    public static final String KEY_AMBIENT_GLOW_STYLE = "key_ambient_glow_style";

    public static final int STYLE_OFF = 0;
    public static final int STYLE_CYBER_NEON = 1;
    public static final int STYLE_MATRIX_PULSE = 2;
    public static final int STYLE_SOLAR_GOLD = 3;
    public static final int STYLE_HOLO_AURORA = 4;
    public static final int STYLE_VIOLET_PLASMA = 5;
    public static final int STYLE_CRIMSON_PHOENIX = 6;
    public static final int STYLE_ARCTIC_DIAMOND = 7;
    public static final int STYLE_SYNTHWAVE_SUNSET = 8;
    public static final int STYLE_TOXIC_CYBER = 9;
    public static final int STYLE_CELESTIAL_STARLIGHT = 10;

    public static final String[] STYLE_NAMES = {
            "Disabled (Normal)",
            "Cyber Cyan & Magenta",
            "Matrix Emerald Pulse",
            "Solar Flare Gold",
            "Holographic Aurora",
            "Electric Violet Plasma",
            "Crimson Phoenix Flame",
            "Arctic Diamond Glacier",
            "Synthwave Sunset Horizon",
            "Toxic Cyber Green",
            "Celestial Starlight Breathing"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Standard borders with no additional glowing pulse",
            "Subtle pulsing cyan and magenta border illumination",
            "Matrix emerald green breathing pulse effect",
            "Warm golden glow with smooth ambient rhythm",
            "Dynamic holographic chromatic border shimmer",
            "High-energy violet & electric purple breathing aura",
            "Blazing crimson red heat pulsation",
            "Cool arctic ice cyan crystalline shimmer",
            "Warm retro synthwave neon magenta horizon",
            "Ultra-vivid toxic neon green hacker glow",
            "Ethereal cosmic starlight gentle luminance"
    };

    private static int cachedStyle = -1;

    public static int getSavedStyle(Context context) {
        if (cachedStyle >= 0) return cachedStyle;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cachedStyle = sp.getInt(KEY_AMBIENT_GLOW_STYLE, STYLE_OFF);
        return cachedStyle;
    }

    public static void setSavedStyle(Context context, int style) {
        cachedStyle = style;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_AMBIENT_GLOW_STYLE, style).apply();
    }

    public static boolean isEnabled(Context context) {
        return getSavedStyle(context) != STYLE_OFF;
    }

    public static ValueAnimator attachPulseToView(final View view, Context context) {
        if (view == null || context == null) return null;
        int style = getSavedStyle(context);
        if (style == STYLE_OFF) return null;

        view.animate().cancel();
        ValueAnimator animator = ValueAnimator.ofFloat(0.86f, 1.0f);
        animator.setDuration(1600);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(animation -> {
            float val = (Float) animation.getAnimatedValue();
            view.setAlpha(val);
        });
        animator.start();
        return animator;
    }
}
