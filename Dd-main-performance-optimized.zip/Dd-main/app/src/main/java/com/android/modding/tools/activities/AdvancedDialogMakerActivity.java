package com.android.modding.tools.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;
import com.android.modding.tools.helpers.ButtonPressAnimationHelper;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.SocialButtonAnimationHelper;
import com.android.modding.tools.helpers.StaggeredEntranceAnimationHelper;
import com.android.modding.tools.helpers.TransitionAnimationManager;

/**
 * Advanced Dialog Maker Main Hub.
 * Features 5 dedicated builders:
 * 1. Simple Smali Dialog Maker
 * 2. Colorful Dialog Maker
 * 3. Profile Dialog Maker
 * 4. Notice Dialog Maker
 * 5. Custom Dialog Maker
 */
public class AdvancedDialogMakerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_dialog_maker);

        GlobalTouchParticleManager.attach(this);

        initViews();

        View menuContainer = findViewById(R.id.layout_dialog_menu_items);
        if (menuContainer instanceof ViewGroup && StaggeredEntranceAnimationHelper.isEnabled(this)) {
            StaggeredEntranceAnimationHelper.animateContainer((ViewGroup) menuContainer, this);
        }
    }

    private void initViews() {
        View btnBack = findViewById(R.id.btn_category_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                finish();
                TransitionAnimationManager.applyBackward(this);
            });
        }

        View btnAbout = findViewById(R.id.btn_category_about);
        if (btnAbout != null) {
            btnAbout.setOnClickListener(v -> MorsalinDialogHelper.showAboutDialog(this));
        }

        // Bind social buttons
        SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // 5 Dedicated Dialog Builders
        View btnSimple = findViewById(R.id.btn_tool_simple_smali_dialog);
        if (btnSimple != null) {
            btnSimple.setOnClickListener(v -> launchTool(SimpleSmaliDialogMakerActivity.class));
        }

        View btnColorful = findViewById(R.id.btn_tool_colorful_dialog);
        if (btnColorful != null) {
            btnColorful.setOnClickListener(v -> launchTool(ColorfulDialogMakerActivity.class));
        }

        View btnProfile = findViewById(R.id.btn_tool_profile_dialog);
        if (btnProfile != null) {
            btnProfile.setOnClickListener(v -> launchTool(ProfileDialogMakerActivity.class));
        }

        View btnNotice = findViewById(R.id.btn_tool_notice_dialog);
        if (btnNotice != null) {
            btnNotice.setOnClickListener(v -> launchTool(NoticeDialogMakerActivity.class));
        }

        View btnCustom = findViewById(R.id.btn_tool_custom_dialog);
        if (btnCustom != null) {
            btnCustom.setOnClickListener(v -> launchTool(CustomDialogMakerActivity.class));
        }
    }

    private void launchTool(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
