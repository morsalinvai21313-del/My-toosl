package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;

import androidx.appcompat.widget.AppCompatTextView;

/**
 * Custom TextView with continuous 60-FPS multi-color flowing gradient lighting animation.
 * Colors flow smoothly across the text letters with silky performance.
 */
public class LightingTextView extends AppCompatTextView implements LightingTextAnimationManager.OnLightingStyleChangeListener {

    private final Matrix gradientMatrix = new Matrix();
    private LinearGradient linearGradient;
    private ValueAnimator animator;
    private float animProgress = 0f;
    private int previewStyle = -1; // -1 means use global manager style
    private boolean isAttached = false;

    public LightingTextView(Context context) {
        super(context);
        init();
    }

    public LightingTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LightingTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2400);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            animProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
    }

    public void setPreviewStyle(int style) {
        this.previewStyle = style;
        rebuildShader();
        invalidate();
    }

    private int getEffectiveStyle() {
        if (previewStyle >= 0 && previewStyle < LightingTextAnimationManager.TOTAL_STYLES) {
            return previewStyle;
        }
        return LightingTextAnimationManager.getSavedStyle(getContext());
    }

    private boolean isLightingActive() {
        if (previewStyle >= 0) return true;
        return LightingTextAnimationManager.isEnabled(getContext());
    }

    private void rebuildShader() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (!isLightingActive()) {
            linearGradient = null;
            getPaint().setShader(null);
            return;
        }

        int style = getEffectiveStyle();
        int[] colors = LightingTextAnimationManager.getColorsForStyle(style);

        // Build continuous looping linear gradient across 1.8x width
        float gradientWidth = Math.max(w * 1.8f, 200f);
        linearGradient = new LinearGradient(
                0, 0, gradientWidth, 0,
                colors, null, Shader.TileMode.REPEAT
        );
        getPaint().setShader(linearGradient);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildShader();
    }

    @Override
    public void onLightingStyleChanged(int newStyle, boolean isEnabled) {
        if (previewStyle == -1) {
            post(() -> {
                rebuildShader();
                invalidate();
            });
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        isAttached = true;
        LightingTextAnimationManager.registerListener(this);
        rebuildShader();
        if (getVisibility() == VISIBLE) {
            startAnimation();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        isAttached = false;
        LightingTextAnimationManager.unregisterListener(this);
        stopAnimation();
    }

    private void startAnimation() {
        if (animator != null && !animator.isRunning()) {
            animator.start();
        }
    }

    private void stopAnimation() {
        if (animator != null && animator.isRunning()) {
            animator.cancel();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (isLightingActive() && linearGradient != null) {
            int w = getWidth();
            float gradientWidth = Math.max(w * 1.8f, 200f);
            float translate = animProgress * gradientWidth;
            gradientMatrix.setTranslate(-translate, 0);
            linearGradient.setLocalMatrix(gradientMatrix);
            getPaint().setShader(linearGradient);
        } else {
            getPaint().setShader(null);
        }
        super.onDraw(canvas);
    }
}
