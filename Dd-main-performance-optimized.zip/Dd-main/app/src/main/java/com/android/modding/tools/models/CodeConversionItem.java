package com.android.modding.tools.models;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CodeConversionItem {
    private String id;
    private String originalLanguage;
    private String convertedLanguage;
    private String originalFileName;
    private String convertedFileName;
    private long timestamp;
    private String originalCode;
    private String convertedCode;
    private int linesProcessed;
    private int linesGenerated;
    private int warningsCount;
    private long conversionTimeMs;

    public CodeConversionItem(String id, String originalLanguage, String convertedLanguage,
                              String originalFileName, String convertedFileName, long timestamp,
                              String originalCode, String convertedCode,
                              int linesProcessed, int linesGenerated, int warningsCount, long conversionTimeMs) {
        this.id = id;
        this.originalLanguage = originalLanguage;
        this.convertedLanguage = convertedLanguage;
        this.originalFileName = originalFileName;
        this.convertedFileName = convertedFileName;
        this.timestamp = timestamp;
        this.originalCode = originalCode;
        this.convertedCode = convertedCode;
        this.linesProcessed = linesProcessed;
        this.linesGenerated = linesGenerated;
        this.warningsCount = warningsCount;
        this.conversionTimeMs = conversionTimeMs;
    }

    public String getId() {
        return id;
    }

    public String getOriginalLanguage() {
        return originalLanguage;
    }

    public String getConvertedLanguage() {
        return convertedLanguage;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public String getConvertedFileName() {
        return convertedFileName;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getOriginalCode() {
        return originalCode;
    }

    public String getConvertedCode() {
        return convertedCode;
    }

    public int getLinesProcessed() {
        return linesProcessed;
    }

    public int getLinesGenerated() {
        return linesGenerated;
    }

    public int getWarningsCount() {
        return warningsCount;
    }

    public long getConversionTimeMs() {
        return conversionTimeMs;
    }

    public String getDirectionTitle() {
        return originalLanguage + " → " + convertedLanguage;
    }

    public String getFormattedDate() {
        Calendar now = Calendar.getInstance();
        Calendar itemCal = Calendar.getInstance();
        itemCal.setTimeInMillis(timestamp);

        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a", Locale.US);
        if (now.get(Calendar.YEAR) == itemCal.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == itemCal.get(Calendar.DAY_OF_YEAR)) {
            return "Today, " + timeFormat.format(new Date(timestamp));
        }

        now.add(Calendar.DAY_OF_YEAR, -1);
        if (now.get(Calendar.YEAR) == itemCal.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == itemCal.get(Calendar.DAY_OF_YEAR)) {
            return "Yesterday, " + timeFormat.format(new Date(timestamp));
        }

        SimpleDateFormat fullFormat = new SimpleDateFormat("MMM dd, yyyy • h:mm a", Locale.US);
        return fullFormat.format(new Date(timestamp));
    }
}
