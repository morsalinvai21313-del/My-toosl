package com.android.modding.tools.dialogmaker;

/**
 * Generates Clean Standalone hook.smali for MT Manager, APKTool, and NP Manager.
 * Contains purely the Dalvik hook invocation, stylish divider, and Islamic blessing with developer credit.
 */
public class GuideGenerator {

    public static final String STYLISH_BORDER = "# ▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰";

    public static String generateSmaliGuide(DialogConfig config, DexValidator.ValidationResult dexResult) {
        if (config == null) config = DialogConfig.createCustomDefault();

        StringBuilder sb = new StringBuilder();

        sb.append("# ----------------------------------------------------\n");
        sb.append("# REAL DALVIK SMALI HOOK FOR ONCREATE\n");
        sb.append("# ----------------------------------------------------\n\n");

        sb.append("invoke-static {p0}, Lcom/morsalin/dialog/MorsalinCustomDialog;->show(Landroid/content/Context;)V\n\n");

        sb.append(STYLISH_BORDER).append("\n");
        sb.append("# 🌸 لَا اِلَهَاِلّا اللهُمَحَمّدُرّسُوْলُالله(ﷺ)__🥰\n");
        sb.append("# -লা ইলাহা ইল্লাল্লাহু মুহাম্মাদর রসূল্লাহ\n");
        sb.append("# ডেভলপার বাই মোরসালিন খান 🇧🇩\n");
        sb.append(STYLISH_BORDER).append("\n");

        return sb.toString();
    }

    public static String generateGuide(DialogConfig config, DexValidator.ValidationResult dexResult, java.util.Map<String, String> xmlFiles) {
        return generateSmaliGuide(config, dexResult);
    }
}

