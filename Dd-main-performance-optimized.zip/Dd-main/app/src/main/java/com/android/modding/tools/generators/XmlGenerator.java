package com.android.modding.tools.generators;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;









import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class XmlGenerator {

    private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
    public static final String BANNER_COMMENT =
            "    <!-- XML Button Designer - Generated Resource -->\n";
    private static final String NS_ANDROID = "xmlns:android=\"http://schemas.android.com/apk/res/android\"";

    private static final Pattern HEX_COLOR_PATTERN =
            Pattern.compile("^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$");

    /**
     * Sanitizes and validates a hex color string.
     * Guarantees that the returned color is a valid Android hex color (#RGB, #ARGB, #RRGGBB, #AARRGGBB),
     * or returns the fallback defaultColor.
     */
    public static String sanitizeColor(String color, String defaultColor) {
        if (color == null) return defaultColor;
        String trimmed = color.trim();
        if (trimmed.isEmpty()) return defaultColor;

        if (!trimmed.startsWith("#")) {
            trimmed = "#" + trimmed;
        }

        if (HEX_COLOR_PATTERN.matcher(trimmed).matches()) {
            return trimmed;
        }
        return defaultColor;
    }

    /**
     * Generates a single <shape> XML.
     */
    public static String generateShapeXml(LayerModel layer) {
        if (layer == null) {
            layer = new LayerModel("Default");
        }
        String shapeType = layer.getShapeType();
        if (shapeType == null || shapeType.trim().isEmpty()) {
            shapeType = "rectangle";
        }

        StringBuilder sb = new StringBuilder();
        sb.append(XML_HEADER);
        sb.append("<shape ").append(NS_ANDROID).append("\n");
        sb.append("    android:shape=\"").append(shapeType).append("\">\n\n");
        sb.append(BANNER_COMMENT);

        appendShapeContent(sb, layer, "    ");

        sb.append("</shape>");
        return sb.toString();
    }

    /**
     * Generates a <layer-list> XML for a list of layers.
     */
    public static String generateLayerListXml(List<LayerModel> layers) {
        StringBuilder sb = new StringBuilder();
        sb.append(XML_HEADER);
        sb.append("<layer-list ").append(NS_ANDROID).append(">\n");
        sb.append(BANNER_COMMENT);

        List<LayerModel> enabledLayers = new ArrayList<>();
        if (layers != null) {
            for (LayerModel l : layers) {
                if (l != null && l.isEnabled()) {
                    enabledLayers.add(l);
                }
            }
        }

        // Android strictly requires at least one <item> inside <layer-list>
        if (enabledLayers.isEmpty()) {
            LayerModel fallback = (layers != null && !layers.isEmpty()) ? layers.get(0) : new LayerModel("Layer 1");
            enabledLayers.add(fallback);
        }

        for (int i = 0; i < enabledLayers.size(); i++) {
            LayerModel layer = enabledLayers.get(i);
            String shapeType = layer.getShapeType();
            if (shapeType == null || shapeType.trim().isEmpty()) {
                shapeType = "rectangle";
            }

            sb.append("    <item");
            InsetsModel insets = layer.getInsets();
            if (insets != null && insets.hasAnyInset()) {
                if (insets.getLeftDp() > 0) sb.append(" android:left=\"").append(insets.getLeftDp()).append("dp\"");
                if (insets.getTopDp() > 0) sb.append(" android:top=\"").append(insets.getTopDp()).append("dp\"");
                if (insets.getRightDp() > 0) sb.append(" android:right=\"").append(insets.getRightDp()).append("dp\"");
                if (insets.getBottomDp() > 0) sb.append(" android:bottom=\"").append(insets.getBottomDp()).append("dp\"");
            }
            sb.append(">\n");

            sb.append("        <shape android:shape=\"").append(shapeType).append("\">\n");
            appendShapeContent(sb, layer, "            ");
            sb.append("        </shape>\n");
            sb.append("    </item>\n");
        }

        sb.append("</layer-list>");
        return sb.toString();
    }

    /**
     * Generates a <selector> XML containing configured states.
     * Ensures states are ordered correctly (specific states first, default normal state last)
     * and guarantees that the selector is never empty.
     */
    public static String generateSelectorXml(Map<String, StateModel> stateMap) {
        StringBuilder sb = new StringBuilder();
        sb.append(XML_HEADER);
        sb.append("<selector ").append(NS_ANDROID).append(">\n");
        sb.append(BANNER_COMMENT);

        // Specific states must precede the default normal state
        String[] stateKeys = {
            StateModel.STATE_PRESSED,
            StateModel.STATE_CHECKED,
            StateModel.STATE_FOCUSED,
            StateModel.STATE_SELECTED,
            StateModel.STATE_DISABLED
        };

        boolean hasAnyState = false;
        if (stateMap != null) {
            for (String key : stateKeys) {
                StateModel state = stateMap.get(key);
                if (state != null && state.isActive()) {
                    appendSelectorItem(sb, state, getStateAttribute(key));
                    hasAnyState = true;
                }
            }

            // Default Normal State (must always be the last item)
            StateModel normalState = stateMap.get(StateModel.STATE_NORMAL);
            if (normalState != null && normalState.isActive()) {
                appendSelectorItem(sb, normalState, null);
                hasAnyState = true;
            } else if (hasAnyState) {
                // If specific states were defined but normal was not marked active,
                // generate a safe fallback default item so normal state does not disappear!
                if (normalState != null) {
                    appendSelectorItem(sb, normalState, null);
                } else {
                    StateModel fallback = new StateModel(StateModel.STATE_NORMAL);
                    appendSelectorItem(sb, fallback, null);
                }
            }
        }

        // If completely empty, generate a safe default shape item
        if (!hasAnyState) {
            StateModel fallback = new StateModel(StateModel.STATE_NORMAL);
            appendSelectorItem(sb, fallback, null);
        }

        sb.append("</selector>");
        return sb.toString();
    }

    /**
     * Generates a Ripple XML (API 21+)
     */
    public static String generateRippleXml(String rippleColor, LayerModel contentLayer, LayerModel maskLayer) {
        String safeRipple = sanitizeColor(rippleColor, "#4000FFFF");

        StringBuilder sb = new StringBuilder();
        sb.append(XML_HEADER);
        sb.append("<ripple ").append(NS_ANDROID).append("\n");
        sb.append("    android:color=\"").append(safeRipple).append("\">\n");
        sb.append(BANNER_COMMENT);

        if (maskLayer != null) {
            String shapeType = maskLayer.getShapeType();
            if (shapeType == null || shapeType.trim().isEmpty()) shapeType = "rectangle";
            sb.append("    <!-- Mask to bound the ripple -->\n");
            sb.append("    <item android:id=\"@android:id/mask\">\n");
            sb.append("        <shape android:shape=\"").append(shapeType).append("\">\n");
            appendShapeContent(sb, maskLayer, "            ");
            sb.append("        </shape>\n");
            sb.append("    </item>\n");
        }

        if (contentLayer != null) {
            String shapeType = contentLayer.getShapeType();
            if (shapeType == null || shapeType.trim().isEmpty()) shapeType = "rectangle";
            sb.append("    <!-- Background content -->\n");
            sb.append("    <item>\n");
            sb.append("        <shape android:shape=\"").append(shapeType).append("\">\n");
            appendShapeContent(sb, contentLayer, "            ");
            sb.append("        </shape>\n");
            sb.append("    </item>\n");
        } else if (maskLayer == null) {
            // Ripple requires at least one item
            sb.append("    <item>\n");
            sb.append("        <shape android:shape=\"rectangle\">\n");
            sb.append("            <solid android:color=\"#00000000\" />\n");
            sb.append("        </shape>\n");
            sb.append("    </item>\n");
        }

        sb.append("</ripple>");
        return sb.toString();
    }

    private static void appendSelectorItem(StringBuilder sb, StateModel state, String stateAttr) {
        sb.append("    <item");
        if (stateAttr != null) {
            sb.append(" ").append(stateAttr);
        }
        sb.append(">\n");

        List<LayerModel> enabledLayers = new ArrayList<>();
        if (state.getLayers() != null) {
            for (LayerModel l : state.getLayers()) {
                if (l != null && l.isEnabled()) {
                    enabledLayers.add(l);
                }
            }
        }

        // If no layers are enabled, enable the first layer so item is never empty
        if (enabledLayers.isEmpty()) {
            if (state.getLayers() != null && !state.getLayers().isEmpty()) {
                enabledLayers.add(state.getLayers().get(0));
            } else {
                enabledLayers.add(new LayerModel("Layer 1"));
            }
        }

        if (enabledLayers.size() == 1) {
            LayerModel single = enabledLayers.get(0);
            String shapeType = single.getShapeType();
            if (shapeType == null || shapeType.trim().isEmpty()) shapeType = "rectangle";
            sb.append("        <shape android:shape=\"").append(shapeType).append("\">\n");
            appendShapeContent(sb, single, "            ");
            sb.append("        </shape>\n");
        } else {
            sb.append("        <layer-list>\n");
            for (LayerModel layer : enabledLayers) {
                String shapeType = layer.getShapeType();
                if (shapeType == null || shapeType.trim().isEmpty()) shapeType = "rectangle";

                sb.append("            <item");
                InsetsModel insets = layer.getInsets();
                if (insets != null && insets.hasAnyInset()) {
                    if (insets.getLeftDp() > 0) sb.append(" android:left=\"").append(insets.getLeftDp()).append("dp\"");
                    if (insets.getTopDp() > 0) sb.append(" android:top=\"").append(insets.getTopDp()).append("dp\"");
                    if (insets.getRightDp() > 0) sb.append(" android:right=\"").append(insets.getRightDp()).append("dp\"");
                    if (insets.getBottomDp() > 0) sb.append(" android:bottom=\"").append(insets.getBottomDp()).append("dp\"");
                }
                sb.append(">\n");
                sb.append("                <shape android:shape=\"").append(shapeType).append("\">\n");
                appendShapeContent(sb, layer, "                    ");
                sb.append("                </shape>\n");
                sb.append("            </item>\n");
            }
            sb.append("        </layer-list>\n");
        }

        sb.append("    </item>\n\n");
    }

    private static String getStateAttribute(String stateKey) {
        switch (stateKey) {
            case StateModel.STATE_PRESSED:
                return "android:state_pressed=\"true\"";
            case StateModel.STATE_CHECKED:
                return "android:state_checked=\"true\"";
            case StateModel.STATE_FOCUSED:
                return "android:state_focused=\"true\"";
            case StateModel.STATE_SELECTED:
                return "android:state_selected=\"true\"";
            case StateModel.STATE_DISABLED:
                return "android:state_enabled=\"false\"";
            default:
                return null;
        }
    }

    private static void appendShapeContent(StringBuilder sb, LayerModel layer, String indent) {
        String shapeType = layer.getShapeType();
        if (shapeType == null || shapeType.trim().isEmpty()) shapeType = "rectangle";
        boolean isRect = "rectangle".equals(shapeType);

        boolean hasFill = false;

        // 1. Solid or Gradient
        if (layer.isGradient()) {
            GradientModel g = layer.getGradient();
            if (g == null) g = new GradientModel();

            String type = g.getType();
            if (type == null || type.trim().isEmpty()) type = GradientModel.TYPE_LINEAR;

            // Ensure startColor and endColor are always valid hex strings (required by Android)
            String startColor = sanitizeColor(g.getStartColor(), "#FF00E5FF");
            String endColor = sanitizeColor(g.getEndColor(), "#FF081A24");

            sb.append(indent).append("<gradient\n");
            sb.append(indent).append("    android:type=\"").append(type).append("\"\n");
            sb.append(indent).append("    android:startColor=\"").append(startColor).append("\"\n");

            if (g.isUseCenterColor()) {
                String centerColor = sanitizeColor(g.getCenterColor(), null);
                if (centerColor != null && !centerColor.equalsIgnoreCase("#00000000")) {
                    sb.append(indent).append("    android:centerColor=\"").append(centerColor).append("\"\n");
                }
            }

            sb.append(indent).append("    android:endColor=\"").append(endColor).append("\"");

            if (GradientModel.TYPE_LINEAR.equals(type)) {
                // Angle must be an integer multiple of 45: 0, 45, 90, 135, 180, 225, 270, 315
                sb.append("\n").append(indent).append("    android:angle=\"").append(g.getNormalizedAngle()).append("\"");
            } else if (GradientModel.TYPE_RADIAL.equals(type)) {
                // Gradient radius must be greater than 0dp for radial type (Android throws IllegalStateException otherwise)
                int radiusDp = Math.max(1, g.getGradientRadiusDp());
                float cx = Math.max(0.0f, Math.min(1.0f, g.getCenterX()));
                float cy = Math.max(0.0f, Math.min(1.0f, g.getCenterY()));
                sb.append("\n").append(indent).append("    android:gradientRadius=\"").append(radiusDp).append("dp\"");
                sb.append("\n").append(indent).append("    android:centerX=\"").append(String.format(Locale.US, "%.2f", cx)).append("\"");
                sb.append("\n").append(indent).append("    android:centerY=\"").append(String.format(Locale.US, "%.2f", cy)).append("\"");
            } else if (GradientModel.TYPE_SWEEP.equals(type)) {
                float cx = Math.max(0.0f, Math.min(1.0f, g.getCenterX()));
                float cy = Math.max(0.0f, Math.min(1.0f, g.getCenterY()));
                sb.append("\n").append(indent).append("    android:centerX=\"").append(String.format(Locale.US, "%.2f", cx)).append("\"");
                sb.append("\n").append(indent).append("    android:centerY=\"").append(String.format(Locale.US, "%.2f", cy)).append("\"");
            }
            sb.append(" />\n");
            hasFill = true;
        } else {
            String color = sanitizeColor(layer.getSolidColor(), null);
            if (color != null && !color.equalsIgnoreCase("#00000000")) {
                sb.append(indent).append("<solid android:color=\"").append(color).append("\" />\n");
                hasFill = true;
            }
        }

        // If neither solid nor gradient is configured, provide safe transparent fill to prevent null paint crash
        if (!hasFill) {
            sb.append(indent).append("<solid android:color=\"#00000000\" />\n");
        }

        // 2. Corners (Valid strictly for rectangle shapes in Android)
        if (isRect) {
            CornersModel corners = layer.getCorners();
            if (corners != null) {
                int tl = Math.max(0, corners.getTopLeftDp());
                int tr = Math.max(0, corners.getTopRightDp());
                int bl = Math.max(0, corners.getBottomLeftDp());
                int br = Math.max(0, corners.getBottomRightDp());

                if (corners.areAllCornersEqual() && tl > 0) {
                    sb.append(indent).append("<corners android:radius=\"").append(tl).append("dp\" />\n");
                } else if (tl > 0 || tr > 0 || bl > 0 || br > 0) {
                    // Always output all 4 corner radius attributes when custom to ensure full cross-version compatibility
                    sb.append(indent).append("<corners\n");
                    sb.append(indent).append("    android:topLeftRadius=\"").append(tl).append("dp\"\n");
                    sb.append(indent).append("    android:topRightRadius=\"").append(tr).append("dp\"\n");
                    sb.append(indent).append("    android:bottomLeftRadius=\"").append(bl).append("dp\"\n");
                    sb.append(indent).append("    android:bottomRightRadius=\"").append(br).append("dp\" />\n");
                }
            }
        }

        // 3. Stroke
        StrokeModel stroke = layer.getStroke();
        if (stroke != null && stroke.getWidthDp() > 0) {
            String strokeColor = sanitizeColor(stroke.getColor(), "#FF00FFFF");
            sb.append(indent).append("<stroke\n");
            sb.append(indent).append("    android:width=\"").append(stroke.getWidthDp()).append("dp\"\n");
            sb.append(indent).append("    android:color=\"").append(strokeColor).append("\"");

            if (stroke.getDashWidthDp() > 0) {
                // dashGap must be > 0 when dashWidth > 0
                int dashGap = Math.max(1, stroke.getDashGapDp());
                sb.append("\n").append(indent).append("    android:dashWidth=\"").append(stroke.getDashWidthDp()).append("dp\"");
                sb.append("\n").append(indent).append("    android:dashGap=\"").append(dashGap).append("dp\"");
            }
            sb.append(" />\n");
        }
    }
}
