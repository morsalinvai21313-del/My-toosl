package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ConverterCategoryActivity extends AppCompatActivity {

    private static final String URL_TELEGRAM = "https://t.me/anonymous_modder_king";
    private static final String URL_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_converter);

        GlobalTouchParticleManager.attach(this);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_category_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        View.OnClickListener openAbout = v -> {
            com.android.modding.tools.dialogs.MorsalinDialogHelper.showAboutDialog(this);
        };

        findViewById(R.id.btn_category_about).setOnClickListener(openAbout);
        findViewById(R.id.btn_category_bottom_about).setOnClickListener(openAbout);

        // Social Links with smooth micro-animation
        com.android.modding.tools.helpers.SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // Tools Navigation
        View btnCodeEditor = findViewById(R.id.btn_tool_code_editor);
        if (btnCodeEditor != null) {
            btnCodeEditor.setOnClickListener(v -> launchTool(CodeEditorActivity.class));
        }
        findViewById(R.id.btn_tool_java_kotlin).setOnClickListener(v -> launchTool(JavaKotlinConverterActivity.class));
        findViewById(R.id.btn_tool_class_to_smali).setOnClickListener(v -> launchTool(ClassToSmaliActivity.class));
    }

    private void launchTool(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
