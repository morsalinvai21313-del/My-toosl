package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.HistoryManager;
import com.android.modding.tools.helpers.MorsalinDexGenerator;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.PackageGenerationRunner;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.XmlProject;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class AnimationMakerActivity extends AppCompatActivity {

    public static class AnimStep {
        public String type;
        public int durationMs;
        public int delayMs;
        public int intensityPct;
        public int directionIndex;
        public int interpolatorIndex;
        public int repeatCount; // 0, 1, 2, 3, 5, -1 (infinite)
        public boolean repeatReverse;

        public AnimStep(String type, int durationMs, int delayMs, int intensityPct,
                        int directionIndex, int interpolatorIndex, int repeatCount, boolean repeatReverse) {
            this.type = type;
            this.durationMs = durationMs;
            this.delayMs = delayMs;
            this.intensityPct = intensityPct;
            this.directionIndex = directionIndex;
            this.interpolatorIndex = interpolatorIndex;
            this.repeatCount = repeatCount;
            this.repeatReverse = repeatReverse;
        }
    }

    private static final String[] ANIM_TYPES = {
            "Fade", "Slide", "Scale", "Zoom",
            "Rotate", "Bounce", "Shake", "Pulse",
            "Blink", "Flip", "Swing", "Elastic"
    };

    private static final String[] DIRECTIONS = {
            "IN / UP", "OUT / DOWN", "LEFT → RIGHT", "RIGHT → LEFT"
    };

    private static final String[] INTERPOLATORS = {
            "OVERSHOOT", "BOUNCE", "ACCEL_DECEL", "ANTICIPATE", "DECELERATE", "LINEAR", "CYCLE"
    };

    private static final int[] REPEAT_COUNTS = {0, 1, 2, 3, 5, ValueAnimator.INFINITE};
    private static final String[] REPEAT_LABELS = {"NONE", "1x", "2x", "3x", "5x", "INFINITE"};

    private String currentType = "Fade";
    private int currentDuration = 500;
    private int currentDelay = 0;
    private int currentIntensity = 100;
    private int currentDirIdx = 0;
    private int currentInterpIdx = 0;
    private int currentRepeatIdx = 0;
    private boolean currentRepeatReverse = true;
    private int presetComboIdx = 0;

    private final List<AnimStep> sequenceChain = new ArrayList<>();
    private Animator currentRunningAnimator;

    // Views
    private View targetAnimView;
    private TextView tvTargetTitle, tvTargetSub;
    private SeekBar seekDuration, seekDelay, seekIntensity;
    private TextView tvDurationVal, tvDelayVal, tvIntensityVal;
    private Button btnDirection, btnInterpolator, btnRepeatCount, btnRepeatMode;
    private TextView tvChainSummary, tvGeneratedCode;
    private Button tabJava, tabXml, tabUsage, tabGuide;
    private final List<Button> typeButtons = new ArrayList<>();

    private int activeCodeTab = 0; // 0=Java, 1=XML, 2=Activity, 3=Guide
    private GeneratedPackageExporter.GeneratedPackage latestPackage;
    private HistoryManager historyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation_maker);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);
        initViews();
        loadDefaultPresetChain();

        String jsonConfig = getIntent().getStringExtra("EXTRA_JSON_CONFIG");
        if (jsonConfig != null && !jsonConfig.isEmpty()) {
            loadFromJsonConfig(jsonConfig);
        }

        updateTypeButtonsUI();
        updateParameterButtonsUI();
        rebuildPackageAndCode();
        playSinglePreview();
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            stopRunningAnimation();
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            MorsalinDialogHelper.showResetDialog(this, "Reset Animation Maker",
                    "Reset all animation parameters and sequence chain to default?", () -> {
                        currentType = "Fade";
                        currentDuration = 500;
                        currentDelay = 0;
                        currentIntensity = 100;
                        currentDirIdx = 0;
                        currentInterpIdx = 0;
                        currentRepeatIdx = 0;
                        currentRepeatReverse = true;
                        seekDuration.setProgress(400);
                        seekDelay.setProgress(0);
                        seekIntensity.setProgress(80);
                        loadDefaultPresetChain();
                        updateTypeButtonsUI();
                        updateParameterButtonsUI();
                        rebuildPackageAndCode();
                        playChainPreview();
                    });
        });

        targetAnimView = findViewById(R.id.target_anim_view);
        tvTargetTitle = findViewById(R.id.tv_anim_target_title);
        tvTargetSub = findViewById(R.id.tv_anim_target_sub);

        findViewById(R.id.btn_play_single).setOnClickListener(v -> playSinglePreview());
        findViewById(R.id.btn_play_chain).setOnClickListener(v -> playChainPreview());
        findViewById(R.id.btn_stop_anim).setOnClickListener(v -> stopRunningAnimation());
        targetAnimView.setOnClickListener(v -> playChainPreview());

        int[] btnIds = {
                R.id.btn_type_fade, R.id.btn_type_slide, R.id.btn_type_scale, R.id.btn_type_zoom,
                R.id.btn_type_rotate, R.id.btn_type_bounce, R.id.btn_type_shake, R.id.btn_type_pulse,
                R.id.btn_type_blink, R.id.btn_type_flip, R.id.btn_type_swing, R.id.btn_type_elastic
        };

        for (int i = 0; i < btnIds.length; i++) {
            final String typeName = ANIM_TYPES[i];
            Button b = findViewById(btnIds[i]);
            typeButtons.add(b);
            b.setOnClickListener(v -> {
                currentType = typeName;
                updateTypeButtonsUI();
                rebuildPackageAndCode();
                playSinglePreview();
            });
        }

        seekDuration = findViewById(R.id.seek_anim_duration);
        seekDelay = findViewById(R.id.seek_anim_delay);
        seekIntensity = findViewById(R.id.seek_anim_intensity);
        tvDurationVal = findViewById(R.id.tv_anim_duration_val);
        tvDelayVal = findViewById(R.id.tv_anim_delay_val);
        tvIntensityVal = findViewById(R.id.tv_anim_intensity_val);

        SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentDuration = 100 + seekDuration.getProgress();
                currentDelay = seekDelay.getProgress();
                currentIntensity = 20 + seekIntensity.getProgress();
                tvDurationVal.setText(currentDuration + " ms");
                tvDelayVal.setText(currentDelay + " ms");
                tvIntensityVal.setText(currentIntensity + "%");
                if (fromUser) {
                    rebuildPackageAndCode();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                playSinglePreview();
            }
        };

        seekDuration.setOnSeekBarChangeListener(seekListener);
        seekDelay.setOnSeekBarChangeListener(seekListener);
        seekIntensity.setOnSeekBarChangeListener(seekListener);

        btnDirection = findViewById(R.id.btn_anim_direction);
        btnInterpolator = findViewById(R.id.btn_anim_interpolator);
        btnRepeatCount = findViewById(R.id.btn_anim_repeat_count);
        btnRepeatMode = findViewById(R.id.btn_anim_repeat_mode);

        btnDirection.setOnClickListener(v -> {
            currentDirIdx = (currentDirIdx + 1) % DIRECTIONS.length;
            updateParameterButtonsUI();
            rebuildPackageAndCode();
            playSinglePreview();
        });

        btnInterpolator.setOnClickListener(v -> {
            currentInterpIdx = (currentInterpIdx + 1) % INTERPOLATORS.length;
            updateParameterButtonsUI();
            rebuildPackageAndCode();
            playSinglePreview();
        });

        btnRepeatCount.setOnClickListener(v -> {
            currentRepeatIdx = (currentRepeatIdx + 1) % REPEAT_COUNTS.length;
            updateParameterButtonsUI();
            rebuildPackageAndCode();
            playSinglePreview();
        });

        btnRepeatMode.setOnClickListener(v -> {
            currentRepeatReverse = !currentRepeatReverse;
            updateParameterButtonsUI();
            rebuildPackageAndCode();
            playSinglePreview();
        });

        tvChainSummary = findViewById(R.id.tv_chain_summary);
        findViewById(R.id.btn_chain_add).setOnClickListener(v -> {
            sequenceChain.add(createCurrentStep());
            rebuildPackageAndCode();
            playChainPreview();
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Added Step",
                    "Added " + currentType + " (" + currentDuration + "ms) to chain!");
        });

        findViewById(R.id.btn_chain_preset).setOnClickListener(v -> {
            presetComboIdx = (presetComboIdx + 1) % 3;
            sequenceChain.clear();
            if (presetComboIdx == 0) {
                loadDefaultPresetChain();
            } else if (presetComboIdx == 1) {
                sequenceChain.add(new AnimStep("Slide", 400, 0, 100, 2, 0, 0, true));
                sequenceChain.add(new AnimStep("Zoom", 450, 0, 120, 0, 0, 0, true));
                sequenceChain.add(new AnimStep("Pulse", 500, 0, 110, 0, 2, 1, true));
                sequenceChain.add(new AnimStep("Flip", 600, 0, 100, 0, 2, 0, true));
            } else {
                sequenceChain.add(new AnimStep("Elastic", 550, 0, 130, 0, 0, 0, true));
                sequenceChain.add(new AnimStep("Swing", 500, 0, 110, 0, 6, 0, true));
                sequenceChain.add(new AnimStep("Shake", 450, 0, 100, 0, 6, 0, true));
                sequenceChain.add(new AnimStep("Bounce", 600, 0, 120, 0, 1, 0, true));
            }
            rebuildPackageAndCode();
            playChainPreview();
        });

        findViewById(R.id.btn_chain_undo).setOnClickListener(v -> {
            if (!sequenceChain.isEmpty()) {
                sequenceChain.remove(sequenceChain.size() - 1);
                rebuildPackageAndCode();
            }
        });

        findViewById(R.id.btn_chain_clear).setOnClickListener(v -> {
            sequenceChain.clear();
            rebuildPackageAndCode();
        });

        android.widget.ScrollView scrollMain = findViewById(R.id.scroll_anim_maker);
        View animPanel = findViewById(R.id.layout_pkg_anim_panel);
        ConversionAnimationView convAnimView = findViewById(R.id.view_pkg_conversion_anim);
        TextView tvAnimBadge = findViewById(R.id.tv_pkg_anim_badge);
        TextView tvAnimStatus = findViewById(R.id.tv_pkg_anim_status);
        View readyPanel = findViewById(R.id.layout_pkg_ready_panel);
        Button btnGenerate = findViewById(R.id.btn_generate_package);

        if (btnGenerate != null) {
            btnGenerate.setOnClickListener(v -> {
                PackageGenerationRunner.runGeneratePipeline(
                        scrollMain,
                        animPanel,
                        convAnimView,
                        tvAnimBadge,
                        tvAnimStatus,
                        readyPanel,
                        "ANIMATION",
                        "CLASSES.DEX",
                        this::rebuildPackageAndCode
                );
            });
        }

        Button btnDownloadDex = findViewById(R.id.btn_download_dex);
        if (btnDownloadDex != null) {
            btnDownloadDex.setOnClickListener(v -> {
                if (latestPackage != null && latestPackage.getDexBinary() != null) {
                    byte[] dexBytes = latestPackage.getDexBinary();
                    FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                            this, "MorsalinXML/" + latestPackage.projectFolderName,
                            "classes.dex", "application/octet-stream", dexBytes);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "classes.dex Downloaded" : "Export Error", res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        Button btnDownloadZip = findViewById(R.id.btn_download_xml);
        if (btnDownloadZip != null) {
            btnDownloadZip.setOnClickListener(v -> {
                if (latestPackage != null) {
                    FileExporter.ExportResult res = GeneratedPackageExporter.exportPackageAsZip(this, latestPackage);
                    GeneratedPackageExporter.exportAllPackageFiles(this, latestPackage);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "ZIP Package Downloaded" : "Export Error",
                            res.success ? "Saved to Downloads/MorsalinXML/" + latestPackage.projectFolderName + ".zip" : res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        findViewById(R.id.btn_save_history).setOnClickListener(v -> {
            String title = "Anim_" + currentType + "_Chain" + Math.max(1, sequenceChain.size());
            XmlProject proj = new XmlProject(title, XmlProject.TYPE_ANIMATION,
                    getXmlFileContent(), buildJsonConfig());
            historyManager.saveProject(proj);
            MorsalinToast.show(this, R.drawable.ic_save, "Saved to History",
                    "Animation project saved to History!");
        });

        findViewById(R.id.btn_share_export).setOnClickListener(v -> {
            if (latestPackage != null) {
                GeneratedPackageExporter.showShareDialog(
                        this, latestPackage, "classes.dex", getCurrentTabContent());
            }
        });
    }

    private void loadDefaultPresetChain() {
        sequenceChain.clear();
        sequenceChain.add(new AnimStep("Fade", 400, 0, 100, 0, 2, 0, true));
        sequenceChain.add(new AnimStep("Scale", 450, 0, 115, 0, 0, 0, true));
        sequenceChain.add(new AnimStep("Rotate", 500, 0, 100, 0, 2, 0, true));
        sequenceChain.add(new AnimStep("Bounce", 550, 0, 110, 0, 1, 0, true));
    }

    private AnimStep createCurrentStep() {
        return new AnimStep(
                currentType,
                currentDuration,
                currentDelay,
                currentIntensity,
                currentDirIdx,
                currentInterpIdx,
                REPEAT_COUNTS[currentRepeatIdx],
                currentRepeatReverse
        );
    }

    private void updateTypeButtonsUI() {
        int cyan = getResources().getColor(R.color.morsalin_cyan);
        int white = Color.WHITE;
        for (int i = 0; i < typeButtons.size(); i++) {
            Button b = typeButtons.get(i);
            boolean active = ANIM_TYPES[i].equals(currentType);
            b.setTextColor(active ? cyan : white);
        }
        tvTargetSub.setText(currentType + " • " + currentDuration + "ms");
    }

    private void updateParameterButtonsUI() {
        btnDirection.setText("DIR: " + DIRECTIONS[currentDirIdx]);
        btnInterpolator.setText("EASE: " + INTERPOLATORS[currentInterpIdx]);
        btnRepeatCount.setText("REPEAT: " + REPEAT_LABELS[currentRepeatIdx]);
        btnRepeatMode.setText("MODE: " + (currentRepeatReverse ? "REVERSE" : "RESTART"));
    }

    private void switchCodeTab(int tabIndex) {
        activeCodeTab = tabIndex;
        int cyan = getResources().getColor(R.color.morsalin_cyan);
        int white = Color.WHITE;
        if (tabJava != null) tabJava.setTextColor(tabIndex == 0 ? cyan : white);
        if (tabXml != null) tabXml.setTextColor(tabIndex == 1 ? cyan : white);
        if (tabUsage != null) tabUsage.setTextColor(tabIndex == 2 ? cyan : white);
        if (tabGuide != null) tabGuide.setTextColor(tabIndex == 3 ? cyan : white);
        displayActiveTabCode();
    }

    private void displayActiveTabCode() {
        if (tvGeneratedCode == null) return;
        String content = getCurrentTabContent();
        if (activeCodeTab == 1 || activeCodeTab == 2) {
            tvGeneratedCode.setText(SyntaxHighlighter.highlightXml(content));
        } else {
            tvGeneratedCode.setText(content);
        }
    }

    private String getCurrentTabFileName() {
        if (activeCodeTab == 0) return "classes.dex";
        if (activeCodeTab == 1 || activeCodeTab == 2) return "morsalin_custom_anim.xml";
        return "ANIMATION_GUIDE.txt";
    }

    private String getCurrentTabContent() {
        if (latestPackage == null) return "";
        if (activeCodeTab == 0) {
            byte[] dex = latestPackage.getDexBinary();
            return MorsalinDexGenerator.getDexBinaryReport(
                    dex,
                    "MorsalinAnimationHelper",
                    "invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playOnActivity(Landroid/app/Activity;)V",
                    tvChainSummary != null ? tvChainSummary.getText().toString() : "Multi-Step View Animation"
            );
        }
        if (activeCodeTab == 1 || activeCodeTab == 2) return latestPackage.files.get("res/anim/morsalin_custom_anim.xml");
        return latestPackage.guideContent;
    }

    private String getXmlFileContent() {
        if (latestPackage == null) return "";
        return latestPackage.files.get("res/anim/morsalin_custom_anim.xml");
    }

    private void stopRunningAnimation() {
        if (currentRunningAnimator != null) {
            currentRunningAnimator.cancel();
            currentRunningAnimator = null;
        }
        resetTargetViewTransform();
    }

    private void resetTargetViewTransform() {
        if (targetAnimView == null) return;
        targetAnimView.setAlpha(1f);
        targetAnimView.setTranslationX(0f);
        targetAnimView.setTranslationY(0f);
        targetAnimView.setScaleX(1f);
        targetAnimView.setScaleY(1f);
        targetAnimView.setRotation(0f);
        targetAnimView.setRotationX(0f);
        targetAnimView.setRotationY(0f);
    }

    private void playSinglePreview() {
        stopRunningAnimation();
        AnimStep step = createCurrentStep();
        tvTargetSub.setText(step.type + " • " + step.durationMs + "ms");
        Animator anim = buildAnimatorForStep(targetAnimView, step);
        currentRunningAnimator = anim;
        anim.start();
    }

    private void playChainPreview() {
        stopRunningAnimation();
        List<AnimStep> steps = sequenceChain.isEmpty()
                ? Arrays.asList(createCurrentStep())
                : new ArrayList<>(sequenceChain);

        AnimatorSet chainSet = new AnimatorSet();
        List<Animator> animList = new ArrayList<>();
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < steps.size(); i++) {
            AnimStep s = steps.get(i);
            if (i > 0) names.append(" → ");
            names.append(s.type);
            animList.add(buildAnimatorForStep(targetAnimView, s));
        }
        tvTargetSub.setText(names.toString());
        chainSet.playSequentially(animList);
        currentRunningAnimator = chainSet;
        chainSet.start();
    }

    private Interpolator resolveInterpolator(int idx) {
        switch (idx) {
            case 0: return new OvershootInterpolator(1.6f);
            case 1: return new BounceInterpolator();
            case 2: return new AccelerateDecelerateInterpolator();
            case 3: return new AnticipateOvershootInterpolator(1.5f);
            case 4: return new DecelerateInterpolator();
            case 5: return new LinearInterpolator();
            case 6: return new CycleInterpolator(2f);
            default: return new AccelerateDecelerateInterpolator();
        }
    }

    private Animator buildAnimatorForStep(View target, AnimStep step) {
        float ratio = step.intensityPct / 100f;
        ObjectAnimator oa;
        switch (step.type) {
            case "Fade": {
                float startAlpha = (step.directionIndex == 1) ? 1f : 0.08f;
                float endAlpha = (step.directionIndex == 1) ? 0.15f : 1f;
                oa = ObjectAnimator.ofFloat(target, View.ALPHA, startAlpha, endAlpha, 1f);
                break;
            }
            case "Slide": {
                float dist = 130f * ratio;
                if (step.directionIndex == 2) {
                    oa = ObjectAnimator.ofFloat(target, View.TRANSLATION_X, -dist, 0f);
                } else if (step.directionIndex == 3) {
                    oa = ObjectAnimator.ofFloat(target, View.TRANSLATION_X, dist, 0f);
                } else if (step.directionIndex == 1) {
                    oa = ObjectAnimator.ofFloat(target, View.TRANSLATION_Y, -dist * 0.7f, 0f);
                } else {
                    oa = ObjectAnimator.ofFloat(target, View.TRANSLATION_Y, dist * 0.7f, 0f);
                }
                break;
            }
            case "Scale": {
                float startS = (step.directionIndex == 1) ? 1.35f * ratio : 0.35f;
                PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, startS, 1.08f, 1f);
                PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, startS, 1.08f, 1f);
                oa = ObjectAnimator.ofPropertyValuesHolder(target, pvhX, pvhY);
                break;
            }
            case "Zoom": {
                float peak = 1.38f * ratio;
                PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.2f, peak, 1f);
                PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.2f, peak, 1f);
                PropertyValuesHolder pvhA = PropertyValuesHolder.ofFloat(View.ALPHA, 0.2f, 1f, 1f);
                oa = ObjectAnimator.ofPropertyValuesHolder(target, pvhX, pvhY, pvhA);
                break;
            }
            case "Rotate": {
                float deg = (step.directionIndex == 1 || step.directionIndex == 3) ? -360f * ratio : 360f * ratio;
                oa = ObjectAnimator.ofFloat(target, View.ROTATION, 0f, deg, 0f);
                break;
            }
            case "Bounce": {
                float jump = -45f * ratio;
                PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f, jump, 0f, jump * 0.45f, 0f);
                PropertyValuesHolder pvhSX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.92f, 1.06f, 0.98f, 1f);
                PropertyValuesHolder pvhSY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.10f, 0.94f, 1.03f, 1f);
                oa = ObjectAnimator.ofPropertyValuesHolder(target, pvhY, pvhSX, pvhSY);
                break;
            }
            case "Shake": {
                float d = 28f * ratio;
                oa = ObjectAnimator.ofFloat(target, View.TRANSLATION_X, 0f, -d, d, -d * 0.7f, d * 0.7f, -d * 0.35f, d * 0.35f, 0f);
                break;
            }
            case "Pulse": {
                float s = 1f + (0.26f * ratio);
                PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, s, 0.94f, s * 0.96f, 1f);
                PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, s, 0.94f, s * 0.96f, 1f);
                oa = ObjectAnimator.ofPropertyValuesHolder(target, pvhX, pvhY);
                break;
            }
            case "Blink": {
                oa = ObjectAnimator.ofFloat(target, View.ALPHA, 1f, 0.05f, 1f, 0.05f, 1f);
                break;
            }
            case "Flip": {
                if (step.directionIndex == 0 || step.directionIndex == 1) {
                    oa = ObjectAnimator.ofFloat(target, View.ROTATION_X, 0f, 180f, 360f);
                } else {
                    oa = ObjectAnimator.ofFloat(target, View.ROTATION_Y, 0f, 180f, 360f);
                }
                break;
            }
            case "Swing": {
                float a = 24f * ratio;
                oa = ObjectAnimator.ofFloat(target, View.ROTATION, 0f, a, -a * 0.8f, a * 0.55f, -a * 0.3f, 0f);
                break;
            }
            case "Elastic":
            default: {
                PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.3f, 1.32f, 0.84f, 1.12f, 0.96f, 1f);
                PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.4f, 0.72f, 1.18f, 0.92f, 1.04f, 1f);
                oa = ObjectAnimator.ofPropertyValuesHolder(target, pvhX, pvhY);
                break;
            }
        }

        oa.setDuration(step.durationMs);
        oa.setStartDelay(step.delayMs);
        oa.setInterpolator(resolveInterpolator(step.interpolatorIndex));
        oa.setRepeatCount(step.repeatCount);
        oa.setRepeatMode(step.repeatReverse ? ValueAnimator.REVERSE : ValueAnimator.RESTART);
        return oa;
    }

    private void rebuildPackageAndCode() {
        List<AnimStep> activeSteps = sequenceChain.isEmpty()
                ? Arrays.asList(createCurrentStep())
                : new ArrayList<>(sequenceChain);

        StringBuilder chainText = new StringBuilder();
        int totalMs = 0;
        for (int i = 0; i < activeSteps.size(); i++) {
            AnimStep s = activeSteps.get(i);
            if (i > 0) chainText.append(" → ");
            chainText.append(s.type).append(" (").append(s.durationMs).append("ms)");
            totalMs += s.durationMs + s.delayMs;
        }
        tvChainSummary.setText(chainText.toString());

        byte[] dexBytes = MorsalinDexGenerator.buildAnimationHelperDex(this, activeSteps);
        String xmlAnim = generateAnimXml(activeSteps);
        String guide = GeneratedPackageExporter.buildAnimationMakerGuide(
                chainText.toString(), activeSteps.size(), totalMs);

        GeneratedPackageExporter.GeneratedPackage pkg =
                new GeneratedPackageExporter.GeneratedPackage("Morsalin_Animation_Package", "Android Animation Maker");
        pkg.addDexBinary(dexBytes);
        pkg.addFile("java/com/morsalin/xmlcreator/MorsalinAnimationHelper.java", generateJavaHelper(activeSteps));
        pkg.addFile("smali/com/morsalin/xmlcreator/MorsalinAnimationHelper.smali", generateSmaliHelper(activeSteps));
        pkg.addFile("res/anim/morsalin_custom_anim.xml", xmlAnim);
        pkg.setGuideContent("ANIMATION_GUIDE.txt", guide);
        latestPackage = pkg;
        displayActiveTabCode();
    }

    private static String floatHex(float val) {
        return String.format(Locale.US, "0x%08x", Float.floatToRawIntBits(val));
    }

    private String generateSmaliHelper(List<AnimStep> steps) {
        StringBuilder sb = new StringBuilder();
        sb.append(".class public Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;\n");
        sb.append(".super Ljava/lang/Object;\n");
        sb.append(".source \"MorsalinAnimationHelper.java\"\n\n");
        sb.append("# ====================================================================\n");
        sb.append("# Generated by Morsalin XML Creator — Android Animation Maker\n");
        sb.append("# Package : com.morsalin.xmlcreator\n");
        sb.append("#\n");
        sb.append("# HOW TO CALL IN MainActivity.smali (inside onCreate before return-void):\n");
        sb.append("# invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playOnActivity(Landroid/app/Activity;)V\n");
        sb.append("#\n");
        sb.append("# OR ON ANY SPECIFIC VIEW REGISTER (e.g. v1):\n");
        sb.append("# invoke-static {v1}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n");
        sb.append("# ====================================================================\n\n");

        sb.append(".method public constructor <init>()V\n");
        sb.append("    .locals 0\n\n");
        sb.append("    invoke-direct {p0}, Ljava/lang/Object;-><init>()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public static playOnActivity(Landroid/app/Activity;)V\n");
        sb.append("    .locals 2\n\n");
        sb.append("    if-eqz p0, :cond_end\n\n");
        sb.append("    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;\n");
        sb.append("    move-result-object v0\n");
        sb.append("    if-eqz v0, :cond_end\n\n");
        sb.append("    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;\n");
        sb.append("    move-result-object v1\n");
        sb.append("    if-eqz v1, :cond_end\n\n");
        sb.append("    invoke-static {v1}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n\n");
        sb.append("    :cond_end\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public static playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n");
        sb.append("    .locals 7\n\n");
        sb.append("    if-nez p0, :cond_start\n");
        sb.append("    const/4 v0, 0x0\n");
        sb.append("    return-object v0\n\n");
        sb.append("    :cond_start\n");
        sb.append("    new-instance v0, Ljava/util/ArrayList;\n");
        sb.append("    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V\n\n");

        for (int i = 0; i < steps.size(); i++) {
            AnimStep s = steps.get(i);
            float ratio = s.intensityPct / 100f;
            String propName = "alpha";
            float f0 = 0.1f, f1 = 1.0f, f2 = 1.0f;

            if ("Fade".equals(s.type)) {
                propName = "alpha";
                f0 = (s.directionIndex == 1) ? 1.0f : 0.1f;
                f1 = (s.directionIndex == 1) ? 0.15f : 1.0f;
                f2 = 1.0f;
            } else if ("Slide".equals(s.type)) {
                float dist = 120f * ratio;
                propName = (s.directionIndex >= 2) ? "translationX" : "translationY";
                f0 = (s.directionIndex == 1 || s.directionIndex == 2) ? -dist : dist;
                f1 = 0f;
                f2 = 0f;
            } else if ("Scale".equals(s.type) || "Zoom".equals(s.type) || "Pulse".equals(s.type) || "Elastic".equals(s.type)) {
                propName = "scaleX";
                f0 = "Pulse".equals(s.type) ? 0.85f : 0.35f;
                f1 = 1.18f * ratio;
                f2 = 1.0f;
            } else if ("Rotate".equals(s.type) || "Swing".equals(s.type)) {
                propName = "rotation";
                f0 = 0f;
                f1 = "Swing".equals(s.type) ? (25f * ratio) : (360f * ratio);
                f2 = 0f;
            } else if ("Bounce".equals(s.type)) {
                propName = "translationY";
                f0 = 0f;
                f1 = -45f * ratio;
                f2 = 0f;
            } else if ("Shake".equals(s.type)) {
                propName = "translationX";
                f0 = -26f * ratio;
                f1 = 26f * ratio;
                f2 = 0f;
            } else if ("Blink".equals(s.type)) {
                propName = "alpha";
                f0 = 1.0f;
                f1 = 0.05f;
                f2 = 1.0f;
            } else {
                propName = (s.directionIndex <= 1) ? "rotationX" : "rotationY";
                f0 = 0f;
                f1 = 180f;
                f2 = 360f;
            }

            sb.append("    # --- Step ").append(i + 1).append(": ").append(s.type)
                    .append(" (").append(s.durationMs).append("ms) ---\n");
            sb.append("    const/4 v2, 0x3\n");
            sb.append("    new-array v2, v2, [F\n");
            sb.append("    const/4 v3, 0x0\n");
            sb.append("    const v4, ").append(floatHex(f0)).append("\n");
            sb.append("    aput v4, v2, v3\n");
            sb.append("    const/4 v3, 0x1\n");
            sb.append("    const v4, ").append(floatHex(f1)).append("\n");
            sb.append("    aput v4, v2, v3\n");
            sb.append("    const/4 v3, 0x2\n");
            sb.append("    const v4, ").append(floatHex(f2)).append("\n");
            sb.append("    aput v4, v2, v3\n");
            sb.append("    const-string v3, \"").append(propName).append("\"\n");
            sb.append("    invoke-static {p0, v3, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;\n");
            sb.append("    move-result-object v2\n");
            sb.append("    const-wide/16 v4, 0x").append(Integer.toHexString(s.durationMs)).append("\n");
            sb.append("    invoke-virtual {v2, v4, v5}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;\n");

            if (s.delayMs > 0) {
                sb.append("    const-wide/16 v4, 0x").append(Integer.toHexString(s.delayMs)).append("\n");
                sb.append("    invoke-virtual {v2, v4, v5}, Landroid/animation/ObjectAnimator;->setStartDelay(J)V\n");
            }

            String interpClass = "Landroid/view/animation/AccelerateDecelerateInterpolator;";
            if (s.interpolatorIndex == 0) interpClass = "Landroid/view/animation/OvershootInterpolator;";
            else if (s.interpolatorIndex == 1) interpClass = "Landroid/view/animation/BounceInterpolator;";
            else if (s.interpolatorIndex == 3) interpClass = "Landroid/view/animation/AnticipateOvershootInterpolator;";
            else if (s.interpolatorIndex == 4) interpClass = "Landroid/view/animation/DecelerateInterpolator;";
            else if (s.interpolatorIndex == 5) interpClass = "Landroid/view/animation/LinearInterpolator;";
            sb.append("    new-instance v3, ").append(interpClass).append("\n");
            sb.append("    invoke-direct {v3}, ").append(interpClass).append("-><init>()V\n");
            sb.append("    invoke-virtual {v2, v3}, Landroid/animation/ObjectAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V\n");

            if (s.repeatCount != 0) {
                String repHex = (s.repeatCount < 0) ? "-0x1" : "0x" + Integer.toHexString(s.repeatCount);
                sb.append("    const/4 v3, ").append(repHex).append("\n");
                sb.append("    invoke-virtual {v2, v3}, Landroid/animation/ObjectAnimator;->setRepeatCount(I)V\n");
                sb.append("    const/4 v3, ").append(s.repeatReverse ? "0x2" : "0x1").append("\n");
                sb.append("    invoke-virtual {v2, v3}, Landroid/animation/ObjectAnimator;->setRepeatMode(I)V\n");
            }

            sb.append("    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z\n\n");
        }

        sb.append("    new-instance v1, Landroid/animation/AnimatorSet;\n");
        sb.append("    invoke-direct {v1}, Landroid/animation/AnimatorSet;-><init>()V\n");
        sb.append("    invoke-virtual {v1, v0}, Landroid/animation/AnimatorSet;->playSequentially(Ljava/util/List;)V\n");
        sb.append("    invoke-virtual {v1}, Landroid/animation/AnimatorSet;->start()V\n");
        sb.append("    return-object v1\n");
        sb.append(".end method\n");
        return sb.toString();
    }

    private String generateAnimXml(List<AnimStep> steps) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        sb.append("<!-- Generated by Morsalin XML Creator - Android Animation Maker -->\n");
        sb.append("<set xmlns:android=\"http://schemas.android.com/apk/res/android\"\n");
        sb.append("    android:fillAfter=\"false\"\n");
        sb.append("    android:shareInterpolator=\"false\">\n\n");

        int runningOffset = 0;
        for (int i = 0; i < steps.size(); i++) {
            AnimStep s = steps.get(i);
            int startOffset = runningOffset + s.delayMs;
            String interpRes = "@android:anim/accelerate_decelerate_interpolator";
            if (s.interpolatorIndex == 0) interpRes = "@android:anim/overshoot_interpolator";
            else if (s.interpolatorIndex == 1) interpRes = "@android:anim/bounce_interpolator";
            else if (s.interpolatorIndex == 3) interpRes = "@android:anim/anticipate_overshoot_interpolator";
            else if (s.interpolatorIndex == 4) interpRes = "@android:anim/decelerate_interpolator";
            else if (s.interpolatorIndex == 5) interpRes = "@android:anim/linear_interpolator";
            else if (s.interpolatorIndex == 6) interpRes = "@android:anim/cycle_interpolator";

            String repeatCountStr = s.repeatCount == ValueAnimator.INFINITE ? "infinite" : String.valueOf(s.repeatCount);
            String repeatModeStr = s.repeatReverse ? "reverse" : "restart";

            sb.append("    <!-- Step ").append(i + 1).append(": ").append(s.type)
                    .append(" (").append(s.durationMs).append("ms) -->\n");

            if ("Fade".equals(s.type) || "Blink".equals(s.type)) {
                sb.append("    <alpha\n");
                sb.append("        android:startOffset=\"").append(startOffset).append("\"\n");
                sb.append("        android:duration=\"").append(s.durationMs).append("\"\n");
                sb.append("        android:fromAlpha=\"0.1\"\n");
                sb.append("        android:toAlpha=\"1.0\"\n");
                sb.append("        android:repeatCount=\"").append(repeatCountStr).append("\"\n");
                sb.append("        android:repeatMode=\"").append(repeatModeStr).append("\"\n");
                sb.append("        android:interpolator=\"").append(interpRes).append("\" />\n\n");
            } else if ("Slide".equals(s.type) || "Bounce".equals(s.type) || "Shake".equals(s.type)) {
                String fromX = "0%", fromY = "35%";
                if ("Shake".equals(s.type)) { fromX = "-12%"; fromY = "0%"; }
                else if (s.directionIndex == 2) { fromX = "-45%"; fromY = "0%"; }
                else if (s.directionIndex == 3) { fromX = "45%"; fromY = "0%"; }
                else if (s.directionIndex == 1) { fromX = "0%"; fromY = "-35%"; }

                sb.append("    <translate\n");
                sb.append("        android:startOffset=\"").append(startOffset).append("\"\n");
                sb.append("        android:duration=\"").append(s.durationMs).append("\"\n");
                sb.append("        android:fromXDelta=\"").append(fromX).append("\"\n");
                sb.append("        android:toXDelta=\"0%\"\n");
                sb.append("        android:fromYDelta=\"").append(fromY).append("\"\n");
                sb.append("        android:toYDelta=\"0%\"\n");
                sb.append("        android:repeatCount=\"").append(repeatCountStr).append("\"\n");
                sb.append("        android:repeatMode=\"").append(repeatModeStr).append("\"\n");
                sb.append("        android:interpolator=\"").append(interpRes).append("\" />\n\n");
            } else if ("Rotate".equals(s.type) || "Swing".equals(s.type) || "Flip".equals(s.type)) {
                int deg = "Swing".equals(s.type) ? 25 : 360;
                sb.append("    <rotate\n");
                sb.append("        android:startOffset=\"").append(startOffset).append("\"\n");
                sb.append("        android:duration=\"").append(s.durationMs).append("\"\n");
                sb.append("        android:fromDegrees=\"0\"\n");
                sb.append("        android:toDegrees=\"").append(deg).append("\"\n");
                sb.append("        android:pivotX=\"50%\"\n");
                sb.append("        android:pivotY=\"50%\"\n");
                sb.append("        android:repeatCount=\"").append(repeatCountStr).append("\"\n");
                sb.append("        android:repeatMode=\"").append(repeatModeStr).append("\"\n");
                sb.append("        android:interpolator=\"").append(interpRes).append("\" />\n\n");
            } else {
                float fromScale = "Pulse".equals(s.type) ? 0.85f : 0.40f;
                sb.append("    <scale\n");
                sb.append("        android:startOffset=\"").append(startOffset).append("\"\n");
                sb.append("        android:duration=\"").append(s.durationMs).append("\"\n");
                sb.append("        android:fromXScale=\"").append(String.format(Locale.US, "%.2f", fromScale)).append("\"\n");
                sb.append("        android:toXScale=\"1.0\"\n");
                sb.append("        android:fromYScale=\"").append(String.format(Locale.US, "%.2f", fromScale)).append("\"\n");
                sb.append("        android:toYScale=\"1.0\"\n");
                sb.append("        android:pivotX=\"50%\"\n");
                sb.append("        android:pivotY=\"50%\"\n");
                sb.append("        android:repeatCount=\"").append(repeatCountStr).append("\"\n");
                sb.append("        android:repeatMode=\"").append(repeatModeStr).append("\"\n");
                sb.append("        android:interpolator=\"").append(interpRes).append("\" />\n\n");
            }
            runningOffset += s.durationMs + s.delayMs;
        }

        sb.append("</set>");
        return sb.toString();
    }

    private String generateJavaHelper(List<AnimStep> steps) {
        StringBuilder sb = new StringBuilder();
        sb.append("package com.morsalin.xmlcreator;\n\n");
        sb.append("import android.app.Activity;\n");
        sb.append("import android.animation.Animator;\n");
        sb.append("import android.animation.AnimatorSet;\n");
        sb.append("import android.animation.ObjectAnimator;\n");
        sb.append("import android.animation.PropertyValuesHolder;\n");
        sb.append("import android.animation.ValueAnimator;\n");
        sb.append("import android.content.Context;\n");
        sb.append("import android.view.View;\n");
        sb.append("import android.view.animation.Animation;\n");
        sb.append("import android.view.animation.AnimationUtils;\n");
        sb.append("import android.view.animation.AccelerateDecelerateInterpolator;\n");
        sb.append("import android.view.animation.AnticipateOvershootInterpolator;\n");
        sb.append("import android.view.animation.BounceInterpolator;\n");
        sb.append("import android.view.animation.CycleInterpolator;\n");
        sb.append("import android.view.animation.DecelerateInterpolator;\n");
        sb.append("import android.view.animation.LinearInterpolator;\n");
        sb.append("import android.view.animation.OvershootInterpolator;\n");
        sb.append("import java.util.ArrayList;\n");
        sb.append("import java.util.List;\n\n");
        sb.append("/**\n");
        sb.append(" * Generated by Morsalin XML Creator — Android Animation Maker\n");
        sb.append(" * Ready-to-use Java Animation Helper.\n");
        sb.append(" */\n");
        sb.append("public class MorsalinAnimationHelper {\n\n");
        sb.append("    /**\n");
        sb.append("     * Plays the configured animation sequence on the Activity's root window view.\n");
        sb.append("     */\n");
        sb.append("    public static void playOnActivity(Activity activity) {\n");
        sb.append("        if (activity == null || activity.getWindow() == null) return;\n");
        sb.append("        playSequence(activity.getWindow().getDecorView());\n");
        sb.append("    }\n\n");
        sb.append("    /**\n");
        sb.append("     * Plays the configured multi-step animation sequence on any View.\n");
        sb.append("     */\n");
        sb.append("    public static AnimatorSet playSequence(View target) {\n");
        sb.append("        if (target == null) return null;\n");
        sb.append("        List<Animator> steps = new ArrayList<>();\n\n");

        for (int i = 0; i < steps.size(); i++) {
            AnimStep s = steps.get(i);
            sb.append("        // Step ").append(i + 1).append(": ").append(s.type)
                    .append(" (").append(s.durationMs).append("ms)\n");
            sb.append("        ObjectAnimator step").append(i + 1).append(" = ");
            float ratio = s.intensityPct / 100f;
            if ("Fade".equals(s.type)) {
                sb.append("ObjectAnimator.ofFloat(target, View.ALPHA, 0.1f, 1f);\n");
            } else if ("Slide".equals(s.type)) {
                float dist = 120f * ratio;
                String prop = (s.directionIndex >= 2) ? "View.TRANSLATION_X" : "View.TRANSLATION_Y";
                sb.append("ObjectAnimator.ofFloat(target, ").append(prop).append(", ")
                        .append(String.format(Locale.US, "%.1ff", dist)).append(", 0f);\n");
            } else if ("Scale".equals(s.type) || "Zoom".equals(s.type) || "Pulse".equals(s.type) || "Elastic".equals(s.type)) {
                sb.append("ObjectAnimator.ofPropertyValuesHolder(target,\n");
                sb.append("                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.4f, 1.15f, 1f),\n");
                sb.append("                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.4f, 1.15f, 1f));\n");
            } else if ("Rotate".equals(s.type) || "Swing".equals(s.type)) {
                float deg = "Swing".equals(s.type) ? 25f : 360f;
                sb.append("ObjectAnimator.ofFloat(target, View.ROTATION, 0f, ")
                        .append(String.format(Locale.US, "%.1ff", deg)).append(", 0f);\n");
            } else if ("Bounce".equals(s.type)) {
                sb.append("ObjectAnimator.ofFloat(target, View.TRANSLATION_Y, 0f, -45f, 0f, -20f, 0f);\n");
            } else if ("Shake".equals(s.type)) {
                sb.append("ObjectAnimator.ofFloat(target, View.TRANSLATION_X, 0f, -25f, 25f, -15f, 15f, 0f);\n");
            } else if ("Blink".equals(s.type)) {
                sb.append("ObjectAnimator.ofFloat(target, View.ALPHA, 1f, 0.05f, 1f, 0.05f, 1f);\n");
            } else {
                sb.append("ObjectAnimator.ofFloat(target, View.ROTATION_Y, 0f, 180f, 360f);\n");
            }
            sb.append("        step").append(i + 1).append(".setDuration(").append(s.durationMs).append(");\n");
            if (s.delayMs > 0) {
                sb.append("        step").append(i + 1).append(".setStartDelay(").append(s.delayMs).append(");\n");
            }
            if (s.repeatCount != 0) {
                sb.append("        step").append(i + 1).append(".setRepeatCount(")
                        .append(s.repeatCount == ValueAnimator.INFINITE ? "ValueAnimator.INFINITE" : s.repeatCount).append(");\n");
                sb.append("        step").append(i + 1).append(".setRepeatMode(ValueAnimator.")
                        .append(s.repeatReverse ? "REVERSE" : "RESTART").append(");\n");
            }
            sb.append("        steps.add(step").append(i + 1).append(");\n\n");
        }

        sb.append("        AnimatorSet set = new AnimatorSet();\n");
        sb.append("        set.playSequentially(steps);\n");
        sb.append("        set.start();\n");
        sb.append("        return set;\n");
        sb.append("    }\n\n");
        sb.append("    /**\n");
        sb.append("     * Loads and starts res/anim/morsalin_custom_anim.xml on any View.\n");
        sb.append("     */\n");
        sb.append("    public static void playXmlAnimation(Context context, View target, int animResId) {\n");
        sb.append("        if (context == null || target == null) return;\n");
        sb.append("        Animation anim = AnimationUtils.loadAnimation(context, animResId);\n");
        sb.append("        target.startAnimation(anim);\n");
        sb.append("    }\n");
        sb.append("}\n");
        return sb.toString();
    }

    private String generateMainActivityUsage(List<AnimStep> steps) {
        return "// ==========================================================\n"
                + "// 1. SMALI CALL (Paste in MainActivity.smali -> onCreate)\n"
                + "// ==========================================================\n"
                + "invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playOnActivity(Landroid/app/Activity;)V\n\n"
                + "// Or on any specific View register (e.g., v1):\n"
                + "invoke-static {v1}, Lcom/morsalin/xmlcreator/MorsalinAnimationHelper;->playSequence(Landroid/view/View;)Landroid/animation/AnimatorSet;\n\n"
                + "// ==========================================================\n"
                + "// 2. JAVA CALL (Paste in MainActivity.java -> onCreate)\n"
                + "// ==========================================================\n"
                + "import com.morsalin.xmlcreator.MorsalinAnimationHelper;\n\n"
                + "Button myButton = findViewById(R.id.my_button);\n"
                + "myButton.setOnClickListener(v -> {\n"
                + "    MorsalinAnimationHelper.playSequence(v);\n"
                + "});\n";
    }

    private String buildJsonConfig() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("currentType", currentType);
            obj.put("currentDuration", currentDuration);
            obj.put("currentDelay", currentDelay);
            obj.put("currentIntensity", currentIntensity);
            obj.put("currentDirIdx", currentDirIdx);
            obj.put("currentInterpIdx", currentInterpIdx);
            obj.put("currentRepeatIdx", currentRepeatIdx);
            obj.put("currentRepeatReverse", currentRepeatReverse);

            JSONArray arr = new JSONArray();
            for (AnimStep s : sequenceChain) {
                JSONObject item = new JSONObject();
                item.put("type", s.type);
                item.put("durationMs", s.durationMs);
                item.put("delayMs", s.delayMs);
                item.put("intensityPct", s.intensityPct);
                item.put("directionIndex", s.directionIndex);
                item.put("interpolatorIndex", s.interpolatorIndex);
                item.put("repeatCount", s.repeatCount);
                item.put("repeatReverse", s.repeatReverse);
                arr.put(item);
            }
            obj.put("chain", arr);
            return obj.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void loadFromJsonConfig(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            currentType = obj.optString("currentType", "Fade");
            currentDuration = obj.optInt("currentDuration", 500);
            currentDelay = obj.optInt("currentDelay", 0);
            currentIntensity = obj.optInt("currentIntensity", 100);
            currentDirIdx = obj.optInt("currentDirIdx", 0);
            currentInterpIdx = obj.optInt("currentInterpIdx", 0);
            currentRepeatIdx = obj.optInt("currentRepeatIdx", 0);
            currentRepeatReverse = obj.optBoolean("currentRepeatReverse", true);

            seekDuration.setProgress(Math.max(0, currentDuration - 100));
            seekDelay.setProgress(Math.max(0, currentDelay));
            seekIntensity.setProgress(Math.max(0, currentIntensity - 20));

            JSONArray arr = obj.optJSONArray("chain");
            if (arr != null && arr.length() > 0) {
                sequenceChain.clear();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject item = arr.getJSONObject(i);
                    sequenceChain.add(new AnimStep(
                            item.optString("type", "Fade"),
                            item.optInt("durationMs", 450),
                            item.optInt("delayMs", 0),
                            item.optInt("intensityPct", 100),
                            item.optInt("directionIndex", 0),
                            item.optInt("interpolatorIndex", 0),
                            item.optInt("repeatCount", 0),
                            item.optBoolean("repeatReverse", true)
                    ));
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        stopRunningAnimation();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        stopRunningAnimation();
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
