package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

/**
 * Handles smooth, safe micro-animations for social buttons.
 * Animates only the targeted icon element without causing whole-screen motion.
 */
public class SocialButtonAnimationHelper {

    public static final String URL_TELEGRAM = "https://t.me/anonymous_modder_king";
    public static final String URL_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";

    public static void bindSocialButtons(View root, Context context) {
        if (root == null || context == null) return;
        View tgL = root.findViewById(com.android.modding.tools.R.id.btn_social_telegram_left);
        View tgR = root.findViewById(com.android.modding.tools.R.id.btn_social_telegram_right);
        View fbL = root.findViewById(com.android.modding.tools.R.id.btn_social_facebook_left);
        View fbR = root.findViewById(com.android.modding.tools.R.id.btn_social_facebook_right);

        if (tgL != null) tgL.setOnClickListener(v -> animateAndOpen(v, URL_TELEGRAM, context));
        if (tgR != null) tgR.setOnClickListener(v -> animateAndOpen(v, URL_TELEGRAM, context));
        if (fbL != null) fbL.setOnClickListener(v -> animateAndOpen(v, URL_FACEBOOK, context));
        if (fbR != null) fbR.setOnClickListener(v -> animateAndOpen(v, URL_FACEBOOK, context));
    }

    public static void animateAndOpen(View v, String url, Context context) {
        if (v != null) {
            v.animate()
                    .rotationBy(25f)
                    .scaleX(0.88f)
                    .scaleY(0.88f)
                    .setDuration(120)
                    .withEndAction(() -> {
                        v.animate()
                                .rotation(0f)
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .setDuration(160)
                                .start();
                        openUrl(url, context);
                    })
                    .start();
        } else {
            openUrl(url, context);
        }
    }

    private static void openUrl(String url, Context context) {
        if (context == null || url == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (!(context instanceof android.app.Activity)) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }
}
