package com.android.modding.tools.helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * Manages smooth staggered entry animations for cards and lists across screens.
 */
public class StaggeredEntranceAnimationHelper {

    private static final String PREF_NAME = "morsalin_settings";
    public static final String KEY_STAGGERED_STYLE = "key_staggered_entrance_style";

    public static final int STYLE_OFF = 0;
    public static final int STYLE_CASCADE_SLIDE = 1;
    public static final int STYLE_ELASTIC_POP = 2;
    public static final int STYLE_CYBER_DRIFT = 3;
    public static final int STYLE_3D_FLIP = 4;
    public static final int STYLE_SPIRAL_UNFURL = 5;
    public static final int STYLE_SHUTTER_WAVE = 6;
    public static final int STYLE_MATRIX_DROP = 7;
    public static final int STYLE_WARP_ZOOM = 8;
    public static final int STYLE_DIAGONAL_SLIDE = 9;

    public static final String[] STYLE_NAMES = {
            "Disabled (Instant)",
            "Smooth Cascade Slide-Up",
            "Pop & Elastic Scale",
            "Horizontal Drift",
            "3D Flip Cascade",
            "Spiral Swirl Unfurl",
            "Shutter Wave Unfold",
            "Matrix Quantum Drop",
            "Hyperspace Warp Zoom",
            "Diagonal Neon Slide"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Cards appear instantly without entrance delay",
            "Cards glide up sequentially with smooth deceleration",
            "Cards scale and pop in with elastic bounce",
            "Cards glide in alternately from left and right",
            "Cards rotate on X-axis and cascade smoothly into place",
            "Cards swirl into view with subtle angular velocity",
            "Cards expand vertically like a camera shutter",
            "High-energy drop-in from top with snappy bounce",
            "Zoom in from deep background with cosmic momentum",
            "Sleek diagonal glide from bottom corner"
    };

    private static int cachedStyle = -1;

    public static int getSavedStyle(Context context) {
        if (cachedStyle >= 0) return cachedStyle;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cachedStyle = sp.getInt(KEY_STAGGERED_STYLE, STYLE_OFF);
        return cachedStyle;
    }

    public static void setSavedStyle(Context context, int style) {
        cachedStyle = style;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_STAGGERED_STYLE, style).apply();
    }

    public static boolean isEnabled(Context context) {
        return getSavedStyle(context) != STYLE_OFF;
    }

    public static void animateContainer(ViewGroup container, Context context) {
        if (container == null || context == null) return;
        int style = getSavedStyle(context);
        if (style == STYLE_OFF) return;

        int count = container.getChildCount();
        for (int i = 0; i < count; i++) {
            final View child = container.getChildAt(i);
            if (child == null || child.getVisibility() != View.VISIBLE) continue;

            child.setAlpha(0f);
            long delay = Math.min(i * 35L, 350L);

            switch (style) {
                case STYLE_CASCADE_SLIDE:
                    child.setTranslationY(45f);
                    child.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setStartDelay(delay)
                            .setDuration(260)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    break;

                case STYLE_ELASTIC_POP:
                    child.setScaleX(0.85f);
                    child.setScaleY(0.85f);
                    child.animate()
                            .alpha(1f)
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setStartDelay(delay)
                            .setDuration(300)
                            .setInterpolator(new OvershootInterpolator(1.8f))
                            .start();
                    break;

                case STYLE_CYBER_DRIFT:
                    child.setTranslationX((i % 2 == 0) ? -45f : 45f);
                    child.animate()
                            .alpha(1f)
                            .translationX(0f)
                            .setStartDelay(delay)
                            .setDuration(240)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    break;

                case STYLE_3D_FLIP:
                    child.setRotationX(24f);
                    child.setTranslationY(30f);
                    child.animate()
                            .alpha(1f)
                            .rotationX(0f)
                            .translationY(0f)
                            .setStartDelay(delay)
                            .setDuration(280)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    break;

                case STYLE_SPIRAL_UNFURL:
                    child.setRotation((i % 2 == 0) ? -6f : 6f);
                    child.setScaleX(0.88f);
                    child.setScaleY(0.88f);
                    child.animate()
                            .alpha(1f)
                            .rotation(0f)
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setStartDelay(delay)
                            .setDuration(300)
                            .setInterpolator(new OvershootInterpolator(1.6f))
                            .start();
                    break;

                case STYLE_SHUTTER_WAVE:
                    child.setScaleY(0.2f);
                    child.animate()
                            .alpha(1f)
                            .scaleY(1.0f)
                            .setStartDelay(delay)
                            .setDuration(240)
                            .setInterpolator(new OvershootInterpolator(1.4f))
                            .start();
                    break;

                case STYLE_MATRIX_DROP:
                    child.setTranslationY(-60f);
                    child.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setStartDelay(delay)
                            .setDuration(280)
                            .setInterpolator(new OvershootInterpolator(2.0f))
                            .start();
                    break;

                case STYLE_WARP_ZOOM:
                    child.setScaleX(0.55f);
                    child.setScaleY(0.55f);
                    child.animate()
                            .alpha(1f)
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setStartDelay(delay)
                            .setDuration(320)
                            .setInterpolator(new OvershootInterpolator(2.2f))
                            .start();
                    break;

                case STYLE_DIAGONAL_SLIDE:
                    child.setTranslationX(-35f);
                    child.setTranslationY(35f);
                    child.animate()
                            .alpha(1f)
                            .translationX(0f)
                            .translationY(0f)
                            .setStartDelay(delay)
                            .setDuration(280)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    break;
            }
        }
    }
}
