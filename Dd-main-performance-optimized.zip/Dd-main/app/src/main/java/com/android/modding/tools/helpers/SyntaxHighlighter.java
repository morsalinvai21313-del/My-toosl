package com.android.modding.tools.helpers;

import android.graphics.Color;
import android.text.Editable;
import android.text.Spannable;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SyntaxHighlighter {

    private static final int COLOR_KEYWORD_CYAN = Color.parseColor("#00E5FF");
    private static final int COLOR_KEYWORD_PINK = Color.parseColor("#FF2A85");
    private static final int COLOR_TYPE_PURPLE = Color.parseColor("#B388FF");
    private static final int COLOR_STRING_GREEN = Color.parseColor("#00FF88");
    private static final int COLOR_ANNOTATION_GOLD = Color.parseColor("#FFD54F");
    private static final int COLOR_NUMBER_ORANGE = Color.parseColor("#FF9E80");
    private static final int COLOR_COMMENT_MUTED = Color.parseColor("#6E97A8");
    private static final int COLOR_SEARCH_BG = Color.parseColor("#66FF007F");

    private static final Pattern PATTERN_KEYWORDS_PRIMARY = Pattern.compile(
            "\\b(package|import|class|interface|enum|object|companion|data|sealed|fun|val|var|lateinit|const|" +
            "public|private|protected|internal|open|final|abstract|static|synchronized|volatile|transient|" +
            "extends|implements|override|constructor|init|by|where|typealias)\\b|" +
            "\\.(class|super|source|implements|field|method|end|locals|registers|param|prologue|line|annotation)\\b"
    );

    private static final Pattern PATTERN_KEYWORDS_CONTROL = Pattern.compile(
            "\\b(if|else|when|switch|case|default|for|while|do|break|continue|return|try|catch|finally|throw|throws|" +
            "new|this|super|null|true|false|is|in|as|instanceof|" +
            "invoke-static|invoke-virtual|invoke-direct|invoke-interface|invoke-super|" +
            "const-string|const-wide|const/4|const/16|const/high16|new-instance|new-array|fill-array-data|" +
            "move-result-object|move-result|return-void|return-object|if-nez|if-eqz|if-lt|if-ge|goto|" +
            "iget-object|iget|iput-object|iput|sget-object|sget|check-cast|instance-of)\\b"
    );

    private static final Pattern PATTERN_TYPES = Pattern.compile(
            "\\b(void|int|long|float|double|boolean|char|byte|short|" +
            "Int|Long|Float|Double|Boolean|Char|Byte|Short|Unit|Any|Nothing|" +
            "String|CharSequence|Object|List|MutableList|ArrayList|Map|MutableMap|HashMap|Set|" +
            "Bundle|Intent|View|TextView|EditText|Button|ImageView|LinearLayout|FrameLayout|RelativeLayout|" +
            "Context|Activity|AppCompatActivity|Fragment|Toast|Log|R|" +
            "v0|v1|v2|v3|v4|v5|v6|v7|v8|v9|v10|v11|v12|p0|p1|p2|p3)\\b|" +
            "L[a-zA-Z0-9_/$]+;"
    );

    private static final Pattern PATTERN_ANNOTATIONS = Pattern.compile("@[A-Za-z_][A-Za-z0-9_]*|:[a-zA-Z0-9_]+");
    private static final Pattern PATTERN_NUMBERS = Pattern.compile("\\b\\d+(\\.\\d+)?[fFdDlL]?\\b|-?0x[0-9a-fA-F]+L?\\b");
    private static final Pattern PATTERN_STRINGS = Pattern.compile("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'");
    private static final Pattern PATTERN_COMMENTS = Pattern.compile("//[^\\n]*|#[^\\n]*|/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->");

    public static void applyHighlighting(Editable editable, String searchQuery) {
        if (editable == null) return;

        ForegroundColorSpan[] oldFg = editable.getSpans(0, editable.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan span : oldFg) {
            editable.removeSpan(span);
        }
        BackgroundColorSpan[] oldBg = editable.getSpans(0, editable.length(), BackgroundColorSpan.class);
        for (BackgroundColorSpan span : oldBg) {
            editable.removeSpan(span);
        }

        String text = editable.toString();
        if (text.isEmpty() || text.length() > 45000) {
            return;
        }

        applyPattern(editable, text, PATTERN_TYPES, COLOR_TYPE_PURPLE);
        applyPattern(editable, text, PATTERN_NUMBERS, COLOR_NUMBER_ORANGE);
        applyPattern(editable, text, PATTERN_KEYWORDS_PRIMARY, COLOR_KEYWORD_CYAN);
        applyPattern(editable, text, PATTERN_KEYWORDS_CONTROL, COLOR_KEYWORD_PINK);
        applyPattern(editable, text, PATTERN_ANNOTATIONS, COLOR_ANNOTATION_GOLD);
        applyPattern(editable, text, PATTERN_STRINGS, COLOR_STRING_GREEN);
        applyPattern(editable, text, PATTERN_COMMENTS, COLOR_COMMENT_MUTED);

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            String queryLower = searchQuery.toLowerCase();
            String textLower = text.toLowerCase();
            int index = textLower.indexOf(queryLower);
            while (index >= 0) {
                editable.setSpan(
                        new BackgroundColorSpan(COLOR_SEARCH_BG),
                        index,
                        index + queryLower.length(),
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                );
                index = textLower.indexOf(queryLower, index + queryLower.length());
            }
        }
    }

    private static void applyPattern(Editable editable, String text, Pattern pattern, int color) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            editable.setSpan(
                    new ForegroundColorSpan(color),
                    matcher.start(),
                    matcher.end(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            );
        }
    }

    public static CharSequence highlightXml(String xml) {
        if (xml == null || xml.isEmpty()) return "";
        android.text.SpannableStringBuilder ssb = new android.text.SpannableStringBuilder(xml);
        applyHighlighting(ssb, null);
        return ssb;
    }
}
