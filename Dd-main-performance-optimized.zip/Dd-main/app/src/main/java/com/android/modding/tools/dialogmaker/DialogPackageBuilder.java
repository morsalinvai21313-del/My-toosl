package com.android.modding.tools.dialogmaker;

import android.content.Context;

import com.android.modding.tools.generators.JavaToSmaliToolchain;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.MorsalinDexGenerator;

import java.util.Collections;
import java.util.Map;

/**
 * End-to-end Build Pipeline for Dialog Maker.
 * 1. Generates 100% programmatic Android Java source code (ZERO XML).
 * 2. Compiles to Dalvik executable (classes.dex) using embedded D8 / ECJ toolchain.
 * 3. Validates binary integrity (Magic header, Adler32, SHA-1, Dexlib2).
 * 4. Generates single authoritative GUIDE.smali.
 * 5. Bundles only strictly required assets.
 * 6. Generates strictly 1 classes.dex and ZERO XML files.
 */
public class DialogPackageBuilder {

    public static class BuildResult {
        public final boolean success;
        public final String errorMessage;
        public final GeneratedPackageExporter.GeneratedPackage generatedPackage;
        public final DexValidator.ValidationResult dexValidation;
        public final byte[] dexBytes;
        public final String guideContent;
        public final String readMeSmali;
        public final Map<String, String> xmlFiles;
        public final DialogAssetGenerator.AssetBundle assetBundle;

        public BuildResult(boolean success, String errorMessage,
                           GeneratedPackageExporter.GeneratedPackage generatedPackage,
                           DexValidator.ValidationResult dexValidation,
                           byte[] dexBytes, String guideContent,
                           String readMeSmali, Map<String, String> xmlFiles,
                           DialogAssetGenerator.AssetBundle assetBundle) {
            this.success = success;
            this.errorMessage = errorMessage;
            this.generatedPackage = generatedPackage;
            this.dexValidation = dexValidation;
            this.dexBytes = dexBytes;
            this.guideContent = guideContent;
            this.readMeSmali = readMeSmali;
            this.xmlFiles = xmlFiles != null ? xmlFiles : Collections.emptyMap();
            this.assetBundle = assetBundle;
        }

        public static BuildResult failure(String message) {
            return new BuildResult(false, message, null, null, null, null, null, null, null);
        }
    }

    public static BuildResult buildDialogPackage(Context context, DialogConfig config) {
        if (context == null || config == null) {
            return BuildResult.failure("Invalid context or null configuration.");
        }

        // 1. Validate Configuration
        if (config.titleText == null || config.titleText.trim().isEmpty()) {
            config.titleText = "Notice";
        }
        if (config.buttonCount < 1) config.buttonCount = 1;
        if (config.buttonCount > 3) config.buttonCount = 3;

        // 2. Generate Pure Programmatic Java Source Code (NO XML)
        String javaCode = ProgrammaticDialogSourceGenerator.generateJavaCode(config);

        // 3. Compile Real Dalvik DEX Binary via D8 / ECJ
        byte[] dexBytes = null;
        try {
            JavaToSmaliToolchain.CompilationResult compResult =
                    JavaToSmaliToolchain.compile(context, javaCode, "MorsalinCustomDialog.java", null);
            if (compResult != null && compResult.success && compResult.dexBytes != null && compResult.dexBytes.length >= 112) {
                dexBytes = compResult.dexBytes;
            }
        } catch (Throwable ignored) {}

        // Fallback to verified template patcher if standalone compiler environment is constrained
        if (dexBytes == null || dexBytes.length < 112) {
            dexBytes = MorsalinDexGenerator.buildCustomDialogDex(
                    context,
                    config.titleText,
                    config.subtitleVisible ? config.subtitleText : "",
                    config.messageVisible ? config.messageText : "",
                    config.buttonCount,
                    config.btn1Text,
                    config.btn2Text,
                    config.btn3Text,
                    config.btn1Url,
                    config.btn2Url,
                    config.btn3Url,
                    config.bgHex,
                    config.borderHex,
                    config.btnBgHex,
                    config.titleColorHex,
                    config.messageColorHex,
                    config.cornerRadiusDp,
                    config.borderWidthDp,
                    config.paddingDp,
                    config.widthPct,
                    config.openAnimMode
            );
        }

        if (dexBytes == null || dexBytes.length == 0) {
            return BuildResult.failure("DEX compilation engine returned empty binary.");
        }

        // 4. Validate Generated DEX Binary (Header, Checksum, SHA-1, Dexlib2)
        DexValidator.ValidationResult valResult = DexValidator.validate(dexBytes, context.getCacheDir());
        if (!valResult.isValid) {
            return BuildResult.failure("DEX binary validation failed: " + valResult.errorMessage);
        }

        // 5. Generate GUIDE.smali
        String guideSmali = GuideGenerator.generateSmaliGuide(config, valResult);

        // 6. Generate Assets Directory Bundle (Only required assets, NO XML)
        DialogAssetGenerator.AssetBundle assetBundle = DialogAssetGenerator.generateAssets(config, context);

        // 7. Assemble Clean Output Package: Strictly SINGLE classes.dex, ONE GUIDE.smali, and assets/
        String folderName = config.dialogName != null && !config.dialogName.trim().isEmpty()
                ? config.dialogName.trim().replaceAll("\\s+", "_")
                : (config.dialogType != null ? config.dialogType.trim().replaceAll("\\s+", "_") : "Dialog_Output");
        GeneratedPackageExporter.GeneratedPackage pkg =
                new GeneratedPackageExporter.GeneratedPackage(folderName, config.dialogType);

        // Strictly SINGLE classes.dex binary for target APK merge (NO DUPLICATE DEX)
        pkg.addDexBinary(dexBytes);

        // Strictly SINGLE authoritative hook.smali
        pkg.setGuideContent("hook.smali", guideSmali);

        // Assets directory files (only dedicated required files for this dialog)
        for (Map.Entry<String, byte[]> entry : assetBundle.binaryAssets.entrySet()) {
            pkg.binaryFiles.put(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, String> entry : assetBundle.textAssets.entrySet()) {
            pkg.addFile(entry.getKey(), entry.getValue());
        }

        // ZERO XML FILES: Intentionally do NOT add any xml files!

        return new BuildResult(true, null, pkg, valResult, dexBytes, guideSmali,
                guideSmali, Collections.emptyMap(), assetBundle);
    }
}
