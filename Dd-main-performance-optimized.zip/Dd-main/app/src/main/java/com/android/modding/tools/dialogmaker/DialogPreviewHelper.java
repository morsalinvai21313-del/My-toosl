package com.android.modding.tools.dialogmaker;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.BounceInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.MorsalinToast;

/**
 * Universal Dialog Live Preview & Test Runner.
 * Perfectly mirrors the programmatic output of classes.dex in real-time.
 */
public class DialogPreviewHelper {

    public static final int[] ICON_RES = {
            R.drawable.ic_about_dev,
            R.drawable.ic_code_convert,
            R.drawable.ic_save,
            R.drawable.ic_refresh,
            R.drawable.ic_settings_anim,
            0
    };

    public static int parseColorSafe(String hex, int fallback) {
        if (hex == null || hex.trim().isEmpty()) return fallback;
        try {
            return Color.parseColor(hex.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    public static int dpToPx(Context context, int dp) {
        if (context == null) return dp * 2;
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    public static GradientDrawable buildDialogDrawable(DialogConfig config, Context context) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        if (config.isGradient) {
            gd.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            int startC = parseColorSafe(config.bgHex, 0xFF0C2230);
            int endC = parseColorSafe(config.bgGradientEndHex, 0xFF142F42);
            gd.setColors(new int[]{startC, endC});
        } else {
            gd.setColor(parseColorSafe(config.bgHex, 0xFF0C2230));
        }
        gd.setCornerRadius(dpToPx(context, config.cornerRadiusDp));
        gd.setStroke(dpToPx(context, config.borderWidthDp), parseColorSafe(config.borderHex, 0xFF00E5FF));
        return gd;
    }

    public static GradientDrawable buildButtonDrawable(DialogConfig config, String bgHex, String borderHex, int borderWidthDp, Context context) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setColor(parseColorSafe(bgHex, 0xFF122C3D));
        gd.setCornerRadius(dpToPx(context, Math.max(4, config.cornerRadiusDp / 2)));
        gd.setStroke(dpToPx(context, borderWidthDp), parseColorSafe(borderHex, 0xFF00E5FF));
        return gd;
    }

    public static GradientDrawable buildButtonDrawable(DialogConfig config, String bgHex, Context context) {
        return buildButtonDrawable(config, bgHex, config.borderHex, 1, context);
    }

    public static Typeface resolveFontTypeface(String fontName) {
        if ("MONOSPACE".equalsIgnoreCase(fontName)) return Typeface.MONOSPACE;
        if ("SERIF".equalsIgnoreCase(fontName)) return Typeface.SERIF;
        if ("SANS_SERIF".equalsIgnoreCase(fontName)) return Typeface.SANS_SERIF;
        return Typeface.DEFAULT;
    }

    public static int resolveGravity(String alignment) {
        if ("LEFT".equalsIgnoreCase(alignment)) return Gravity.START;
        if ("RIGHT".equalsIgnoreCase(alignment)) return Gravity.END;
        return Gravity.CENTER;
    }

    public static Bitmap createFramedAvatarBitmap(
            Context context, Bitmap src, int sizeDp, String shape,
            int borderWidthDp, String borderHex, String borderStyle) {
        if (src == null) return null;
        try {
            int sizePx = dpToPx(context, Math.max(36, sizeDp));
            Bitmap output = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);

            int strokePx = dpToPx(context, Math.max(0, borderWidthDp));
            int strokeColor = parseColorSafe(borderHex, 0xFF00E5FF);

            float halfStroke = strokePx / 2f;
            RectF innerRect = new RectF(strokePx, strokePx, sizePx - strokePx, sizePx - strokePx);
            RectF borderRect = new RectF(halfStroke, halfStroke, sizePx - halfStroke, sizePx - halfStroke);

            Bitmap scaledSrc = Bitmap.createScaledBitmap(src, (int) Math.max(1, innerRect.width()), (int) Math.max(1, innerRect.height()), true);
            BitmapShader shader = new BitmapShader(scaledSrc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            Matrix matrix = new Matrix();
            matrix.setTranslate(innerRect.left, innerRect.top);
            shader.setLocalMatrix(matrix);

            Paint imgPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            imgPaint.setShader(shader);

            boolean isCircle = "CIRCLE".equalsIgnoreCase(shape);
            boolean isRounded = "ROUNDED".equalsIgnoreCase(shape);
            float cornerRadius = isCircle ? sizePx / 2f : (isRounded ? sizePx * 0.22f : 0f);

            if (isCircle) {
                canvas.drawCircle(sizePx / 2f, sizePx / 2f, (sizePx - strokePx * 2) / 2f, imgPaint);
            } else if (isRounded) {
                canvas.drawRoundRect(innerRect, cornerRadius, cornerRadius, imgPaint);
            } else {
                canvas.drawRect(innerRect, imgPaint);
            }

            if (strokePx > 0) {
                Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                borderPaint.setStyle(Paint.Style.STROKE);
                borderPaint.setStrokeWidth(strokePx);
                borderPaint.setColor(strokeColor);

                if ("DOTTED".equalsIgnoreCase(borderStyle)) {
                    borderPaint.setStrokeCap(Paint.Cap.ROUND);
                    borderPaint.setPathEffect(new DashPathEffect(new float[]{Math.max(1f, strokePx * 0.4f), Math.max(4f, strokePx * 2.2f)}, 0));
                } else if ("DASHED".equalsIgnoreCase(borderStyle)) {
                    borderPaint.setPathEffect(new DashPathEffect(new float[]{strokePx * 3.2f, strokePx * 2.0f}, 0));
                } else if ("GLOW".equalsIgnoreCase(borderStyle)) {
                    borderPaint.setShadowLayer(strokePx * 2.5f, 0, 0, strokeColor);
                }

                if (isCircle) {
                    canvas.drawCircle(sizePx / 2f, sizePx / 2f, (sizePx - strokePx) / 2f, borderPaint);
                } else if (isRounded) {
                    canvas.drawRoundRect(borderRect, cornerRadius, cornerRadius, borderPaint);
                } else {
                    canvas.drawRect(borderRect, borderPaint);
                }
            }

            return output;
        } catch (Throwable t) {
            return src;
        }
    }

    public static void showInteractiveTestDialog(Activity activity, DialogConfig config) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        boolean forceUpdateMode = config.isForceUpdate
                || (DialogConfig.TYPE_NOTICE.equalsIgnoreCase(config.dialogType) && config.isForceUpdate);
        dialog.setCancelable(!forceUpdateMode && config.cancelable);
        if (forceUpdateMode) {
            dialog.setCanceledOnTouchOutside(false);
            dialog.setOnKeyListener((d, keyCode, event) -> keyCode == android.view.KeyEvent.KEYCODE_BACK);
        }

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dpToPx(activity, config.paddingDp);
        root.setPadding(pad, pad, pad, pad);
        root.setMinimumHeight(dpToPx(activity, Math.max(260, config.heightDp)));
        root.setBackground(buildDialogDrawable(config, activity));

        // 1. Notice Badge
        if (config.hasNoticeBadge) {
            TextView tvBadge = new TextView(activity);
            tvBadge.setText(config.noticeBadgeText);
            tvBadge.setTextColor(parseColorSafe(config.noticeBadgeTextHex, Color.WHITE));
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, Typeface.BOLD);
            tvBadge.setPadding(dpToPx(activity, 12), dpToPx(activity, 3), dpToPx(activity, 12), dpToPx(activity, 3));
            GradientDrawable badgeBg = new GradientDrawable();
            badgeBg.setColor(parseColorSafe(config.noticeBadgeBgHex, 0xFFFF1744));
            badgeBg.setCornerRadius(dpToPx(activity, 8));
            tvBadge.setBackground(badgeBg);
            root.addView(tvBadge);
        }

        // 2. Icon / Avatar / Image
        boolean isProfileImg = "AVATAR".equalsIgnoreCase(config.imageKind)
                || DialogConfig.TYPE_PROFILE.equalsIgnoreCase(config.dialogType)
                || config.hasCustomAvatar;
        if (config.hasImage || isProfileImg) {
            ImageView iv = new ImageView(activity);
            int sizeDp = isProfileImg ? config.avatarSizeDp : config.imageSizeDp;
            int size = dpToPx(activity, Math.max(32, sizeDp));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.topMargin = dpToPx(activity, 6);
            lp.bottomMargin = dpToPx(activity, 4);

            if (isProfileImg) {
                Bitmap rawBmp = null;
                if (config.hasCustomAvatar && config.customAvatarBytes != null && config.customAvatarBytes.length > 0) {
                    try {
                        rawBmp = BitmapFactory.decodeByteArray(config.customAvatarBytes, 0, config.customAvatarBytes.length);
                    } catch (Throwable ignored) {}
                }
                if (rawBmp == null) {
                    int avatarRes = R.drawable.avatar_morsalin_cyber_1790834216696;
                    if ("Morsalin Neon".equalsIgnoreCase(config.avatarPreset)) {
                        avatarRes = R.drawable.avatar_morsalin_neon_1790834232712;
                    } else if ("Sanny DJ".equalsIgnoreCase(config.avatarPreset)) {
                        avatarRes = R.drawable.avatar_sanny_dj_1790834248190;
                    } else if ("Sanny Modder".equalsIgnoreCase(config.avatarPreset)) {
                        avatarRes = R.drawable.avatar_sanny_modder_1790834263619;
                    }
                    rawBmp = BitmapFactory.decodeResource(activity.getResources(), avatarRes);
                }
                if (rawBmp != null) {
                    Bitmap framed = createFramedAvatarBitmap(
                            activity, rawBmp, config.avatarSizeDp, config.avatarShape,
                            config.avatarBorderWidthDp, config.avatarBorderHex, config.avatarBorderStyle);
                    iv.setImageBitmap(framed != null ? framed : rawBmp);
                    iv.clearColorFilter();
                }
            } else {
                int res = ICON_RES[Math.min(config.iconResIndex, ICON_RES.length - 1)];
                if (res != 0) {
                    iv.setImageResource(res);
                    iv.setColorFilter(parseColorSafe(config.borderHex, Color.CYAN));
                }
            }

            if (!isProfileImg && config.imageBgHex != null && !config.imageBgHex.trim().isEmpty()) {
                GradientDrawable ivBg = new GradientDrawable();
                ivBg.setColor(parseColorSafe(config.imageBgHex, 0x2500E5FF));
                ivBg.setCornerRadius(dpToPx(activity, "CIRCLE".equalsIgnoreCase(config.avatarShape) ? 999 : 12));
                iv.setBackground(ivBg);
                int p = dpToPx(activity, 4);
                iv.setPadding(p, p, p, p);
            }

            root.addView(iv, lp);
        }

        // Live Countdown Timer (টাইম সেট / কাউন্টডাউন টাইমার)
        if (config.hasCountdownTimer) {
            final TextView tvCountdown = new TextView(activity);
            tvCountdown.setText("⏱️ Mandatory Update in: " + config.countdownSeconds + "s");
            tvCountdown.setTextSize(12.5f);
            tvCountdown.setTextColor(parseColorSafe("#FFB703", Color.YELLOW));
            tvCountdown.setTypeface(null, Typeface.BOLD);
            tvCountdown.setGravity(Gravity.CENTER);
            tvCountdown.setPadding(dpToPx(activity, 14), dpToPx(activity, 4), dpToPx(activity, 14), dpToPx(activity, 4));
            GradientDrawable timerBg = new GradientDrawable();
            timerBg.setColor(parseColorSafe("#2A2000", 0xFF2A2000));
            timerBg.setCornerRadius(dpToPx(activity, 8));
            timerBg.setStroke(dpToPx(activity, 1), parseColorSafe("#FFB703", Color.YELLOW));
            tvCountdown.setBackground(timerBg);
            LinearLayout.LayoutParams cdLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cdLp.topMargin = dpToPx(activity, 6);
            cdLp.gravity = Gravity.CENTER_HORIZONTAL;
            root.addView(tvCountdown, cdLp);

            final int startSec = Math.max(3, config.countdownSeconds);
            final android.os.CountDownTimer timer = new android.os.CountDownTimer(startSec * 1000L, 1000L) {
                @Override
                public void onTick(long millisUntilFinished) {
                    long s = (millisUntilFinished / 1000L) + 1;
                    tvCountdown.setText("⏱️ Mandatory Update in: " + s + "s");
                }

                @Override
                public void onFinish() {
                    tvCountdown.setText("⏱️ Time Expired! Redirecting to Update...");
                    tvCountdown.setTextColor(parseColorSafe("#FF1744", Color.RED));
                    if (forceUpdateMode) {
                        handleAction(activity, config.btn3Action, config.btn3Url, config.btn3Text, dialog);
                    }
                }
            };
            timer.start();
            dialog.setOnDismissListener(d -> timer.cancel());
        }

        // 3. Title
        if (config.titleVisible) {
            TextView tvTitle = new TextView(activity);
            tvTitle.setText(config.titleText);
            tvTitle.setTextSize(config.titleSizeSp);
            tvTitle.setTextColor(parseColorSafe(config.titleColorHex, Color.CYAN));
            tvTitle.setGravity(resolveGravity(config.titleAlignment));
            tvTitle.setTypeface(resolveFontTypeface(config.titleFont), config.titleBold ? Typeface.BOLD : Typeface.NORMAL);
            if (config.titleBgHex != null && !config.titleBgHex.trim().isEmpty()) {
                tvTitle.setBackgroundColor(parseColorSafe(config.titleBgHex, Color.TRANSPARENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dpToPx(activity, 8);
            root.addView(tvTitle, lp);
        }

        // 4. Subtitle
        if (config.subtitleVisible && config.subtitleText != null && !config.subtitleText.isEmpty()) {
            TextView tvSub = new TextView(activity);
            tvSub.setText(config.subtitleText);
            tvSub.setTextSize(config.subtitleSizeSp);
            tvSub.setTextColor(parseColorSafe(config.subtitleColorHex, 0xFF00FF88));
            tvSub.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dpToPx(activity, 4);
            root.addView(tvSub, lp);
        }

        // 5. Message
        if (config.messageVisible && config.messageText != null && !config.messageText.isEmpty()) {
            TextView tvMsg = new TextView(activity);
            tvMsg.setText(config.messageText);
            tvMsg.setTextSize(config.messageSizeSp);
            tvMsg.setTextColor(parseColorSafe(config.messageColorHex, Color.WHITE));
            tvMsg.setGravity(resolveGravity(config.messageAlignment));
            tvMsg.setTypeface(resolveFontTypeface(config.messageFont));
            tvMsg.setLineSpacing(0, config.messageLineSpacing);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dpToPx(activity, 10);
            lp.bottomMargin = dpToPx(activity, 6);
            root.addView(tvMsg, lp);
        }

        // Checkbox: Don't show again (টিক চিহ্ন)
        if (config.hasDontShowAgain) {
            android.widget.CheckBox cb = new android.widget.CheckBox(activity);
            cb.setText(config.dontShowAgainText != null && !config.dontShowAgainText.isEmpty()
                    ? config.dontShowAgainText : "Don't show this again");
            cb.setTextColor(parseColorSafe(config.dontShowAgainColorHex, 0xFF94A3B8));
            cb.setTextSize(12.5f);
            LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cbLp.topMargin = dpToPx(activity, 8);
            cbLp.bottomMargin = dpToPx(activity, 4);
            cbLp.gravity = Gravity.CENTER_HORIZONTAL;
            root.addView(cb, cbLp);
        }

        // 6. Responsive Buttons
        boolean isNarrow = config.widthPct < 84 || (config.buttonCount == 3 && config.widthPct < 90);
        boolean isVertical = "VERTICAL".equalsIgnoreCase(config.btnOrientation) || isNarrow;
        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(isVertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpRow.topMargin = dpToPx(activity, 14);

        float responsiveSp = Math.max(10.5f, Math.min(13.5f, 12.5f * (config.widthPct / 92f)));
        int btnHeightPx = dpToPx(activity, Math.max(36, Math.min(46, (int) (42 * (config.widthPct / 90f)))));

        if (!forceUpdateMode && config.buttonCount >= 2) {
            Button b1 = new Button(activity);
            b1.setText(config.btn1Text);
            b1.setSingleLine(true);
            b1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            b1.setTextSize(TypedValue.COMPLEX_UNIT_SP, responsiveSp);
            b1.setTextColor(parseColorSafe(config.btn1ColorHex, Color.WHITE));
            b1.setTypeface(resolveFontTypeface(config.btn1Font), Typeface.BOLD);
            b1.setBackground(buildButtonDrawable(config, config.btn1BgHex, config.btn1BorderHex, config.btn1BorderWidthDp, activity));
            b1.setPadding(dpToPx(activity, 8), 0, dpToPx(activity, 8), 0);
            LinearLayout.LayoutParams lp1 = isVertical
                    ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnHeightPx)
                    : new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
            if (isVertical) {
                lp1.bottomMargin = dpToPx(activity, 4);
            } else {
                lp1.rightMargin = dpToPx(activity, 3);
            }
            b1.setOnClickListener(v -> handleAction(activity, config.btn1Action, config.btn1Url, config.btn1Text, dialog));
            btnRow.addView(b1, lp1);
        }

        if (!forceUpdateMode && config.buttonCount == 3) {
            Button b2 = new Button(activity);
            b2.setText(config.btn2Text);
            b2.setSingleLine(true);
            b2.setEllipsize(android.text.TextUtils.TruncateAt.END);
            b2.setTextSize(TypedValue.COMPLEX_UNIT_SP, responsiveSp);
            b2.setTextColor(parseColorSafe(config.btn2ColorHex, Color.WHITE));
            b2.setTypeface(resolveFontTypeface(config.btn2Font), Typeface.BOLD);
            b2.setBackground(buildButtonDrawable(config, config.btn2BgHex, config.btn2BorderHex, config.btn2BorderWidthDp, activity));
            b2.setPadding(dpToPx(activity, 8), 0, dpToPx(activity, 8), 0);
            LinearLayout.LayoutParams lp2 = isVertical
                    ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnHeightPx)
                    : new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
            if (isVertical) {
                lp2.bottomMargin = dpToPx(activity, 4);
            } else {
                lp2.leftMargin = dpToPx(activity, 2);
                lp2.rightMargin = dpToPx(activity, 2);
            }
            b2.setOnClickListener(v -> handleAction(activity, config.btn2Action, config.btn2Url, config.btn2Text, dialog));
            btnRow.addView(b2, lp2);
        }

        Button b3 = new Button(activity);
        b3.setText(forceUpdateMode ? (config.btn3Text != null && !config.btn3Text.isEmpty() ? config.btn3Text : "UPDATE APP NOW") : config.btn3Text);
        b3.setSingleLine(true);
        b3.setEllipsize(android.text.TextUtils.TruncateAt.END);
        b3.setTextSize(TypedValue.COMPLEX_UNIT_SP, responsiveSp);
        b3.setTextColor(parseColorSafe(config.btn3ColorHex, Color.CYAN));
        b3.setTypeface(resolveFontTypeface(config.btn3Font), Typeface.BOLD);
        b3.setBackground(buildButtonDrawable(config, config.btn3BgHex, config.btn3BorderHex, config.btn3BorderWidthDp, activity));
        b3.setPadding(dpToPx(activity, 8), 0, dpToPx(activity, 8), 0);
        LinearLayout.LayoutParams lp3 = (isVertical || forceUpdateMode || config.buttonCount == 1)
                ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, btnHeightPx)
                : new LinearLayout.LayoutParams(0, btnHeightPx, 1f);
        if (!isVertical && !forceUpdateMode && config.buttonCount >= 2) {
            lp3.leftMargin = dpToPx(activity, 3);
        }
        b3.setOnClickListener(v -> handleAction(activity, config.btn3Action, config.btn3Url, config.btn3Text, dialog));
        btnRow.addView(b3, lp3);

        root.addView(btnRow, lpRow);

        ScrollView sv = new ScrollView(activity);
        sv.setFillViewport(true);
        sv.addView(root);

        dialog.setContentView(sv);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setWindowAnimations(0);
            if ("TOP".equalsIgnoreCase(config.dialogPosition)) {
                dialog.getWindow().setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            } else if ("BOTTOM".equalsIgnoreCase(config.dialogPosition)) {
                dialog.getWindow().setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            } else {
                dialog.getWindow().setGravity(Gravity.CENTER);
            }
            int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
            int w = (int) (screenWidth * (config.widthPct / 100f));
            dialog.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        prepareInitialAnimState(root, config.openAnimMode, activity);

        dialog.setOnShowListener(d -> root.post(() -> {
            if (root.getWidth() > 0) {
                root.setPivotX(root.getWidth() / 2f);
                root.setPivotY(root.getHeight() / 2f);
            }
            playOpeningAnimation(root, config.openAnimMode, config.animDurationMs);
        }));

        dialog.show();
    }

    private static void handleAction(Activity activity, String action, String param, String label, Dialog dialog) {
        if (dialog != null) {
            try { dialog.dismiss(); } catch (Exception ignored) {}
        }
        if (DialogConfig.ACTION_OPEN_URL.equalsIgnoreCase(action) && param != null && !param.trim().isEmpty()) {
            try {
                String u = param.trim();
                if (!u.startsWith("http://") && !u.startsWith("https://") && !u.startsWith("tg://")) {
                    u = "https://" + u;
                }
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            } catch (Exception e) {
                MorsalinToast.show(activity, R.drawable.ic_cat_arrow, "Action", "Opening URL: " + param);
            }
        } else if (DialogConfig.ACTION_OPEN_ACTIVITY.equalsIgnoreCase(action) && param != null && !param.trim().isEmpty()) {
            try {
                Class<?> target = Class.forName(param.trim());
                Intent intent = new Intent(activity, target);
                activity.startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(activity, "Activity not found: " + param, Toast.LENGTH_SHORT).show();
            }
        } else if (DialogConfig.ACTION_COPY_TEXT.equalsIgnoreCase(action)) {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("DialogText", param != null ? param : label));
                MorsalinToast.show(activity, R.drawable.ic_content_copy, "Copied", "Copied to clipboard!");
            }
        } else if (DialogConfig.ACTION_CUSTOM.equalsIgnoreCase(action) || DialogConfig.ACTION_SHOW_TOAST.equalsIgnoreCase(action)) {
            MorsalinToast.show(activity, R.drawable.ic_about_dev, label, (param != null && !param.isEmpty()) ? param : "Dialog Action Triggered!");
        } else {
            MorsalinToast.show(activity, R.drawable.ic_about_dev, "Dialog Dismissed", "Action: " + label);
        }
    }

    public static void prepareInitialAnimState(View view, String mode, Context context) {
        if (view == null) return;
        try {
            if ("Fade".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
            } else if ("Slide".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setTranslationY(dpToPx(context, 160));
            } else if ("Bounce".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setScaleX(0.2f);
                view.setScaleY(0.2f);
            } else if ("Flip 3D".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setRotationY(80f);
                view.setScaleX(0.4f);
            } else if ("Cyber Glitch".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setTranslationX(-30f);
            } else if ("Boomerang".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setRotation(-40f);
                view.setScaleX(0.2f);
                view.setScaleY(0.2f);
            } else if ("Matrix Drop".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setTranslationY(-dpToPx(context, 200));
            } else if ("Hologram".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setScaleY(0.7f);
            } else if ("Origami".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setRotationX(80f);
                view.setTranslationY(dpToPx(context, 80));
            } else if ("Vortex".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setRotation(270f);
                view.setScaleX(0.1f);
                view.setScaleY(0.1f);
            } else if ("Warp".equalsIgnoreCase(mode)) {
                view.setAlpha(0.01f);
                view.setScaleX(2.0f);
                view.setScaleY(0.1f);
            } else {
                view.setAlpha(0.01f);
                view.setScaleX(0.2f);
                view.setScaleY(0.2f);
            }
        } catch (Throwable ignored) {}
    }

    public static void playOpeningAnimation(View view, String mode, int durationMs) {
        if (view == null) return;
        int dur = Math.max(150, durationMs > 0 ? durationMs : 350);
        try {
            if ("Fade".equalsIgnoreCase(mode)) {
                view.animate().alpha(1f).setDuration(dur).start();
            } else if ("Slide".equalsIgnoreCase(mode)) {
                view.animate().translationY(0f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.2f)).start();
            } else if ("Bounce".equalsIgnoreCase(mode)) {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur).setInterpolator(new BounceInterpolator()).start();
            } else if ("Flip 3D".equalsIgnoreCase(mode)) {
                view.animate().rotationY(0f).scaleX(1f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.2f)).start();
            } else if ("Cyber Glitch".equalsIgnoreCase(mode)) {
                view.animate().translationX(0f).scaleX(1f).alpha(1f).setDuration(dur).start();
            } else if ("Boomerang".equalsIgnoreCase(mode)) {
                view.animate().rotation(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.3f)).start();
            } else if ("Matrix Drop".equalsIgnoreCase(mode)) {
                view.animate().translationY(0f).alpha(1f).setDuration(dur).setInterpolator(new BounceInterpolator()).start();
            } else if ("Hologram".equalsIgnoreCase(mode)) {
                view.animate().scaleY(1f).alpha(1f).setDuration(dur).start();
            } else if ("Origami".equalsIgnoreCase(mode)) {
                view.animate().rotationX(0f).translationY(0f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.2f)).start();
            } else if ("Vortex".equalsIgnoreCase(mode)) {
                view.animate().rotation(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.1f)).start();
            } else if ("Warp".equalsIgnoreCase(mode)) {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.2f)).start();
            } else {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur).setInterpolator(new OvershootInterpolator(1.3f)).start();
            }
        } catch (Throwable ignored) {}
    }

    public static void playOpeningAnimation(View view, String mode) {
        playOpeningAnimation(view, mode, 350);
    }
}
