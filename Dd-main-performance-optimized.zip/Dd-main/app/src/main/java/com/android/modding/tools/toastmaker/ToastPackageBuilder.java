package com.android.modding.tools.toastmaker;

import android.content.Context;

import com.android.modding.tools.dialogmaker.DexValidator;
import com.android.modding.tools.generators.JavaToSmaliToolchain;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.SmaliToastGenerator;

import java.util.Collections;
import java.util.Map;

/**
 * End-to-end Build Pipeline for Toast Maker.
 * 1. Generates 100% programmatic Android Java source code (ZERO XML).
 * 2. Compiles to Dalvik executable (classes.dex) using embedded D8 / ECJ toolchain.
 * 3. Validates binary integrity (Magic header, Adler32, SHA-1, Dexlib2).
 * 4. Generates single authoritative GUIDE.smali (with inline and dex hook options).
 * 5. Bundles required assets in assets/.
 * 6. Generates strictly 1 classes.dex and ZERO XML files.
 */
public class ToastPackageBuilder {

    public static class BuildResult {
        public final boolean success;
        public final String errorMessage;
        public final GeneratedPackageExporter.GeneratedPackage generatedPackage;
        public final DexValidator.ValidationResult dexValidation;
        public final byte[] dexBytes;
        public final String guideContent;
        public final String javaSourceCode;
        public final String inlineSmaliCode;
        public final ToastAssetGenerator.AssetBundle assetBundle;

        public BuildResult(boolean success, String errorMessage,
                           GeneratedPackageExporter.GeneratedPackage generatedPackage,
                           DexValidator.ValidationResult dexValidation,
                           byte[] dexBytes, String guideContent,
                           String javaSourceCode, String inlineSmaliCode,
                           ToastAssetGenerator.AssetBundle assetBundle) {
            this.success = success;
            this.errorMessage = errorMessage;
            this.generatedPackage = generatedPackage;
            this.dexValidation = dexValidation;
            this.dexBytes = dexBytes;
            this.guideContent = guideContent;
            this.javaSourceCode = javaSourceCode;
            this.inlineSmaliCode = inlineSmaliCode;
            this.assetBundle = assetBundle;
        }

        public static BuildResult failure(String message) {
            return new BuildResult(false, message, null, null, null, null, null, null, null);
        }
    }

    public static BuildResult buildToastPackage(Context context, ToastConfig config) {
        if (context == null || config == null) {
            return BuildResult.failure("Invalid context or null configuration.");
        }

        // 1. Validate Configuration
        if (config.messageText == null || config.messageText.trim().isEmpty()) {
            config.messageText = "Welcome to Modded App by Morsalin!";
        }

        // 2. Generate Pure Programmatic Java Source Code (NO XML)
        String javaCode = ProgrammaticToastSourceGenerator.generateJavaCode(config);

        // 3. Compile Real Dalvik DEX Binary via D8 / ECJ
        byte[] dexBytes = null;
        try {
            JavaToSmaliToolchain.CompilationResult compResult =
                    JavaToSmaliToolchain.compile(context, javaCode, "MorsalinCustomToast.java", null);
            if (compResult != null && compResult.success && compResult.dexBytes != null && compResult.dexBytes.length >= 112) {
                dexBytes = compResult.dexBytes;
            }
        } catch (Throwable ignored) {}

        // Fallback: minimal clean toast Java class compilation if memory was tight
        if (dexBytes == null || dexBytes.length < 112) {
            try {
                String minimalJava = "package com.morsalin.toast;\n"
                        + "import android.content.Context;\n"
                        + "import android.widget.Toast;\n"
                        + "public class MorsalinCustomToast {\n"
                        + "    public static void show(Context context) {\n"
                        + "        if (context != null) Toast.makeText(context, \"" + escape(config.messageText) + "\", Toast.LENGTH_SHORT).show();\n"
                        + "    }\n"
                        + "    public static void show(Context context, String msg) {\n"
                        + "        if (context != null) Toast.makeText(context, msg != null ? msg : \"" + escape(config.messageText) + "\", Toast.LENGTH_SHORT).show();\n"
                        + "    }\n"
                        + "}\n";
                JavaToSmaliToolchain.CompilationResult fallbackRes =
                        JavaToSmaliToolchain.compile(context, minimalJava, "MorsalinCustomToast.java", null);
                if (fallbackRes != null && fallbackRes.success && fallbackRes.dexBytes != null) {
                    dexBytes = fallbackRes.dexBytes;
                }
            } catch (Throwable ignored) {}
        }

        if (dexBytes == null || dexBytes.length == 0) {
            return BuildResult.failure("DEX compilation engine returned empty binary.");
        }

        // 4. Validate Generated DEX Binary (Header, Checksum, SHA-1, Dexlib2)
        DexValidator.ValidationResult valResult = DexValidator.validate(dexBytes, context.getCacheDir());
        if (!valResult.isValid) {
            return BuildResult.failure("DEX binary validation failed: " + valResult.errorMessage);
        }

        // 5. Generate In-line Smali Alternative
        String inlineSmali = generateInlineSmali(config);

        // 6. Generate Authoritative GUIDE.smali
        String guideSmali = ToastGuideGenerator.generateSmaliGuide(config, valResult, inlineSmali);

        // 7. Generate Assets Directory Bundle
        ToastAssetGenerator.AssetBundle assetBundle = ToastAssetGenerator.generateAssets(config, context);

        // 8. Assemble Clean Output Package: Strictly classes.dex, GUIDE.smali, and assets/
        String folderName = config.toastName != null && !config.toastName.trim().isEmpty()
                ? config.toastName.trim().replaceAll("\\s+", "_")
                : (config.toastType != null ? config.toastType.trim().replaceAll("\\s+", "_") : "Toast_Output");

        GeneratedPackageExporter.GeneratedPackage pkg =
                new GeneratedPackageExporter.GeneratedPackage(folderName, config.toastType);

        pkg.addDexBinary(dexBytes);
        pkg.setGuideContent("hook.smali", guideSmali);

        for (Map.Entry<String, byte[]> entry : assetBundle.binaryAssets.entrySet()) {
            pkg.binaryFiles.put(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, String> entry : assetBundle.textAssets.entrySet()) {
            pkg.addFile(entry.getKey(), entry.getValue());
        }

        return new BuildResult(true, null, pkg, valResult, dexBytes, guideSmali,
                javaCode, inlineSmali, assetBundle);
    }

    private static String generateInlineSmali(ToastConfig config) {
        try {
            if (ToastConfig.TYPE_BASE64.equals(config.toastType)) {
                return SmaliToastGenerator.generateBase64Toast(config.messageText, config.isLongDuration, config.gravity);
            } else if (ToastConfig.TYPE_COLORFUL.equals(config.toastType)) {
                int bg = android.graphics.Color.parseColor(config.bgHex != null ? config.bgHex : "#FF1744");
                int text = android.graphics.Color.parseColor(config.textColorHex != null ? config.textColorHex : "#FFFFFF");
                int stroke = android.graphics.Color.parseColor(config.strokeColorHex != null ? config.strokeColorHex : "#00E5FF");
                return SmaliToastGenerator.generateColorfulToast(config.messageText, bg, text,
                        config.cornerRadiusDp, stroke, config.strokeWidthDp, config.isLongDuration);
            } else if (ToastConfig.TYPE_ANIMATED.equals(config.toastType)) {
                int animType = 0;
                if ("Fade".equalsIgnoreCase(config.animMode)) animType = 1;
                else if ("Slide".equalsIgnoreCase(config.animMode)) animType = 2;
                return SmaliToastGenerator.generateAnimatedToast(config.messageText, animType, config.animDurationMs, config.isLongDuration);
            } else if (ToastConfig.TYPE_IMAGE.equals(config.toastType)) {
                int bg = android.graphics.Color.parseColor(config.bgHex != null ? config.bgHex : "#F0191E28");
                int text = android.graphics.Color.parseColor(config.textColorHex != null ? config.textColorHex : "#FFFFFF");
                return SmaliToastGenerator.generateImageToast(config.titleText, config.messageText,
                        config.symbolIcon != null ? config.symbolIcon : "👑", bg, text, config.isLongDuration);
            } else {
                return SmaliToastGenerator.generateSimpleToast(config.messageText, config.isLongDuration, config.gravity);
            }
        } catch (Throwable t) {
            return SmaliToastGenerator.generateSimpleToast(config.messageText, config.isLongDuration, config.gravity);
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
