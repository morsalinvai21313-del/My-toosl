package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Universal helper that applies the smooth multi-color flowing gradient lighting animation
 * to all text across the entire application, while strictly excluding generated XML code,
 * code outputs, syntax containers, and editor code blocks.
 */
public class LightingTextHelper {

    private static final String TAG_LIGHTING_ATTACHED = "lighting_attached";

    private static class ViewState {
        final Matrix matrix = new Matrix();
        LinearGradient shader;
        int lastWidth = 0;
        int lastStyle = -1;
    }

    private static final WeakHashMap<TextView, ViewState> activeViews = new WeakHashMap<>();
    private static ValueAnimator masterAnimator;
    private static float currentProgress = 0f;
    private static boolean listenerRegistered = false;

    private static synchronized void ensureMasterAnimator() {
        if (masterAnimator != null) return;

        masterAnimator = ValueAnimator.ofFloat(0f, 1f);
        masterAnimator.setDuration(2600);
        masterAnimator.setRepeatCount(ValueAnimator.INFINITE);
        masterAnimator.setInterpolator(new LinearInterpolator());
        masterAnimator.addUpdateListener(animation -> {
            currentProgress = (float) animation.getAnimatedValue();
            dispatchShaderUpdate();
        });

        if (!listenerRegistered) {
            listenerRegistered = true;
            LightingTextAnimationManager.registerListener((newStyle, isEnabled) -> {
                rebuildAllShaders();
            });
        }
    }

    private static synchronized void dispatchShaderUpdate() {
        if (activeViews.isEmpty()) {
            if (masterAnimator != null && masterAnimator.isRunning()) {
                masterAnimator.cancel();
            }
            return;
        }

        boolean anyEnabled = false;
        Iterator<Map.Entry<TextView, ViewState>> iterator = activeViews.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<TextView, ViewState> entry = iterator.next();
            TextView tv = entry.getKey();
            ViewState state = entry.getValue();

            if (tv == null) {
                iterator.remove();
                continue;
            }

            if (!tv.isAttachedToWindow() || tv.getVisibility() != View.VISIBLE) {
                continue;
            }

            if (!LightingTextAnimationManager.isEnabled(tv.getContext())) {
                if (tv.getPaint().getShader() != null) {
                    tv.getPaint().setShader(null);
                    tv.setTextColor(0xFFFFFFFF);
                    tv.invalidate();
                }
                continue;
            }

            anyEnabled = true;
            int w = tv.getWidth();
            if (w <= 0) continue;

            int currentStyle = LightingTextAnimationManager.getSavedStyle(tv.getContext());

            // Build or update shader if size or style changed
            if (state.shader == null || state.lastWidth != w || state.lastStyle != currentStyle) {
                state.lastWidth = w;
                state.lastStyle = currentStyle;
                int[] colors = LightingTextAnimationManager.getColorsForStyle(currentStyle);
                float gradW = Math.max(w * 1.8f, 200f);
                state.shader = new LinearGradient(
                        0, 0, gradW, 0, colors, null, Shader.TileMode.REPEAT
                );
                tv.getPaint().setShader(state.shader);
            }

            // Translate matrix smoothly
            float gradW = Math.max(w * 1.8f, 200f);
            state.matrix.setTranslate(-currentProgress * gradW, 0);
            state.shader.setLocalMatrix(state.matrix);
            tv.invalidate();
        }

        if (!anyEnabled && masterAnimator != null && masterAnimator.isRunning()) {
            masterAnimator.cancel();
        }
    }

    private static synchronized void rebuildAllShaders() {
        boolean anyEnabled = false;
        for (Map.Entry<TextView, ViewState> entry : activeViews.entrySet()) {
            TextView tv = entry.getKey();
            ViewState state = entry.getValue();
            if (tv != null && state != null) {
                state.shader = null;
                if (!LightingTextAnimationManager.isEnabled(tv.getContext())) {
                    tv.getPaint().setShader(null);
                    tv.setTextColor(0xFFFFFFFF);
                    tv.invalidate();
                } else {
                    anyEnabled = true;
                }
            }
        }
        if (anyEnabled) {
            if (masterAnimator != null && !masterAnimator.isRunning() && !activeViews.isEmpty()) {
                masterAnimator.start();
            }
        } else {
            if (masterAnimator != null && masterAnimator.isRunning()) {
                masterAnimator.cancel();
            }
        }
    }

    /**
     * Attaches lighting animation to a specific TextView, unless it's identified as a code view.
     */
    public static void attach(TextView textView) {
        if (textView == null) return;
        if (isCodeView(textView)) {
            // Strictly exclude code and ensure clean green text rendering
            textView.getPaint().setShader(null);
            textView.setTextColor(0xFF00FF88);
            return;
        }

        if (!LightingTextAnimationManager.isEnabled(textView.getContext())) {
            textView.getPaint().setShader(null);
            textView.setTextColor(0xFFFFFFFF);
            return;
        }

        // Avoid re-registering
        if (activeViews.containsKey(textView)) {
            return;
        }

        ensureMasterAnimator();
        activeViews.put(textView, new ViewState());

        if (masterAnimator != null && !masterAnimator.isRunning()) {
            masterAnimator.start();
        }

        textView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                if (LightingTextAnimationManager.isEnabled(v.getContext())
                        && masterAnimator != null && !masterAnimator.isRunning()) {
                    masterAnimator.start();
                }
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                // View will be garbage collected or handled by WeakHashMap
            }
        });
    }

    /**
     * Recursively walks through any View tree and attaches lighting animation
     * to all TextViews & Buttons, strictly skipping code and XML generation views.
     */
    public static void applyToViewTree(View root) {
        if (root == null || !LightingTextAnimationManager.isEnabled(root.getContext())) return;

        // Skip code containers entirely
        if (isCodeContainer(root)) {
            return;
        }

        if (root instanceof TextView) {
            attach((TextView) root);
        }

        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            int count = vg.getChildCount();
            for (int i = 0; i < count; i++) {
                applyToViewTree(vg.getChildAt(i));
            }
        }
    }

    /**
     * Checks if a view group is a dedicated code or XML preview container.
     */
    private static boolean isCodeContainer(View view) {
        if (view == null) return false;

        Object tag = view.getTag();
        if (tag != null && "code".equalsIgnoreCase(tag.toString())) {
            return true;
        }

        int id = view.getId();
        if (id != View.NO_ID && view.getResources() != null) {
            try {
                String name = view.getResources().getResourceEntryName(id).toLowerCase();
                if (name.contains("code_box") ||
                    name.contains("code_container") ||
                    name.contains("xml_container") ||
                    name.contains("code_scroll") ||
                    name.contains("xml_scroll") ||
                    name.contains("syntax_container")) {
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    /**
     * Returns true if the given TextView is a generated XML code block, code editor,
     * monospace code view, or syntax display.
     */
    public static boolean isCodeView(TextView tv) {
        if (tv == null) return false;

        // Explicit tag check
        Object tag = tv.getTag();
        if (tag != null && "code".equalsIgnoreCase(tag.toString())) {
            return true;
        }

        // Check view ID
        int id = tv.getId();
        if (id != View.NO_ID && tv.getResources() != null) {
            try {
                String name = tv.getResources().getResourceEntryName(id).toLowerCase();
                if (name.contains("code_output") ||
                    name.contains("xml_output") ||
                    name.contains("generated_code") ||
                    name.contains("generated_xml") ||
                    name.contains("code_preview") ||
                    name.contains("preview_code") ||
                    name.contains("editor_code") ||
                    name.contains("code_content") ||
                    name.contains("xml_content") ||
                    name.contains("tv_code") ||
                    name.contains("et_code") ||
                    name.contains("syntax")) {
                    return true;
                }
            } catch (Exception ignored) {}
        }

        // Monospace font (standard for code editors and outputs)
        Typeface tf = tv.getTypeface();
        if (tf != null && tf.equals(Typeface.MONOSPACE)) {
            return true;
        }

        // Multi-line code input in EditText
        if (tv instanceof EditText) {
            int inputType = ((EditText) tv).getInputType();
            if ((inputType & android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
                return true;
            }
        }

        // Check if placed inside a horizontal scroll container (characteristic of code boxes)
        View parent = (View) tv.getParent();
        if (parent instanceof HorizontalScrollView) {
            return true;
        }
        if (parent != null && parent.getParent() instanceof HorizontalScrollView) {
            return true;
        }

        return false;
    }
}
