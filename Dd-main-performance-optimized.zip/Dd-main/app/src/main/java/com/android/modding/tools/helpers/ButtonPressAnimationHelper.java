package com.android.modding.tools.helpers;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * Manages Button & Card Press Micro-Interactions across the app.
 * Provides physics-based spring bounce, cyber pulse, and gentle depth.
 */
public class ButtonPressAnimationHelper {

    private static final String PREF_NAME = "morsalin_settings";
    public static final String KEY_BUTTON_PRESS_STYLE = "key_button_press_anim_style";

    public static final int STYLE_OFF = 0;
    public static final int STYLE_SPRING_BOUNCE = 1;
    public static final int STYLE_CYBER_PULSE = 2;
    public static final int STYLE_GENTLE_DEPTH = 3;
    public static final int STYLE_POP_OVERSHOOT = 4;
    public static final int STYLE_3D_TILT = 5;
    public static final int STYLE_CYBER_GLITCH = 6;
    public static final int STYLE_NEON_SHOCKWAVE = 7;
    public static final int STYLE_RUBBER_BAND = 8;
    public static final int STYLE_MAGNETIC_LIFT = 9;
    public static final int STYLE_QUANTUM_RIPPLE = 10;

    public static final String[] STYLE_NAMES = {
            "Disabled (Normal)",
            "Spring Elastic Bounce",
            "Glow Pulse",
            "Gentle Depth Squeeze",
            "Pop & Overshoot",
            "3D Hologram Tilt",
            "Cyber Glitch Jitter",
            "Neon Shockwave Halo",
            "Rubber Band Flex",
            "Magnetic Elevation Lift",
            "Matrix Quantum Ripple"
    };

    public static final String[] STYLE_DESCRIPTIONS = {
            "Standard touch response with no extra motion",
            "Physics-based spring bounce back when clicked",
            "Subtle glow pulse on press",
            "Smooth and subtle depth scaling",
            "Pops out slightly and settles back",
            "Tilts slightly in 3D perspective with depth shadow",
            "Cyberpunk rapid horizontal twitch jitter",
            "Expands with luminous alpha flash",
            "Horizontal stretch & snappy rubber rebound",
            "Floats upward slightly like a magnetic pad",
            "Subtle quantum rotation twist and snap"
    };

    private static int cachedStyle = -1;
    private static View activePressedView = null;

    public static int getSavedStyle(Context context) {
        if (cachedStyle >= 0) return cachedStyle;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cachedStyle = sp.getInt(KEY_BUTTON_PRESS_STYLE, STYLE_OFF);
        return cachedStyle;
    }

    public static void setSavedStyle(Context context, int style) {
        cachedStyle = style;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_BUTTON_PRESS_STYLE, style).apply();
    }

    public static boolean isEnabled(Context context) {
        return getSavedStyle(context) != STYLE_OFF;
    }

    public static void handleTouchDown(Activity activity, float rawX, float rawY) {
        int style = getSavedStyle(activity);
        if (style == STYLE_OFF) return;

        try {
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            View target = findClickableViewAt(decor, rawX, rawY);
            if (target != null) {
                activePressedView = target;
                applyPressDown(target, style);
            }
        } catch (Throwable ignored) {}
    }

    public static void handleTouchUp() {
        if (activePressedView != null) {
            int style = cachedStyle >= 0 ? cachedStyle : STYLE_SPRING_BOUNCE;
            applyPressUp(activePressedView, style);
            activePressedView = null;
        }
    }

    private static void applyPressDown(View v, int style) {
        if (v == null) return;
        switch (style) {
            case STYLE_SPRING_BOUNCE:
                v.animate().cancel();
                v.animate()
                        .scaleX(0.94f)
                        .scaleY(0.94f)
                        .setDuration(90)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
                break;
            case STYLE_CYBER_PULSE:
                v.animate().cancel();
                v.animate()
                        .scaleX(0.92f)
                        .scaleY(0.92f)
                        .alpha(0.85f)
                        .setDuration(80)
                        .start();
                break;
            case STYLE_GENTLE_DEPTH:
                v.animate().cancel();
                v.animate()
                        .scaleX(0.97f)
                        .scaleY(0.97f)
                        .setDuration(90)
                        .start();
                break;
            case STYLE_POP_OVERSHOOT:
                v.animate().cancel();
                v.animate()
                        .scaleX(1.05f)
                        .scaleY(1.05f)
                        .setDuration(90)
                        .start();
                break;
            case STYLE_3D_TILT:
                v.animate().cancel();
                v.animate()
                        .rotationX(12f)
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(80)
                        .start();
                break;
            case STYLE_CYBER_GLITCH:
                v.animate().cancel();
                v.animate()
                        .translationX(6f)
                        .scaleX(0.96f)
                        .setDuration(60)
                        .start();
                break;
            case STYLE_NEON_SHOCKWAVE:
                v.animate().cancel();
                v.animate()
                        .scaleX(1.08f)
                        .scaleY(1.08f)
                        .alpha(0.75f)
                        .setDuration(90)
                        .start();
                break;
            case STYLE_RUBBER_BAND:
                v.animate().cancel();
                v.animate()
                        .scaleX(1.15f)
                        .scaleY(0.85f)
                        .setDuration(80)
                        .start();
                break;
            case STYLE_MAGNETIC_LIFT:
                v.animate().cancel();
                v.animate()
                        .translationY(-8f)
                        .scaleX(1.02f)
                        .scaleY(1.02f)
                        .setDuration(90)
                        .start();
                break;
            case STYLE_QUANTUM_RIPPLE:
                v.animate().cancel();
                v.animate()
                        .rotation(-3f)
                        .scaleX(0.94f)
                        .scaleY(0.94f)
                        .setDuration(80)
                        .start();
                break;
        }
    }

    private static void applyPressUp(View v, int style) {
        if (v == null) return;
        switch (style) {
            case STYLE_SPRING_BOUNCE:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(220)
                        .setInterpolator(new OvershootInterpolator(2.4f))
                        .start();
                break;
            case STYLE_CYBER_PULSE:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(180)
                        .setInterpolator(new OvershootInterpolator(1.8f))
                        .start();
                break;
            case STYLE_GENTLE_DEPTH:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(160)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
                break;
            case STYLE_POP_OVERSHOOT:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(180)
                        .setInterpolator(new OvershootInterpolator(2.0f))
                        .start();
                break;
            case STYLE_3D_TILT:
                v.animate()
                        .rotationX(0f)
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(220)
                        .setInterpolator(new OvershootInterpolator(2.0f))
                        .start();
                break;
            case STYLE_CYBER_GLITCH:
                v.animate()
                        .translationX(0f)
                        .scaleX(1.0f)
                        .setDuration(160)
                        .setInterpolator(new OvershootInterpolator(2.2f))
                        .start();
                break;
            case STYLE_NEON_SHOCKWAVE:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(200)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
                break;
            case STYLE_RUBBER_BAND:
                v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(240)
                        .setInterpolator(new OvershootInterpolator(3.0f))
                        .start();
                break;
            case STYLE_MAGNETIC_LIFT:
                v.animate()
                        .translationY(0f)
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(200)
                        .setInterpolator(new OvershootInterpolator(1.6f))
                        .start();
                break;
            case STYLE_QUANTUM_RIPPLE:
                v.animate()
                        .rotation(0f)
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(220)
                        .setInterpolator(new OvershootInterpolator(2.5f))
                        .start();
                break;
        }
    }

    public static void animateSingleClick(View v, Context context) {
        if (v == null || context == null) return;
        int style = getSavedStyle(context);
        if (style == STYLE_OFF) return;
        applyPressDown(v, style);
        v.postDelayed(() -> applyPressUp(v, style), 100);
    }

    private static final int[] TEMP_LOC = new int[2];

    private static View findClickableViewAt(ViewGroup parent, float x, float y) {
        if (parent == null) return null;
        for (int i = parent.getChildCount() - 1; i >= 0; i--) {
            View child = parent.getChildAt(i);
            if (child == null || child.getVisibility() != View.VISIBLE) continue;
            if (child instanceof TouchParticleOverlayView) continue;

            child.getLocationOnScreen(TEMP_LOC);
            int l = TEMP_LOC[0], t = TEMP_LOC[1], r = l + child.getWidth(), b = t + child.getHeight();
            if (x >= l && x <= r && y >= t && y <= b) {
                if (child instanceof ViewGroup) {
                    View inner = findClickableViewAt((ViewGroup) child, x, y);
                    if (inner != null) return inner;
                }
                if (child.isClickable() || child instanceof android.widget.Button
                        || child instanceof android.widget.ImageView
                        || child instanceof android.widget.RadioButton
                        || child.hasOnClickListeners()) {
                    return child;
                }
            }
        }
        return null;
    }
}
