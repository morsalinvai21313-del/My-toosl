package com.android.modding.tools.activities;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import java.util.ArrayList;
import java.util.List;

public class PresetsActivity extends AppCompatActivity {

    public static class PresetItem {
        public final String title;
        public final String description;
        public final String xmlCode;
        public final Class<?> editorClass;
        public final int[] gradientColors;
        public final int strokeColor;
        public final float cornerRadiusDp;

        public PresetItem(String title, String description, String xmlCode, Class<?> editorClass,
                          int[] gradientColors, int strokeColor, float cornerRadiusDp) {
            this.title = title;
            this.description = description;
            this.xmlCode = xmlCode.trim();
            this.editorClass = editorClass;
            this.gradientColors = gradientColors;
            this.strokeColor = strokeColor;
            this.cornerRadiusDp = cornerRadiusDp;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presets);

        GlobalTouchParticleManager.attach(this);

        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_presets);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<PresetItem> presets = buildPresetsList();
        recyclerView.setAdapter(new PresetsAdapter(presets));
    }

    private List<PresetItem> buildPresetsList() {
        List<PresetItem> list = new ArrayList<>();

        list.add(new PresetItem(
                "Neon Cyan Glow",
                "3D layered card with neon cyan border and dark contrast background",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"45\"\n"
                        + "        android:startColor=\"#0D1117\"\n"
                        + "        android:endColor=\"#161B22\" />\n"
                        + "    <corners android:radius=\"14dp\" />\n"
                        + "    <stroke\n"
                        + "        android:width=\"2dp\"\n"
                        + "        android:color=\"#00E5FF\" />\n"
                        + "</shape>",
                NormalEditorActivity.class,
                new int[]{Color.parseColor("#0D1117"), Color.parseColor("#161B22")},
                Color.parseColor("#00E5FF"),
                14f
        ));

        list.add(new PresetItem(
                "Cyber Gold Luxury",
                "Metallic gold gradient with smooth rounded corners",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"90\"\n"
                        + "        android:startColor=\"#FFB300\"\n"
                        + "        android:centerColor=\"#FFA000\"\n"
                        + "        android:endColor=\"#FF6F00\"\n"
                        + "        android:type=\"linear\" />\n"
                        + "    <corners android:radius=\"12dp\" />\n"
                        + "</shape>",
                GradientEditorActivity.class,
                new int[]{Color.parseColor("#FFB300"), Color.parseColor("#FFA000"), Color.parseColor("#FF6F00")},
                Color.TRANSPARENT,
                12f
        ));

        list.add(new PresetItem(
                "Emerald Matrix Glow",
                "Dark hacker themed card with vibrant emerald neon stroke",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"135\"\n"
                        + "        android:startColor=\"#051C14\"\n"
                        + "        android:endColor=\"#0A3324\" />\n"
                        + "    <corners android:radius=\"16dp\" />\n"
                        + "    <stroke\n"
                        + "        android:width=\"2dp\"\n"
                        + "        android:color=\"#00E676\" />\n"
                        + "</shape>",
                NormalEditorActivity.class,
                new int[]{Color.parseColor("#051C14"), Color.parseColor("#0A3324")},
                Color.parseColor("#00E676"),
                16f
        ));

        list.add(new PresetItem(
                "Deep Purple Cyberpunk",
                "Vibrant violet and magenta gradient with smooth curvature",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"45\"\n"
                        + "        android:startColor=\"#7C4DFF\"\n"
                        + "        android:endColor=\"#D500F9\"\n"
                        + "        android:type=\"linear\" />\n"
                        + "    <corners android:radius=\"20dp\" />\n"
                        + "</shape>",
                GradientEditorActivity.class,
                new int[]{Color.parseColor("#7C4DFF"), Color.parseColor("#D500F9")},
                Color.TRANSPARENT,
                20f
        ));

        list.add(new PresetItem(
                "Crimson Alert",
                "High-contrast fiery gradient with ruby outline for alert elements",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"90\"\n"
                        + "        android:startColor=\"#B71C1C\"\n"
                        + "        android:endColor=\"#D50000\" />\n"
                        + "    <corners android:radius=\"10dp\" />\n"
                        + "    <stroke\n"
                        + "        android:width=\"1.5dp\"\n"
                        + "        android:color=\"#FF5252\" />\n"
                        + "</shape>",
                NormalEditorActivity.class,
                new int[]{Color.parseColor("#B71C1C"), Color.parseColor("#D50000")},
                Color.parseColor("#FF5252"),
                10f
        ));

        list.add(new PresetItem(
                "Sunset Horizon",
                "Vibrant coral to deep rose gradient banner style",
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                        + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                        + "    android:shape=\"rectangle\">\n"
                        + "    <gradient\n"
                        + "        android:angle=\"0\"\n"
                        + "        android:startColor=\"#FF512F\"\n"
                        + "        android:endColor=\"#DD2476\" />\n"
                        + "    <corners android:radius=\"14dp\" />\n"
                        + "</shape>",
                GradientEditorActivity.class,
                new int[]{Color.parseColor("#FF512F"), Color.parseColor("#DD2476")},
                Color.TRANSPARENT,
                14f
        ));

        return list;
    }

    private class PresetsAdapter extends RecyclerView.Adapter<PresetsAdapter.ViewHolder> {
        private final List<PresetItem> items;

        public PresetsAdapter(List<PresetItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_preset_card, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            PresetItem item = items.get(position);
            holder.tvTitle.setText(item.title);
            holder.tvDesc.setText(item.description);

            // Preview background
            GradientDrawable gd = new GradientDrawable();
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            gd.setColors(item.gradientColors);
            float density = getResources().getDisplayMetrics().density;
            gd.setCornerRadius(item.cornerRadiusDp * density);
            if (item.strokeColor != Color.TRANSPARENT) {
                gd.setStroke((int) (2 * density), item.strokeColor);
            }
            holder.previewFrame.setBackground(gd);

            holder.btnLoad.setOnClickListener(v -> {
                Intent intent = new Intent(PresetsActivity.this, item.editorClass);
                intent.putExtra("EXTRA_IMPORTED_XML", item.xmlCode);
                startActivity(intent);
                TransitionAnimationManager.applyForward(PresetsActivity.this);
            });

            holder.btnCopy.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Preset XML", item.xmlCode));
                MorsalinToast.show(PresetsActivity.this, R.drawable.ic_content_copy, "Copied", item.title + " XML copied!");
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDesc, tvBtnLabel;
            FrameLayout previewFrame;
            Button btnLoad, btnCopy;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.tv_preset_title);
                tvDesc = itemView.findViewById(R.id.tv_preset_desc);
                previewFrame = itemView.findViewById(R.id.preview_preset);
                tvBtnLabel = itemView.findViewById(R.id.tv_preset_button_label);
                btnLoad = itemView.findViewById(R.id.btn_load_preset);
                btnCopy = itemView.findViewById(R.id.btn_copy_preset_xml);
            }
        }
    }
}
