package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class XmlProject implements Serializable {
    public static final String TYPE_NORMAL = "NORMAL";
    public static final String TYPE_GRADIENT = "GRADIENT";
    public static final String TYPE_SELECTOR = "SELECTOR";
    public static final String TYPE_3D = "3D";
    public static final String TYPE_LAYOUT = "LAYOUT";
    public static final String TYPE_RIPPLE = "RIPPLE";
    public static final String TYPE_ANIMATION = "ANIMATION";
    public static final String TYPE_TEXT_ANIM = "TEXT_ANIM";
    public static final String TYPE_DIALOG = "DIALOG";
    public static final String TYPE_NOTIFICATION = "NOTIFICATION";
    public static final String TYPE_TOAST = "TOAST";

    private String id;
    private String name;
    private String type;
    private long timestamp;
    private String xmlCode;
    private String jsonConfig;

    public XmlProject() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.timestamp = System.currentTimeMillis();
    }

    public XmlProject(String name, String type, String xmlCode) {
        this(name, type, xmlCode, null);
    }

    public XmlProject(String name, String type, String xmlCode, String jsonConfig) {
        this.id = String.valueOf(System.currentTimeMillis());
        this.name = name;
        this.type = type;
        this.timestamp = System.currentTimeMillis();
        this.xmlCode = xmlCode;
        this.jsonConfig = jsonConfig;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name != null ? name : "Untitled Project";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type != null ? type : TYPE_NORMAL;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getXmlCode() {
        return xmlCode != null ? xmlCode : "";
    }

    public void setXmlCode(String xmlCode) {
        this.xmlCode = xmlCode;
    }

    public String getJsonConfig() {
        return jsonConfig;
    }

    public void setJsonConfig(String jsonConfig) {
        this.jsonConfig = jsonConfig;
    }
}
