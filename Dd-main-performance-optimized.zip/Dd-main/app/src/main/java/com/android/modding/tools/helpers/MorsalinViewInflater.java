package com.android.modding.tools.helpers;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatViewInflater;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatTextView;

/**
 * Custom AppCompatViewInflater that automatically loads the custom font
 * from assets/fonts/comic_neue.ttf and applies it to all text-based views
 * across the entire application while preserving Bold/Italic styles.
 */
public class MorsalinViewInflater extends AppCompatViewInflater {

    private static Typeface cachedRegularTypeface;
    private static Typeface cachedBoldTypeface;

    public static synchronized Typeface getAppTypeface(Context context, boolean bold) {
        if (context == null) {
            return bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
        try {
            if (cachedRegularTypeface == null) {
                cachedRegularTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/comic_neue.ttf");
                cachedBoldTypeface = Typeface.create(cachedRegularTypeface, Typeface.BOLD);
            }
            return bold ? cachedBoldTypeface : cachedRegularTypeface;
        } catch (Exception e) {
            return bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT;
        }
    }

    public static void applyCustomFont(TextView tv) {
        if (tv == null) return;
        try {
            Typeface current = tv.getTypeface();
            int style = (current != null) ? current.getStyle() : Typeface.NORMAL;
            boolean isBold = (style & Typeface.BOLD) != 0;
            Typeface base = getAppTypeface(tv.getContext(), isBold);
            tv.setTypeface(base, style);
        } catch (Exception ignored) {}
    }

    public static void applyStylingAndTextColor(TextView tv) {
        if (tv == null) return;
        applyCustomFont(tv);
        try {
            if (LightingTextHelper.isCodeView(tv)) {
                // Generated XML and code blocks are styled with vibrant green
                tv.setTextColor(0xFF00FF88);
            } else {
                // All other UI text across the entire app is cleanly unified to white
                tv.setTextColor(0xFFFFFFFF);
            }
        } catch (Exception ignored) {}
    }

    @NonNull
    @Override
    protected AppCompatTextView createTextView(Context context, AttributeSet attrs) {
        AppCompatTextView view = super.createTextView(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }

    @NonNull
    @Override
    protected AppCompatButton createButton(Context context, AttributeSet attrs) {
        AppCompatButton view = super.createButton(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }

    @NonNull
    @Override
    protected AppCompatEditText createEditText(Context context, AttributeSet attrs) {
        AppCompatEditText view = super.createEditText(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }

    @NonNull
    @Override
    protected AppCompatCheckBox createCheckBox(Context context, AttributeSet attrs) {
        AppCompatCheckBox view = super.createCheckBox(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }

    @NonNull
    @Override
    protected AppCompatRadioButton createRadioButton(Context context, AttributeSet attrs) {
        AppCompatRadioButton view = super.createRadioButton(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }

    @NonNull
    @Override
    protected AppCompatCheckedTextView createCheckedTextView(Context context, @Nullable AttributeSet attrs) {
        AppCompatCheckedTextView view = super.createCheckedTextView(context, attrs);
        applyStylingAndTextColor(view);
        return view;
    }
}
