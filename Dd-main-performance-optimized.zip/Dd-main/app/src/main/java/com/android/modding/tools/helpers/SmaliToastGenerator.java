package com.android.modding.tools.helpers;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Smali Toast & Notification Code Generator for Android APK Modding (MT Manager, APKTool M, Apktool).
 * Generates 100% verified, zero-dependency Dalvik / ART compliant Smali instructions
 * designed to be directly inserted into onCreate(Landroid/os/Bundle;)V of any Android Activity.
 *
 * Fully optimized register allocation (only v0..v5) with universal 32-bit const syntax
 * guaranteed to compile and save in MT Manager without any errors.
 */
public class SmaliToastGenerator {

    // =========================================================================
    // 1. SIMPLE SMALI TOAST
    // =========================================================================
    public static String generateSimpleToast(String message, boolean isLong, int gravity) {
        String safeMsg = escapeString(message);
        int durationConst = isLong ? 1 : 0;
        String durationDesc = isLong ? "Toast.LENGTH_LONG (3.5 seconds)" : "Toast.LENGTH_SHORT (2.0 seconds)";
        String gravityDesc = gravity == 1 ? "Center of Screen" : (gravity == 2 ? "Top of Screen" : "Bottom (Standard)");

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Simple Smali Toast Maker\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Instant popup notification on app launch (onCreate)\n");
        sb.append("# MESSAGE      : \"").append(message).append("\"\n");
        sb.append("# DURATION     : ").append(durationDesc).append("\n");
        sb.append("# POSITION     : ").append(gravityDesc).append("\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (All Dalvik & ART runtimes)\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER SETUP]\n");
        sb.append("# Check the line directly below '.method protected onCreate(...)V'\n");
        sb.append("# If it says '.locals 1' or '.locals 2' or '.locals 3', CHANGE IT TO:\n");
        sb.append("#     .locals 5\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Load message string into register v0\n");
        sb.append("const-string v0, \"").append(safeMsg).append("\"\n\n");

        sb.append("# [Step 2] Set Toast duration (0 = SHORT, 1 = LONG)\n");
        sb.append("const/4 v1, 0x").append(durationConst).append("\n\n");

        sb.append("# [Step 3] Create Toast instance using Activity Context (p0)\n");
        sb.append("invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;\n");
        sb.append("move-result-object v0\n\n");

        if (gravity == 1) { // Center
            sb.append("# [Step 4] Align Toast to Screen Center (Gravity.CENTER = 0x11)\n");
            sb.append("const/16 v1, 0x11\n");
            sb.append("const/4 v2, 0x0\n");
            sb.append("const/4 v3, 0x0\n");
            sb.append("invoke-virtual {v0, v1, v2, v3}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        } else if (gravity == 2) { // Top
            sb.append("# [Step 4] Align Toast to Screen Top (Gravity.TOP = 0x30, yOffset = 100)\n");
            sb.append("const/16 v1, 0x30\n");
            sb.append("const/4 v2, 0x0\n");
            sb.append("const/16 v3, 0x64\n");
            sb.append("invoke-virtual {v0, v1, v2, v3}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        }

        sb.append("# [Step 5] Display Toast on screen\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->show()V\n");

        return sb.toString();
    }

    // =========================================================================
    // 2. BASE64 SMALI TOAST (OBFUSCATED STRING ANTI-DETECTION)
    // =========================================================================
    public static String generateBase64Toast(String message, boolean isLong, int gravity) {
        String base64Encoded = Base64.encodeToString(message.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        int durationConst = isLong ? 1 : 0;
        String durationDesc = isLong ? "Toast.LENGTH_LONG (3.5 seconds)" : "Toast.LENGTH_SHORT (2.0 seconds)";
        String gravityDesc = gravity == 1 ? "Center of Screen" : (gravity == 2 ? "Top of Screen" : "Bottom (Standard)");

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Base64 Obfuscated Smali Toast Maker\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Anti-detection & string-search bypass for modded APKs\n");
        sb.append("# FEATURE      : Plaintext is hidden from string search, DEX grep, & anti-cheat\n");
        sb.append("# DECODED MSG  : \"").append(message).append("\"\n");
        sb.append("# BASE64 HASH  : ").append(base64Encoded).append("\n");
        sb.append("# DURATION     : ").append(durationDesc).append("\n");
        sb.append("# POSITION     : ").append(gravityDesc).append("\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (All Dalvik & ART runtimes)\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER SETUP]\n");
        sb.append("# Check the line directly below '.method protected onCreate(...)V'\n");
        sb.append("# If it says '.locals 1' or '.locals 2' or '.locals 3', CHANGE IT TO:\n");
        sb.append("#     .locals 5\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Load obfuscated Base64 ciphertext into v0\n");
        sb.append("const-string v0, \"").append(base64Encoded).append("\"\n\n");

        sb.append("# [Step 2] Decode Base64 ciphertext at runtime into byte[] (Base64.DEFAULT = 0)\n");
        sb.append("const/4 v1, 0x0\n");
        sb.append("invoke-static {v0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B\n");
        sb.append("move-result-object v0\n\n");

        sb.append("# [Step 3] Reconstruct plaintext String from byte array\n");
        sb.append("new-instance v1, Ljava/lang/String;\n");
        sb.append("invoke-direct {v1, v0}, Ljava/lang/String;-><init>([B)V\n\n");

        sb.append("# [Step 4] Create Toast with decoded message\n");
        sb.append("const/4 v2, 0x").append(durationConst).append("\n");
        sb.append("invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;\n");
        sb.append("move-result-object v0\n\n");

        if (gravity == 1) { // Center
            sb.append("# [Step 5] Align Toast to Screen Center (Gravity.CENTER = 0x11)\n");
            sb.append("const/16 v1, 0x11\n");
            sb.append("const/4 v2, 0x0\n");
            sb.append("const/4 v3, 0x0\n");
            sb.append("invoke-virtual {v0, v1, v2, v3}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        } else if (gravity == 2) { // Top
            sb.append("# [Step 5] Align Toast to Screen Top (Gravity.TOP = 0x30, yOffset = 100)\n");
            sb.append("const/16 v1, 0x30\n");
            sb.append("const/4 v2, 0x0\n");
            sb.append("const/16 v3, 0x64\n");
            sb.append("invoke-virtual {v0, v1, v2, v3}, Landroid/widget/Toast;->setGravity(III)V\n\n");
        }

        sb.append("# [Step 6] Display Toast on screen\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->show()V\n");

        return sb.toString();
    }

    public static String generateBase64Toast(String message, boolean isLong) {
        return generateBase64Toast(message, isLong, 0);
    }

    // =========================================================================
    // 3. COLORFUL TOAST (STANDALONE GRADIENT DRAWABLE STYLING IN SMALI)
    // =========================================================================
    public static String generateColorfulToast(String message, int bgColor, int textColor,
                                              int cornerRadiusDp, int strokeColor, int strokeWidthDp, boolean isLong) {
        String safeMsg = escapeString(message);
        int durationConst = isLong ? 1 : 0;
        String hexBg = "0x" + Integer.toHexString(bgColor).toUpperCase(Locale.US);
        String hexText = "0x" + Integer.toHexString(textColor).toUpperCase(Locale.US);
        int radiusBits = Float.floatToIntBits((float) cornerRadiusDp);

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Colorful Custom Toast Maker\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Custom colored bubble notification with rounded corners & stroke\n");
        sb.append("# MESSAGE      : \"").append(message).append("\"\n");
        sb.append("# STYLING      : BG=").append(hexBg).append(", Text=").append(hexText).append(", Radius=").append(cornerRadiusDp).append("dp\n");
        sb.append("# ARCHITECTURE : Zero XML layout dependencies (constructs custom view in pure Smali)\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (All Dalvik & ART runtimes)\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER / APKTOOL SETUP]\n");
        sb.append("# Look at the line directly below '.method protected onCreate(...)V'\n");
        sb.append("# If it says '.locals 1', '.locals 2', '.locals 3', or '.locals 4',\n");
        sb.append("# YOU MUST CHANGE IT TO:\n");
        sb.append("#     .locals 6\n");
        sb.append("# (This guarantees MT Manager compiles and saves with 0 errors!)\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Instantiate Toast object in v0\n");
        sb.append("new-instance v0, Landroid/widget/Toast;\n");
        sb.append("invoke-direct {v0, p0}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V\n\n");

        sb.append("# [Step 2] Create Container TextView in v1\n");
        sb.append("new-instance v1, Landroid/widget/TextView;\n");
        sb.append("invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V\n\n");

        sb.append("# [Step 3] Set Message & Text Color\n");
        sb.append("const-string v2, \"").append(safeMsg).append("\"\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V\n");
        sb.append("const v2, ").append(formatHexColor(textColor)).append("\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V\n");
        sb.append("const v2, 0x41600000 # 14.0sp\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V\n\n");

        sb.append("# [Step 4] Add Padding (horizontal=44px, vertical=20px)\n");
        sb.append("const/16 v2, 0x2c\n");
        sb.append("const/16 v3, 0x14\n");
        sb.append("const/16 v4, 0x2c\n");
        sb.append("const/16 v5, 0x14\n");
        sb.append("invoke-virtual/range {v1 .. v5}, Landroid/widget/TextView;->setPadding(IIII)V\n\n");

        sb.append("# [Step 5] Create GradientDrawable for rounded background in v2\n");
        sb.append("new-instance v2, Landroid/graphics/drawable/GradientDrawable;\n");
        sb.append("invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V\n");
        sb.append("const v3, ").append(formatHexColor(bgColor)).append("\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V\n");
        sb.append("const v3, 0x").append(Integer.toHexString(radiusBits)).append(" # ").append(cornerRadiusDp).append(".0f corner radius\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V\n");

        if (strokeWidthDp > 0) {
            sb.append("const/4 v3, 0x").append(strokeWidthDp).append(" # stroke width\n");
            sb.append("const v4, ").append(formatHexColor(strokeColor)).append(" # stroke color\n");
            sb.append("invoke-virtual {v2, v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V\n");
        }

        sb.append("invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V\n\n");

        sb.append("# [Step 6] Attach View to Toast and Show\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/widget/Toast;->setView(Landroid/view/View;)V\n");
        sb.append("const/4 v1, 0x").append(durationConst).append("\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/widget/Toast;->setDuration(I)V\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->show()V\n");

        return sb.toString();
    }

    // =========================================================================
    // 4. ANIMATED TOAST (ENTRANCE ALPHA/SCALE ANIMATION IN SMALI)
    // =========================================================================
    public static String generateAnimatedToast(String message, int animType, int durationMs, boolean isLong) {
        String safeMsg = escapeString(message);
        int durationConst = isLong ? 1 : 0;
        String animName = getAnimTypeName(animType);

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Animated Toast Maker\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Display toast with smooth entrance animation\n");
        sb.append("# ANIMATION    : ").append(animName).append(" (").append(durationMs).append("ms duration)\n");
        sb.append("# MESSAGE      : \"").append(message).append("\"\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (All Dalvik & ART runtimes)\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER SETUP]\n");
        sb.append("# Check the line directly below '.method protected onCreate(...)V'\n");
        sb.append("# If it has less than .locals 11, CHANGE IT TO:\n");
        sb.append("#     .locals 11\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Create base Toast\n");
        sb.append("const-string v0, \"").append(safeMsg).append("\"\n");
        sb.append("const/4 v1, 0x").append(durationConst).append("\n");
        sb.append("invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;\n");
        sb.append("move-result-object v0\n\n");

        sb.append("# [Step 2] Check Toast View and attach Animation\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->getView()Landroid/view/View;\n");
        sb.append("move-result-object v1\n");
        sb.append("if-nez v1, :cond_show_animated\n\n");

        if (animType == 0) { // Scale Zoom
            sb.append("# [Step 3] Scale Animation (from 0.0f to 1.0f from center pivot)\n");
            sb.append("new-instance v2, Landroid/view/animation/ScaleAnimation;\n");
            sb.append("const v3, 0x0 # fromX 0.0f\n");
            sb.append("const v4, 0x3f800000 # toX 1.0f\n");
            sb.append("const v5, 0x0 # fromY 0.0f\n");
            sb.append("const v6, 0x3f800000 # toY 1.0f\n");
            sb.append("const/4 v7, 0x1 # RELATIVE_TO_SELF\n");
            sb.append("const v8, 0x3f000000 # pivotX 0.5f\n");
            sb.append("const/4 v9, 0x1 # RELATIVE_TO_SELF\n");
            sb.append("const v10, 0x3f000000 # pivotY 0.5f\n");
            sb.append("invoke-direct/range {v2 .. v10}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFFFIF)V\n");
        } else { // Alpha Fade
            sb.append("# [Step 3] Alpha Animation (from 0.0f to 1.0f)\n");
            sb.append("new-instance v2, Landroid/view/animation/AlphaAnimation;\n");
            sb.append("const v3, 0x0 # fromAlpha 0.0f\n");
            sb.append("const v4, 0x3f800000 # toAlpha 1.0f\n");
            sb.append("invoke-direct {v2, v3, v4}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V\n");
        }

        sb.append("const-wide/16 v3, ").append(durationMs).append("\n");
        sb.append("invoke-virtual {v2, v3, v4}, Landroid/view/animation/Animation;->setDuration(J)V\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V\n\n");

        sb.append(":cond_show_animated\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->show()V\n");

        return sb.toString();
    }

    // =========================================================================
    // 5. IMAGE TOAST (CUSTOM VIEW WITH ICON + MESSAGE IN SMALI)
    // =========================================================================
    public static String generateImageToast(String title, String message, String iconName,
                                            int bgColor, int textColor, boolean isLong) {
        String safeTitle = escapeString(title);
        String safeMsg = escapeString(message);
        int durationConst = isLong ? 1 : 0;

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Image & Badge Toast Maker\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Branded VIP notification with icon badge and title\n");
        sb.append("# BADGE SYMBOL : ").append(iconName).append("\n");
        sb.append("# HEADER TITLE : \"").append(title).append("\"\n");
        sb.append("# MESSAGE BODY : \"").append(message).append("\"\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (All Dalvik & ART runtimes)\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER SETUP]\n");
        sb.append("# Check the line directly below '.method protected onCreate(...)V'\n");
        sb.append("# If it has less than .locals 7, CHANGE IT TO:\n");
        sb.append("#     .locals 7\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Create custom Toast in v0\n");
        sb.append("new-instance v0, Landroid/widget/Toast;\n");
        sb.append("invoke-direct {v0, p0}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V\n\n");

        sb.append("# [Step 2] Build horizontal container LinearLayout in v1\n");
        sb.append("new-instance v1, Landroid/widget/LinearLayout;\n");
        sb.append("invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V\n");
        sb.append("const/4 v2, 0x0 # HORIZONTAL\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V\n");
        sb.append("const/16 v2, 0x11 # Gravity.CENTER\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V\n\n");

        sb.append("# [Step 3] Set Container Padding (32px horizontal, 20px vertical)\n");
        sb.append("const/16 v2, 0x20\n");
        sb.append("const/16 v3, 0x14\n");
        sb.append("const/16 v4, 0x20\n");
        sb.append("const/16 v5, 0x14\n");
        sb.append("invoke-virtual/range {v1 .. v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V\n\n");

        sb.append("# [Step 4] Apply Pill GradientDrawable to Container in v2\n");
        sb.append("new-instance v2, Landroid/graphics/drawable/GradientDrawable;\n");
        sb.append("invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V\n");
        sb.append("const v3, ").append(formatHexColor(bgColor)).append("\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V\n");
        sb.append("const v3, 0x42200000 # 40.0f corner radius\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V\n\n");

        sb.append("# [Step 5] Create and add Badge TextView in v2\n");
        sb.append("new-instance v2, Landroid/widget/TextView;\n");
        sb.append("invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V\n");
        sb.append("const-string v3, \"").append(safeTitle).append(safeTitle.isEmpty() ? "" : " • ").append(safeMsg).append("\"\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V\n");
        sb.append("const v3, ").append(formatHexColor(textColor)).append("\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V\n");
        sb.append("const v3, 0x41600000 # 14.0sp\n");
        sb.append("invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V\n");
        sb.append("invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V\n\n");

        sb.append("# [Step 6] Attach View to Toast and Display\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/widget/Toast;->setView(Landroid/view/View;)V\n");
        sb.append("const/4 v1, 0x").append(durationConst).append("\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/widget/Toast;->setDuration(I)V\n");
        sb.append("invoke-virtual {v0}, Landroid/widget/Toast;->show()V\n");

        return sb.toString();
    }

    // =========================================================================
    // 6. UNIVERSAL DIALOG HOOK (100% RELIABLE ON ANDROID 11, 12, 13, 14, 15)
    // =========================================================================
    public static String generateUniversalDialog(String title, String message, String buttonText) {
        String safeTitle = escapeString(title);
        String safeMsg = escapeString(message);
        String safeBtn = escapeString(buttonText != null && !buttonText.isEmpty() ? buttonText : "OK");

        StringBuilder sb = new StringBuilder();
        sb.append("# =====================================================================\n");
        sb.append("# TOOL NAME    : Universal Dialog Popup Hook\n");
        sb.append("# DEVELOPED BY : Morsalin (Morsalin XML Creator)\n");
        sb.append("# PURPOSE      : Guaranteed on-screen popup alert on app start\n");
        sb.append("# COMPATIBILITY: Android 4.4 to 15.0 (NEVER blocked by Google OS)\n");
        sb.append("# TARGET HOOK  : Any Activity -> onCreate(Landroid/os/Bundle;)V\n");
        sb.append("# PLACEMENT    : Immediately after 'invoke-super {p0, p1}, L...;->onCreate(...)V'\n");
        sb.append("#\n");
        sb.append("# [CRITICAL MT MANAGER SETUP]\n");
        sb.append("# Ensure method has: .locals 4\n");
        sb.append("# =====================================================================\n\n");

        sb.append("# [Step 1] Create AlertDialog.Builder instance in v0\n");
        sb.append("new-instance v0, Landroid/app/AlertDialog$Builder;\n");
        sb.append("invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V\n\n");

        sb.append("# [Step 2] Set Dialog Title\n");
        sb.append("const-string v1, \"").append(safeTitle).append("\"\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;\n\n");

        sb.append("# [Step 3] Set Dialog Message\n");
        sb.append("const-string v1, \"").append(safeMsg).append("\"\n");
        sb.append("invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;\n\n");

        sb.append("# [Step 4] Add Confirm/Dismiss Button\n");
        sb.append("const-string v1, \"").append(safeBtn).append("\"\n");
        sb.append("const/4 v2, 0x0\n");
        sb.append("invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;\n\n");

        sb.append("# [Step 5] Display Dialog Popup on screen\n");
        sb.append("invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;\n");

        return sb.toString();
    }

    private static String escapeString(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static String formatHexColor(int color) {
        long unsigned = color & 0xFFFFFFFFL;
        if (unsigned <= 0x7FFFFFFF) {
            return "0x" + Long.toHexString(unsigned);
        } else {
            return "-0x" + Long.toHexString((~unsigned + 1) & 0xFFFFFFFFL);
        }
    }

    private static String getAnimTypeName(int type) {
        switch (type) {
            case 0: return "Zoom & Scale In";
            case 1: return "Fade Alpha Dissolve";
            case 2: return "Slide Up Bounce";
            default: return "Smooth Motion";
        }
    }
}
