package com.android.modding.tools.helpers;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

/**
 * Global Touch Particle Manager.
 * Intercepts touch events on the Window to render particle bursts
 * without blocking clicks, buttons, or scroll gestures.
 */
public class GlobalTouchParticleManager {

    private static final String PREF_NAME = "morsalin_settings";
    public static final String KEY_PARTICLE_STYLE = "key_touch_particle_style";

    private static int cachedStyle = -1;

    public static int getSavedStyle(Context context) {
        if (cachedStyle >= 0) return cachedStyle;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        cachedStyle = sp.getInt(KEY_PARTICLE_STYLE, TouchParticleOverlayView.STYLE_NONE);
        return cachedStyle;
    }

    public static void setSavedStyle(Context context, int style) {
        cachedStyle = style;
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(KEY_PARTICLE_STYLE, style).apply();
    }

    public static TouchParticleOverlayView getOverlay(Activity activity) {
        if (activity == null) return null;
        try {
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            for (int i = 0; i < decor.getChildCount(); i++) {
                if (decor.getChildAt(i) instanceof TouchParticleOverlayView) {
                    return (TouchParticleOverlayView) decor.getChildAt(i);
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    /**
     * Attaches the touch particle overlay to the given activity's decor view
     * and listens to touches via a lightweight window callback wrapper.
     */
    public static TouchParticleOverlayView attach(final Activity activity) {
        if (activity == null) return null;

        try {
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            // Check if already attached
            for (int i = 0; i < decor.getChildCount(); i++) {
                if (decor.getChildAt(i) instanceof TouchParticleOverlayView) {
                    TouchParticleOverlayView existing = (TouchParticleOverlayView) decor.getChildAt(i);
                    existing.setStyle(getSavedStyle(activity));
                    existing.setAmbientStyle(AmbientBackgroundAnimationManager.getSavedStyle(activity));
                    return existing;
                }
            }

            final TouchParticleOverlayView overlay = new TouchParticleOverlayView(activity);
            overlay.setStyle(getSavedStyle(activity));
            overlay.setAmbientStyle(AmbientBackgroundAnimationManager.getSavedStyle(activity));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            );
            decor.addView(overlay, lp);

            // Apply universal screen transitions, scroll transitions and typing text
            try {
                TransitionAnimationManager.applyForward(activity);
                MorsalinTypingTextHelper.applyUniversalTextAnimation(activity);
            } catch (Throwable ignored) {}

            // Wrap window callback to detect touches and micro-interactions cleanly
            final Window window = activity.getWindow();
            final Window.Callback originalCallback = window.getCallback();
            window.setCallback(new WindowCallbackWrapper(originalCallback) {
                @Override
                public boolean dispatchTouchEvent(MotionEvent event) {
                    if (event != null) {
                        int action = event.getAction();
                        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                            int current = getSavedStyle(activity);
                            if (current != TouchParticleOverlayView.STYLE_NONE) {
                                overlay.setStyle(current);
                                overlay.spawnBurst(event.getX(), event.getY());
                            }
                            if (ButtonPressAnimationHelper.isEnabled(activity)) {
                                ButtonPressAnimationHelper.handleTouchDown(activity, event.getRawX(), event.getRawY());
                            }
                        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                            if (ButtonPressAnimationHelper.isEnabled(activity)) {
                                ButtonPressAnimationHelper.handleTouchUp();
                            }
                        }
                    }
                    return super.dispatchTouchEvent(event);
                }
            });

            return overlay;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static void refreshAll(Activity activity) {
        TouchParticleOverlayView overlay = getOverlay(activity);
        if (overlay != null) {
            overlay.setStyle(getSavedStyle(activity));
            overlay.setAmbientStyle(AmbientBackgroundAnimationManager.getSavedStyle(activity));
        }
    }
}
