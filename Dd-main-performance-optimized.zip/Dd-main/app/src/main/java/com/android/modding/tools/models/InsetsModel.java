package com.android.modding.tools.models;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import java.io.Serializable;

public class InsetsModel implements Serializable {
    private int leftDp = 0;
    private int topDp = 0;
    private int rightDp = 0;
    private int bottomDp = 0;
    private boolean linked = false;

    public InsetsModel() {}

    public InsetsModel(int leftDp, int topDp, int rightDp, int bottomDp) {
        this.leftDp = leftDp;
        this.topDp = topDp;
        this.rightDp = rightDp;
        this.bottomDp = bottomDp;
    }

    public void setInsets(int left, int top, int right, int bottom, boolean linked) {
        this.linked = linked;
        this.leftDp = Math.max(0, left);
        this.topDp = Math.max(0, top);
        this.rightDp = Math.max(0, right);
        this.bottomDp = Math.max(0, bottom);
    }

    public int getLeftDp() {
        return leftDp;
    }

    public void setLeftDp(int leftDp) {
        this.leftDp = Math.max(0, leftDp);
        if (linked) {
            this.topDp = this.leftDp;
            this.rightDp = this.leftDp;
            this.bottomDp = this.leftDp;
        }
    }

    public int getTopDp() {
        return topDp;
    }

    public void setTopDp(int topDp) {
        this.topDp = Math.max(0, topDp);
        if (linked) {
            this.leftDp = this.topDp;
            this.rightDp = this.topDp;
            this.bottomDp = this.topDp;
        }
    }

    public int getRightDp() {
        return rightDp;
    }

    public void setRightDp(int rightDp) {
        this.rightDp = Math.max(0, rightDp);
        if (linked) {
            this.leftDp = this.rightDp;
            this.topDp = this.rightDp;
            this.bottomDp = this.rightDp;
        }
    }

    public int getBottomDp() {
        return bottomDp;
    }

    public void setBottomDp(int bottomDp) {
        this.bottomDp = Math.max(0, bottomDp);
        if (linked) {
            this.leftDp = this.bottomDp;
            this.topDp = this.bottomDp;
            this.rightDp = this.bottomDp;
        }
    }

    public boolean isLinked() {
        return linked;
    }

    public void setLinked(boolean linked) {
        this.linked = linked;
    }

    public boolean hasAnyInset() {
        return leftDp > 0 || topDp > 0 || rightDp > 0 || bottomDp > 0;
    }

    public InsetsModel copy() {
        InsetsModel copy = new InsetsModel(leftDp, topDp, rightDp, bottomDp);
        copy.setLinked(linked);
        return copy;
    }
}
