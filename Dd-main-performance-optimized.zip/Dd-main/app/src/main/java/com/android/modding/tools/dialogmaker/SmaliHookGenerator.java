package com.android.modding.tools.dialogmaker;

/**
 * Generates verified, authentic ReadMe.smali for APK modding.
 * Contains direct Smali hook invocation, register setup instructions,
 * assets folder mapping, and MT Manager / NP Manager step-by-step guidance.
 */
public class SmaliHookGenerator {

    public static String generateReadMeSmali(DialogConfig config, DexValidator.ValidationResult dexResult) {
        StringBuilder sb = new StringBuilder();

        sb.append("# ====================================================================\n");
        sb.append("#                  MORSALIN ADVANCED DIALOG MAKER                     \n");
        sb.append("#                 REAL DALVIK SMALI HOOK & INJECTION                  \n");
        sb.append("# ====================================================================\n");
        sb.append("# Dialog Name    : ").append(config.dialogName).append("\n");
        sb.append("# Dialog Type    : ").append(config.dialogType).append("\n");
        sb.append("# Target Runtime : Android 5.0 - Android 15.0+ (Dalvik & ART Compatible)\n");
        sb.append("# Architecture   : Sanny & Morsalin (Anonymous Modder King)\n");
        sb.append("# Telegram       : https://t.me/anonymous_modder_king\n");
        sb.append("# YouTube        : https://www.youtube.com/@apk.modding\n");
        sb.append("# ====================================================================\n\n");

        sb.append("# --------------------------------------------------------------------\n");
        sb.append("# 📦 GENERATED PACKAGE CONTENTS\n");
        sb.append("# --------------------------------------------------------------------\n");
        sb.append("# 1. classes.dex          -> Compiled Dalvik bytecode (Lcom/morsalin/...)\n");
        sb.append("# 2. classes_rename.dex   -> Identical bytecode (rename to classes2/3.dex)\n");
        sb.append("# 3. ReadMe.smali         -> This Smali hook instruction file\n");
        sb.append("# 4. GUIDE.txt            -> Complete bilingual integration guide\n");
        sb.append("# 5. assets/              -> Assets directory to copy into target APK\n");
        sb.append("#    ├── morsalin_dialog_data.dat    (Dialog configuration & manifest payload)\n");
        sb.append("#    ├── morsalin_dialog_icon.png    (App-branded dialog icon graphic)\n");
        sb.append("#    ├── morsalin_dialog_title.png   (App-branded dialog title banner)\n");
        sb.append("#    └── morsalin_dialog_config.json (Human-readable parameters)\n\n");

        sb.append("# ====================================================================\n");
        sb.append("# 🚀 STEP-BY-STEP APK MODDING INSTRUCTIONS (MT MANAGER / NP MANAGER)\n");
        sb.append("# ====================================================================\n");
        sb.append("# [STEP 1 : DEX INJECTION]\n");
        sb.append("# 1. Open your target APK in MT Manager or NP Manager.\n");
        sb.append("# 2. Copy 'classes.dex' (or 'classes_rename.dex') into the root of APK:\n");
        sb.append("#    • If APK already has classes.dex, rename this to 'classes2.dex'\n");
        sb.append("#      (or 'classes3.dex', 'classes4.dex', etc.).\n");
        sb.append("#    • OR open classes.dex in Dex Editor Plus and select 'Merge Dex'.\n#\n");

        sb.append("# [STEP 2 : ASSETS DIRECTORY EXTRACTION]\n");
        sb.append("# 1. Copy the entire 'assets/' folder into your target APK's 'assets/' folder.\n");
        sb.append("#    Make sure the following files are inside APK's assets/:\n");
        sb.append("#    • assets/morsalin_dialog_data.dat\n");
        sb.append("#    • assets/morsalin_dialog_icon.png\n");
        sb.append("#    • assets/morsalin_dialog_title.png\n");
        sb.append("#    • assets/morsalin_dialog_config.json\n#\n");

        sb.append("# [STEP 3 : SMALI HOOK PLACEMENT]\n");
        sb.append("# 1. Open the target Activity (usually MainActivity.smali or SplashActivity.smali)\n");
        sb.append("#    inside Dex Editor Plus.\n");
        sb.append("# 2. Locate '.method protected onCreate(Landroid/os/Bundle;)V'\n");
        sb.append("#    or '.method public onCreate(Landroid/os/Bundle;)V'.\n");
        sb.append("# 3. Check the line directly below '.method ... onCreate(...)':\n");
        sb.append("#    If it says '.locals 0', '.locals 1', '.locals 2', or '.locals 3',\n");
        sb.append("#    CHANGE IT TO:\n");
        sb.append("#        .locals 5\n");
        sb.append("# 4. Paste the 1-LINE HOOK below right before the final 'return-void':\n\n");

        sb.append("# ====================================================================\n");
        sb.append("# 🎯 >>>>>>>>>>>>>>>>> DIALOG HOOK CODE START <<<<<<<<<<<<<<<<<\n");
        sb.append("# ====================================================================\n\n");

        sb.append(".line 1\n");
        sb.append("# Context register: p0 inside Activity (or v0)\n");
        sb.append("invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->show(Landroid/content/Context;)V\n\n");

        sb.append("# ====================================================================\n");
        sb.append("# 🎯 >>>>>>>>>>>>>>>>>> DIALOG HOOK CODE END <<<<<<<<<<<<<<<<<<\n");
        sb.append("# ====================================================================\n\n");

        sb.append("# --------------------------------------------------------------------\n");
        sb.append("# 🔧 ADVANCED / OPTIONAL HOOK OPTIONS\n");
        sb.append("# --------------------------------------------------------------------\n");
        sb.append("# Option A: Trigger Dialog with custom Title string override:\n");
        sb.append("# const-string v0, \"").append(escapeSmaliString(config.titleText)).append("\"\n");
        sb.append("# invoke-static {p0, v0}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->showWithTitle(Landroid/content/Context;Ljava/lang/String;)V\n\n");

        sb.append("# Option B: Programmatically dismiss dialog from any method:\n");
        sb.append("# invoke-static {}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->dismissDialog()V\n\n");

        sb.append("# --------------------------------------------------------------------\n");
        sb.append("# 🔍 DEX INTEGRITY VALIDATION DETAILS\n");
        sb.append("# --------------------------------------------------------------------\n");
        if (dexResult != null && dexResult.isValid) {
            sb.append("# • Status       : 100% VALID DALVIK / ART BINARY\n");
            sb.append("# • Size         : ").append(dexResult.sizeBytes).append(" bytes\n");
            sb.append("# • Adler32      : 0x").append(dexResult.checksumHex).append("\n");
            sb.append("# • SHA-1        : ").append(dexResult.sha1Hex).append("\n");
            sb.append("# • Classes      : ").append(dexResult.classCount).append("\n");
        } else {
            sb.append("# • Status       : Self-contained binary template\n");
        }
        sb.append("# ====================================================================\n");

        return sb.toString();
    }

    public static String generateSmaliHookSnippet() {
        return "invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinCustomDialog;->show(Landroid/content/Context;)V";
    }

    private static String escapeSmaliString(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
