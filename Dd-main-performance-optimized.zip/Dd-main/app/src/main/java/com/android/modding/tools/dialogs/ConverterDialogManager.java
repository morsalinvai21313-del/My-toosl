package com.android.modding.tools.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.CodeConversionHistoryManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.models.CodeConversionItem;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class ConverterDialogManager {

    public interface OnExportRequestedListener {
        void onChooseFolderWithSaf(String fullFileName, String mimeType, String codeContent);
    }

    public interface OnHistoryItemLoadListener {
        void onLoadIntoEditor(CodeConversionItem item);
    }

    public static void showExportDialog(Activity activity, String defaultBaseName, String defaultExt,
                                        String codeContent, OnExportRequestedListener safListener) {
        Dialog dialog = new Dialog(activity, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_converter_export);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        EditText etBaseName = dialog.findViewById(R.id.et_export_file_name);
        Button btnExtKt = dialog.findViewById(R.id.btn_ext_kt);
        Button btnExtJava = dialog.findViewById(R.id.btn_ext_java);
        Button btnExtTxt = dialog.findViewById(R.id.btn_ext_txt);
        Button btnChooseFolder = dialog.findViewById(R.id.btn_export_choose_folder);
        Button btnQuickDownloads = dialog.findViewById(R.id.btn_export_quick_downloads);
        Button btnCancel = dialog.findViewById(R.id.btn_export_cancel);

        String cleanBase = stripExtension(defaultBaseName != null ? defaultBaseName : "ConvertedCode");
        etBaseName.setText(cleanBase);

        final String[] selectedExt = {defaultExt != null ? defaultExt : ".kt"};
        Runnable updateExtButtons = () -> {
            btnExtKt.setTextColor(".kt".equals(selectedExt[0]) ? Color.parseColor("#00FF88") : Color.WHITE);
            btnExtJava.setTextColor(".java".equals(selectedExt[0]) ? Color.parseColor("#00FF88") : Color.WHITE);
            btnExtTxt.setTextColor(".txt".equals(selectedExt[0]) ? Color.parseColor("#00FF88") : Color.WHITE);
        };
        updateExtButtons.run();

        btnExtKt.setOnClickListener(v -> {
            selectedExt[0] = ".kt";
            updateExtButtons.run();
        });
        btnExtJava.setOnClickListener(v -> {
            selectedExt[0] = ".java";
            updateExtButtons.run();
        });
        btnExtTxt.setOnClickListener(v -> {
            selectedExt[0] = ".txt";
            updateExtButtons.run();
        });

        btnChooseFolder.setOnClickListener(v -> {
            String base = stripExtension(etBaseName.getText().toString().trim());
            if (base.isEmpty()) base = "ConvertedCode";
            String fullFileName = base + selectedExt[0];
            dialog.dismiss();
            if (safListener != null) {
                safListener.onChooseFolderWithSaf(fullFileName, "text/plain", codeContent);
            }
        });

        btnQuickDownloads.setOnClickListener(v -> {
            String base = stripExtension(etBaseName.getText().toString().trim());
            if (base.isEmpty()) base = "ConvertedCode";
            String fullFileName = base + selectedExt[0];
            dialog.dismiss();
            exportCodeToDownloads(activity, fullFileName, codeContent);
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    public static void exportCodeToDownloads(Activity activity, String fileName, String codeContent) {
        try {
            byte[] bytes = (codeContent != null ? codeContent : "").getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MorsalinConverter");

                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream os = activity.getContentResolver().openOutputStream(uri)) {
                        if (os != null) {
                            os.write(bytes);
                            os.flush();
                            MorsalinToast.showDownload(activity, "File exported successfully: Downloads/MorsalinConverter/" + fileName);
                            return;
                        }
                    }
                }
            }

            File docsDir = activity.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (docsDir == null) docsDir = activity.getFilesDir();
            File outFile = new File(docsDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                fos.write(bytes);
                fos.flush();
            }
            MorsalinToast.showDownload(activity, "File exported successfully: " + outFile.getName());
        } catch (Exception e) {
            MorsalinToast.show(activity, R.drawable.ic_download, "Export Error", "Could not save file: " + e.getMessage());
        }
    }

    public static void shareCode(Activity activity, String fileName, String codeContent) {
        MorsalinDialogHelper.showResetDialog(
                activity,
                "Share Converted Code",
                "Press 'Reset Now' (Share File) to share as a " + fileName + " source file, or press Cancel to share as plain text.",
                () -> shareAsFile(activity, fileName, codeContent)
        );
        // Also allow direct file share with text fallback if anything fails
    }

    public static void shareCodeFileOrText(Activity activity, String fileName, String codeContent) {
        try {
            File cacheDir = new File(activity.getCacheDir(), "shared_code");
            if (!cacheDir.exists()) {
                cacheDir.mkdirs();
            }
            File tempFile = new File(cacheDir, fileName);
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write((codeContent != null ? codeContent : "").getBytes(StandardCharsets.UTF_8));
                fos.flush();
            }

            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", tempFile);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.putExtra(Intent.EXTRA_SUBJECT, fileName);
            intent.putExtra(Intent.EXTRA_TEXT, codeContent);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(Intent.createChooser(intent, "Share Converted Code"));
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, fileName);
            intent.putExtra(Intent.EXTRA_TEXT, codeContent);
            activity.startActivity(Intent.createChooser(intent, "Share Converted Code as Text"));
        }
    }

    private static void shareAsFile(Activity activity, String fileName, String codeContent) {
        shareCodeFileOrText(activity, fileName, codeContent);
    }

    public static void showHistoryDialog(Activity activity, OnHistoryItemLoadListener loadListener,
                                         OnExportRequestedListener safListener) {
        Dialog dialog = new Dialog(activity, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_converter_history);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.95);
            int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.86);
            dialog.getWindow().setLayout(width, height);
        }

        EditText etSearch = dialog.findViewById(R.id.et_search_history);
        Button btnClearAll = dialog.findViewById(R.id.btn_history_clear_all);
        Button btnClose = dialog.findViewById(R.id.btn_history_dialog_close);
        LinearLayout containerList = dialog.findViewById(R.id.container_conversion_history_list);
        TextView tvEmpty = dialog.findViewById(R.id.tv_conversion_history_empty);

        final Runnable[] refreshList = new Runnable[1];
        refreshList[0] = () -> {
            String query = etSearch.getText().toString();
            List<CodeConversionItem> items = CodeConversionHistoryManager.searchConversions(activity, query);
            containerList.removeAllViews();
            if (items.isEmpty()) {
                tvEmpty.setVisibility(View.VISIBLE);
                return;
            }
            tvEmpty.setVisibility(View.GONE);
            LayoutInflater inflater = LayoutInflater.from(activity);
            for (CodeConversionItem item : items) {
                View card = inflater.inflate(R.layout.item_converter_history, containerList, false);
                TextView tvDir = card.findViewById(R.id.tv_hist_direction);
                TextView tvFile = card.findViewById(R.id.tv_hist_filename);
                TextView tvDate = card.findViewById(R.id.tv_hist_datetime);
                TextView tvLines = card.findViewById(R.id.tv_hist_lines_badge);

                Button btnOpen = card.findViewById(R.id.btn_hist_open);
                Button btnCopy = card.findViewById(R.id.btn_hist_copy);
                Button btnExport = card.findViewById(R.id.btn_hist_export);
                Button btnShare = card.findViewById(R.id.btn_hist_share);
                Button btnDelete = card.findViewById(R.id.btn_hist_delete);

                tvDir.setText(item.getDirectionTitle());
                tvFile.setText(item.getOriginalFileName() + " → " + item.getConvertedFileName());
                tvDate.setText(item.getFormattedDate());
                tvLines.setText(item.getLinesGenerated() + " lines");

                btnOpen.setOnClickListener(v -> showHistoryDetailDialog(
                        activity, item, dialog, refreshList[0], loadListener, safListener
                ));

                btnCopy.setOnClickListener(v -> {
                    copyToClipboard(activity, item.getConvertedFileName(), item.getConvertedCode());
                    MorsalinToast.showCopy(activity, "Converted code copied from history!");
                });

                btnExport.setOnClickListener(v -> {
                    String ext = item.getConvertedLanguage().equalsIgnoreCase("Kotlin") ? ".kt" : ".java";
                    showExportDialog(activity, item.getConvertedFileName(), ext, item.getConvertedCode(), safListener);
                });

                btnShare.setOnClickListener(v -> shareCodeFileOrText(activity, item.getConvertedFileName(), item.getConvertedCode()));

                btnDelete.setOnClickListener(v -> {
                    CodeConversionHistoryManager.deleteConversion(activity, item.getId());
                    refreshList[0].run();
                    MorsalinToast.show(activity, R.drawable.ic_refresh, "Deleted", "Conversion history item deleted.");
                });

                containerList.addView(card);
            }
        };

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshList[0].run();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnClearAll.setOnClickListener(v -> {
            MorsalinDialogHelper.showResetDialog(
                    activity,
                    "Clear All History?",
                    "Are you sure you want to permanently delete all saved Java ↔ Kotlin conversions?",
                    () -> {
                        CodeConversionHistoryManager.clearAllConversions(activity);
                        refreshList[0].run();
                        MorsalinToast.showReset(activity, "All conversion history cleared!");
                    }
            );
        });

        btnClose.setOnClickListener(v -> dialog.dismiss());
        refreshList[0].run();
        dialog.show();
    }

    public static void showHistoryDetailDialog(Activity activity, CodeConversionItem item,
                                               Dialog parentHistoryDialog, Runnable onChanged,
                                               OnHistoryItemLoadListener loadListener,
                                               OnExportRequestedListener safListener) {
        Dialog detailDialog = new Dialog(activity, R.style.Theme_MyApplication_Dialog);
        detailDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        detailDialog.setContentView(R.layout.dialog_converter_history_detail);

        if (detailDialog.getWindow() != null) {
            detailDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.95);
            int height = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.88);
            detailDialog.getWindow().setLayout(width, height);
        }

        TextView tvTitle = detailDialog.findViewById(R.id.tv_detail_title);
        TextView tvSubtitle = detailDialog.findViewById(R.id.tv_detail_subtitle);
        TextView tvOrigLabel = detailDialog.findViewById(R.id.tv_detail_original_label);
        TextView tvOrigCode = detailDialog.findViewById(R.id.tv_detail_original_code);
        TextView tvConvCode = detailDialog.findViewById(R.id.tv_detail_converted_code);

        Button btnLoadEditor = detailDialog.findViewById(R.id.btn_detail_load_editor);
        Button btnClose = detailDialog.findViewById(R.id.btn_detail_close);
        Button btnCopyOrig = detailDialog.findViewById(R.id.btn_detail_copy_original);
        Button btnCopyConv = detailDialog.findViewById(R.id.btn_detail_copy_converted);
        Button btnExport = detailDialog.findViewById(R.id.btn_detail_export);
        Button btnShare = detailDialog.findViewById(R.id.btn_detail_share);
        Button btnDelete = detailDialog.findViewById(R.id.btn_detail_delete);

        tvTitle.setText(item.getDirectionTitle());
        tvSubtitle.setText(item.getOriginalFileName() + " • " + item.getFormattedDate());
        tvOrigLabel.setText("Original Code (" + item.getOriginalLanguage() + ")");

        SpannableStringBuilder origSpan = new SpannableStringBuilder(item.getOriginalCode());
        SyntaxHighlighter.applyHighlighting(origSpan, null);
        tvOrigCode.setText(origSpan);

        SpannableStringBuilder convSpan = new SpannableStringBuilder(item.getConvertedCode());
        SyntaxHighlighter.applyHighlighting(convSpan, null);
        tvConvCode.setText(convSpan);

        btnLoadEditor.setOnClickListener(v -> {
            detailDialog.dismiss();
            if (parentHistoryDialog != null) parentHistoryDialog.dismiss();
            if (loadListener != null) loadListener.onLoadIntoEditor(item);
        });

        btnClose.setOnClickListener(v -> detailDialog.dismiss());

        btnCopyOrig.setOnClickListener(v -> {
            copyToClipboard(activity, item.getOriginalFileName(), item.getOriginalCode());
            MorsalinToast.showCopy(activity, "Original " + item.getOriginalLanguage() + " code copied!");
        });

        btnCopyConv.setOnClickListener(v -> {
            copyToClipboard(activity, item.getConvertedFileName(), item.getConvertedCode());
            MorsalinToast.showCopy(activity, "Converted " + item.getConvertedLanguage() + " code copied!");
        });

        btnExport.setOnClickListener(v -> {
            String ext = item.getConvertedLanguage().equalsIgnoreCase("Kotlin") ? ".kt" : ".java";
            showExportDialog(activity, item.getConvertedFileName(), ext, item.getConvertedCode(), safListener);
        });

        btnShare.setOnClickListener(v -> shareCodeFileOrText(activity, item.getConvertedFileName(), item.getConvertedCode()));

        btnDelete.setOnClickListener(v -> {
            CodeConversionHistoryManager.deleteConversion(activity, item.getId());
            detailDialog.dismiss();
            if (onChanged != null) onChanged.run();
            MorsalinToast.show(activity, R.drawable.ic_refresh, "Deleted", "History item deleted.");
        });

        detailDialog.show();
    }

    public static void copyToClipboard(Context context, String label, String text) {
        ClipboardManager cb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cb != null) {
            cb.setPrimaryClip(ClipData.newPlainText(label, text != null ? text : ""));
        }
    }

    public static String stripExtension(String fileName) {
        if (fileName == null) return "ConvertedCode";
        String f = fileName.trim();
        int dot = f.lastIndexOf('.');
        if (dot > 0) {
            return f.substring(0, dot);
        }
        return f;
    }
}
