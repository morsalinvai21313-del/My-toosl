package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Universal Multi-Engine Procedural Visual Animation View.
 * Powers the 5 brand-new, ultra-modern loading & conversion animations
 * across Dialog Maker, Toast Maker, Code Converter, and Settings Studio.
 */
public class ConversionAnimationView extends View {

    private Paint bgPaint;
    private Paint gridPaint;
    private Paint glowPaint;
    private Paint ringPaint;
    private Paint arcPaint;
    private Paint panelBgPaint;
    private Paint panelStrokePaint;
    private Paint laserPaint;
    private Paint streamPaint;
    private Paint textPaint;
    private Paint subTextPaint;
    private Paint badgeTextPaint;
    private Paint percentPaint;
    private Paint particlePaint;
    private Paint stepNodePaint;

    private final RectF coreInnerRect = new RectF();
    private final RectF pipelineCardRect = new RectF();
    private final RectF progressTrackRect = new RectF();
    private final RectF progressFillRect = new RectF();
    private final RectF tempRect = new RectF();

    private final Path hexPath = new Path();

    private ValueAnimator loopAnimator;
    private float animPhase = 0f;
    private float continuousTime = 0f;
    private int progress = 0;
    private int currentStepIndex = 0;
    private String currentStepText = "Initializing Dalvik Compiler...";
    private String sourceLang = "INPUT";
    private String targetLang = "OUTPUT";

    // Active Visual Animation Configuration (5 brand new engines)
    private int activeEngineType = ConverterAnimationManager.ENGINE_COSMIC_NEBULA;
    private int activePaletteType = ConverterAnimationManager.PALETTE_SIGNATURE;
    private boolean overdriveParticles = true;
    private String activeHeaderBanner = "🌌 COSMIC NEBULA & PULSAR VORTEX 🌌";
    private String activeStyleTitle = "1. Cosmic Nebula & Pulsar Vortex";

    // Resolved active theme colors
    private int themePrimary = 0xFF7C4DFF;
    private int themeSecondary = 0xFF00E5FF;
    private int themeAccent = 0xFFFF4081;
    private int themeBgTop = 0xFF050314;
    private int themeBgMid = 0xFF10082E;

    private static final String[] STEP_SHORT_LABELS = {
            "PARSE", "TREE", "TRANSFORM", "OPTIMIZE", "VERIFY", "DONE"
    };

    private static class SparkParticle {
        float x, y;
        float vx, vy;
        float alpha;
        float radius;
        int color;
        float angle;
        float orbitRadius;
        float orbitSpeed;
    }

    private final List<SparkParticle> sparks = new ArrayList<>();
    private final Random random = new Random(42);

    public ConversionAnimationView(Context context) {
        super(context);
        init(context);
    }

    public ConversionAnimationView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ConversionAnimationView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        Typeface boldTf = MorsalinViewInflater.getAppTypeface(context, true);

        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setStyle(Paint.Style.FILL);

        gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1.4f);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);

        ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringPaint.setStyle(Paint.Style.STROKE);

        arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        panelBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        panelBgPaint.setStyle(Paint.Style.FILL);

        panelStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        panelStrokePaint.setStyle(Paint.Style.STROKE);
        panelStrokePaint.setStrokeWidth(3f);

        laserPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        laserPaint.setStyle(Paint.Style.STROKE);

        streamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        streamPaint.setStyle(Paint.Style.STROKE);
        streamPaint.setStrokeCap(Paint.Cap.ROUND);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(boldTf);

        subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        subTextPaint.setColor(0xFF00E5FF);
        subTextPaint.setTextAlign(Paint.Align.CENTER);
        subTextPaint.setTypeface(boldTf);

        badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        badgeTextPaint.setColor(Color.WHITE);
        badgeTextPaint.setTextAlign(Paint.Align.CENTER);
        badgeTextPaint.setTypeface(boldTf);

        percentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        percentPaint.setColor(Color.WHITE);
        percentPaint.setTextAlign(Paint.Align.CENTER);
        percentPaint.setTypeface(boldTf);

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        particlePaint.setStyle(Paint.Style.FILL);

        stepNodePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        resolveThemeColors();
        seedParticles();
    }

    public void applyAnimationConfig(ConverterAnimationManager.ConverterAnimItem item) {
        if (item == null) return;
        this.activeEngineType = item.engineType;
        this.activePaletteType = item.paletteType;
        this.overdriveParticles = item.overdriveParticles;
        this.activeHeaderBanner = item.headerBanner;
        this.activeStyleTitle = item.name;
        resolveThemeColors();
        seedParticles();
        invalidate();
    }

    public void loadSelectedFromPrefs() {
        ConverterAnimationManager.ConverterAnimItem item =
                ConverterAnimationManager.resolveAnimationForConversion(getContext());
        applyAnimationConfig(item);
    }

    public String getActiveStyleTitle() {
        return activeStyleTitle;
    }

    private void resolveThemeColors() {
        if (activePaletteType == ConverterAnimationManager.PALETTE_CYBER_NEON) {
            themePrimary = 0xFF00E5FF;
            themeSecondary = 0xFFFF2A85;
            themeAccent = 0xFF69F0AE;
            themeBgTop = 0xFF02090F;
            themeBgMid = 0xFF051724;
            return;
        } else if (activePaletteType == ConverterAnimationManager.PALETTE_MATRIX_GREEN) {
            themePrimary = 0xFF00FF66;
            themeSecondary = 0xFF00E5FF;
            themeAccent = 0xFFB9F6CA;
            themeBgTop = 0xFF020B05;
            themeBgMid = 0xFF051A0D;
            return;
        } else if (activePaletteType == ConverterAnimationManager.PALETTE_RED_OVERDRIVE) {
            themePrimary = 0xFFFF1744;
            themeSecondary = 0xFFFFD600;
            themeAccent = 0xFFFF5252;
            themeBgTop = 0xFF140502;
            themeBgMid = 0xFF2B0B04;
            return;
        } else if (activePaletteType == ConverterAnimationManager.PALETTE_QUANTUM_VIOLET) {
            themePrimary = 0xFFB388FF;
            themeSecondary = 0xFF00E5FF;
            themeAccent = 0xFFEA80FC;
            themeBgTop = 0xFF080417;
            themeBgMid = 0xFF14092E;
            return;
        } else if (activePaletteType == ConverterAnimationManager.PALETTE_SOLAR_GOLD) {
            themePrimary = 0xFFFFAB00;
            themeSecondary = 0xFFFF3D00;
            themeAccent = 0xFFFFEA00;
            themeBgTop = 0xFF120902;
            themeBgMid = 0xFF241205;
            return;
        }

        // Signature Palette mapped to the 5 engines
        switch (activeEngineType) {
            case ConverterAnimationManager.ENGINE_CYBER_HEX_SHIELD:
                themePrimary = 0xFF00E5FF;
                themeSecondary = 0xFF00FF66;
                themeAccent = 0xFFFFFFFF;
                themeBgTop = 0xFF02090F;
                themeBgMid = 0xFF051724;
                break;
            case ConverterAnimationManager.ENGINE_NEON_WARP_TUNNEL:
                themePrimary = 0xFFFF2A85;
                themeSecondary = 0xFF00E5FF;
                themeAccent = 0xFFEA80FC;
                themeBgTop = 0xFF0B0212;
                themeBgMid = 0xFF1A0629;
                break;
            case ConverterAnimationManager.ENGINE_PHOENIX_INFERNO:
                themePrimary = 0xFFFF6D00;
                themeSecondary = 0xFFFFD600;
                themeAccent = 0xFFFF1744;
                themeBgTop = 0xFF140502;
                themeBgMid = 0xFF2B0B04;
                break;
            case ConverterAnimationManager.ENGINE_QUANTUM_COLLIDER:
                themePrimary = 0xFF00E5FF;
                themeSecondary = 0xFF69F0AE;
                themeAccent = 0xFFFFFFFF;
                themeBgTop = 0xFF030A14;
                themeBgMid = 0xFF07192B;
                break;
            case ConverterAnimationManager.ENGINE_COSMIC_NEBULA:
            default:
                themePrimary = 0xFF7C4DFF;
                themeSecondary = 0xFF00E5FF;
                themeAccent = 0xFFFF4081;
                themeBgTop = 0xFF050314;
                themeBgMid = 0xFF10082E;
                break;
        }
    }

    private void seedParticles() {
        sparks.clear();
        int sparkCount = overdriveParticles ? 48 : 30;
        for (int i = 0; i < sparkCount; i++) {
            SparkParticle sp = new SparkParticle();
            resetSpark(sp, 500, 400, i, sparkCount);
            sparks.add(sp);
        }
    }

    private void resetSpark(SparkParticle sp, float cx, float cy, int index, int total) {
        double angle = random.nextDouble() * Math.PI * 2.0;
        float speed = 1.4f + random.nextFloat() * 3.6f;
        sp.x = cx + (random.nextFloat() - 0.5f) * 32f;
        sp.y = cy + (random.nextFloat() - 0.5f) * 32f;
        sp.vx = (float) Math.cos(angle) * speed;
        sp.vy = (float) Math.sin(angle) * speed;
        sp.alpha = 0.55f + random.nextFloat() * 0.45f;
        sp.radius = 2.0f + random.nextFloat() * 3.2f;
        sp.angle = (float) ((index / (double) Math.max(1, total)) * Math.PI * 2.0);
        sp.orbitRadius = 0.25f + random.nextFloat() * 0.75f;
        sp.orbitSpeed = 0.025f + random.nextFloat() * 0.045f;
        int pick = random.nextInt(3);
        sp.color = pick == 0 ? themePrimary : (pick == 1 ? themeSecondary : themeAccent);
    }

    public void setConversionDirection(boolean forwardMode) {
        if (forwardMode) {
            sourceLang = "INPUT";
            targetLang = "OUTPUT";
        } else {
            sourceLang = "SOURCE";
            targetLang = "TARGET";
        }
        seedParticles();
        invalidate();
    }

    public void setLanguages(String srcLang, String dstLang) {
        this.sourceLang = (srcLang != null && !srcLang.trim().isEmpty()) ? srcLang.toUpperCase() : "INPUT";
        this.targetLang = (dstLang != null && !dstLang.trim().isEmpty()) ? dstLang.toUpperCase() : "OUTPUT";
        seedParticles();
        invalidate();
    }

    public void setProgressAndStage(float progressPercent, String stageBadge) {
        int p = Math.round(progressPercent);
        updateState(p, stageBadge != null ? stageBadge : "CONVERTING");
    }

    public void startParticleAnimation() {
        startAnimationLoop();
    }

    public void stopParticleAnimation() {
        stopAnimationLoop();
    }

    public void updateState(int progressPercent, String stepDescription) {
        this.progress = Math.max(0, Math.min(100, progressPercent));
        this.currentStepText = stepDescription;
        if (progressPercent < 18) currentStepIndex = 0;
        else if (progressPercent < 36) currentStepIndex = 1;
        else if (progressPercent < 56) currentStepIndex = 2;
        else if (progressPercent < 76) currentStepIndex = 3;
        else if (progressPercent < 96) currentStepIndex = 4;
        else currentStepIndex = 5;
        invalidate();
    }

    public void startAnimationLoop() {
        stopAnimationLoop();
        loopAnimator = ValueAnimator.ofFloat(0f, 1f);
        loopAnimator.setDuration(1800);
        loopAnimator.setRepeatCount(ValueAnimator.INFINITE);
        loopAnimator.setInterpolator(new LinearInterpolator());
        loopAnimator.addUpdateListener(animation -> {
            animPhase = (float) animation.getAnimatedValue();
            continuousTime += 0.032f;
            advancePhysics();
            invalidate();
        });
        loopAnimator.start();
    }

    public void stopAnimationLoop() {
        if (loopAnimator != null) {
            loopAnimator.cancel();
            loopAnimator = null;
        }
    }

    private void advancePhysics() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        float cx = w / 2f;
        float cy = h * 0.41f;
        for (int i = 0; i < sparks.size(); i++) {
            SparkParticle sp = sparks.get(i);
            sp.x += sp.vx;
            sp.y += sp.vy;
            sp.angle += sp.orbitSpeed;
            sp.alpha -= 0.016f;
            if (sp.alpha <= 0.05f) {
                resetSpark(sp, cx, cy, i, sparks.size());
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimationLoop();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float cx = w / 2f;
        float cy = h * 0.40f;

        // 1. Deep Atmospheric Background
        bgPaint.setShader(new LinearGradient(
                0, 0, 0, h,
                new int[]{themeBgTop, themeBgMid, themeBgTop},
                new float[]{0f, 0.52f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawRect(0, 0, w, h, bgPaint);

        // 2. Engine-Specific Background Layer
        drawEngineBackgroundLayer(canvas, w, h, cx, cy, density);

        // 3. Top Header Banner
        subTextPaint.setTextSize(10.5f * density);
        subTextPaint.setColor(themePrimary);
        subTextPaint.setLetterSpacing(0.08f);
        canvas.drawText(activeHeaderBanner, cx, h * 0.072f, subTextPaint);
        subTextPaint.setLetterSpacing(0f);

        textPaint.setTextSize(13.5f * density);
        textPaint.setColor(0xEEFFFFFF);
        canvas.drawText(sourceLang + "  ━━━▶  " + targetLang, cx, h * 0.118f, textPaint);

        float coreRadius = Math.min(w * 0.23f, 96f * density);
        float leftBound = w * 0.05f;
        float rightBound = w * 0.95f;

        // 4. Center Spectacle Engine (5 Distinct Engines)
        switch (activeEngineType) {
            case ConverterAnimationManager.ENGINE_CYBER_HEX_SHIELD:
                drawCyberHexShieldCenter(canvas, leftBound, rightBound, cx, cy, coreRadius, density);
                break;
            case ConverterAnimationManager.ENGINE_NEON_WARP_TUNNEL:
                drawNeonWarpTunnelCenter(canvas, leftBound, rightBound, cx, cy, coreRadius, density);
                break;
            case ConverterAnimationManager.ENGINE_PHOENIX_INFERNO:
                drawPhoenixInfernoCenter(canvas, leftBound, rightBound, cx, cy, coreRadius, density);
                break;
            case ConverterAnimationManager.ENGINE_QUANTUM_COLLIDER:
                drawQuantumColliderCenter(canvas, leftBound, rightBound, cx, cy, coreRadius, density);
                break;
            case ConverterAnimationManager.ENGINE_COSMIC_NEBULA:
            default:
                drawCosmicNebulaCenter(canvas, leftBound, rightBound, cx, cy, coreRadius, density);
                break;
        }

        // 5. Ambient Sparks
        for (SparkParticle sp : sparks) {
            particlePaint.setColor(sp.color);
            particlePaint.setAlpha((int) (sp.alpha * 220));
            canvas.drawCircle(sp.x, sp.y, sp.radius, particlePaint);
        }

        // 6. Bottom 6-Stage Conversion Pipeline HUD Card
        drawCompilerPipelineCard(canvas, w, h, cx, density);
    }

    private void drawEngineBackgroundLayer(Canvas canvas, int w, int h, float cx, float cy, float density) {
        gridPaint.setColor((themePrimary & 0x00FFFFFF) | 0x16000000);
        float gridSpacing = 32f * density;
        float gridShift = (animPhase * gridSpacing);
        for (float x = -gridSpacing + gridShift; x < w + gridSpacing; x += gridSpacing) {
            canvas.drawLine(x, 0, x, h, gridPaint);
        }
        for (float y = -gridSpacing + gridShift; y < h + gridSpacing; y += gridSpacing) {
            canvas.drawLine(0, y, w, y, gridPaint);
        }

        float pulseScale = 1f + 0.10f * (float) Math.sin(animPhase * Math.PI * 2);
        float auraRadius = Math.min(w, h) * 0.44f * pulseScale;
        glowPaint.setShader(new RadialGradient(
                cx, cy, Math.max(1f, auraRadius),
                new int[]{
                        (themePrimary & 0x00FFFFFF) | 0x44000000,
                        (themeSecondary & 0x00FFFFFF) | 0x22000000,
                        0x00050814
                },
                new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, auraRadius, glowPaint);
    }

    // =========================================================================
    // 1. COSMIC NEBULA & PULSAR VORTEX
    // =========================================================================
    private void drawCosmicNebulaCenter(Canvas canvas, float leftEdge, float rightEdge,
                                        float cx, float cy, float coreRadius, float density) {
        ringPaint.setStrokeWidth(1.2f * density);
        for (int r = 1; r <= 3; r++) {
            float orbitR = coreRadius * (0.6f + r * 0.45f);
            ringPaint.setColor((themePrimary & 0x00FFFFFF) | (0x22000000 / r));
            canvas.drawCircle(cx, cy, orbitR, ringPaint);
        }

        // 4 Spiral Galaxy Nebula Arms
        for (int arm = 0; arm < 4; arm++) {
            double armBaseAngle = (animPhase * Math.PI * 2.0) + arm * (Math.PI / 2.0);
            for (int k = 2; k <= 22; k++) {
                float dist = (k / 22f) * coreRadius * 1.85f;
                double angle = armBaseAngle + (k * 0.16);
                float px = cx + (float) (Math.cos(angle) * dist);
                float py = cy + (float) (Math.sin(angle) * dist);

                particlePaint.setColor(k % 2 == 0 ? themePrimary : themeSecondary);
                int alpha = Math.max(15, (int) (180 * (1f - (k / 24f))));
                particlePaint.setAlpha(alpha);
                float pRadius = (2.4f + (k % 4) * 1.1f) * density;
                canvas.drawCircle(px, py, pRadius, particlePaint);
            }
        }

        // Orbiting Celestial Star Clusters (8 bodies with starlight flares)
        for (int i = 0; i < 8; i++) {
            double starAngle = (continuousTime * (0.8 + i * 0.2)) + i * (Math.PI / 4.0);
            float starDist = coreRadius * (0.7f + (i % 3) * 0.45f);
            float sx = cx + (float) (Math.cos(starAngle) * starDist);
            float sy = cy + (float) (Math.sin(starAngle) * starDist);

            particlePaint.setColor(i % 2 == 0 ? themeAccent : Color.WHITE);
            particlePaint.setAlpha(240);
            canvas.drawCircle(sx, sy, 3.2f * density, particlePaint);

            laserPaint.setColor(particlePaint.getColor());
            laserPaint.setAlpha(160);
            laserPaint.setStrokeWidth(1.2f * density);
            float flareLen = 7f * density;
            canvas.drawLine(sx - flareLen, sy, sx + flareLen, sy, laserPaint);
            canvas.drawLine(sx, sy - flareLen, sx, sy + flareLen, laserPaint);
        }

        // Pulsar Shockwave Rings (Expanding outward)
        arcPaint.setStrokeWidth(2.5f * density);
        for (int w = 0; w < 3; w++) {
            float phaseOffset = (animPhase + w * 0.333f) % 1f;
            float waveR = coreRadius * (0.4f + phaseOffset * 1.4f);
            int waveAlpha = (int) (220 * (1f - phaseOffset));
            arcPaint.setColor(themePrimary);
            arcPaint.setAlpha(waveAlpha);
            canvas.drawCircle(cx, cy, waveR, arcPaint);
        }

        // Central Pulsar Core
        float pulseScale = 1f + 0.14f * (float) Math.sin(continuousTime * 5f);
        float pulseR = coreRadius * 0.46f * pulseScale;
        glowPaint.setShader(new RadialGradient(
                cx, cy, pulseR,
                new int[]{0xFFFFFFFF, themeSecondary, (themePrimary & 0x00FFFFFF) | 0x88000000, 0x00000000},
                new float[]{0f, 0.35f, 0.75f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, pulseR, glowPaint);

        drawCoreProgressReadout(canvas, cx, cy, coreRadius * 0.62f, "COSMIC PULSAR", density);
    }

    // =========================================================================
    // 2. CYBER HOLOGRAM HEX-SHIELD
    // =========================================================================
    private void drawCyberHexShieldCenter(Canvas canvas, float leftEdge, float rightEdge,
                                          float cx, float cy, float coreRadius, float density) {
        float hexR = coreRadius * 0.30f;
        float hDistX = hexR * 1.732f;
        float hDistY = hexR * 1.5f;

        float[][] hexCenters = new float[][]{
                {0, 0},
                {hDistX, 0}, {-hDistX, 0},
                {hDistX * 0.5f, hDistY}, {-hDistX * 0.5f, hDistY},
                {hDistX * 0.5f, -hDistY}, {-hDistX * 0.5f, -hDistY},
                {hDistX * 1.5f, hDistY}, {-hDistX * 1.5f, hDistY},
                {hDistX * 1.5f, -hDistY}, {-hDistX * 1.5f, -hDistY},
                {0, hDistY * 2f}, {0, -hDistY * 2f},
                {hDistX * 2f, 0}, {-hDistX * 2f, 0},
                {hDistX, hDistY * 2f}, {-hDistX, hDistY * 2f},
                {hDistX, -hDistY * 2f}, {-hDistX, -hDistY * 2f}
        };

        for (int i = 0; i < hexCenters.length; i++) {
            float hx = cx + hexCenters[i][0];
            float hy = cy + hexCenters[i][1];

            hexPath.reset();
            for (int k = 0; k < 6; k++) {
                double rad = Math.toRadians(k * 60 - 30);
                float px = hx + (float) (Math.cos(rad) * (hexR * 0.94f));
                float py = hy + (float) (Math.sin(rad) * (hexR * 0.94f));
                if (k == 0) hexPath.moveTo(px, py);
                else hexPath.lineTo(px, py);
            }
            hexPath.close();

            float pulse = (float) Math.sin(continuousTime * 3.5f + i * 0.6f);
            boolean active = pulse > 0.1f;

            panelBgPaint.setColor(active ? ((themePrimary & 0x00FFFFFF) | 0x40000000) : 0x14051020);
            canvas.drawPath(hexPath, panelBgPaint);

            ringPaint.setColor(active ? themePrimary : (themePrimary & 0x00FFFFFF) | 0x44000000);
            ringPaint.setStrokeWidth((active ? 2.0f : 1.0f) * density);
            canvas.drawPath(hexPath, ringPaint);

            if (active) {
                particlePaint.setColor(themeAccent);
                particlePaint.setAlpha(200);
                canvas.drawCircle(hx, hy, 2.2f * density, particlePaint);
            }
        }

        // 360-Degree Radar Scanner Sweep
        float sweepAngle = animPhase * 360f;
        double sweepRad = Math.toRadians(sweepAngle);
        float sweepLen = coreRadius * 1.55f;
        float sweepX = cx + (float) Math.cos(sweepRad) * sweepLen;
        float sweepY = cy + (float) Math.sin(sweepRad) * sweepLen;

        laserPaint.setColor(themePrimary);
        laserPaint.setStrokeWidth(2.2f * density);
        laserPaint.setAlpha(240);
        canvas.drawLine(cx, cy, sweepX, sweepY, laserPaint);

        tempRect.set(cx - sweepLen, cy - sweepLen, cx + sweepLen, cy + sweepLen);
        arcPaint.setStrokeWidth(sweepLen * 0.5f);
        arcPaint.setColor((themePrimary & 0x00FFFFFF) | 0x18000000);
        canvas.drawArc(tempRect, sweepAngle - 45f, 45f, false, arcPaint);

        // Tactical Reticle Brackets
        ringPaint.setStrokeWidth(1.6f * density);
        ringPaint.setColor(themeSecondary);
        float bracketDist = coreRadius * 1.45f;
        float bLen = 14f * density;
        canvas.drawLine(cx - bracketDist, cy - bracketDist, cx - bracketDist + bLen, cy - bracketDist, ringPaint);
        canvas.drawLine(cx - bracketDist, cy - bracketDist, cx - bracketDist, cy - bracketDist + bLen, ringPaint);
        canvas.drawLine(cx + bracketDist, cy - bracketDist, cx + bracketDist - bLen, cy - bracketDist, ringPaint);
        canvas.drawLine(cx + bracketDist, cy - bracketDist, cx + bracketDist, cy - bracketDist + bLen, ringPaint);
        canvas.drawLine(cx - bracketDist, cy + bracketDist, cx - bracketDist + bLen, cy + bracketDist, ringPaint);
        canvas.drawLine(cx - bracketDist, cy + bracketDist, cx - bracketDist, cy + bracketDist - bLen, ringPaint);
        canvas.drawLine(cx + bracketDist, cy + bracketDist, cx + bracketDist - bLen, cy + bracketDist, ringPaint);
        canvas.drawLine(cx + bracketDist, cy + bracketDist, cx + bracketDist, cy + bracketDist - bLen, ringPaint);

        drawCoreProgressReadout(canvas, cx, cy, coreRadius * 0.60f, "HEX-SHIELD", density);
    }

    // =========================================================================
    // 3. NEON VORTEX HYPERSPACE TUNNEL
    // =========================================================================
    private void drawNeonWarpTunnelCenter(Canvas canvas, float leftEdge, float rightEdge,
                                         float cx, float cy, float coreRadius, float density) {
        float maxDimension = Math.max(cx, cy) * 1.05f;

        for (int i = 0; i < 8; i++) {
            float z = ((animPhase * 1.3f) + i / 8f) % 1f;
            float scale = (float) Math.pow(z, 2.3);
            float r = coreRadius * 0.16f + maxDimension * scale;
            float rot = (continuousTime * 22f) + (z * 65f);

            int color = (i % 3 == 0) ? themePrimary : ((i % 3 == 1) ? themeSecondary : themeAccent);
            ringPaint.setColor(color);
            int alpha = Math.min(255, (int) (35 + 220 * z));
            ringPaint.setAlpha(alpha);
            ringPaint.setStrokeWidth((1.2f + 3.8f * z) * density);

            hexPath.reset();
            for (int k = 0; k < 8; k++) {
                double rad = Math.toRadians(k * 45 + rot);
                float px = cx + (float) (Math.cos(rad) * r);
                float py = cy + (float) (Math.sin(rad) * r * 0.88f);
                if (k == 0) hexPath.moveTo(px, py);
                else hexPath.lineTo(px, py);
            }
            hexPath.close();
            canvas.drawPath(hexPath, ringPaint);
        }

        laserPaint.setStrokeWidth(1.8f * density);
        for (int k = 0; k < 16; k++) {
            double angle = Math.toRadians(k * 22.5 + (animPhase * 45f));
            float startDist = coreRadius * (0.35f + (float) Math.sin(continuousTime * 3f + k) * 0.1f);
            float endDist = maxDimension * 0.95f;

            float x1 = cx + (float) Math.cos(angle) * startDist;
            float y1 = cy + (float) Math.sin(angle) * startDist * 0.88f;
            float x2 = cx + (float) Math.cos(angle) * endDist;
            float y2 = cy + (float) Math.sin(angle) * endDist * 0.88f;

            laserPaint.setColor(k % 2 == 0 ? themePrimary : themeSecondary);
            laserPaint.setAlpha(180);
            canvas.drawLine(x1, y1, x2, y2, laserPaint);
        }

        float coreGlowR = coreRadius * 0.38f;
        glowPaint.setShader(new RadialGradient(
                cx, cy, coreGlowR,
                new int[]{0xFFFFFFFF, themePrimary, (themeSecondary & 0x00FFFFFF) | 0x88000000, 0x00000000},
                new float[]{0f, 0.3f, 0.7f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, coreGlowR, glowPaint);

        drawCoreProgressReadout(canvas, cx, cy, coreRadius * 0.58f, "WARP TUNNEL", density);
    }

    // =========================================================================
    // 4. DRAGON FIRE & PHOENIX INFERNO
    // =========================================================================
    private void drawPhoenixInfernoCenter(Canvas canvas, float leftEdge, float rightEdge,
                                         float cx, float cy, float coreRadius, float density) {
        for (int i = 0; i < 12; i++) {
            double angle = Math.toRadians(i * 30 + (continuousTime * 15f));
            float flareLength = coreRadius * (0.85f + 0.35f * (float) Math.sin(continuousTime * 6f + i * 1.5f));
            float fx = cx + (float) Math.cos(angle) * flareLength;
            float fy = cy + (float) Math.sin(angle) * flareLength;

            laserPaint.setColor(i % 2 == 0 ? themePrimary : themeSecondary);
            laserPaint.setStrokeWidth(3.0f * density);
            laserPaint.setAlpha(200);
            canvas.drawLine(cx, cy, fx, fy, laserPaint);
        }

        streamPaint.setStrokeWidth(3.2f * density);
        float ribbonTop = cy - coreRadius * 1.45f;
        float ribbonBottom = cy + coreRadius * 1.45f;
        float ribbonSteps = 30;
        float dy = (ribbonBottom - ribbonTop) / ribbonSteps;

        hexPath.reset();
        for (int s = 0; s <= ribbonSteps; s++) {
            float y = ribbonBottom - s * dy;
            float x = cx + (float) Math.sin(continuousTime * 4.5f + s * 0.32f) * (coreRadius * 0.75f);
            if (s == 0) hexPath.moveTo(x, y);
            else hexPath.lineTo(x, y);
        }
        streamPaint.setColor(themePrimary);
        streamPaint.setAlpha(210);
        canvas.drawPath(hexPath, streamPaint);

        hexPath.reset();
        for (int s = 0; s <= ribbonSteps; s++) {
            float y = ribbonBottom - s * dy;
            float x = cx - (float) Math.sin(continuousTime * 4.5f + s * 0.32f) * (coreRadius * 0.75f);
            if (s == 0) hexPath.moveTo(x, y);
            else hexPath.lineTo(x, y);
        }
        streamPaint.setColor(themeSecondary);
        streamPaint.setAlpha(210);
        canvas.drawPath(hexPath, streamPaint);

        for (int i = 0; i < 28; i++) {
            float emberPhase = (animPhase + (i / 28f)) % 1f;
            float ey = ribbonBottom - (emberPhase * (ribbonBottom - ribbonTop + 40f * density));
            float drift = (float) Math.sin(continuousTime * 3f + i * 2f) * (coreRadius * 0.6f);
            float ex = cx + drift;

            particlePaint.setColor(i % 2 == 0 ? themeSecondary : themeAccent);
            int eAlpha = (int) (240 * (1f - emberPhase));
            particlePaint.setAlpha(Math.max(10, eAlpha));
            canvas.drawCircle(ex, ey, (1.8f + (i % 3) * 1.1f) * density, particlePaint);
        }

        float sunR = coreRadius * 0.52f;
        glowPaint.setShader(new RadialGradient(
                cx, cy, sunR,
                new int[]{0xFFFFFFFF, themeSecondary, themePrimary, 0x00FF1744},
                new float[]{0f, 0.35f, 0.75f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, sunR, glowPaint);

        ringPaint.setStrokeWidth(1.8f * density);
        ringPaint.setColor(themePrimary);
        ringPaint.setAlpha(180);
        float haloR = coreRadius * 1.18f;
        canvas.drawCircle(cx, cy, haloR, ringPaint);

        drawCoreProgressReadout(canvas, cx, cy, coreRadius * 0.60f, "PHOENIX INFERNO", density);
    }

    // =========================================================================
    // 5. QUANTUM PARTICLE COLLIDER
    // =========================================================================
    private void drawQuantumColliderCenter(Canvas canvas, float leftEdge, float rightEdge,
                                          float cx, float cy, float coreRadius, float density) {
        float outerRingR = coreRadius * 1.35f;
        float innerRingR = coreRadius * 0.82f;

        ringPaint.setStrokeWidth(2.2f * density);
        ringPaint.setColor(themePrimary);
        ringPaint.setAlpha(180);
        canvas.drawCircle(cx, cy, outerRingR, ringPaint);

        ringPaint.setStrokeWidth(1.8f * density);
        ringPaint.setColor(themeSecondary);
        ringPaint.setAlpha(180);
        canvas.drawCircle(cx, cy, innerRingR, ringPaint);

        for (int p = 0; p < 4; p++) {
            double oAngle = (animPhase * Math.PI * 2.0) + p * (Math.PI / 2.0);
            float opx = cx + (float) Math.cos(oAngle) * outerRingR;
            float opy = cy + (float) Math.sin(oAngle) * outerRingR;
            particlePaint.setColor(Color.WHITE);
            particlePaint.setAlpha(255);
            canvas.drawCircle(opx, opy, 4.2f * density, particlePaint);

            particlePaint.setColor(themePrimary);
            particlePaint.setAlpha(180);
            canvas.drawCircle(opx, opy, 7f * density, particlePaint);

            double iAngle = (-animPhase * Math.PI * 2.0) + p * (Math.PI / 2.0);
            float ipx = cx + (float) Math.cos(iAngle) * innerRingR;
            float ipy = cy + (float) Math.sin(iAngle) * innerRingR;
            particlePaint.setColor(Color.WHITE);
            particlePaint.setAlpha(255);
            canvas.drawCircle(ipx, ipy, 3.8f * density, particlePaint);
            particlePaint.setColor(themeSecondary);
            particlePaint.setAlpha(180);
            canvas.drawCircle(ipx, ipy, 6f * density, particlePaint);
        }

        streamPaint.setStrokeWidth(1.6f * density);
        streamPaint.setColor((themeAccent & 0x00FFFFFF) | 0x88000000);
        hexPath.reset();
        hexPath.moveTo(cx - outerRingR, cy - outerRingR * 0.4f);
        hexPath.cubicTo(cx - outerRingR * 0.5f, cy - outerRingR * 1.5f,
                cx + outerRingR * 0.5f, cy - outerRingR * 1.5f,
                cx + outerRingR, cy - outerRingR * 0.4f);
        canvas.drawPath(hexPath, streamPaint);

        hexPath.reset();
        hexPath.moveTo(cx - outerRingR, cy + outerRingR * 0.4f);
        hexPath.cubicTo(cx - outerRingR * 0.5f, cy + outerRingR * 1.5f,
                cx + outerRingR * 0.5f, cy + outerRingR * 1.5f,
                cx + outerRingR, cy + outerRingR * 0.4f);
        canvas.drawPath(hexPath, streamPaint);

        float pulse = (float) Math.abs(Math.sin(continuousTime * 6f));
        float flashR = coreRadius * (0.35f + pulse * 0.45f);
        glowPaint.setShader(new RadialGradient(
                cx, cy, flashR,
                new int[]{0xFFFFFFFF, themeAccent, themePrimary, 0x00000000},
                new float[]{0f, 0.28f, 0.65f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, flashR, glowPaint);

        laserPaint.setStrokeWidth(1.6f * density);
        for (int k = 0; k < 12; k++) {
            double rAngle = Math.toRadians(k * 30 + (continuousTime * 40f));
            float rLen = coreRadius * (0.55f + 0.35f * (float) Math.sin(continuousTime * 8f + k));
            float rx = cx + (float) Math.cos(rAngle) * rLen;
            float ry = cy + (float) Math.sin(rAngle) * rLen;
            laserPaint.setColor(k % 2 == 0 ? themeAccent : Color.WHITE);
            laserPaint.setAlpha((int) (230 * pulse));
            canvas.drawLine(cx, cy, rx, ry, laserPaint);
        }

        drawCoreProgressReadout(canvas, cx, cy, coreRadius * 0.60f, "QUANTUM COLLIDER", density);
    }

    // =========================================================================
    // SHARED HELPER: CENTRAL PROGRESS SHIELD READOUT
    // =========================================================================
    private void drawCoreProgressReadout(Canvas canvas, float cx, float cy, float shieldRadius,
                                         String subtitle, float density) {
        coreInnerRect.set(cx - shieldRadius * 1.16f, cy - shieldRadius * 1.16f,
                cx + shieldRadius * 1.16f, cy + shieldRadius * 1.16f);
        arcPaint.setStrokeWidth(6.5f * density);
        arcPaint.setShader(new LinearGradient(
                coreInnerRect.left, coreInnerRect.top,
                coreInnerRect.right, coreInnerRect.bottom,
                new int[]{themePrimary, themeSecondary, themeAccent},
                null,
                Shader.TileMode.CLAMP
        ));
        float sweepAngle = (progress / 100f) * 360f;
        canvas.drawArc(coreInnerRect, -90f, sweepAngle, false, arcPaint);
        arcPaint.setShader(null);

        panelBgPaint.setColor(0xEE070C1D);
        canvas.drawCircle(cx, cy, shieldRadius, panelBgPaint);

        percentPaint.setTextSize(19.5f * density);
        percentPaint.setColor(progress >= 100 ? themeAccent : Color.WHITE);
        canvas.drawText(progress + "%", cx, cy + 3.5f * density, percentPaint);

        subTextPaint.setTextSize(7.8f * density);
        subTextPaint.setColor(progress >= 100 ? themeAccent : themePrimary);
        canvas.drawText(progress >= 100 ? "VERIFIED ✓" : subtitle, cx, cy + 17.5f * density, subTextPaint);
    }

    private void drawCompilerPipelineCard(Canvas canvas, int w, int h, float cx, float density) {
        float cardMarginX = Math.max(14f * density, w * 0.045f);
        float cardTop = h * 0.68f;
        float cardBottom = Math.min(h - 10f * density, cardTop + 144f * density);
        pipelineCardRect.set(cardMarginX, cardTop, w - cardMarginX, cardBottom);

        panelBgPaint.setColor(0xE80A1126);
        canvas.drawRoundRect(pipelineCardRect, 15f * density, 15f * density, panelBgPaint);

        panelStrokePaint.setStrokeWidth(1.8f * density);
        panelStrokePaint.setShader(new LinearGradient(
                pipelineCardRect.left, pipelineCardRect.top,
                pipelineCardRect.right, pipelineCardRect.bottom,
                (themePrimary & 0x00FFFFFF) | 0xAA000000,
                (themeSecondary & 0x00FFFFFF) | 0xAA000000,
                Shader.TileMode.CLAMP
        ));
        canvas.drawRoundRect(pipelineCardRect, 15f * density, 15f * density, panelStrokePaint);
        panelStrokePaint.setShader(null);

        textPaint.setTextSize(13.5f * density);
        textPaint.setColor(progress >= 100 ? themeAccent : themePrimary);
        canvas.drawText(currentStepText, cx, pipelineCardRect.top + 24f * density, textPaint);

        int stepCount = STEP_SHORT_LABELS.length;
        float nodeStartX = pipelineCardRect.left + 24f * density;
        float nodeEndX = pipelineCardRect.right - 24f * density;
        float stepSpan = (nodeEndX - nodeStartX) / (stepCount - 1);
        float nodeY = pipelineCardRect.top + 54f * density;

        stepNodePaint.setStyle(Paint.Style.STROKE);
        stepNodePaint.setStrokeWidth(2.2f * density);
        stepNodePaint.setColor(0x33FFFFFF);
        canvas.drawLine(nodeStartX, nodeY, nodeEndX, nodeY, stepNodePaint);

        float activeEndX = nodeStartX + stepSpan * currentStepIndex;
        stepNodePaint.setColor(themePrimary);
        canvas.drawLine(nodeStartX, nodeY, activeEndX, nodeY, stepNodePaint);

        badgeTextPaint.setTextSize(7.8f * density);
        for (int i = 0; i < stepCount; i++) {
            float nx = nodeStartX + i * stepSpan;
            boolean completed = i < currentStepIndex || progress >= 100;
            boolean active = (i == currentStepIndex) && progress < 100;

            if (active) {
                stepNodePaint.setStyle(Paint.Style.FILL);
                stepNodePaint.setColor((themeSecondary & 0x00FFFFFF) | 0x44000000);
                canvas.drawCircle(nx, nodeY, 10.5f * density, stepNodePaint);
            }

            stepNodePaint.setStyle(Paint.Style.FILL);
            if (completed) {
                stepNodePaint.setColor(themeAccent);
            } else if (active) {
                stepNodePaint.setColor(themeSecondary);
            } else {
                stepNodePaint.setColor(0xFF1E2949);
            }
            canvas.drawCircle(nx, nodeY, 6f * density, stepNodePaint);

            badgeTextPaint.setColor(completed ? themeAccent : (active ? 0xFFFFFFFF : 0x77FFFFFF));
            canvas.drawText(STEP_SHORT_LABELS[i], nx, nodeY + 17.5f * density, badgeTextPaint);
        }

        float barMargin = 20f * density;
        float barTop = pipelineCardRect.bottom - 31f * density;
        float barBottom = barTop + 8.5f * density;
        progressTrackRect.set(
                pipelineCardRect.left + barMargin,
                barTop,
                pipelineCardRect.right - barMargin,
                barBottom
        );
        panelBgPaint.setColor(0xFF18223F);
        canvas.drawRoundRect(progressTrackRect, 6f * density, 6f * density, panelBgPaint);

        float fillW = progressTrackRect.width() * (progress / 100f);
        if (fillW > 2f) {
            progressFillRect.set(
                    progressTrackRect.left,
                    barTop,
                    progressTrackRect.left + fillW,
                    barBottom
            );
            glowPaint.setShader(new LinearGradient(
                    progressFillRect.left, barTop,
                    progressFillRect.right, barBottom,
                    new int[]{themePrimary, themeSecondary, themeAccent},
                    null,
                    Shader.TileMode.CLAMP
            ));
            canvas.drawRoundRect(progressFillRect, 6f * density, 6f * density, glowPaint);

            particlePaint.setColor(Color.WHITE);
            particlePaint.setAlpha(240);
            canvas.drawCircle(progressFillRect.right, (barTop + barBottom) * 0.5f, 5f * density, particlePaint);
        }

        subTextPaint.setTextSize(8.2f * density);
        subTextPaint.setColor(0xAAFFFFFF);
        String telemetry = "STYLE: " + activeStyleTitle.toUpperCase() + "  •  STEP " + (currentStepIndex + 1) + "/6";
        canvas.drawText(telemetry, cx, pipelineCardRect.bottom - 9f * density, subTextPaint);
    }
}
