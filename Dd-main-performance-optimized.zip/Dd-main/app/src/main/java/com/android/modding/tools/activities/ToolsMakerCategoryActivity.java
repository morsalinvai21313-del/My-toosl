package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.SocialButtonAnimationHelper;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ToolsMakerCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_tools_maker);

        GlobalTouchParticleManager.attach(this);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_category_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_category_about).setOnClickListener(v -> {
            com.android.modding.tools.dialogs.MorsalinDialogHelper.showAboutDialog(this);
        });

        // Social Links with smooth micro-animation
        SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // 5 Dedicated Toast Maker Tools matching screenshot
        View btnSimpleToast = findViewById(R.id.btn_tool_simple_toast);
        if (btnSimpleToast != null) {
            btnSimpleToast.setOnClickListener(v -> launchTool(SimpleSmaliToastActivity.class));
        }

        View btnBase64Toast = findViewById(R.id.btn_tool_base64_toast);
        if (btnBase64Toast != null) {
            btnBase64Toast.setOnClickListener(v -> launchTool(Base64SmaliToastActivity.class));
        }

        View btnColorfulToast = findViewById(R.id.btn_tool_colorful_toast);
        if (btnColorfulToast != null) {
            btnColorfulToast.setOnClickListener(v -> launchTool(ColorfulToastActivity.class));
        }

        View btnAnimatedToast = findViewById(R.id.btn_tool_animated_toast);
        if (btnAnimatedToast != null) {
            btnAnimatedToast.setOnClickListener(v -> launchTool(AnimatedToastActivity.class));
        }

        View btnImageToast = findViewById(R.id.btn_tool_image_toast);
        if (btnImageToast != null) {
            btnImageToast.setOnClickListener(v -> launchTool(ImageToastActivity.class));
        }
    }

    private void launchTool(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
