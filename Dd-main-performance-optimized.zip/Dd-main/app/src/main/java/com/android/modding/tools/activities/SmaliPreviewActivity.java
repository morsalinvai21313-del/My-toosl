package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SmaliPreviewActivity extends AppCompatActivity {

    public static final String EXTRA_SMALI_CONTENT = "EXTRA_SMALI_CONTENT";
    public static final String EXTRA_SMALI_FILE_NAME = "EXTRA_SMALI_FILE_NAME";

    private String smaliContent = "";
    private String smaliFileName = "Output.smali";

    private TextView tvTitle;
    private TextView tvLineNumbers;
    private EditText etCodeBody;
    private EditText etSearch;
    private TextView tvMatchCount;
    private ScrollView scrollVertical;

    private final List<Integer> matchLineIndices = new ArrayList<>();
    private int currentMatchIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smali_preview);

        GlobalTouchParticleManager.attach(this);

        smaliContent = getIntent().getStringExtra(EXTRA_SMALI_CONTENT);
        if (smaliContent == null) smaliContent = "";
        smaliFileName = getIntent().getStringExtra(EXTRA_SMALI_FILE_NAME);
        if (smaliFileName == null || smaliFileName.isEmpty()) smaliFileName = "Output.smali";

        initViews();
        populateContent();
    }

    private void initViews() {
        findViewById(R.id.btn_smali_preview_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        tvTitle = findViewById(R.id.tv_smali_preview_title);
        tvTitle.setText(smaliFileName);

        tvLineNumbers = findViewById(R.id.tv_smali_line_numbers);
        etCodeBody = findViewById(R.id.et_smali_code_body);
        etSearch = findViewById(R.id.et_smali_search);
        tvMatchCount = findViewById(R.id.tv_smali_match_count);
        scrollVertical = findViewById(R.id.scroll_smali_vertical);

        findViewById(R.id.btn_smali_preview_copy).setOnClickListener(v -> copyToClipboard());
        findViewById(R.id.btn_smali_preview_share).setOnClickListener(v -> shareSmaliContent());
        findViewById(R.id.btn_smali_select_all).setOnClickListener(v -> etCodeBody.selectAll());

        findViewById(R.id.btn_smali_prev).setOnClickListener(v -> navigateMatch(false));
        findViewById(R.id.btn_smali_next).setOnClickListener(v -> navigateMatch(true));

        // Quick Search Filters
        setQuickFilter(R.id.chip_search_method, ".method");
        setQuickFilter(R.id.chip_search_class, ".class");
        setQuickFilter(R.id.chip_search_invoke, "invoke");
        setQuickFilter(R.id.chip_search_const, "const");
        setQuickFilter(R.id.chip_search_return, "return");
        setQuickFilter(R.id.chip_search_new_instance, "new-instance");

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int count, int after) {
                performSearch(s != null ? s.toString().trim() : "");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setQuickFilter(int buttonId, String query) {
        Button btn = findViewById(buttonId);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                etSearch.setText(query);
                etSearch.setSelection(query.length());
            });
        }
    }

    private void populateContent() {
        etCodeBody.setText(smaliContent);
        SyntaxHighlighter.applyHighlighting(etCodeBody.getText(), null);

        // Generate line numbers
        String[] lines = smaliContent.split("\n", -1);
        int totalLines = Math.max(1, lines.length);
        StringBuilder numSb = new StringBuilder();
        for (int i = 1; i <= totalLines; i++) {
            numSb.append(i).append("\n");
        }
        tvLineNumbers.setText(numSb.toString());
    }

    private void performSearch(String query) {
        matchLineIndices.clear();
        currentMatchIndex = -1;

        if (query.isEmpty()) {
            tvMatchCount.setText("0 matches");
            SyntaxHighlighter.applyHighlighting(etCodeBody.getText(), null);
            return;
        }

        SyntaxHighlighter.applyHighlighting(etCodeBody.getText(), query);

        String[] lines = smaliContent.split("\n", -1);
        String qLower = query.toLowerCase();
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].toLowerCase().contains(qLower)) {
                matchLineIndices.add(i);
            }
        }

        int count = matchLineIndices.size();
        tvMatchCount.setText(count + (count == 1 ? " match" : " matches"));

        if (count > 0) {
            currentMatchIndex = 0;
            scrollToLine(matchLineIndices.get(0));
        }
    }

    private void navigateMatch(boolean next) {
        if (matchLineIndices.isEmpty()) return;
        if (next) {
            currentMatchIndex = (currentMatchIndex + 1) % matchLineIndices.size();
        } else {
            currentMatchIndex = (currentMatchIndex - 1 + matchLineIndices.size()) % matchLineIndices.size();
        }
        int line = matchLineIndices.get(currentMatchIndex);
        tvMatchCount.setText((currentMatchIndex + 1) + "/" + matchLineIndices.size() + " matches");
        scrollToLine(line);
    }

    private void scrollToLine(int lineIndex) {
        int lineHeight = etCodeBody.getLineHeight();
        if (lineHeight <= 0) lineHeight = 40;
        int targetY = Math.max(0, (lineIndex * lineHeight) - 120);
        scrollVertical.smoothScrollTo(0, targetY);
    }

    private void copyToClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("smali", smaliContent));
            MorsalinToast.show(this, R.drawable.ic_content_copy, "Copied to Clipboard",
                    smaliFileName + " copied successfully (" + smaliContent.length() + " chars)");
        }
    }

    private void shareSmaliContent() {
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, smaliFileName);
        sendIntent.putExtra(Intent.EXTRA_TEXT, smaliContent);
        startActivity(Intent.createChooser(sendIntent, "Share Smali via"));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
