package com.android.modding.tools.dialogs;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.AnimatedAvatarBorderView;
import com.android.modding.tools.helpers.MovieCreditsTickerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MorsalinDialogHelper {

    private static final String URL_TELEGRAM_MORSALIN = "https://t.me/anonymous_modder_king";
    private static final String URL_TELEGRAM_SANNY = "https://t.me/anonymous_modder_king";
    private static final String URL_YOUTUBE = "https://youtube.com/@anonymous_modder_king";
    private static final String URL_TELEGRAM_CHANNEL = "https://t.me/anonymous_modder_king";
    private static final String URL_TELEGRAM_DISCUSS = "https://t.me/anonymous_modder_king";

    public interface OnConfirmedListener {
        void onConfirmed();
    }

    public static void showResetDialog(Context context, String title, String message, OnConfirmedListener listener) {
        if (context == null) return;
        Dialog dialog = new Dialog(context, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_custom_confirm);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        ImageView ivIcon = dialog.findViewById(R.id.iv_dialog_icon);
        TextView tvTitle = dialog.findViewById(R.id.tv_dialog_title);
        TextView tvMsg = dialog.findViewById(R.id.tv_dialog_message);
        Button btnCancel = dialog.findViewById(R.id.btn_dialog_cancel);
        Button btnConfirm = dialog.findViewById(R.id.btn_dialog_confirm);

        ivIcon.setImageResource(R.drawable.ic_refresh);
        if (title != null) tvTitle.setText(title);
        if (message != null) tvMsg.setText(message);
        btnConfirm.setText("Reset Now");

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnConfirm.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) {
                listener.onConfirmed();
            }
        });

        dialog.show();
    }

    /**
     * Shows the floating modal About Dialog styled exactly as requested in the screenshot:
     * - Floating neon cyan bordered card
     * - Two avatars with rotating cyber rings & auto vertical slide slideshows (3 photos each)
     * - Two developer info cards for MX MORSALIN and DJ SANNY
     * - Individual TELEGRAM buttons
     * - Continuous auto-scrolling credits ticker
     * - CHANNEL & DISCUSS buttons
     * - CLOSE button
     */
    public static void showAboutDialog(Context context) {
        if (context == null) return;

        Dialog dialog = new Dialog(context, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_about_morsalin);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.85);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        // Title Lighting Text Animation
        TextView tvTitle = dialog.findViewById(R.id.tv_about_dialog_title);
        if (tvTitle != null) {
            com.android.modding.tools.helpers.LightingTextHelper.attach(tvTitle);
        }

        // Left Avatar (MX MORSALIN with 3 alternating photos)
        AnimatedAvatarBorderView avatarMorsalin = dialog.findViewById(R.id.dialog_avatar_morsalin);
        if (avatarMorsalin != null) {
            avatarMorsalin.setAvatarList(new int[]{
                    R.drawable.img_avatar_morsalin,
                    R.drawable.avatar_morsalin_cyber_1790834216696,
                    R.drawable.avatar_morsalin_neon_1790834232712
            }, 0xFF00E5FF, 0xFF0096C7, 0xFF48CAE4);
        }

        // Right Avatar (DJ SANNY with 3 alternating photos)
        AnimatedAvatarBorderView avatarSanny = dialog.findViewById(R.id.dialog_avatar_sanny);
        if (avatarSanny != null) {
            avatarSanny.setAvatarList(new int[]{
                    R.drawable.img_avatar_sanny,
                    R.drawable.avatar_sanny_dj_1790834248190,
                    R.drawable.avatar_sanny_modder_1790834263619
            }, 0xFF00E5FF, 0xFF0096C7, 0xFF48CAE4);
        }

        // Auto-scrolling movie credits ticker
        MovieCreditsTickerView ticker = dialog.findViewById(R.id.dialog_credits_ticker);
        if (ticker != null) {
            ticker.setCreditLines(new String[]{
                    "Special thanks & mentorship of DJ SANNY.",
                    "His profound insights, creative ideas,",
                    "and constant guidance were the sparks",
                    "that ignited many of the features",
                    "you see today. This app is as much",
                    "a testament to his collaborative spirit",
                    "as it is to my coding efforts.",
                    "",
                    "★ MX MORSALIN & DJ SANNY ★",
                    "Android Modding & Creative Studio",
                    "All Rights Reserved 2025"
            });
        }

        // Social Buttons
        Button btnTelegramMorsalin = dialog.findViewById(R.id.btn_about_telegram_morsalin);
        if (btnTelegramMorsalin != null) {
            btnTelegramMorsalin.setOnClickListener(v -> openUrl(context, URL_TELEGRAM_MORSALIN));
        }

        Button btnYoutubeSanny = dialog.findViewById(R.id.btn_about_youtube_sanny);
        if (btnYoutubeSanny != null) {
            btnYoutubeSanny.setOnClickListener(v -> openUrl(context, URL_YOUTUBE));
        }

        Button btnChannel = dialog.findViewById(R.id.btn_about_channel);
        if (btnChannel != null) {
            btnChannel.setOnClickListener(v -> openUrl(context, URL_TELEGRAM_CHANNEL));
        }

        Button btnDiscuss = dialog.findViewById(R.id.btn_about_discuss);
        if (btnDiscuss != null) {
            btnDiscuss.setOnClickListener(v -> openUrl(context, URL_TELEGRAM_DISCUSS));
        }

        Button btnClose = dialog.findViewById(R.id.btn_about_close);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    public static void showLightingTextDialog(Context context, Runnable onDismissCallback) {
        if (context == null) return;
        Dialog dialog = new Dialog(context, R.style.Theme_MyApplication_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_lighting_text_anim);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.92);
            dialog.getWindow().setLayout(w, LinearLayout.LayoutParams.WRAP_CONTENT);
        }

        com.android.modding.tools.helpers.LightingTextView previewText = dialog.findViewById(R.id.preview_lighting_text);
        androidx.appcompat.widget.SwitchCompat switchToggle = dialog.findViewById(R.id.switch_lighting_text_toggle);
        LinearLayout layoutItems = dialog.findViewById(R.id.layout_lighting_text_items);
        Button btnClose = dialog.findViewById(R.id.btn_close_lighting_text_dialog);

        boolean isEnabled = com.android.modding.tools.helpers.LightingTextAnimationManager.isEnabled(context);
        int currentSelected = com.android.modding.tools.helpers.LightingTextAnimationManager.getSavedStyle(context);

        if (switchToggle != null) {
            switchToggle.setChecked(isEnabled);
            switchToggle.setOnCheckedChangeListener((btn, checked) -> {
                com.android.modding.tools.helpers.LightingTextAnimationManager.setEnabled(context, checked);
                if (previewText != null) {
                    previewText.setPreviewStyle(checked ? com.android.modding.tools.helpers.LightingTextAnimationManager.getSavedStyle(context) : -1);
                }
                showToast(context, R.drawable.ic_code_convert,
                        "Lighting Text Effect", checked ? "Lighting Text: Enabled" : "Lighting Text: Disabled");
            });
        }

        if (previewText != null) {
            previewText.setPreviewStyle(isEnabled ? currentSelected : -1);
        }

        float density = context.getResources().getDisplayMetrics().density;
        int dp6 = (int) (6 * density);
        int dp10 = (int) (10 * density);
        int dp11 = (int) (11 * density);
        int dp14 = (int) (14 * density);

        for (int i = 0; i < com.android.modding.tools.helpers.LightingTextAnimationManager.TOTAL_STYLES; i++) {
            final int styleIdx = i;
            String styleName = com.android.modding.tools.helpers.LightingTextAnimationManager.getStyleName(i);
            boolean isSelected = (styleIdx == currentSelected);

            LinearLayout card = new LinearLayout(context);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.setBackgroundResource(R.drawable.morsalin_button_bg);
            card.setClickable(true);
            card.setFocusable(true);
            card.setPadding(dp14, dp10, dp14, dp10);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp6);
            card.setLayoutParams(lp);

            int[] colors = com.android.modding.tools.helpers.LightingTextAnimationManager.getColorsForStyle(styleIdx);
            for (int k = 0; k < Math.min(3, colors.length); k++) {
                View dot = new View(context);
                android.graphics.drawable.GradientDrawable dotDrawable = new android.graphics.drawable.GradientDrawable();
                dotDrawable.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                dotDrawable.setColor(colors[k]);
                dot.setBackground(dotDrawable);
                LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp11, dp11);
                dotLp.setMargins(0, 0, (int)(5 * density), 0);
                dot.setLayoutParams(dotLp);
                card.addView(dot);
            }

            TextView tv = new TextView(context);
            tv.setText(styleName);
            tv.setTextSize(13.5f);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, isSelected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            card.addView(tv);

            TextView tvBadge = new TextView(context);
            tvBadge.setText(isSelected ? "✓ ACTIVE" : "SELECT");
            tvBadge.setTextSize(11f);
            tvBadge.setTypeface(null, android.graphics.Typeface.BOLD);
            tvBadge.setTextColor(isSelected ? Color.parseColor("#00E5FF") : Color.WHITE);
            tvBadge.setBackgroundResource(R.drawable.dialog_step_button_bg);
            tvBadge.setPadding(dp10, (int)(3 * density), dp10, (int)(3 * density));
            card.addView(tvBadge);

            card.setOnClickListener(v -> {
                com.android.modding.tools.helpers.LightingTextAnimationManager.setSavedStyle(context, styleIdx);
                com.android.modding.tools.helpers.LightingTextAnimationManager.setEnabled(context, true);
                if (switchToggle != null) switchToggle.setChecked(true);
                if (previewText != null) previewText.setPreviewStyle(styleIdx);
                dialog.dismiss();
                if (onDismissCallback != null) onDismissCallback.run();
                showToast(context, R.drawable.ic_code_convert,
                        "Lighting Text Style Applied", styleName);
            });

            layoutItems.addView(card);
        }

        if (btnClose != null) {
            btnClose.setOnClickListener(v -> {
                dialog.dismiss();
                if (onDismissCallback != null) onDismissCallback.run();
            });
        }
        dialog.setOnDismissListener(d -> {
            if (onDismissCallback != null) onDismissCallback.run();
        });
        dialog.show();
    }

    private static void showToast(Context context, int iconRes, String title, String msg) {
        if (context instanceof Activity) {
            com.android.modding.tools.helpers.MorsalinToast.show((Activity) context, iconRes, title, msg);
        } else if (context != null) {
            Toast.makeText(context, title + ": " + msg, Toast.LENGTH_SHORT).show();
        }
    }

    private static void openUrl(Context context, String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }
}
