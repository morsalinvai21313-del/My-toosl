package com.android.modding.tools.helpers;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

public class AnimatedDividerView extends View implements AnimatedDividerManager.OnDividerStyleChangeListener {

    private static final int COLOR_CYAN = 0xFF00E5FF;
    private static final int COLOR_CYAN_DEEP = 0xFF0096C7;
    private static final int COLOR_WHITE = 0xFFFFFFFF;
    private static final int COLOR_CYAN_DIM = 0x2400E5FF;

    private int previewStyle = -1; // -1 means use global style from manager
    private float animProgress = 0f;
    private ValueAnimator animator;

    private Paint baseRailPaint;
    private Paint primaryPaint;
    private Paint glowPaint;
    private Paint particlePaint;
    private Paint highlightPaint;
    private Path dynamicPath;
    private final RectF tempRect = new RectF();

    private float density = 1f;
    private boolean isAttached = false;
    private final Random random = new Random(42);

    public AnimatedDividerView(Context context) {
        super(context);
        init();
    }

    public AnimatedDividerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AnimatedDividerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        baseRailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        baseRailPaint.setStyle(Paint.Style.STROKE);
        baseRailPaint.setStrokeWidth(1.2f * density);
        baseRailPaint.setColor(COLOR_CYAN_DIM);
        baseRailPaint.setStrokeCap(Paint.Cap.ROUND);

        primaryPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        primaryPaint.setStyle(Paint.Style.STROKE);
        primaryPaint.setStrokeWidth(2.2f * density);
        primaryPaint.setColor(COLOR_CYAN);
        primaryPaint.setStrokeCap(Paint.Cap.ROUND);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(4.8f * density);
        glowPaint.setColor(0x5500E5FF);
        glowPaint.setStrokeCap(Paint.Cap.ROUND);

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        particlePaint.setStyle(Paint.Style.FILL);

        highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        highlightPaint.setStyle(Paint.Style.FILL);
        highlightPaint.setColor(COLOR_WHITE);

        dynamicPath = new Path();

        setupAnimator();
    }

    private void setupAnimator() {
        if (animator != null) {
            animator.cancel();
        }
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1800);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.RESTART);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            animProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
    }

    public void setPreviewStyle(int style) {
        this.previewStyle = style;
        adjustAnimatorDurationForStyle(getActiveStyle());
        invalidate();
    }

    public int getActiveStyle() {
        if (previewStyle >= 0 && previewStyle < AnimatedDividerManager.TOTAL_STYLES) {
            return previewStyle;
        }
        return AnimatedDividerManager.getSavedStyle(getContext());
    }

    private void adjustAnimatorDurationForStyle(int style) {
        if (animator == null) return;
        long duration = 1800;
        switch (style) {
            case AnimatedDividerManager.STYLE_LIGHT_SWEEP_LTR:
                duration = 1800;
                break;
            case AnimatedDividerManager.STYLE_DUAL_INWARD_BEAMS:
                duration = 1900;
                break;
            case AnimatedDividerManager.STYLE_CENTER_GLOW:
                duration = 1600;
                break;
            case AnimatedDividerManager.STYLE_PLASMA_COMET:
                duration = 2000;
                break;
            case AnimatedDividerManager.STYLE_CYBER_GLITCH_SCAN:
                duration = 1500;
                break;
            case AnimatedDividerManager.STYLE_QUANTUM_RIPPLE:
                duration = 1700;
                break;
            case AnimatedDividerManager.STYLE_ELECTRIC_TESLA_ARC:
                duration = 1300;
                break;
            case AnimatedDividerManager.STYLE_DIGITAL_BINARY_STREAM:
                duration = 2200;
                break;
            case AnimatedDividerManager.STYLE_HYPERDRIVE_WARP:
                duration = 1600;
                break;
            case AnimatedDividerManager.STYLE_DUAL_PING_PONG:
                duration = 2100;
                break;
            case AnimatedDividerManager.STYLE_SUPERNOVA_LASER:
                duration = 1800;
                break;
            case AnimatedDividerManager.STYLE_AURORA_CYBER_RIBBON:
                duration = 2000;
                break;
            case AnimatedDividerManager.STYLE_BREATHING_STARLIGHT_RAIL:
                duration = 2200;
                break;
        }
        if (animator.getDuration() != duration) {
            animator.setDuration(duration);
        }
    }

    @Override
    public void onDividerStyleChanged(int newStyle) {
        if (previewStyle == -1) {
            adjustAnimatorDurationForStyle(newStyle);
            postInvalidate();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        isAttached = true;
        AnimatedDividerManager.registerListener(this);
        adjustAnimatorDurationForStyle(getActiveStyle());
        if (getVisibility() == VISIBLE && getWindowVisibility() == VISIBLE) {
            startAnimation();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        isAttached = false;
        AnimatedDividerManager.unregisterListener(this);
        stopAnimation();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateAnimationState();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateAnimationState();
    }

    private void updateAnimationState() {
        if (isAttached && getVisibility() == VISIBLE && getWindowVisibility() == VISIBLE) {
            startAnimation();
        } else {
            stopAnimation();
        }
    }

    private void startAnimation() {
        if (animator != null && !animator.isRunning()) {
            animator.start();
        }
    }

    private void stopAnimation() {
        if (animator != null && animator.isRunning()) {
            animator.cancel();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float centerY = h / 2f;
        int style = getActiveStyle();

        switch (style) {
            case AnimatedDividerManager.STYLE_LIGHT_SWEEP_LTR:
                drawLightSweep(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_DUAL_INWARD_BEAMS:
                drawDualInwardBeams(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_CENTER_GLOW:
                drawCenterGlow(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_PLASMA_COMET:
                drawPlasmaComet(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_CYBER_GLITCH_SCAN:
                drawCyberGlitchScan(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_QUANTUM_RIPPLE:
                drawQuantumRipple(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_ELECTRIC_TESLA_ARC:
                drawElectricTeslaArc(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_DIGITAL_BINARY_STREAM:
                drawDigitalBinaryStream(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_HYPERDRIVE_WARP:
                drawHyperdriveWarp(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_DUAL_PING_PONG:
                drawDualPingPong(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_SUPERNOVA_LASER:
                drawSupernovaLaser(canvas, w, centerY);
                break;
            case AnimatedDividerManager.STYLE_AURORA_CYBER_RIBBON:
                drawAuroraCyberRibbon(canvas, w, h, centerY);
                break;
            case AnimatedDividerManager.STYLE_BREATHING_STARLIGHT_RAIL:
            default:
                drawBreathingStarlightRail(canvas, w, centerY);
                break;
        }
    }

    /** 1. Light Sweep (Kept as requested) */
    private void drawLightSweep(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float beamLength = Math.max(width * 0.35f, 100f * density);
        float totalDist = width + beamLength * 2f;
        float cx = totalDist * animProgress - beamLength;

        float left = Math.max(0, cx - beamLength / 2f);
        float right = Math.min(width, cx + beamLength / 2f);

        if (right > left) {
            LinearGradient gradient = new LinearGradient(
                    cx - beamLength / 2f, centerY,
                    cx + beamLength / 2f, centerY,
                    new int[]{0x0000E5FF, 0x8800E5FF, COLOR_WHITE, 0x8800E5FF, 0x0000E5FF},
                    new float[]{0f, 0.3f, 0.5f, 0.7f, 1f},
                    Shader.TileMode.CLAMP);

            glowPaint.setShader(gradient);
            glowPaint.setStrokeWidth(5f * density);
            canvas.drawLine(left, centerY, right, centerY, glowPaint);

            primaryPaint.setShader(gradient);
            primaryPaint.setStrokeWidth(2.2f * density);
            canvas.drawLine(left, centerY, right, centerY, primaryPaint);

            glowPaint.setShader(null);
            primaryPaint.setShader(null);

            if (cx >= 0 && cx <= width) {
                highlightPaint.setColor(COLOR_WHITE);
                canvas.drawCircle(cx, centerY, 1.8f * density, highlightPaint);
            }
        }
    }

    /** 2. Dual Inward Beams (Kept #3 as requested) */
    private void drawDualInwardBeams(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float midX = width / 2f;
        float p = animProgress;
        float beamLength = width * 0.22f;

        float t = Math.min(p / 0.7f, 1f);
        float leftHead = midX * t;
        float rightHead = width - midX * t;

        LinearGradient gradLeft = new LinearGradient(
                leftHead - beamLength, centerY, leftHead, centerY,
                new int[]{0x0000E5FF, 0xAA00E5FF, COLOR_WHITE},
                new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP);
        primaryPaint.setShader(gradLeft);
        primaryPaint.setStrokeWidth(2.4f * density);
        canvas.drawLine(Math.max(0, leftHead - beamLength), centerY, leftHead, centerY, primaryPaint);

        LinearGradient gradRight = new LinearGradient(
                rightHead, centerY, rightHead + beamLength, centerY,
                new int[]{COLOR_WHITE, 0xAA00E5FF, 0x0000E5FF},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP);
        primaryPaint.setShader(gradRight);
        canvas.drawLine(rightHead, centerY, Math.min(width, rightHead + beamLength), centerY, primaryPaint);
        primaryPaint.setShader(null);

        if (p >= 0.65f) {
            float flareProgress = (p - 0.65f) / 0.35f;
            float radius = (6f + 20f * flareProgress) * density;
            int alpha = (int) (255 * (1f - flareProgress));
            if (alpha > 0) {
                RadialGradient flare = new RadialGradient(
                        midX, centerY, radius,
                        new int[]{Color.argb(alpha, 255, 255, 255), Color.argb(alpha / 2, 0, 229, 255), 0x0000E5FF},
                        new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP);
                particlePaint.setShader(flare);
                canvas.drawCircle(midX, centerY, radius, particlePaint);
                particlePaint.setShader(null);
            }
        }
    }

    /** 3. Center Glow (Kept #6 as requested) */
    private void drawCenterGlow(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float midX = width / 2f;
        float p = animProgress;
        float spread = (midX + 40f * density) * p;
        int alpha = (int) (255 * (1f - p * 0.85f));

        LinearGradient grad = new LinearGradient(
                midX - spread, centerY, midX + spread, centerY,
                new int[]{0x0000E5FF, Color.argb(alpha, 0, 229, 255), Color.argb(alpha, 255, 255, 255), Color.argb(alpha, 0, 229, 255), 0x0000E5FF},
                new float[]{0f, 0.4f, 0.5f, 0.6f, 1f},
                Shader.TileMode.CLAMP);

        glowPaint.setShader(grad);
        glowPaint.setStrokeWidth(5f * density);
        canvas.drawLine(Math.max(0, midX - spread), centerY, Math.min(width, midX + spread), centerY, glowPaint);

        primaryPaint.setShader(grad);
        primaryPaint.setStrokeWidth(2.4f * density);
        canvas.drawLine(Math.max(0, midX - spread), centerY, Math.min(width, midX + spread), centerY, primaryPaint);

        glowPaint.setShader(null);
        primaryPaint.setShader(null);
    }

    /** 4. Plasma Comet (Sparkling Tail) */
    private void drawPlasmaComet(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float trailLen = width * 0.45f;
        float headX = (width + trailLen * 1.5f) * animProgress - trailLen * 0.5f;

        // Long tapering gradient trail
        LinearGradient cometGrad = new LinearGradient(
                headX - trailLen, centerY, headX, centerY,
                new int[]{0x0000E5FF, 0x3300E5FF, 0xCC00E5FF, COLOR_WHITE},
                new float[]{0f, 0.4f, 0.85f, 1f}, Shader.TileMode.CLAMP);

        glowPaint.setShader(cometGrad);
        glowPaint.setStrokeWidth(5f * density);
        canvas.drawLine(Math.max(0, headX - trailLen), centerY, Math.min(width, headX), centerY, glowPaint);

        primaryPaint.setShader(cometGrad);
        primaryPaint.setStrokeWidth(2.5f * density);
        canvas.drawLine(Math.max(0, headX - trailLen), centerY, Math.min(width, headX), centerY, primaryPaint);
        glowPaint.setShader(null);
        primaryPaint.setShader(null);

        // Sparkling stardust droplets in the tail
        for (int i = 1; i <= 6; i++) {
            float dist = i * (trailLen / 7f);
            float px = headX - dist;
            if (px >= 0 && px <= width) {
                float sparkle = (float) Math.sin((animProgress * 15f) + i);
                float rad = (1.2f + 0.8f * sparkle) * density;
                int alpha = (int) (180 * (1f - (i / 7f)));
                particlePaint.setColor(Color.argb(alpha, 0, 229, 255));
                canvas.drawCircle(px, centerY, rad, particlePaint);
            }
        }

        // Brilliant comet nucleus
        if (headX >= 0 && headX <= width) {
            highlightPaint.setColor(COLOR_WHITE);
            canvas.drawCircle(headX, centerY, 3f * density, highlightPaint);
            particlePaint.setColor(0x8800E5FF);
            canvas.drawCircle(headX, centerY, 5.5f * density, particlePaint);
        }
    }

    /** 5. Cyber Glitch Scanner */
    private void drawCyberGlitchScan(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        // Stepped cyber scan bar
        float p = animProgress;
        float jitter = ((int)(p * 30)) % 2 == 0 ? 0f : (density * 1.5f);
        float barLen = width * 0.16f;
        float cx = width * p;

        float left = Math.max(0, cx - barLen / 2f);
        float right = Math.min(width, cx + barLen / 2f);

        LinearGradient scanGrad = new LinearGradient(
                left, centerY, right, centerY,
                new int[]{0x0000E5FF, COLOR_CYAN, COLOR_WHITE, COLOR_CYAN, 0x0000E5FF},
                new float[]{0f, 0.25f, 0.5f, 0.75f, 1f}, Shader.TileMode.CLAMP);

        glowPaint.setShader(scanGrad);
        glowPaint.setStrokeWidth(5f * density);
        canvas.drawLine(left, centerY + jitter, right, centerY + jitter, glowPaint);

        primaryPaint.setShader(scanGrad);
        primaryPaint.setStrokeWidth(2.6f * density);
        canvas.drawLine(left, centerY, right, centerY, primaryPaint);
        glowPaint.setShader(null);
        primaryPaint.setShader(null);

        // Secondary digital glitch echo
        if (p > 0.2f && p < 0.8f) {
            float echoX = cx - width * 0.12f;
            if (echoX >= 0 && echoX <= width) {
                primaryPaint.setColor(0x7700E5FF);
                primaryPaint.setStrokeWidth(1.8f * density);
                canvas.drawLine(Math.max(0, echoX - 10f * density), centerY - 1.5f * density,
                        Math.min(width, echoX + 10f * density), centerY - 1.5f * density, primaryPaint);
            }
        }
    }

    /** 6. Quantum Ripple (Drop Shockwave) */
    private void drawQuantumRipple(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float midX = width / 2f;
        float maxSpread = midX + 30f * density;

        // 3 expanding concentric ripple shockwaves
        for (int ring = 0; ring < 3; ring++) {
            float ringProgress = (animProgress + ring * 0.33f) % 1.0f;
            float spread = maxSpread * ringProgress;
            int alpha = (int) (220 * (1f - ringProgress));

            if (alpha > 0) {
                float left = Math.max(0, midX - spread);
                float right = Math.min(width, midX + spread);
                float waveLen = 22f * density;

                // Left ripple head
                LinearGradient gradL = new LinearGradient(
                        left, centerY, left + waveLen, centerY,
                        new int[]{Color.argb(alpha, 0, 229, 255), 0x0000E5FF},
                        null, Shader.TileMode.CLAMP);
                primaryPaint.setShader(gradL);
                primaryPaint.setStrokeWidth(2.2f * density);
                canvas.drawLine(left, centerY, Math.min(midX, left + waveLen), centerY, primaryPaint);

                // Right ripple head
                LinearGradient gradR = new LinearGradient(
                        right - waveLen, centerY, right, centerY,
                        new int[]{0x0000E5FF, Color.argb(alpha, 0, 229, 255)},
                        null, Shader.TileMode.CLAMP);
                primaryPaint.setShader(gradR);
                canvas.drawLine(Math.max(midX, right - waveLen), centerY, right, centerY, primaryPaint);
                primaryPaint.setShader(null);
            }
        }

        // Center drop origin dot
        highlightPaint.setColor(COLOR_WHITE);
        canvas.drawCircle(midX, centerY, 2.2f * density, highlightPaint);
    }

    /** 7. Electric Tesla Arc */
    private void drawElectricTeslaArc(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float arcLen = width * 0.32f;
        float startX = (width + arcLen) * animProgress - arcLen;
        float endX = startX + arcLen;

        dynamicPath.reset();
        int segments = 14;
        float segW = arcLen / segments;

        boolean started = false;
        for (int i = 0; i <= segments; i++) {
            float x = startX + i * segW;
            if (x < 0) x = 0;
            if (x > width) x = width;

            // Randomized high-frequency lightning jitter
            float jitterY = (i == 0 || i == segments) ? 0 :
                    (float) Math.sin((animProgress * 30f) + i * 2.3f) * (2.2f * density);

            float y = centerY + jitterY;
            if (!started) {
                dynamicPath.moveTo(x, y);
                started = true;
            } else {
                dynamicPath.lineTo(x, y);
            }
        }

        glowPaint.setColor(0x6600E5FF);
        glowPaint.setStrokeWidth(4.5f * density);
        canvas.drawPath(dynamicPath, glowPaint);

        primaryPaint.setColor(COLOR_WHITE);
        primaryPaint.setStrokeWidth(2.2f * density);
        canvas.drawPath(dynamicPath, primaryPaint);
    }

    /** 8. Digital Matrix Bit Stream */
    private void drawDigitalBinaryStream(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        int bitCount = 7;
        float spacing = width / (float) bitCount;

        for (int i = 0; i < bitCount; i++) {
            float bitX = (i * spacing + animProgress * width) % width;
            float bitW = (8f + (i % 3) * 6f) * density;
            float bitH = 2.4f * density;

            tempRect.set(bitX - bitW / 2f, centerY - bitH / 2f, bitX + bitW / 2f, centerY + bitH / 2f);

            // Glowing rectangular cyber bit
            particlePaint.setColor(i % 2 == 0 ? COLOR_CYAN : COLOR_WHITE);
            canvas.drawRoundRect(tempRect, 1.5f * density, 1.5f * density, particlePaint);

            // Subtle glow around bit
            tempRect.inset(-2f * density, -1.5f * density);
            particlePaint.setColor(0x3300E5FF);
            canvas.drawRoundRect(tempRect, 2.5f * density, 2.5f * density, particlePaint);
        }
    }

    /** 9. Hyperdrive Warp Streak */
    private void drawHyperdriveWarp(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        // Supersonic acceleration easing: p^2.5
        float p = (float) Math.pow(animProgress, 2.2);
        float streakLen = width * 0.45f;
        float cx = (width + streakLen * 2f) * p - streakLen;

        LinearGradient warpGrad = new LinearGradient(
                cx - streakLen, centerY, cx, centerY,
                new int[]{0x0000E5FF, 0x4400E5FF, COLOR_CYAN, COLOR_WHITE},
                new float[]{0f, 0.4f, 0.8f, 1f}, Shader.TileMode.CLAMP);

        glowPaint.setShader(warpGrad);
        glowPaint.setStrokeWidth(5.5f * density);
        canvas.drawLine(Math.max(0, cx - streakLen), centerY, Math.min(width, cx), centerY, glowPaint);

        primaryPaint.setShader(warpGrad);
        primaryPaint.setStrokeWidth(2.6f * density);
        canvas.drawLine(Math.max(0, cx - streakLen), centerY, Math.min(width, cx), centerY, primaryPaint);
        glowPaint.setShader(null);
        primaryPaint.setShader(null);

        if (cx >= 0 && cx <= width) {
            highlightPaint.setColor(COLOR_WHITE);
            canvas.drawCircle(cx, centerY, 3f * density, highlightPaint);
        }
    }

    /** 10. Dual Orb Ping-Pong */
    private void drawDualPingPong(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        // Smooth cosine harmonic oscillation
        float t1 = (float) (0.5 - 0.5 * Math.cos(animProgress * 2 * Math.PI));
        float t2 = 1.0f - t1;

        float x1 = width * t1;
        float x2 = width * t2;

        // Orb 1
        particlePaint.setColor(0x5500E5FF);
        canvas.drawCircle(x1, centerY, 5f * density, particlePaint);
        highlightPaint.setColor(COLOR_WHITE);
        canvas.drawCircle(x1, centerY, 2.2f * density, highlightPaint);

        // Orb 2
        particlePaint.setColor(0x5500B4D8);
        canvas.drawCircle(x2, centerY, 5f * density, particlePaint);
        canvas.drawCircle(x2, centerY, 2.2f * density, highlightPaint);

        // Flash when meeting in center
        float dist = Math.abs(x1 - x2);
        if (dist < 20f * density) {
            float flare = 1f - (dist / (20f * density));
            particlePaint.setColor(Color.argb((int)(200 * flare), 255, 255, 255));
            canvas.drawCircle((x1 + x2) / 2f, centerY, (4f + 6f * flare) * density, particlePaint);
        }
    }

    /** 11. Supernova Laser Burst */
    private void drawSupernovaLaser(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float midX = width / 2f;
        float p = animProgress;

        if (p < 0.35f) {
            // Charging phase at center
            float charge = p / 0.35f;
            float r = (3f + 4f * charge) * density;
            particlePaint.setColor(COLOR_CYAN);
            canvas.drawCircle(midX, centerY, r * 1.5f, particlePaint);
            highlightPaint.setColor(COLOR_WHITE);
            canvas.drawCircle(midX, centerY, r, highlightPaint);
        } else {
            // Explosive horizontal laser eruption to both sides
            float eruptProgress = (p - 0.35f) / 0.65f;
            float beamW = midX * eruptProgress;
            int alpha = (int) (255 * (1f - eruptProgress * 0.8f));

            LinearGradient burstGrad = new LinearGradient(
                    midX - beamW, centerY, midX + beamW, centerY,
                    new int[]{0x0000E5FF, Color.argb(alpha, 0, 229, 255), Color.argb(alpha, 255, 255, 255), Color.argb(alpha, 0, 229, 255), 0x0000E5FF},
                    new float[]{0f, 0.35f, 0.5f, 0.65f, 1f}, Shader.TileMode.CLAMP);

            glowPaint.setShader(burstGrad);
            glowPaint.setStrokeWidth(5.5f * density);
            canvas.drawLine(Math.max(0, midX - beamW), centerY, Math.min(width, midX + beamW), centerY, glowPaint);

            primaryPaint.setShader(burstGrad);
            primaryPaint.setStrokeWidth(2.8f * density);
            canvas.drawLine(Math.max(0, midX - beamW), centerY, Math.min(width, midX + beamW), centerY, primaryPaint);
            glowPaint.setShader(null);
            primaryPaint.setShader(null);
        }
    }

    /** 12. Aurora Cyber Ribbon */
    private void drawAuroraCyberRibbon(Canvas canvas, int width, int height, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        float amp = Math.min(2.5f * density, (height / 2f) - 1f);
        float wavelength = 85f * density;
        float phase = animProgress * 2f * (float) Math.PI;

        dynamicPath.reset();
        for (int x = 0; x <= width; x += 4) {
            float y = centerY + (float) Math.sin((x / wavelength) * 2f * Math.PI - phase) * amp;
            if (x == 0) dynamicPath.moveTo(x, y);
            else dynamicPath.lineTo(x, y);
        }

        LinearGradient ribbonGrad = new LinearGradient(
                0, centerY, width, centerY,
                new int[]{0x6600E5FF, 0xAA00B4D8, 0xEE00FFFF, 0xAA00B4D8, 0x6600E5FF},
                null, Shader.TileMode.REPEAT);

        glowPaint.setShader(ribbonGrad);
        glowPaint.setStrokeWidth(5f * density);
        canvas.drawPath(dynamicPath, glowPaint);

        primaryPaint.setShader(ribbonGrad);
        primaryPaint.setStrokeWidth(2.2f * density);
        canvas.drawPath(dynamicPath, primaryPaint);
        glowPaint.setShader(null);
        primaryPaint.setShader(null);
    }

    /** 13. Breathing Starlight Nodes */
    private void drawBreathingStarlightRail(Canvas canvas, int width, float centerY) {
        canvas.drawLine(0, centerY, width, centerY, baseRailPaint);

        int nodeCount = 7;
        float seg = width / (float) (nodeCount + 1);

        for (int i = 1; i <= nodeCount; i++) {
            float nx = i * seg;
            // Traveling wave pulse
            float wave = (float) (0.5 + 0.5 * Math.sin(i * 0.9 + animProgress * 2 * Math.PI));
            int alphaGlow = (int) (40 + 190 * wave);
            float r = (1.5f + 1.2f * wave) * density;

            particlePaint.setColor(Color.argb(alphaGlow, 0, 229, 255));
            canvas.drawCircle(nx, centerY, r * 2.2f, particlePaint);

            highlightPaint.setColor(COLOR_WHITE);
            canvas.drawCircle(nx, centerY, r, highlightPaint);
        }
    }
}
