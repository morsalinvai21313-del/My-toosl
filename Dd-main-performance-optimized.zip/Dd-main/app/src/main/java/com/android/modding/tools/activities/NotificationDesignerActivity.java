package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.dialogs.ColorPickerDialog;
import com.android.modding.tools.dialogs.MorsalinDialogHelper;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.HistoryManager;
import com.android.modding.tools.helpers.MorsalinDexGenerator;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.PackageGenerationRunner;
import com.android.modding.tools.helpers.SyntaxHighlighter;
import com.android.modding.tools.helpers.TransitionAnimationManager;
import com.android.modding.tools.models.XmlProject;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class NotificationDesignerActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "morsalin_designer_channel";
    private static final String[] STYLES = {"Basic", "Big Text", "Big Picture", "Progress", "Action Buttons"};
    private static final String[] PRIORITIES = {"HIGH", "DEFAULT", "LOW"};

    private String currentStyle = "Basic";
    private String notifTitle = "Build Completed Successfully";
    private String notifDesc = "Your Android package is ready for export and installation.";
    private String accentHex = "#00E5FF";
    private boolean showLargeIcon = true;
    private int progressVal = 68;
    private int actionCount = 3;
    private int priorityIdx = 0;
    private String act1Label = "OPEN";
    private String act2Label = "SHARE";
    private String act3Label = "DISMISS";
    private String mainClickUrl = "https://t.me/anonymous_modder_king";
    private String act1Url = "https://t.me/anonymous_modder_king";
    private String act2Url = "https://www.youtube.com/@apk.modding";
    private String act3Url = "https://t.me/anonymous_modder_king";
    private Uri customPictureUri = null;

    // Preview Views
    private ImageView ivSmallIcon, ivLargeIcon, ivBigPicture;
    private TextView tvStyleBadge, tvPrevTitle, tvPrevDesc;
    private ProgressBar pbPreview;
    private LinearLayout layoutActions;
    private Button btnAct1, btnAct2, btnAct3;

    // Controls
    private Button btnStyleBasic, btnStyleBigText, btnStyleBigPic, btnStyleProgress, btnStyleActions;
    private EditText etTitle, etDesc, etAct1, etAct2, etAct3;
    private EditText etMainUrl, etAct1Url, etAct2Url, etAct3Url;
    private Button btnToggleLargeIcon, btnActionCount, btnPriority;
    private SeekBar seekProgress;
    private TextView tvProgressVal;
    private Button tabJava, tabIcon, tabManifest, tabGuide;
    private TextView tvGeneratedCode;

    private int activeCodeTab = 0;
    private GeneratedPackageExporter.GeneratedPackage latestPackage;
    private HistoryManager historyManager;
    private ActivityResultLauncher<PickVisualMediaRequest> pickImageLauncher;
    private ActivityResultLauncher<String> notifPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_designer);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);

        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.PickVisualMedia(),
                uri -> {
                    if (uri != null) {
                        customPictureUri = uri;
                        currentStyle = "Big Picture";
                        refreshPreviewAndPackage();
                        MorsalinToast.show(this, R.drawable.ic_save, "Image Added",
                                "Gallery image applied to Notification!");
                    }
                }
        );

        notifPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    if (granted) {
                        dispatchRealSystemNotification();
                    } else {
                        MorsalinToast.show(this, R.drawable.ic_about_dev, "Permission Info",
                                "Notification preview updated on screen!");
                    }
                }
        );

        initViews();

        String jsonConfig = getIntent().getStringExtra("EXTRA_JSON_CONFIG");
        if (jsonConfig != null && !jsonConfig.isEmpty()) {
            loadFromJsonConfig(jsonConfig);
        }

        refreshPreviewAndPackage();
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            MorsalinDialogHelper.showResetDialog(this, "Reset Notification Designer",
                    "Reset notification style, text, progress, and actions to default?", () -> {
                        currentStyle = "Basic";
                        notifTitle = "Build Completed Successfully";
                        notifDesc = "Your Android package is ready for export and installation.";
                        accentHex = "#00E5FF";
                        showLargeIcon = true;
                        progressVal = 68;
                        actionCount = 3;
                        priorityIdx = 0;
                        act1Label = "OPEN";
                        act2Label = "SHARE";
                        act3Label = "DISMISS";
                        mainClickUrl = "https://t.me/anonymous_modder_king";
                        act1Url = "https://t.me/anonymous_modder_king";
                        act2Url = "https://www.youtube.com/@apk.modding";
                        customPictureUri = null;
                        etTitle.setText(notifTitle);
                        etDesc.setText(notifDesc);
                        etAct1.setText(act1Label);
                        etAct2.setText(act2Label);
                        etAct3.setText(act3Label);
                        etMainUrl.setText(mainClickUrl);
                        etAct1Url.setText(act1Url);
                        etAct2Url.setText(act2Url);
                        seekProgress.setProgress(68);
                        refreshPreviewAndPackage();
                    });
        });

        ivSmallIcon = findViewById(R.id.iv_notif_small_icon);
        ivLargeIcon = findViewById(R.id.iv_notif_large_icon);
        ivBigPicture = findViewById(R.id.iv_notif_big_picture);
        tvStyleBadge = findViewById(R.id.tv_notif_style_badge);
        tvPrevTitle = findViewById(R.id.tv_notif_prev_title);
        tvPrevDesc = findViewById(R.id.tv_notif_prev_desc);
        pbPreview = findViewById(R.id.pb_notif_preview);
        layoutActions = findViewById(R.id.layout_notif_actions);
        btnAct1 = findViewById(R.id.btn_notif_act_1);
        btnAct2 = findViewById(R.id.btn_notif_act_2);
        btnAct3 = findViewById(R.id.btn_notif_act_3);

        findViewById(R.id.btn_send_real_notification).setOnClickListener(v -> triggerRealNotification());

        findViewById(R.id.card_notif_preview).setOnClickListener(v -> openNotificationUrl(mainClickUrl, "Notification Body"));
        btnAct1.setOnClickListener(v -> openNotificationUrl(act1Url.isEmpty() ? mainClickUrl : act1Url, act1Label));
        btnAct2.setOnClickListener(v -> openNotificationUrl(act2Url.isEmpty() ? mainClickUrl : act2Url, act2Label));
        btnAct3.setOnClickListener(v -> openNotificationUrl(act3Url.isEmpty() ? mainClickUrl : act3Url, act3Label));

        btnStyleBasic = findViewById(R.id.btn_nt_basic);
        btnStyleBigText = findViewById(R.id.btn_nt_big_text);
        btnStyleBigPic = findViewById(R.id.btn_nt_big_pic);
        btnStyleProgress = findViewById(R.id.btn_nt_progress);
        btnStyleActions = findViewById(R.id.btn_nt_actions);

        btnStyleBasic.setOnClickListener(v -> { currentStyle = "Basic"; refreshPreviewAndPackage(); });
        btnStyleBigText.setOnClickListener(v -> { currentStyle = "Big Text"; refreshPreviewAndPackage(); });
        btnStyleBigPic.setOnClickListener(v -> { currentStyle = "Big Picture"; refreshPreviewAndPackage(); });
        btnStyleProgress.setOnClickListener(v -> { currentStyle = "Progress"; refreshPreviewAndPackage(); });
        btnStyleActions.setOnClickListener(v -> { currentStyle = "Action Buttons"; refreshPreviewAndPackage(); });

        etTitle = findViewById(R.id.et_notif_title);
        etDesc = findViewById(R.id.et_notif_desc);
        etAct1 = findViewById(R.id.et_nt_act1);
        etAct2 = findViewById(R.id.et_nt_act2);
        etAct3 = findViewById(R.id.et_nt_act3);
        etMainUrl = findViewById(R.id.et_nt_main_url);
        etAct1Url = findViewById(R.id.et_nt_act1_url);
        etAct2Url = findViewById(R.id.et_nt_act2_url);
        etAct3Url = findViewById(R.id.et_nt_act3_url);

        TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                notifTitle = etTitle.getText().toString();
                notifDesc = etDesc.getText().toString();
                act1Label = etAct1.getText().toString();
                act2Label = etAct2.getText().toString();
                act3Label = etAct3.getText().toString();
                mainClickUrl = etMainUrl.getText().toString().trim();
                act1Url = etAct1Url.getText().toString().trim();
                act2Url = etAct2Url.getText().toString().trim();
                if (etAct3Url != null) act3Url = etAct3Url.getText().toString().trim();
                refreshPreviewAndPackage();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        etTitle.addTextChangedListener(watcher);
        etDesc.addTextChangedListener(watcher);
        etAct1.addTextChangedListener(watcher);
        etAct2.addTextChangedListener(watcher);
        etAct3.addTextChangedListener(watcher);
        etMainUrl.addTextChangedListener(watcher);
        etAct1Url.addTextChangedListener(watcher);
        etAct2Url.addTextChangedListener(watcher);
        if (etAct3Url != null) etAct3Url.addTextChangedListener(watcher);

        findViewById(R.id.btn_nt_url_tg).setOnClickListener(v -> {
            etMainUrl.setText("https://t.me/anonymous_modder_king");
            etAct1Url.setText("https://t.me/anonymous_modder_king");
        });
        findViewById(R.id.btn_nt_url_yt).setOnClickListener(v -> {
            etMainUrl.setText("https://www.youtube.com/@apk.modding");
            etAct1Url.setText("https://www.youtube.com/@apk.modding");
        });
        findViewById(R.id.btn_nt_url_gh).setOnClickListener(v -> {
            etMainUrl.setText("https://github.com/morsalinvai21313-del/Dd");
            etAct1Url.setText("https://github.com/morsalinvai21313-del/Dd");
        });
        findViewById(R.id.btn_nt_url_fb).setOnClickListener(v -> {
            etMainUrl.setText("https://www.facebook.com/share/19bhVG8oJF/");
            etAct1Url.setText("https://www.facebook.com/share/19bhVG8oJF/");
        });

        findViewById(R.id.btn_nt_accent_color).setOnClickListener(v -> {
            new ColorPickerDialog(this, accentHex, hex -> { accentHex = hex; refreshPreviewAndPackage(); },
                    hex -> { accentHex = hex; refreshPreviewAndPackage(); }).show();
        });

        btnToggleLargeIcon = findViewById(R.id.btn_nt_toggle_large_icon);
        btnToggleLargeIcon.setOnClickListener(v -> {
            showLargeIcon = !showLargeIcon;
            btnToggleLargeIcon.setText(showLargeIcon ? "LARGE ICON: ON" : "LARGE ICON: OFF");
            refreshPreviewAndPackage();
        });

        findViewById(R.id.btn_nt_pick_image).setOnClickListener(v -> {
            try {
                pickImageLauncher.launch(new PickVisualMediaRequest.Builder()
                        .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                        .build());
            } catch (Exception e) {
                currentStyle = "Big Picture";
                refreshPreviewAndPackage();
            }
        });

        seekProgress = findViewById(R.id.seek_nt_progress);
        tvProgressVal = findViewById(R.id.tv_nt_progress_val);
        seekProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressVal = progress;
                tvProgressVal.setText(progressVal + "%");
                if (fromUser) {
                    refreshPreviewAndPackage();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnActionCount = findViewById(R.id.btn_nt_action_count);
        btnPriority = findViewById(R.id.btn_nt_priority);

        btnActionCount.setOnClickListener(v -> {
            actionCount = (actionCount + 1) % 4;
            btnActionCount.setText("ACTIONS: " + actionCount);
            refreshPreviewAndPackage();
        });

        btnPriority.setOnClickListener(v -> {
            priorityIdx = (priorityIdx + 1) % PRIORITIES.length;
            btnPriority.setText("PRIORITY: " + PRIORITIES[priorityIdx]);
            refreshPreviewAndPackage();
        });

        android.widget.ScrollView scrollView = findViewById(R.id.scroll_notif_designer);
        View panelGenAnim = findViewById(R.id.panel_gen_anim);
        com.android.modding.tools.helpers.ConversionAnimationView genAnimView = findViewById(R.id.gen_anim_view);
        TextView tvGenStatus = findViewById(R.id.tv_gen_status);
        View panelDownloadReady = findViewById(R.id.panel_download_ready);
        Button btnGeneratePackage = findViewById(R.id.btn_generate_package);
        Button btnDownloadDex = findViewById(R.id.btn_download_dex);
        Button btnDownloadZip = findViewById(R.id.btn_download_xml);

        btnGeneratePackage.setOnClickListener(v -> {
            refreshPreviewAndPackage();
            PackageGenerationRunner.runGeneratePipeline(
                    scrollView,
                    panelGenAnim,
                    genAnimView,
                    null,
                    tvGenStatus,
                    panelDownloadReady,
                    "NOTIFICATION",
                    "CLASSES.DEX",
                    () -> {
                        refreshPreviewAndPackage();
                        MorsalinToast.show(this, R.drawable.ic_download, "Package Ready",
                                "classes.dex and ZIP ready to download!");
                    }
            );
        });

        if (btnDownloadDex != null) {
            btnDownloadDex.setOnClickListener(v -> {
                if (latestPackage != null && latestPackage.getDexBinary() != null) {
                    byte[] dexBytes = latestPackage.getDexBinary();
                    FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                            this, "MorsalinXML/" + latestPackage.projectFolderName,
                            "classes.dex", "application/octet-stream", dexBytes);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "classes.dex Downloaded" : "Export Error", res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        if (btnDownloadZip != null) {
            btnDownloadZip.setOnClickListener(v -> {
                if (latestPackage != null) {
                    FileExporter.ExportResult res = GeneratedPackageExporter.exportPackageAsZip(this, latestPackage);
                    GeneratedPackageExporter.exportAllPackageFiles(this, latestPackage);
                    MorsalinToast.show(this, R.drawable.ic_download,
                            res.success ? "ZIP Package Downloaded" : "Export Error",
                            res.success ? "Saved to Downloads/MorsalinXML/" + latestPackage.projectFolderName + ".zip" : res.message);
                } else {
                    MorsalinToast.show(this, R.drawable.ic_download, "Generating...", "Please tap Generate first!");
                }
            });
        }

        findViewById(R.id.btn_save_history).setOnClickListener(v -> {
            String name = "Notif_" + currentStyle.replace(" ", "_");
            XmlProject proj = new XmlProject(name, XmlProject.TYPE_NOTIFICATION,
                    latestPackage != null ? latestPackage.files.get("res/drawable/ic_morsalin_notif_small.xml") : "", buildJsonConfig());
            historyManager.saveProject(proj);
            MorsalinToast.show(this, R.drawable.ic_save, "Saved to History",
                    "Notification project saved to History!");
        });

        findViewById(R.id.btn_share_export).setOnClickListener(v -> {
            if (latestPackage != null) {
                GeneratedPackageExporter.showShareDialog(
                        this, latestPackage, "classes.dex", getCurrentTabContent());
            }
        });
    }

    private void openNotificationUrl(String url, String label) {
        if (url != null && !url.trim().isEmpty()) {
            String target = url.trim();
            if (!target.startsWith("http://") && !target.startsWith("https://")
                    && !target.startsWith("tg://") && !target.startsWith("mailto:")) {
                target = "https://" + target;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(target));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception e) {
                MorsalinToast.show(this, R.drawable.ic_code_convert, label, "Opening: " + target);
            }
        } else {
            MorsalinToast.show(this, R.drawable.ic_about_dev, label, "No link set for this action");
        }
    }

    private PendingIntent buildUrlPendingIntent(String url, int reqCode, int flags) {
        if (url != null && !url.trim().isEmpty()) {
            String target = url.trim();
            if (!target.startsWith("http://") && !target.startsWith("https://")
                    && !target.startsWith("tg://") && !target.startsWith("mailto:")) {
                target = "https://" + target;
            }
            try {
                Intent urlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(target));
                urlIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                return PendingIntent.getActivity(this, reqCode, urlIntent, flags);
            } catch (Exception ignored) {}
        }
        Intent fallback = new Intent(this, NotificationDesignerActivity.class);
        return PendingIntent.getActivity(this, reqCode, fallback, flags);
    }

    private int parseSafeColor(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }

    private void refreshPreviewAndPackage() {
        int cyan = getResources().getColor(R.color.morsalin_cyan);
        btnStyleBasic.setTextColor("Basic".equals(currentStyle) ? cyan : Color.WHITE);
        btnStyleBigText.setTextColor("Big Text".equals(currentStyle) ? cyan : Color.WHITE);
        btnStyleBigPic.setTextColor("Big Picture".equals(currentStyle) ? cyan : Color.WHITE);
        btnStyleProgress.setTextColor("Progress".equals(currentStyle) ? cyan : Color.WHITE);
        btnStyleActions.setTextColor("Action Buttons".equals(currentStyle) ? cyan : Color.WHITE);

        tvStyleBadge.setText(currentStyle.toUpperCase());
        ivSmallIcon.setColorFilter(parseSafeColor(accentHex, cyan));
        tvPrevTitle.setText(notifTitle);
        tvPrevDesc.setText(notifDesc);
        tvPrevDesc.setMaxLines("Big Text".equals(currentStyle) ? 5 : 2);

        ivLargeIcon.setVisibility(showLargeIcon ? View.VISIBLE : View.GONE);

        if ("Progress".equals(currentStyle)) {
            pbPreview.setVisibility(View.VISIBLE);
            pbPreview.setProgress(progressVal);
        } else {
            pbPreview.setVisibility(View.GONE);
        }

        if ("Big Picture".equals(currentStyle)) {
            ivBigPicture.setVisibility(View.VISIBLE);
            if (customPictureUri != null) {
                ivBigPicture.setImageURI(customPictureUri);
            } else {
                ivBigPicture.setImageResource(R.drawable.img_avatar_morsalin);
            }
        } else {
            ivBigPicture.setVisibility(View.GONE);
        }

        if (actionCount == 0) {
            layoutActions.setVisibility(View.GONE);
        } else {
            layoutActions.setVisibility(View.VISIBLE);
            btnAct1.setText(act1Label);
            btnAct2.setText(act2Label);
            btnAct3.setText(act3Label);
            btnAct1.setVisibility(actionCount >= 1 ? View.VISIBLE : View.GONE);
            btnAct2.setVisibility(actionCount >= 2 ? View.VISIBLE : View.GONE);
            btnAct3.setVisibility(actionCount >= 3 ? View.VISIBLE : View.GONE);
        }

        byte[] dexBytes = MorsalinDexGenerator.buildNotificationHelperDex(
                this,
                currentStyle,
                notifTitle,
                notifDesc,
                accentHex,
                progressVal,
                actionCount,
                act1Label,
                act2Label,
                act3Label,
                mainClickUrl,
                act1Url,
                act2Url,
                act3Url
        );
        String iconXml = generateSmallIconXml();
        String manifestXml = generateManifestSnippet();

        GeneratedPackageExporter.GeneratedPackage pkg =
                new GeneratedPackageExporter.GeneratedPackage("Morsalin_Notification_Package", "Notification Designer");
        pkg.addDexBinary(dexBytes);
        pkg.addFile("java/com/morsalin/xmlcreator/MorsalinNotificationHelper.java", generateNotificationJavaCode());
        pkg.addFile("smali/com/morsalin/xmlcreator/MorsalinNotificationHelper.smali", generateNotificationSmaliCode());
        pkg.addFile("res/drawable/ic_morsalin_notif_small.xml", iconXml);
        pkg.addFile("AndroidManifest_Notification.xml", manifestXml);

        String guide = GeneratedPackageExporter.buildNotificationDesignerGuide(
                currentStyle,
                notifTitle,
                actionCount,
                mainClickUrl,
                act1Label, act1Url,
                act2Label, act2Url,
                act3Label, act3Url
        );
        pkg.setGuideContent("NOTIFICATION_GUIDE.txt", guide);
        latestPackage = pkg;
        displayActiveTabCode();
    }

    private void triggerRealNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                return;
            }
        }
        dispatchRealSystemNotification();
    }

    private void dispatchRealSystemNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                int imp = NotificationManager.IMPORTANCE_HIGH;
                if (priorityIdx == 1) imp = NotificationManager.IMPORTANCE_DEFAULT;
                else if (priorityIdx == 2) imp = NotificationManager.IMPORTANCE_LOW;

                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Morsalin Notification Designer", imp);
                channel.setDescription("Live notifications from Morsalin XML Creator");
                nm.createNotificationChannel(channel);
            }

            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent piMain = buildUrlPendingIntent(mainClickUrl, 101, flags);
            PendingIntent piAct1 = buildUrlPendingIntent(act1Url.isEmpty() ? mainClickUrl : act1Url, 102, flags);
            PendingIntent piAct2 = buildUrlPendingIntent(act2Url.isEmpty() ? mainClickUrl : act2Url, 103, flags);
            PendingIntent piAct3 = buildUrlPendingIntent(act3Url.isEmpty() ? mainClickUrl : act3Url, 104, flags);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_about_dev)
                    .setContentTitle(notifTitle)
                    .setContentText(notifDesc)
                    .setColor(parseSafeColor(accentHex, Color.CYAN))
                    .setAutoCancel(true)
                    .setContentIntent(piMain)
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            if (showLargeIcon) {
                Bitmap largeBmp = BitmapFactory.decodeResource(getResources(), R.drawable.img_avatar_sanny);
                if (largeBmp != null) {
                    builder.setLargeIcon(largeBmp);
                }
            }

            if ("Big Text".equals(currentStyle)) {
                builder.setStyle(new NotificationCompat.BigTextStyle().bigText(notifDesc));
            } else if ("Big Picture".equals(currentStyle)) {
                Bitmap picBmp = BitmapFactory.decodeResource(getResources(), R.drawable.img_avatar_morsalin);
                if (picBmp != null) {
                    builder.setStyle(new NotificationCompat.BigPictureStyle()
                            .bigPicture(picBmp)
                            .setSummaryText(notifDesc));
                }
            } else if ("Progress".equals(currentStyle)) {
                builder.setProgress(100, progressVal, false);
            }

            if (actionCount >= 1) {
                builder.addAction(0, act1Label, piAct1);
            }
            if (actionCount >= 2) {
                builder.addAction(0, act2Label, piAct2);
            }
            if (actionCount >= 3) {
                builder.addAction(0, act3Label, piAct3);
            }

            nm.notify((int) (System.currentTimeMillis() & 0xFFFFFF), builder.build());
            MorsalinToast.show(this, R.drawable.ic_save, "Notification Sent",
                    "Live Android notification posted to status bar!");
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_about_dev, "Notification Ready",
                    "Preview updated! (" + e.getMessage() + ")");
        }
    }

    private void switchCodeTab(int idx) {
        activeCodeTab = idx;
    }

    private void displayActiveTabCode() {
        // Files are prepared in package for direct download
    }

    private String getCurrentTabFileName() {
        if (activeCodeTab == 0) return "classes.dex";
        if (activeCodeTab == 1) return "ic_morsalin_notif_small.xml";
        if (activeCodeTab == 2) return "AndroidManifest_Notification.xml";
        return "GUIDE.txt";
    }

    private String getCurrentTabContent() {
        if (latestPackage == null) return "";
        if (activeCodeTab == 0) {
            byte[] dex = latestPackage.getDexBinary();
            return MorsalinDexGenerator.getDexBinaryReport(
                    dex,
                    "Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;",
                    "invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;->sendNotification(Landroid/content/Context;)V",
                    "Style: " + currentStyle + " | Title: " + notifTitle + " | Link: " + mainClickUrl
            );
        }
        if (activeCodeTab == 1) return latestPackage.files.get("res/drawable/ic_morsalin_notif_small.xml");
        if (activeCodeTab == 2) return latestPackage.files.get("AndroidManifest_Notification.xml");
        return latestPackage.guideContent;
    }

    private String generateSmallIconXml() {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                + "    android:width=\"24dp\"\n"
                + "    android:height=\"24dp\"\n"
                + "    android:viewportWidth=\"24\"\n"
                + "    android:viewportHeight=\"24\">\n"
                + "    <path\n"
                + "        android:fillColor=\"" + accentHex + "\"\n"
                + "        android:pathData=\"M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.9,2 2,2zM18,16v-5c0,-3.07 -1.63,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.64,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z\" />\n"
                + "</vector>";
    }

    private String generateManifestSnippet() {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<!-- Add this permission inside your AndroidManifest.xml above <application> -->\n"
                + "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">\n\n"
                + "    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />\n\n"
                + "</manifest>";
    }

    private String generateNotificationSmaliCode() {
        String safeTitle = notifTitle.replace("\\", "\\\\").replace("\"", "\\\"");
        String safeDesc = notifDesc.replace("\\", "\\\\").replace("\"", "\\\"");
        String safeAct1 = act1Label.replace("\\", "\\\\").replace("\"", "\\\"");
        String safeAct2 = act2Label.replace("\\", "\\\\").replace("\"", "\\\"");
        String safeAct3 = act3Label.replace("\\", "\\\\").replace("\"", "\\\"");

        int impConst = 4; // IMPORTANCE_HIGH
        if (priorityIdx == 1) impConst = 3; // IMPORTANCE_DEFAULT
        else if (priorityIdx == 2) impConst = 2; // IMPORTANCE_LOW

        StringBuilder sb = new StringBuilder();
        sb.append(".class public Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;\n");
        sb.append(".super Ljava/lang/Object;\n");
        sb.append(".source \"MorsalinNotificationHelper.java\"\n\n");
        sb.append("# ====================================================================\n");
        sb.append("# Generated by Morsalin XML Creator — Notification Designer\n");
        sb.append("# Package : com.morsalin.xmlcreator\n");
        sb.append("# Style   : ").append(currentStyle).append(" | Priority: ").append(PRIORITIES[priorityIdx]).append("\n");
        sb.append("#\n");
        sb.append("# HOW TO CALL IN MainActivity.smali (inside onCreate before return-void):\n");
        sb.append("# invoke-static {p0}, Lcom/morsalin/xmlcreator/MorsalinNotificationHelper;->sendNotification(Landroid/content/Context;)V\n");
        sb.append("# ====================================================================\n\n");

        sb.append(".method public constructor <init>()V\n");
        sb.append("    .locals 0\n\n");
        sb.append("    invoke-direct {p0}, Ljava/lang/Object;-><init>()V\n");
        sb.append("    return-void\n");
        sb.append(".end method\n\n");

        sb.append(".method public static sendNotification(Landroid/content/Context;)V\n");
        sb.append("    .locals 7\n\n");
        sb.append("    if-nez p0, :cond_start\n");
        sb.append("    return-void\n\n");
        sb.append("    :cond_start\n");
        sb.append("    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I\n");
        sb.append("    const/16 v1, 0x21\n");
        sb.append("    if-lt v0, v1, :cond_perm_ok\n\n");

        sb.append("    # Android 13+ (API 33) POST_NOTIFICATIONS runtime check\n");
        sb.append("    const-string v1, \"android.permission.POST_NOTIFICATIONS\"\n");
        sb.append("    invoke-virtual {p0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I\n");
        sb.append("    move-result v2\n");
        sb.append("    if-eqz v2, :cond_perm_ok\n");
        sb.append("    instance-of v2, p0, Landroid/app/Activity;\n");
        sb.append("    if-eqz v2, :cond_end\n");
        sb.append("    move-object v2, p0\n");
        sb.append("    check-cast v2, Landroid/app/Activity;\n");
        sb.append("    const/4 v3, 0x1\n");
        sb.append("    new-array v3, v3, [Ljava/lang/String;\n");
        sb.append("    const/4 v4, 0x0\n");
        sb.append("    aput-object v1, v3, v4\n");
        sb.append("    const/16 v1, 0x65\n");
        sb.append("    invoke-virtual {v2, v3, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V\n");
        sb.append("    return-void\n\n");

        sb.append("    :cond_perm_ok\n");
        sb.append("    const-string v1, \"notification\"\n");
        sb.append("    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;\n");
        sb.append("    move-result-object v1\n");
        sb.append("    check-cast v1, Landroid/app/NotificationManager;\n");
        sb.append("    if-eqz v1, :cond_end\n\n");

        sb.append("    const-string v2, \"morsalin_custom_channel\"\n");
        sb.append("    const/16 v3, 0x1a\n");
        sb.append("    if-lt v0, v3, :cond_legacy_builder\n\n");

        sb.append("    # Android 8.0+ NotificationChannel\n");
        sb.append("    new-instance v3, Landroid/app/NotificationChannel;\n");
        sb.append("    const-string v4, \"Morsalin Channel\"\n");
        sb.append("    const/4 v5, 0x").append(impConst).append("\n");
        sb.append("    invoke-direct {v3, v2, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V\n");
        sb.append("    invoke-virtual {v1, v3}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V\n");
        sb.append("    new-instance v3, Landroid/app/Notification$Builder;\n");
        sb.append("    invoke-direct {v3, p0, v2}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V\n");
        sb.append("    goto :goto_configure\n\n");

        sb.append("    :cond_legacy_builder\n");
        sb.append("    new-instance v3, Landroid/app/Notification$Builder;\n");
        sb.append("    invoke-direct {v3, p0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V\n\n");

        sb.append("    :goto_configure\n");
        sb.append("    const v4, 0x108009b\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;\n");
        sb.append("    const-string v4, \"").append(safeTitle).append("\"\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;\n");
        sb.append("    const-string v4, \"").append(safeDesc).append("\"\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;\n");
        sb.append("    const/4 v4, 0x1\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;\n\n");

        sb.append("    const/16 v4, 0x15\n");
        sb.append("    if-lt v0, v4, :cond_skip_color\n");
        sb.append("    const-string v4, \"").append(accentHex).append("\"\n");
        sb.append("    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I\n");
        sb.append("    move-result v4\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;\n");
        sb.append("    :cond_skip_color\n\n");

        if ("Big Text".equals(currentStyle)) {
            sb.append("    new-instance v4, Landroid/app/Notification$BigTextStyle;\n");
            sb.append("    invoke-direct {v4}, Landroid/app/Notification$BigTextStyle;-><init>()V\n");
            sb.append("    const-string v5, \"").append(safeDesc).append("\"\n");
            sb.append("    invoke-virtual {v4, v5}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;\n");
            sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;\n\n");
        } else if ("Progress".equals(currentStyle)) {
            sb.append("    const/16 v4, 0x64\n");
            sb.append("    const/16 v5, 0x").append(Integer.toHexString(progressVal)).append("\n");
            sb.append("    const/4 v6, 0x0\n");
            sb.append("    invoke-virtual {v3, v4, v5, v6}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;\n\n");
        }

        sb.append("    # Launch PendingIntent when notification or action is tapped\n");
        sb.append("    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;\n");
        sb.append("    move-result-object v4\n");
        sb.append("    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;\n");
        sb.append("    move-result-object v5\n");
        sb.append("    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;\n");
        sb.append("    move-result-object v4\n");
        sb.append("    if-nez v4, :cond_has_intent\n");
        sb.append("    new-instance v4, Landroid/content/Intent;\n");
        sb.append("    invoke-direct {v4}, Landroid/content/Intent;-><init>()V\n");
        sb.append("    :cond_has_intent\n");
        sb.append("    const/4 v5, 0x0\n");
        sb.append("    const/high16 v6, 0x4000000\n");
        sb.append("    invoke-static {p0, v5, v4, v6}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;\n");
        sb.append("    move-result-object v4\n");
        sb.append("    invoke-virtual {v3, v4}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;\n\n");

        if (actionCount >= 1) {
            sb.append("    const/4 v5, 0x0\n");
            sb.append("    const-string v6, \"").append(safeAct1).append("\"\n");
            sb.append("    invoke-virtual {v3, v5, v6, v4}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;\n");
        }
        if (actionCount >= 2) {
            sb.append("    const/4 v5, 0x0\n");
            sb.append("    const-string v6, \"").append(safeAct2).append("\"\n");
            sb.append("    invoke-virtual {v3, v5, v6, v4}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;\n");
        }
        if (actionCount >= 3) {
            sb.append("    const/4 v5, 0x0\n");
            sb.append("    const-string v6, \"").append(safeAct3).append("\"\n");
            sb.append("    invoke-virtual {v3, v5, v6, v4}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;\n");
        }

        sb.append("\n    invoke-virtual {v3}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;\n");
        sb.append("    move-result-object v3\n");
        sb.append("    const/16 v4, 0x3e9\n");
        sb.append("    invoke-virtual {v1, v4, v3}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V\n\n");
        sb.append("    :cond_end\n");
        sb.append("    return-void\n");
        sb.append(".end method\n");
        return sb.toString();
    }

    private String generateNotificationJavaCode() {
        return "package com.morsalin.xmlcreator;\n\n"
                + "import android.Manifest;\n"
                + "import android.app.Activity;\n"
                + "import android.app.NotificationChannel;\n"
                + "import android.app.NotificationManager;\n"
                + "import android.app.PendingIntent;\n"
                + "import android.content.Context;\n"
                + "import android.content.Intent;\n"
                + "import android.content.pm.PackageManager;\n"
                + "import android.graphics.Color;\n"
                + "import android.os.Build;\n"
                + "import androidx.core.app.ActivityCompat;\n"
                + "import androidx.core.app.NotificationCompat;\n"
                + "import androidx.core.content.ContextCompat;\n\n"
                + "/**\n"
                + " * Generated by Morsalin XML Creator — Notification Designer\n"
                + " * Style: " + currentStyle + " | Priority: " + PRIORITIES[priorityIdx] + "\n"
                + " */\n"
                + "public class MorsalinNotificationHelper {\n\n"
                + "    private static final String CHANNEL_ID = \"morsalin_custom_channel\";\n"
                + "    private static final int NOTIFICATION_ID = 1001;\n\n"
                + "    public static void sendNotification(Context context) {\n"
                + "        if (Build.VERSION.SDK_INT >= 33) {\n"
                + "            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)\n"
                + "                    != PackageManager.PERMISSION_GRANTED) {\n"
                + "                if (context instanceof Activity) {\n"
                + "                    ActivityCompat.requestPermissions((Activity) context,\n"
                + "                            new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);\n"
                + "                }\n"
                + "                return;\n"
                + "            }\n"
                + "        }\n\n"
                + "        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);\n"
                + "        if (nm == null) return;\n\n"
                + "        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {\n"
                + "            NotificationChannel channel = new NotificationChannel(\n"
                + "                    CHANNEL_ID, \"General Notifications\", NotificationManager.IMPORTANCE_HIGH);\n"
                + "            nm.createNotificationChannel(channel);\n"
                + "        }\n\n"
                + "        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());\n"
                + "        if (intent == null) intent = new Intent();\n"
                + "        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M\n"
                + "                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE\n"
                + "                : PendingIntent.FLAG_UPDATE_CURRENT;\n"
                + "        PendingIntent pi = PendingIntent.getActivity(context, 0, intent, flags);\n\n"
                + "        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)\n"
                + "                .setSmallIcon(android.R.drawable.ic_dialog_info)\n"
                + "                .setContentTitle(\"" + notifTitle.replace("\"", "\\\"") + "\")\n"
                + "                .setContentText(\"" + notifDesc.replace("\"", "\\\"") + "\")\n"
                + "                .setColor(Color.parseColor(\"" + accentHex + "\"))\n"
                + "                .setAutoCancel(true)\n"
                + "                .setContentIntent(pi)\n"
                + "                .setPriority(NotificationCompat.PRIORITY_HIGH);\n\n"
                + ("Big Text".equals(currentStyle)
                ? "        builder.setStyle(new NotificationCompat.BigTextStyle().bigText(\"" + notifDesc.replace("\"", "\\\"") + "\"));\n"
                : "")
                + ("Progress".equals(currentStyle)
                ? "        builder.setProgress(100, " + progressVal + ", false);\n"
                : "")
                + (actionCount >= 1 ? "        builder.addAction(0, \"" + act1Label.replace("\"", "\\\"") + "\", pi);\n" : "")
                + (actionCount >= 2 ? "        builder.addAction(0, \"" + act2Label.replace("\"", "\\\"") + "\", pi);\n" : "")
                + (actionCount >= 3 ? "        builder.addAction(0, \"" + act3Label.replace("\"", "\\\"") + "\", pi);\n" : "")
                + "\n        nm.notify(NOTIFICATION_ID, builder.build());\n"
                + "    }\n"
                + "}\n";
    }

    private String buildJsonConfig() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("currentStyle", currentStyle);
            obj.put("notifTitle", notifTitle);
            obj.put("notifDesc", notifDesc);
            obj.put("accentHex", accentHex);
            obj.put("showLargeIcon", showLargeIcon);
            obj.put("progressVal", progressVal);
            obj.put("actionCount", actionCount);
            obj.put("priorityIdx", priorityIdx);
            obj.put("act1Label", act1Label);
            obj.put("act2Label", act2Label);
            obj.put("act3Label", act3Label);
            obj.put("mainClickUrl", mainClickUrl);
            obj.put("act1Url", act1Url);
            obj.put("act2Url", act2Url);
            return obj.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void loadFromJsonConfig(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            currentStyle = obj.optString("currentStyle", "Basic");
            notifTitle = obj.optString("notifTitle", notifTitle);
            notifDesc = obj.optString("notifDesc", notifDesc);
            accentHex = obj.optString("accentHex", accentHex);
            showLargeIcon = obj.optBoolean("showLargeIcon", true);
            progressVal = obj.optInt("progressVal", 68);
            actionCount = obj.optInt("actionCount", 3);
            priorityIdx = obj.optInt("priorityIdx", 0);
            act1Label = obj.optString("act1Label", "OPEN");
            act2Label = obj.optString("act2Label", "SHARE");
            act3Label = obj.optString("act3Label", "DISMISS");
            mainClickUrl = obj.optString("mainClickUrl", mainClickUrl);
            act1Url = obj.optString("act1Url", act1Url);
            act2Url = obj.optString("act2Url", act2Url);

            etTitle.setText(notifTitle);
            etDesc.setText(notifDesc);
            etAct1.setText(act1Label);
            etAct2.setText(act2Label);
            etAct3.setText(act3Label);
            etMainUrl.setText(mainClickUrl);
            etAct1Url.setText(act1Url);
            etAct2Url.setText(act2Url);
            seekProgress.setProgress(progressVal);
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
