package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class XmlCreatorCategoryActivity extends AppCompatActivity {

    private static final String URL_TELEGRAM = "https://t.me/anonymous_modder_king";
    private static final String URL_FACEBOOK = "https://www.facebook.com/share/19bhVG8oJF/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_xml_creator);

        GlobalTouchParticleManager.attach(this);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.btn_category_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        View.OnClickListener openAbout = v -> {
            com.android.modding.tools.dialogs.MorsalinDialogHelper.showAboutDialog(this);
        };

        findViewById(R.id.btn_category_about).setOnClickListener(openAbout);
        findViewById(R.id.btn_category_bottom_about).setOnClickListener(openAbout);

        // Social Links with smooth micro-animation
        com.android.modding.tools.helpers.SocialButtonAnimationHelper.bindSocialButtons(findViewById(android.R.id.content), this);

        // Tools Navigation
        View btnNormal = findViewById(R.id.btn_tool_normal_xml);
        if (btnNormal != null) btnNormal.setOnClickListener(v -> launchTool(NormalEditorActivity.class));

        View btnGradient = findViewById(R.id.btn_tool_gradient_xml);
        if (btnGradient != null) btnGradient.setOnClickListener(v -> launchTool(GradientEditorActivity.class));

        View btn3d = findViewById(R.id.btn_tool_3d_xml);
        if (btn3d != null) btn3d.setOnClickListener(v -> launchTool(ThreeDEditorActivity.class));

        View btnLayout = findViewById(R.id.btn_tool_layout_xml);
        if (btnLayout != null) btnLayout.setOnClickListener(v -> launchTool(LayoutXmlEditorActivity.class));
    }

    private void launchTool(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
        TransitionAnimationManager.applyForward(this);
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
