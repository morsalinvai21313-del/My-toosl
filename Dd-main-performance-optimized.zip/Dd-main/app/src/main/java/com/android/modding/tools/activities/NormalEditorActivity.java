package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.models.*;
import com.android.modding.tools.generators.*;
import com.android.modding.tools.helpers.*;
import com.android.modding.tools.dialogs.*;
import com.android.modding.tools.activities.*;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;







import java.util.HashMap;
import java.util.Map;

public class NormalEditorActivity extends AppCompatActivity {

    public static final String XML_INITIAL_PLACEHOLDER =
            "<!-- XML will be generated here when you select colors or configure layers -->";

    private final Map<String, StateModel> stateMap = new HashMap<>();
    private String currentState = StateModel.STATE_NORMAL;

    // Sticky Preview Views
    private FrameLayout boxFrameNormal, boxFrameChecked, boxFramePressed;
    private FrameLayout cardNormal, cardChecked, cardPressed;
    private TextView tvPreviewNormalLabel, tvPreviewCheckedLabel, tvPreviewPressedLabel;

    // Tabs
    private Button tabNormal, tabChecked, tabPressed;

    // Layer UI controls
    private TextView tvBgColorHex, tvStrokeColorHex;
    private TextView etGeneratedXml;
    private ScrollView scrollCodeVertical;
    private HorizontalScrollView scrollCodeHorizontal;

    private HistoryManager historyManager;
    private boolean isRippleMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_normal_editor);

        GlobalTouchParticleManager.attach(this);

        historyManager = new HistoryManager(this);
        isRippleMode = getIntent().getBooleanExtra("EXTRA_MODE_RIPPLE", false);

        initBlankStates();
        String importedXml = getIntent().getStringExtra("EXTRA_IMPORTED_XML");
        if (importedXml != null && !importedXml.trim().isEmpty()) {
            loadImportedXml(importedXml.trim());
        }
        initViews();
        if (isRippleMode) {
            TextView tvTitle = findViewById(R.id.tv_normal_editor_title);
            if (tvTitle != null) tvTitle.setText("Ripple XML Creator");
        }
        updateTabsSelection();
        updateStateFrameSelection();
        updateUiForCurrentState();
        updatePreviewAndXml();
    }

    private void loadImportedXml(String xml) {
        XmlParser.ParseResult result = XmlParser.parseXml(xml);
        if (!result.success) return;

        if (result.selectorStates != null && !result.selectorStates.isEmpty()) {
            stateMap.clear();
            stateMap.putAll(result.selectorStates);
            for (StateModel sm : stateMap.values()) {
                sm.setActive(true);
                for (LayerModel l : sm.getLayers()) {
                    l.setGradient(false);
                }
            }
        } else if (result.singleLayer != null) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            result.singleLayer.setGradient(false);
            normal.getLayers().add(result.singleLayer);
            stateMap.put(StateModel.STATE_NORMAL, normal);
        } else if (result.layerList != null && !result.layerList.isEmpty()) {
            StateModel normal = new StateModel(StateModel.STATE_NORMAL);
            normal.setActive(true);
            normal.getLayers().clear();
            LayerModel l = result.layerList.get(0);
            l.setGradient(false);
            normal.getLayers().add(l);
            stateMap.put(StateModel.STATE_NORMAL, normal);
        }
    }

    /**
     * Initializes all states completely blank (no pre-filled colors, no strokes, no XML).
     */
    private void initBlankStates() {
        stateMap.clear();

        // Normal State (Starts completely blank and inactive until user configures it)
        StateModel normal = new StateModel(StateModel.STATE_NORMAL);
        normal.setActive(false);
        LayerModel lNormal = normal.getLayers().get(0);
        lNormal.setSolidColor("#00000000");
        lNormal.getStroke().setColor("#00000000");
        lNormal.getStroke().setWidthDp(0);
        lNormal.getCorners().setCorners(0, 0, 0, 0, false);
        stateMap.put(StateModel.STATE_NORMAL, normal);

        // Checked State (Starts completely blank and inactive)
        StateModel checked = new StateModel(StateModel.STATE_CHECKED);
        checked.setActive(false);
        LayerModel lChecked = checked.getLayers().get(0);
        lChecked.setSolidColor("#00000000");
        lChecked.getStroke().setColor("#00000000");
        lChecked.getStroke().setWidthDp(0);
        lChecked.getCorners().setCorners(0, 0, 0, 0, false);
        stateMap.put(StateModel.STATE_CHECKED, checked);

        // Pressed State (Starts completely blank and inactive)
        StateModel pressed = new StateModel(StateModel.STATE_PRESSED);
        pressed.setActive(false);
        LayerModel lPressed = pressed.getLayers().get(0);
        lPressed.setSolidColor("#00000000");
        lPressed.getStroke().setColor("#00000000");
        lPressed.getStroke().setWidthDp(0);
        lPressed.getCorners().setCorners(0, 0, 0, 0, false);
        stateMap.put(StateModel.STATE_PRESSED, pressed);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });
        findViewById(R.id.btn_reset).setOnClickListener(v -> showResetDialog());

        boxFrameNormal = findViewById(R.id.box_frame_normal);
        boxFrameChecked = findViewById(R.id.box_frame_checked);
        boxFramePressed = findViewById(R.id.box_frame_pressed);

        cardNormal = findViewById(R.id.card_preview_normal);
        cardChecked = findViewById(R.id.card_preview_checked);
        cardPressed = findViewById(R.id.card_preview_pressed);

        tvPreviewNormalLabel = findViewById(R.id.tv_preview_normal_label);
        tvPreviewCheckedLabel = findViewById(R.id.tv_preview_checked_label);
        tvPreviewPressedLabel = findViewById(R.id.tv_preview_pressed_label);

        // Labels are always visible centered inside the preview boxes
        tvPreviewNormalLabel.setVisibility(View.VISIBLE);
        tvPreviewCheckedLabel.setVisibility(View.VISIBLE);
        tvPreviewPressedLabel.setVisibility(View.VISIBLE);

        tabNormal = findViewById(R.id.tab_edit_normal);
        tabChecked = findViewById(R.id.tab_edit_checked);
        tabPressed = findViewById(R.id.tab_edit_pressed);

        tvBgColorHex = findViewById(R.id.tv_bg_color_hex);
        tvStrokeColorHex = findViewById(R.id.tv_stroke_color_hex);
        scrollCodeVertical = findViewById(R.id.scroll_code_vertical);
        scrollCodeHorizontal = findViewById(R.id.scroll_code_horizontal);
        etGeneratedXml = findViewById(R.id.et_generated_xml);

        // Enable smooth, isolated scrolling inside the code box
        XmlFormatter.enableCodeBoxScroll(etGeneratedXml, scrollCodeVertical, scrollCodeHorizontal);

        // State Tab Clicks
        tabNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        tabChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        tabPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        cardNormal.setOnClickListener(v -> switchState(StateModel.STATE_NORMAL));
        cardChecked.setOnClickListener(v -> switchState(StateModel.STATE_CHECKED));
        cardPressed.setOnClickListener(v -> switchState(StateModel.STATE_PRESSED));

        // Background Color Picker
        findViewById(R.id.btn_pick_bg_color).setOnClickListener(v -> {
            LayerModel layer = getCurrentLayer();
            String currentHex = layer.getSolidColor();
            String pickerInitial = (currentHex == null || currentHex.equals("#00000000")) ? "#FF0000E6" : currentHex;

            ColorPickerDialog dialog = new ColorPickerDialog(this, pickerInitial,
                    color -> {
                        // Live preview as user drags
                        markCurrentStateConfigured();
                        layer.setSolidColor(color);
                        updateUiForCurrentState();
                        updatePreviewOnly();
                    },
                    finalColor -> {
                        // User clicks set / apply
                        markCurrentStateConfigured();
                        layer.setSolidColor(finalColor);
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        // Stroke Color Picker
        findViewById(R.id.btn_pick_stroke_color).setOnClickListener(v -> {
            LayerModel layer = getCurrentLayer();
            String currentHex = layer.getStroke().getColor();
            String pickerInitial = (currentHex == null || currentHex.equals("#00000000")) ? "#FF00FF00" : currentHex;

            ColorPickerDialog dialog = new ColorPickerDialog(this, pickerInitial,
                    color -> {
                        markCurrentStateConfigured();
                        layer.getStroke().setColor(color);
                        if (layer.getStroke().getWidthDp() == 0) {
                            layer.getStroke().setWidthDp(2);
                        }
                        updateUiForCurrentState();
                        updatePreviewOnly();
                    },
                    finalColor -> {
                        markCurrentStateConfigured();
                        layer.getStroke().setColor(finalColor);
                        if (layer.getStroke().getWidthDp() == 0) {
                            layer.getStroke().setWidthDp(2);
                        }
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    }
            );
            dialog.show();
        });

        // Set Custom Stroke Dialog
        findViewById(R.id.btn_set_custom_stroke).setOnClickListener(v -> {
            LayerModel layer = getCurrentLayer();
            StrokeModel currentStroke = layer.getStroke();
            if (currentStroke.getWidthDp() == 0 && (currentStroke.getColor() == null || currentStroke.getColor().equals("#00000000"))) {
                currentStroke.setColor("#FF00FF00");
                currentStroke.setWidthDp(2);
            }

            CustomStrokeDialog dialog = new CustomStrokeDialog(this, layer.getStroke(),
                    (widthDp, dashWidthDp, dashGapDp) -> {
                        markCurrentStateConfigured();
                        layer.getStroke().setWidthDp(widthDp);
                        layer.getStroke().setDashWidthDp(dashWidthDp);
                        layer.getStroke().setDashGapDp(dashGapDp);
                        updateUiForCurrentState();
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((widthDp, dashWidthDp, dashGapDp) -> {
                markCurrentStateConfigured();
                layer.getStroke().setWidthDp(widthDp);
                layer.getStroke().setDashWidthDp(dashWidthDp);
                layer.getStroke().setDashGapDp(dashGapDp);
                updatePreviewAndXml();
            });
            dialog.show();
        });

        // Set Custom Corners Dialog
        findViewById(R.id.btn_set_custom_corners).setOnClickListener(v -> {
            LayerModel layer = getCurrentLayer();
            CustomCornersDialog dialog = new CustomCornersDialog(this, layer.getCorners(),
                    (tl, tr, bl, br, linked) -> {
                        markCurrentStateConfigured();
                        layer.getCorners().setCorners(tl, tr, bl, br, linked);
                        updatePreviewAndXml();
                    }
            );
            dialog.setLiveListener((tl, tr, bl, br, linked) -> {
                markCurrentStateConfigured();
                layer.getCorners().setCorners(tl, tr, bl, br, linked);
                updatePreviewAndXml();
            });
            dialog.show();
        });

        // Bottom Action Buttons
        findViewById(R.id.btn_copy_code).setOnClickListener(v -> copyXmlToClipboard());
        findViewById(R.id.btn_save_history).setOnClickListener(v -> saveToHistory());
        findViewById(R.id.btn_download_xml).setOnClickListener(v -> downloadXmlFile());
        findViewById(R.id.btn_share_export).setOnClickListener(v -> shareXml());
    }

    private void markCurrentStateConfigured() {
        getCurrentStateModel().setActive(true);
    }

    private void switchState(String stateKey) {
        currentState = stateKey;
        updateTabsSelection();
        updateStateFrameSelection();
        updateUiForCurrentState();
        // Switching state does NOT auto-configure it!
    }

    private void updateTabsSelection() {
        boolean isNorm = StateModel.STATE_NORMAL.equals(currentState);
        boolean isChk = StateModel.STATE_CHECKED.equals(currentState);
        boolean isPrs = StateModel.STATE_PRESSED.equals(currentState);

        tabNormal.setSelected(isNorm);
        tabChecked.setSelected(isChk);
        tabPressed.setSelected(isPrs);
    }

    private void updateStateFrameSelection() {
        boolean isNorm = StateModel.STATE_NORMAL.equals(currentState);
        boolean isChk = StateModel.STATE_CHECKED.equals(currentState);
        boolean isPrs = StateModel.STATE_PRESSED.equals(currentState);

        boxFrameNormal.setBackgroundResource(isNorm ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFrameChecked.setBackgroundResource(isChk ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
        boxFramePressed.setBackgroundResource(isPrs ? R.drawable.morsalin_preview_frame : R.drawable.morsalin_preview_frame_inactive);
    }

    private StateModel getCurrentStateModel() {
        StateModel state = stateMap.get(currentState);
        if (state == null) {
            state = new StateModel(currentState);
            state.setActive(false);
            stateMap.put(currentState, state);
        }
        return state;
    }

    private LayerModel getCurrentLayer() {
        return getCurrentStateModel().getLayers().get(0);
    }

    private void updateUiForCurrentState() {
        LayerModel layer = getCurrentLayer();
        boolean hasSolid = layer.getSolidColor() != null && !layer.getSolidColor().isEmpty() && !layer.getSolidColor().equals("#00000000");
        boolean hasStroke = layer.getStroke().getWidthDp() > 0 && layer.getStroke().getColor() != null && !layer.getStroke().getColor().isEmpty() && !layer.getStroke().getColor().equals("#00000000");

        applyColorBadge(tvBgColorHex, hasSolid ? layer.getSolidColor() : null, "None");

        if (hasStroke) {
            applyColorBadge(tvStrokeColorHex, layer.getStroke().getColor(), "None (0dp)");
            tvStrokeColorHex.setText(layer.getStroke().getColor() + " (" + layer.getStroke().getWidthDp() + "dp)");
        } else {
            tvStrokeColorHex.setText("None (0dp)");
            tvStrokeColorHex.setTextColor(getColor(R.color.morsalin_text_muted));
            tvStrokeColorHex.setBackgroundResource(R.drawable.morsalin_code_bg);
        }
    }

    private void applyColorBadge(TextView tv, String hexColor, String defaultLabel) {
        tv.setBackgroundResource(R.drawable.morsalin_code_bg);
        if (hexColor == null || hexColor.isEmpty() || hexColor.equals("#00000000")) {
            tv.setText(defaultLabel);
            tv.setTextColor(getColor(R.color.morsalin_text_muted));
        } else {
            tv.setText(hexColor);
            tv.setTextColor(getColor(R.color.morsalin_cyan));
        }
    }

    private boolean isLightColor(int color) {
        if (Color.alpha(color) < 80) return false;
        double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0;
        return darkness < 0.45;
    }

    private boolean isStateConfigured(StateModel sm) {
        if (sm == null || !sm.isActive()) return false;
        LayerModel l = sm.getLayers().get(0);
        boolean hasColor = l.getSolidColor() != null && !l.getSolidColor().equals("#00000000");
        boolean hasStroke = l.getStroke() != null && l.getStroke().getWidthDp() > 0;
        boolean hasCorners = l.getCorners() != null && (l.getCorners().getTopLeftDp() > 0
                || l.getCorners().getTopRightDp() > 0
                || l.getCorners().getBottomLeftDp() > 0
                || l.getCorners().getBottomRightDp() > 0);
        return hasColor || hasStroke || hasCorners;
    }

    private boolean isAnyStateConfigured() {
        for (StateModel sm : stateMap.values()) {
            if (isStateConfigured(sm)) return true;
        }
        return false;
    }

    private void updatePreviewOnly() {
        StateModel normal = stateMap.get(StateModel.STATE_NORMAL);
        StateModel checked = stateMap.get(StateModel.STATE_CHECKED);
        StateModel pressed = stateMap.get(StateModel.STATE_PRESSED);

        if (StateModel.STATE_NORMAL.equals(currentState) && isStateConfigured(normal)) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, normal.getLayers()));
        } else if (StateModel.STATE_CHECKED.equals(currentState) && isStateConfigured(checked)) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, checked.getLayers()));
        } else if (StateModel.STATE_PRESSED.equals(currentState) && isStateConfigured(pressed)) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, pressed.getLayers()));
        }
    }

    private void updatePreviewAndXml() {
        // Normal State Preview
        StateModel normal = stateMap.get(StateModel.STATE_NORMAL);
        if (isStateConfigured(normal)) {
            cardNormal.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, normal.getLayers()));
        } else {
            cardNormal.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Checked State Preview
        StateModel checked = stateMap.get(StateModel.STATE_CHECKED);
        if (isStateConfigured(checked)) {
            cardChecked.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, checked.getLayers()));
        } else {
            cardChecked.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Pressed State Preview
        StateModel pressed = stateMap.get(StateModel.STATE_PRESSED);
        if (isStateConfigured(pressed)) {
            cardPressed.setBackground(LiveDrawableRenderer.createLayerListDrawable(this, pressed.getLayers()));
        } else {
            cardPressed.setBackgroundResource(R.drawable.morsalin_preview_placeholder);
        }

        // Labels stay visible centered inside preview boxes
        tvPreviewNormalLabel.setVisibility(View.VISIBLE);
        tvPreviewCheckedLabel.setVisibility(View.VISIBLE);
        tvPreviewPressedLabel.setVisibility(View.VISIBLE);

        // XML Code Generation
        if (!isAnyStateConfigured()) {
            // Nothing is configured yet: keep completely blank placeholder comment!
            etGeneratedXml.setText(XML_INITIAL_PLACEHOLDER);
        } else {
            // Generate XML with only the states configured by user
            String xml;
            if (isRippleMode) {
                StateModel norm = stateMap.get(StateModel.STATE_NORMAL);
                LayerModel contentLayer = (norm != null && !norm.getLayers().isEmpty()) ? norm.getLayers().get(0) : null;
                xml = XmlGenerator.generateRippleXml("#4000FFFF", contentLayer, null);
            } else {
                xml = XmlGenerator.generateSelectorXml(stateMap);
            }
            xml = XmlFormatter.formatXml(xml);
            etGeneratedXml.setText(xml);
        }
    }

    private void copyXmlToClipboard() {
        String xml = etGeneratedXml.getText().toString();
        if (xml.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_content_copy, "No XML Yet", "Configure a layer or color to generate XML code first.");
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Shape XML", xml);
        cm.setPrimaryClip(clip);
        MorsalinToast.showCopy(this, "Normal Shape XML");
    }

    private void saveToHistory() {
        String xml = etGeneratedXml.getText().toString();
        if (xml.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_save, "No XML Yet", "Configure a layer or color first.");
            return;
        }
        XmlProject project = new XmlProject(
                "Normal Shape " + (System.currentTimeMillis() % 1000),
                XmlProject.TYPE_NORMAL,
                xml
        );
        historyManager.saveProject(project);
        MorsalinToast.show(this, R.drawable.ic_save, "Saved to History", "Project successfully added to History.");
    }

    private void downloadXmlFile() {
        String xml = etGeneratedXml.getText().toString();
        if (xml.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_download, "No XML Yet", "Configure a layer or color first.");
            return;
        }
        FileExporter.exportXmlToFile(this, "MS MORSALIN_BG.xml", xml);
        MorsalinToast.showDownload(this, "MS MORSALIN_BG.xml");
    }

    private void shareXml() {
        String xml = etGeneratedXml.getText().toString();
        if (xml.equals(XML_INITIAL_PLACEHOLDER)) {
            MorsalinToast.show(this, R.drawable.ic_share, "No XML Yet", "Configure a layer or color first.");
            return;
        }
        ShareHelper.shareXmlText(this, xml, "Share Normal Shape XML");
    }

    private void showResetDialog() {
        MorsalinDialogHelper.showResetDialog(
                this,
                "Reset Shape",
                "Are you sure you want to reset and clear all colors?",
                () -> {
                    initBlankStates();
                    currentState = StateModel.STATE_NORMAL;
                    updateTabsSelection();
                    updateStateFrameSelection();
                    updateUiForCurrentState();
                    updatePreviewAndXml();
                    MorsalinToast.show(this, R.drawable.ic_refresh, "Reset Complete", "All states cleared to initial blank state.");
                }
        );
    }
}
