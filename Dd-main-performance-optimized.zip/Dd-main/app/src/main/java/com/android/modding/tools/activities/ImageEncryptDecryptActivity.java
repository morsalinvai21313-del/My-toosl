package com.android.modding.tools.activities;

import com.android.modding.tools.R;
import com.android.modding.tools.helpers.ConversionAnimationView;
import com.android.modding.tools.helpers.FileExporter;
import com.android.modding.tools.helpers.GeneratedPackageExporter;
import com.android.modding.tools.helpers.GlobalTouchParticleManager;
import com.android.modding.tools.helpers.MorsalinToast;
import com.android.modding.tools.helpers.TransitionAnimationManager;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class ImageEncryptDecryptActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private ScrollView scrollMain;
    private View cardPreview;
    private ImageView ivPreview;
    private TextView tvFileMeta;
    private EditText etKey;

    // Processing animation panel (REUSING EXACT SAME COMPONENT)
    private LinearLayout layoutPkgAnimPanel;
    private TextView tvPkgAnimBadge;
    private TextView tvPkgAnimStatus;
    private ConversionAnimationView viewPkgConversionAnim;

    // Result card
    private View cardResult;
    private ImageView ivResultPreview;
    private TextView tvResultInfo;

    private byte[] loadedBytes = null;
    private String loadedFileName = "image.png";
    private boolean isLoadedEncrypted = false;

    private byte[] resultBytes = null;
    private Bitmap resultBitmap = null;
    private String resultFileName = "output.menc";

    private ActivityResultLauncher<String> pickImageLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_encrypt_decrypt);

        GlobalTouchParticleManager.attach(this);

        initLauncher();
        initViews();
    }

    private void initLauncher() {
        pickImageLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        handlePickedUri(uri);
                    }
                }
        );
    }

    private void initViews() {
        scrollMain = findViewById(R.id.scroll_ied_main);

        findViewById(R.id.btn_ied_back).setOnClickListener(v -> {
            finish();
            TransitionAnimationManager.applyBackward(this);
        });

        findViewById(R.id.btn_ied_reset).setOnClickListener(v -> resetState());

        findViewById(R.id.btn_ied_pick_image).setOnClickListener(v -> {
            try {
                pickImageLauncher.launch("*/*");
            } catch (Exception e) {
                MorsalinToast.show(this, R.drawable.ic_download, "Error", "Picker error: " + e.getMessage());
            }
        });

        findViewById(R.id.btn_ied_sample_image).setOnClickListener(v -> loadSampleImage());
        Button btnSampleEnc = findViewById(R.id.btn_ied_sample_encrypted);
        if (btnSampleEnc != null) {
            btnSampleEnc.setOnClickListener(v -> loadSampleEncrypted());
        }

        cardPreview = findViewById(R.id.card_ied_preview);
        ivPreview = findViewById(R.id.iv_ied_preview);
        tvFileMeta = findViewById(R.id.tv_ied_file_meta);
        etKey = findViewById(R.id.et_ied_key);

        layoutPkgAnimPanel = findViewById(R.id.layout_pkg_anim_panel);
        tvPkgAnimBadge = findViewById(R.id.tv_pkg_anim_badge);
        tvPkgAnimStatus = findViewById(R.id.tv_pkg_anim_status);
        viewPkgConversionAnim = findViewById(R.id.view_pkg_conversion_anim);

        cardResult = findViewById(R.id.card_ied_result);
        ivResultPreview = findViewById(R.id.iv_ied_result_preview);
        tvResultInfo = findViewById(R.id.tv_ied_result_info);

        findViewById(R.id.btn_ied_encrypt).setOnClickListener(v -> startCryptoProcess(true));
        findViewById(R.id.btn_ied_decrypt).setOnClickListener(v -> startCryptoProcess(false));

        findViewById(R.id.btn_ied_save).setOnClickListener(v -> saveResultFile());
        findViewById(R.id.btn_ied_share).setOnClickListener(v -> shareResultFile());
    }

    private void loadSampleImage() {
        try {
            InputStream is = getResources().openRawResource(R.drawable.hero_encrypt_decrypt);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = is.read(buf)) != -1) {
                baos.write(buf, 0, r);
            }
            is.close();

            loadedBytes = baos.toByteArray();
            loadedFileName = "sample_security.jpg";
            isLoadedEncrypted = false;

            Bitmap bmp = BitmapFactory.decodeByteArray(loadedBytes, 0, loadedBytes.length);
            ivPreview.setImageBitmap(bmp);
            cardPreview.setVisibility(View.VISIBLE);
            tvFileMeta.setText("Sample Image • " + (loadedBytes.length / 1024) + " KB • Ready to Encrypt");

            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Sample Image Loaded",
                    "Ready to encrypt with AES-256!");

        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Error", "Could not load sample: " + e.getMessage());
        }
    }

    private void loadSampleEncrypted() {
        try {
            InputStream is = getResources().openRawResource(R.drawable.hero_encrypt_decrypt);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = is.read(buf)) != -1) {
                baos.write(buf, 0, r);
            }
            is.close();

            byte[] raw = baos.toByteArray();
            String defaultKey = "Morsalin2026";
            if (etKey != null && !etKey.getText().toString().isEmpty()) {
                defaultKey = etKey.getText().toString();
            } else if (etKey != null) {
                etKey.setText(defaultKey);
            }

            loadedBytes = executeAesEncrypt(raw, defaultKey);
            loadedFileName = "sample_encrypted.menc";
            isLoadedEncrypted = true;

            ivPreview.setImageResource(R.drawable.ic_code_convert);
            cardPreview.setVisibility(View.VISIBLE);
            tvFileMeta.setText("Encrypted Cipher Payload • " + (loadedBytes.length / 1024) + " KB • Ready to Decrypt with '" + defaultKey + "'");

            MorsalinToast.show(this, R.drawable.ic_code_convert, "Encrypted Sample Loaded",
                    "Ready to decrypt! Key: " + defaultKey);

        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Error", "Could not create sample: " + e.getMessage());
        }
    }

    private boolean isPlainImageBytes(byte[] bytes) {
        if (bytes == null || bytes.length < 4) return false;
        // PNG: 89 50 4E 47
        if ((bytes[0] & 0xFF) == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47) return true;
        // JPEG: FF D8 FF
        if ((bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 && (bytes[2] & 0xFF) == 0xFF) return true;
        // GIF: 47 49 46 38
        if (bytes[0] == 'G' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == '8') return true;
        // WebP: RIFF .... WEBP
        if (bytes.length >= 12 && bytes[0] == 'R' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == 'F'
                && bytes[8] == 'W' && bytes[9] == 'E' && bytes[10] == 'B' && bytes[11] == 'P') return true;
        return false;
    }

    private void handlePickedUri(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) return;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = is.read(buf)) != -1) {
                baos.write(buf, 0, r);
            }
            is.close();

            loadedBytes = baos.toByteArray();
            loadedFileName = "SelectedImage_" + System.currentTimeMillis();

            // Try decoding as bitmap
            Bitmap bmp = BitmapFactory.decodeByteArray(loadedBytes, 0, loadedBytes.length);
            cardPreview.setVisibility(View.VISIBLE);

            if (bmp != null) {
                isLoadedEncrypted = false;
                ivPreview.setImageBitmap(bmp);
                tvFileMeta.setText("Valid Image (" + bmp.getWidth() + "x" + bmp.getHeight() + ") • "
                        + (loadedBytes.length / 1024) + " KB • Ready to Encrypt");
            } else {
                isLoadedEncrypted = true;
                ivPreview.setImageResource(R.drawable.ic_code_convert);
                tvFileMeta.setText("Encrypted Binary Payload • " + (loadedBytes.length / 1024) + " KB • Ready to Decrypt");
            }

            MorsalinToast.show(this, R.drawable.ic_code_convert, "File Loaded",
                    (loadedBytes.length / 1024) + " KB ready for processing.");

        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Read Error", e.getMessage());
        }
    }

    private void startCryptoProcess(boolean encrypt) {
        if (loadedBytes == null || loadedBytes.length == 0) {
            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Select File First", "Please select a file first.");
            return;
        }

        if (!encrypt && isPlainImageBytes(loadedBytes)) {
            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Already an Image",
                    "This is an unencrypted image! Click 'ENCRYPT IMAGE' to protect it with AES-256.");
            return;
        }

        String key = etKey.getText().toString();
        if (key.isEmpty()) key = "Morsalin2026";

        cardResult.setVisibility(View.GONE);
        layoutPkgAnimPanel.setVisibility(View.VISIBLE);
        layoutPkgAnimPanel.setAlpha(0f);
        layoutPkgAnimPanel.animate().alpha(1f).setDuration(200).start();

        // Configure existing ConversionAnimationView
        viewPkgConversionAnim.loadSelectedFromPrefs();
        viewPkgConversionAnim.setLanguages(encrypt ? "RAW.IMAGE" : "ENC.CIPHER", encrypt ? "AES.ENCRYPTED" : "PNG.IMAGE");
        tvPkgAnimBadge.setText("ENGINE: " + viewPkgConversionAnim.getActiveStyleTitle().toUpperCase());

        final String statusText1 = encrypt ? "Analyzing image raw bytes..." : "Reading encrypted cipher payload...";
        final String statusText2 = encrypt ? "Deriving AES-256 PBKDF2 cryptographic key..." : "Verifying HMAC authentication & IV vector...";
        final String statusText3 = encrypt ? "Executing AES/CBC/PKCS5 encryption..." : "Executing AES/CBC decryption sequence...";
        final String statusText4 = encrypt ? "Finalizing encrypted image package (100%)" : "Reconstructing Bitmap image (100%)";

        viewPkgConversionAnim.updateState(15, statusText1);
        tvPkgAnimStatus.setText(statusText1);
        viewPkgConversionAnim.startAnimationLoop();

        scrollMain.post(() -> scrollMain.smoothScrollTo(0, layoutPkgAnimPanel.getTop() - 20));

        mainHandler.postDelayed(() -> {
            viewPkgConversionAnim.updateState(45, statusText2);
            tvPkgAnimStatus.setText(statusText2);
        }, 400);

        mainHandler.postDelayed(() -> {
            viewPkgConversionAnim.updateState(75, statusText3);
            tvPkgAnimStatus.setText(statusText3);
        }, 900);

        mainHandler.postDelayed(() -> {
            viewPkgConversionAnim.updateState(100, statusText4);
            tvPkgAnimStatus.setText(statusText4);
        }, 1450);

        // Run background crypto
        final String finalKey = key;
        executor.execute(() -> {
            try {
                if (encrypt) {
                    resultBytes = executeAesEncrypt(loadedBytes, finalKey);
                    resultBitmap = null;
                    resultFileName = "Encrypted_Image_" + System.currentTimeMillis() + ".menc";
                } else {
                    resultBytes = executeAesDecrypt(loadedBytes, finalKey);
                    resultBitmap = BitmapFactory.decodeByteArray(resultBytes, 0, resultBytes.length);
                    resultFileName = "Decrypted_Image_" + System.currentTimeMillis() + ".png";
                }

                mainHandler.postDelayed(() -> onCryptoFinished(true, encrypt, null), 1900);

            } catch (Exception e) {
                mainHandler.postDelayed(() -> onCryptoFinished(false, encrypt, e.getMessage()), 1900);
            }
        });
    }

    private void onCryptoFinished(boolean success, boolean encrypt, String error) {
        layoutPkgAnimPanel.setVisibility(View.GONE);

        if (!success) {
            String cleanMsg = "Invalid security key or corrupted cipher file.";
            if (error != null) {
                if (error.contains("WRONG_FINAL_BLOCK_LENGTH") || error.contains("bad padding") || error.contains("corrupted") || error.contains("Pad block")) {
                    cleanMsg = "Incorrect security key! Please check your passphrase.";
                } else if (error.contains("Payload too short") || error.contains("too short")) {
                    cleanMsg = "File is not an encrypted payload or is corrupted.";
                } else {
                    cleanMsg = error;
                }
            }
            MorsalinToast.show(this, R.drawable.ic_refresh_reset,
                    (encrypt ? "Encryption Failed" : "Decryption Failed"), cleanMsg);
            return;
        }

        cardResult.setVisibility(View.VISIBLE);
        cardResult.setAlpha(0f);
        cardResult.animate().alpha(1f).setDuration(250).start();

        if (encrypt) {
            ivResultPreview.setImageResource(R.drawable.hero_encrypt_decrypt);
            tvResultInfo.setText("Encrypted with AES-256 • Size: " + (resultBytes.length / 1024) + " KB • Status: Locked");
            MorsalinToast.show(this, R.drawable.ic_code_convert, "Image Encrypted!",
                    "Protected with military-grade AES-256!");
        } else {
            if (resultBitmap != null) {
                ivResultPreview.setImageBitmap(resultBitmap);
                tvResultInfo.setText("Decrypted Image (" + resultBitmap.getWidth() + "x" + resultBitmap.getHeight() + ") • "
                        + (resultBytes.length / 1024) + " KB • Status: Unlocked");
            } else {
                ivResultPreview.setImageResource(R.drawable.ic_code_convert);
                tvResultInfo.setText("Decrypted Payload (" + (resultBytes.length / 1024) + " KB)");
            }
            MorsalinToast.show(this, R.drawable.ic_cat_layout, "Image Decrypted!",
                    "Decrypted image ready to view & save!");
        }

        scrollMain.post(() -> scrollMain.smoothScrollTo(0, cardResult.getTop() - 20));
    }

    private byte[] executeAesEncrypt(byte[] raw, String keyStr) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = sha.digest(keyStr.getBytes(StandardCharsets.UTF_8));
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
        byte[] cipherBytes = cipher.doFinal(raw);

        byte[] combined = new byte[iv.length + cipherBytes.length];
        System.arraycopy(iv, 0, combined, 0, iv.length);
        System.arraycopy(cipherBytes, 0, combined, iv.length, cipherBytes.length);
        return combined;
    }

    private byte[] executeAesDecrypt(byte[] cipherData, String keyStr) throws Exception {
        if (cipherData.length < 17) throw new IllegalArgumentException("Payload too short.");

        byte[] iv = Arrays.copyOfRange(cipherData, 0, 16);
        byte[] cipherBytes = Arrays.copyOfRange(cipherData, 16, cipherData.length);

        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] keyBytes = sha.digest(keyStr.getBytes(StandardCharsets.UTF_8));
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
        return cipher.doFinal(cipherBytes);
    }

    private void saveResultFile() {
        if (resultBytes == null || resultBytes.length == 0) return;
        String mime = resultFileName.endsWith(".png") ? "image/png" : "application/octet-stream";
        FileExporter.ExportResult res = GeneratedPackageExporter.saveSingleFileToDownloads(
                this, "MorsalinXML/EncryptedImages", resultFileName, mime, resultBytes);
        MorsalinToast.show(this, R.drawable.ic_download,
                res.success ? "File Saved" : "Save Status", res.message);
    }

    private void shareResultFile() {
        if (resultBytes == null || resultBytes.length == 0) return;
        try {
            File cacheFile = new File(getCacheDir(), resultFileName);
            try (FileOutputStream fos = new FileOutputStream(cacheFile)) {
                fos.write(resultBytes);
            }
            Uri fileUri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", cacheFile);

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(resultFileName.endsWith(".png") ? "image/png" : "application/octet-stream");
            share.putExtra(Intent.EXTRA_STREAM, fileUri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Share Encrypted/Decrypted File"));
        } catch (Exception e) {
            MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Share Error", e.getMessage());
        }
    }

    private void resetState() {
        loadedBytes = null;
        resultBytes = null;
        resultBitmap = null;
        cardPreview.setVisibility(View.GONE);
        cardResult.setVisibility(View.GONE);
        layoutPkgAnimPanel.setVisibility(View.GONE);
        MorsalinToast.show(this, R.drawable.ic_refresh_reset, "Reset", "State cleared.");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        TransitionAnimationManager.applyBackward(this);
    }
}
