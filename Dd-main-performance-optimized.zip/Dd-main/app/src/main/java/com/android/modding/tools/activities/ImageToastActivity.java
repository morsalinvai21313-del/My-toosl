package com.android.modding.tools.activities;

import com.android.modding.tools.toastmaker.ToastConfig;

/**
 * Image / Badge Toast Maker.
 * Focused on two-line notification banners with custom emblem badges (Crown, Shield, Rocket, Fire, Diamond)
 * and bundled badge PNG assets compiled into Dalvik classes.dex executables and packages.
 */
public class ImageToastActivity extends BaseToastMakerActivity {

    @Override
    protected ToastConfig getInitialConfig() {
        return ToastConfig.createImageDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Image & Badge Toast Maker";
    }

    @Override
    protected boolean showGalleryPickerSection() {
        return true;
    }

    @Override
    protected boolean showEmblemSection() {
        return true;
    }

    @Override
    protected boolean showTitleInput() {
        return true;
    }

    @Override
    protected boolean showAnimationSection() {
        return false;
    }

    @Override
    protected boolean showBase64Section() {
        return false;
    }

    @Override
    protected boolean showGradientSection() {
        return true;
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("👑 EMBLEM BADGE QUICK PRESETS");
        }

        if (btnPreset1 != null) {
            btnPreset1.setText("Crown VIP");
            btnPreset1.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createImageDefault();
                p.toastName = "Badge_Crown_VIP";
                p.titleText = "VIP ACTIVATED";
                p.messageText = "Modded by Morsalin • All Features Unlocked";
                p.iconType = "CROWN";
                p.iconEmoji = "👑";
                p.iconBgHex = "#FFD700";
                p.bgHex = "#1C1427";
                p.bgGradientEndHex = "#401850";
                p.borderHex = "#FFD700";
                p.titleColorHex = "#FFD700";
                p.animMode = "Slide";
                applyPreset(p, "Crown VIP");
            });
        }

        if (btnPreset2 != null) {
            btnPreset2.setText("Modder Shield");
            btnPreset2.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createImageDefault();
                p.toastName = "Badge_Modder_Shield";
                p.titleText = "SECURITY ACTIVE";
                p.messageText = "Real-time Anti-Detect Shield Running";
                p.iconType = "SHIELD";
                p.iconEmoji = "🛡️";
                p.iconBgHex = "#00E5FF";
                p.bgHex = "#031B28";
                p.bgGradientEndHex = "#0A3D56";
                p.borderHex = "#00E5FF";
                p.titleColorHex = "#00E5FF";
                p.animMode = "Bounce";
                applyPreset(p, "Modder Shield");
            });
        }

        if (btnPreset3 != null) {
            btnPreset3.setText("Rocket Speed");
            btnPreset3.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createImageDefault();
                p.toastName = "Badge_Rocket_Speed";
                p.titleText = "TURBO BOOST";
                p.messageText = "60 FPS Refresh Rate & Network Accelerated";
                p.iconType = "ROCKET";
                p.iconEmoji = "🚀";
                p.iconBgHex = "#FF5722";
                p.bgHex = "#260E04";
                p.bgGradientEndHex = "#4E1D09";
                p.borderHex = "#FF5722";
                p.titleColorHex = "#FF8A65";
                p.animMode = "Zoom";
                applyPreset(p, "Rocket Speed");
            });
        }

        if (btnPreset4 != null) {
            btnPreset4.setText("Fire Flame");
            btnPreset4.setOnClickListener(v -> {
                ToastConfig p = ToastConfig.createImageDefault();
                p.toastName = "Badge_Fire_Flame";
                p.titleText = "GOD MODE ACTIVE";
                p.messageText = "Infinite Stamina & Power Multiplier [x10]";
                p.iconType = "FIRE";
                p.iconEmoji = "🔥";
                p.iconBgHex = "#FF1744";
                p.bgHex = "#210006";
                p.bgGradientEndHex = "#520010";
                p.borderHex = "#FF1744";
                p.titleColorHex = "#FF5252";
                p.animMode = "Bounce";
                applyPreset(p, "Fire Flame");
            });
        }
    }
}
