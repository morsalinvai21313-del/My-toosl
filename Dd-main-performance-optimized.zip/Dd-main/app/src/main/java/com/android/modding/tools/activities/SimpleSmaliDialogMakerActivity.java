package com.android.modding.tools.activities;

import android.view.View;
import com.android.modding.tools.dialogmaker.DialogConfig;

/**
 * Simple Smali Dialog Maker.
 * Focused on fast, clean, minimal Smali alert dialogs with pure Dalvik bytecode.
 */
public class SimpleSmaliDialogMakerActivity extends BaseDialogMakerActivity {

    @Override
    protected DialogConfig getInitialConfig() {
        return DialogConfig.createSimpleSmaliDefault();
    }

    @Override
    protected String getScreenTitle() {
        return "Simple Smali Dialog Maker";
    }

    @Override
    protected void setupPresets() {
        if (tvPresetsCardTitle != null) {
            tvPresetsCardTitle.setText("⚡ SIMPLE SMALI QUICK PRESETS");
        }
        if (btnPreset1 != null) {
            btnPreset1.setText("Clean Minimal");
            btnPreset1.setOnClickListener(v -> applyPreset(createCleanMinimalPreset(), "Clean Minimal"));
        }
        if (btnPreset2 != null) {
            btnPreset2.setText("Slate Dark");
            btnPreset2.setOnClickListener(v -> applyPreset(createSlateDarkPreset(), "Slate Dark"));
        }
        if (btnPreset3 != null) {
            btnPreset3.setText("Classic Alert");
            btnPreset3.setOnClickListener(v -> applyPreset(createClassicAlertPreset(), "Classic Alert"));
        }
        if (btnPreset4 != null) {
            btnPreset4.setText("Quick Confirm");
            btnPreset4.setOnClickListener(v -> applyPreset(createQuickConfirmPreset(), "Quick Confirm"));
        }
    }

    @Override
    protected void setupCustomMakerOptions() {
        if (layoutProfilePhotoSection != null) layoutProfilePhotoSection.setVisibility(View.GONE);
        if (layoutVectorIconSection != null) layoutVectorIconSection.setVisibility(View.VISIBLE);
        if (tvEmblemSectionTitle != null) tvEmblemSectionTitle.setText("4. MINIMAL VECTOR EMBLEM (OPTIONAL)");
    }

    private DialogConfig createCleanMinimalPreset() {
        DialogConfig c = DialogConfig.createSimpleSmaliDefault();
        c.titleText = "Notice";
        c.messageText = "Operation finished successfully. Press OK to proceed.";
        c.buttonCount = 1;
        c.btn3Text = "OK";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.bgHex = "#0F1A24";
        c.borderHex = "#00E5FF";
        c.openAnimMode = "Fade";
        return c;
    }

    private DialogConfig createSlateDarkPreset() {
        DialogConfig c = DialogConfig.createSimpleSmaliDefault();
        c.titleText = "System Status";
        c.messageText = "Background service has been initialized without errors.";
        c.buttonCount = 2;
        c.btn1Text = "Cancel";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Continue";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.bgHex = "#0B131B";
        c.borderHex = "#94A3B8";
        c.openAnimMode = "Slide";
        return c;
    }

    private DialogConfig createClassicAlertPreset() {
        DialogConfig c = DialogConfig.createSimpleSmaliDefault();
        c.titleText = "Security Alert";
        c.messageText = "Please confirm this operation before proceeding with installation.";
        c.buttonCount = 2;
        c.btn1Text = "Dismiss";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Proceed";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.hasImage = true;
        c.iconName = "SHIELD";
        c.iconResIndex = 0;
        c.borderHex = "#FFB703";
        c.openAnimMode = "Bounce";
        return c;
    }

    private DialogConfig createQuickConfirmPreset() {
        DialogConfig c = DialogConfig.createSimpleSmaliDefault();
        c.titleText = "Confirm Action";
        c.messageText = "Are you sure you want to apply the new configuration settings?";
        c.buttonCount = 2;
        c.btn1Text = "No";
        c.btn1Action = DialogConfig.ACTION_DISMISS;
        c.btn3Text = "Yes";
        c.btn3Action = DialogConfig.ACTION_DISMISS;
        c.borderHex = "#00FF88";
        c.openAnimMode = "Zoom";
        return c;
    }
}
