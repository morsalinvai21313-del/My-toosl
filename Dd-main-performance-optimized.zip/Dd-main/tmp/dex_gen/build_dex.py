import os
import subprocess

SRC_DIR = "/tmp/dex_gen/src/com/morsalin/xmlcreator"
CLASSES_DIR = "/tmp/dex_gen/classes"
OUT_DIR = "/tmp/dex_gen/out"
ASSETS_DIR = "/app/applet/app/src/main/assets/dex_templates"

os.makedirs(SRC_DIR, exist_ok=True)
os.makedirs(CLASSES_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(ASSETS_DIR, exist_ok=True)

# 1. MorsalinCustomDialog.java
custom_dialog_code = '''package com.morsalin.xmlcreator;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MorsalinCustomDialog {

    public static final String MORSALIN_CONFIG = "MORSALIN_B64_CFG:''' + (' ' * (2048 - len('MORSALIN_B64_CFG:'))) + '''";

    public static void show(final Context context) {
        if (context == null) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                safeShowDialog(context);
            }
        });
    }

    public static void show(final Activity activity) {
        show((Context) activity);
    }

    public static void show() {
        // Safe no-op if context not provided
    }

    public static void init(Context context) {
        show(context);
    }

    public static void create(Context context) {
        show(context);
    }

    public static void display(Context context) {
        show(context);
    }

    public static void display(Activity activity) {
        show((Context) activity);
    }

    private static void safeShowDialog(Context context) {
        try {
            if (context instanceof Activity) {
                Activity act = (Activity) context;
                if (act.isFinishing()) return;
                if (Build.VERSION.SDK_INT >= 17 && act.isDestroyed()) return;
            }

            String cfg = getConfig();
            String[] p = cfg.split("\\\\|", -1);
            String title = p.length > 0 && !p[0].isEmpty() ? p[0] : "Notice";
            String subtitle = p.length > 1 ? p[1] : "";
            String message = p.length > 2 ? p[2] : "";
            int buttonCount = p.length > 3 ? parseIntSafe(p[3], 1) : 1;
            String btn1Text = p.length > 4 && !p[4].isEmpty() ? p[4] : "OK";
            String btn2Text = p.length > 5 ? p[5] : "Cancel";
            String btn3Text = p.length > 6 ? p[6] : "More";
            final String btn1Url = p.length > 7 ? p[7] : "";
            final String btn2Url = p.length > 8 ? p[8] : "";
            final String btn3Url = p.length > 9 ? p[9] : "";
            String bgHex = p.length > 10 && !p[10].isEmpty() ? p[10] : "#1A2238";
            String borderHex = p.length > 11 && !p[11].isEmpty() ? p[11] : "#00E5FF";
            String btnBgHex = p.length > 12 && !p[12].isEmpty() ? p[12] : "#00E5FF";
            String titleHex = p.length > 13 && !p[13].isEmpty() ? p[13] : "#FFFFFF";
            String textHex = p.length > 14 && !p[14].isEmpty() ? p[14] : "#A0AEC0";
            int cornerRadiusDp = p.length > 15 ? parseIntSafe(p[15], 16) : 16;
            int borderWidthDp = p.length > 16 ? parseIntSafe(p[16], 2) : 2;
            int paddingDp = p.length > 17 ? parseIntSafe(p[17], 16) : 16;

            final Dialog dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

            LinearLayout root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            int pad = dpToPx(context, paddingDp);
            root.setPadding(pad, pad, pad, pad);

            GradientDrawable gd = new GradientDrawable();
            gd.setColor(parseColorSafe(bgHex, 0xFF1A2238));
            gd.setCornerRadius(dpToPx(context, cornerRadiusDp));
            gd.setStroke(dpToPx(context, borderWidthDp), parseColorSafe(borderHex, 0xFF00E5FF));
            root.setBackground(gd);

            TextView tvTitle = new TextView(context);
            tvTitle.setText(title);
            tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            tvTitle.setTextColor(parseColorSafe(titleHex, 0xFFFFFFFF));
            tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
            root.addView(tvTitle);

            if (!subtitle.isEmpty()) {
                TextView tvSub = new TextView(context);
                tvSub.setText(subtitle);
                tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tvSub.setTextColor(parseColorSafe(borderHex, 0xFF00E5FF));
                tvSub.setPadding(0, dpToPx(context, 4), 0, 0);
                root.addView(tvSub);
            }

            if (!message.isEmpty()) {
                TextView tvMsg = new TextView(context);
                tvMsg.setText(message);
                tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tvMsg.setTextColor(parseColorSafe(textHex, 0xFFA0AEC0));
                tvMsg.setPadding(0, dpToPx(context, 8), 0, dpToPx(context, 16));
                root.addView(tvMsg);
            }

            LinearLayout btnRow = new LinearLayout(context);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.END);
            btnRow.setPadding(0, dpToPx(context, 8), 0, 0);

            if (buttonCount >= 3 && !btn3Text.isEmpty()) {
                Button b3 = createStyledButton(context, btn3Text, "#334155", titleHex);
                b3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        openUrl(v.getContext(), btn3Url);
                    }
                });
                btnRow.addView(b3);
            }

            if (buttonCount >= 2 && !btn2Text.isEmpty()) {
                Button b2 = createStyledButton(context, btn2Text, "#1E293B", titleHex);
                b2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        openUrl(v.getContext(), btn2Url);
                    }
                });
                btnRow.addView(b2);
            }

            if (buttonCount >= 1 && !btn1Text.isEmpty()) {
                Button b1 = createStyledButton(context, btn1Text, btnBgHex, "#0B101E");
                b1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        openUrl(v.getContext(), btn1Url);
                    }
                });
                btnRow.addView(b1);
            }

            root.addView(btnRow);

            ScrollView sv = new ScrollView(context);
            sv.addView(root);

            dialog.setContentView(sv);
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                );
            }
            dialog.show();
        } catch (Throwable ignored) {}
    }

    private static Button createStyledButton(Context ctx, String text, String bgHex, String textHex) {
        Button b = new Button(ctx);
        try {
            b.setText(text);
            b.setTextColor(parseColorSafe(textHex, Color.WHITE));
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(parseColorSafe(bgHex, 0xFF00E5FF));
            bg.setCornerRadius(dpToPx(ctx, 8));
            b.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dpToPx(ctx, 38));
            lp.setMargins(dpToPx(ctx, 4), 0, dpToPx(ctx, 4), 0);
            b.setLayoutParams(lp);
        } catch (Throwable ignored) {}
        return b;
    }

    private static void openUrl(Context ctx, String url) {
        if (url == null || url.trim().isEmpty() || ctx == null) return;
        try {
            String u = url.trim();
            if (!u.startsWith("http://") && !u.startsWith("https://") && !u.startsWith("tg://")) {
                u = "https://" + u;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
        } catch (Throwable ignored) {}
    }

    private static String getConfig() {
        try {
            String s = MORSALIN_CONFIG;
            if (s.startsWith("MORSALIN_B64_CFG:")) {
                String b64 = s.substring("MORSALIN_B64_CFG:".length()).trim();
                if (!b64.isEmpty()) {
                    byte[] data = Base64.decode(b64, Base64.DEFAULT);
                    return new String(data, "UTF-8");
                }
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private static int parseColorSafe(String hex, int fallback) {
        try { return Color.parseColor(hex); } catch (Throwable e) { return fallback; }
    }

    private static int parseIntSafe(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Throwable e) { return fallback; }
    }

    private static int dpToPx(Context ctx, int dp) {
        try {
            return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, ctx.getResources().getDisplayMetrics());
        } catch (Throwable e) {
            return dp * 2;
        }
    }
}
'''

# 2. MorsalinNotificationHelper.java
notif_helper_code = '''package com.morsalin.xmlcreator;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;

public class MorsalinNotificationHelper {

    public static final String MORSALIN_CONFIG = "MORSALIN_B64_CFG:''' + (' ' * (2048 - len('MORSALIN_B64_CFG:'))) + '''";

    public static void sendNotification(Context context) {
        safeNotify(context);
    }

    public static void sendNotification(Activity activity) {
        safeNotify((Context) activity);
    }

    public static void show(Context context) {
        safeNotify(context);
    }

    public static void show(Activity activity) {
        safeNotify((Context) activity);
    }

    public static void notify(Context context) {
        safeNotify(context);
    }

    public static void notify(Activity activity) {
        safeNotify((Context) activity);
    }

    public static void send(Context context) {
        safeNotify(context);
    }

    public static void send(Activity activity) {
        safeNotify((Context) activity);
    }

    private static void safeNotify(Context context) {
        if (context == null) return;
        try {
            String cfg = getConfig();
            String[] p = cfg.split("\\\\|", -1);
            String title = p.length > 1 && !p[1].isEmpty() ? p[1] : "Morsalin Notification";
            String desc = p.length > 2 ? p[2] : "Active notification message";
            String accentHex = p.length > 3 && !p[3].isEmpty() ? p[3] : "#00E5FF";
            int actionCount = p.length > 5 ? parseIntSafe(p[5], 0) : 0;
            String act1Label = p.length > 6 ? p[6] : "Open";
            String act2Label = p.length > 7 ? p[7] : "View";
            String act3Label = p.length > 8 ? p[8] : "More";
            String mainUrl = p.length > 9 ? p[9] : "";
            String act1Url = p.length > 10 ? p[10] : "";
            String act2Url = p.length > 11 ? p[11] : "";
            String act3Url = p.length > 12 ? p[12] : "";

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            String channelId = "morsalin_notif_channel";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    NotificationChannel channel = new NotificationChannel(
                        channelId, "Notifications", NotificationManager.IMPORTANCE_HIGH);
                    channel.enableLights(true);
                    channel.setLightColor(parseColorSafe(accentHex, 0xFF00E5FF));
                    nm.createNotificationChannel(channel);
                } catch (Throwable ignored) {}
            }

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, channelId);
            } else {
                builder = new Notification.Builder(context);
            }

            int iconRes = 0;
            try {
                if (context.getApplicationInfo() != null && context.getApplicationInfo().icon != 0) {
                    iconRes = context.getApplicationInfo().icon;
                }
            } catch (Throwable ignored) {}
            if (iconRes == 0) {
                iconRes = android.R.drawable.sym_def_app_icon;
            }

            builder.setContentTitle(title)
                   .setContentText(desc)
                   .setAutoCancel(true)
                   .setSmallIcon(iconRes);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                builder.setColor(parseColorSafe(accentHex, 0xFF00E5FF));
            }

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                flags |= 0x04000000; // FLAG_IMMUTABLE
            }

            if (!mainUrl.isEmpty()) {
                builder.setContentIntent(createPendingIntent(context, mainUrl, 1001, flags));
            }

            if (actionCount >= 1 && !act1Label.isEmpty()) {
                builder.addAction(0, act1Label, createPendingIntent(context, act1Url.isEmpty() ? mainUrl : act1Url, 1002, flags));
            }
            if (actionCount >= 2 && !act2Label.isEmpty()) {
                builder.addAction(0, act2Label, createPendingIntent(context, act2Url.isEmpty() ? mainUrl : act2Url, 1003, flags));
            }
            if (actionCount >= 3 && !act3Label.isEmpty()) {
                builder.addAction(0, act3Label, createPendingIntent(context, act3Url.isEmpty() ? mainUrl : act3Url, 1004, flags));
            }

            nm.notify(7771, builder.build());
        } catch (Throwable ignored) {}
    }

    private static PendingIntent createPendingIntent(Context ctx, String url, int code, int flags) {
        try {
            String u = url != null ? url.trim() : "";
            if (!u.startsWith("http://") && !u.startsWith("https://") && !u.startsWith("tg://")) {
                u = "https://" + u;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return PendingIntent.getActivity(ctx, code, intent, flags);
        } catch (Throwable e) {
            Intent dummy = new Intent();
            return PendingIntent.getActivity(ctx, code, dummy, flags);
        }
    }

    private static String getConfig() {
        try {
            String s = MORSALIN_CONFIG;
            if (s.startsWith("MORSALIN_B64_CFG:")) {
                String b64 = s.substring("MORSALIN_B64_CFG:".length()).trim();
                if (!b64.isEmpty()) {
                    byte[] data = Base64.decode(b64, Base64.DEFAULT);
                    return new String(data, "UTF-8");
                }
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private static int parseColorSafe(String hex, int fallback) {
        try { return Color.parseColor(hex); } catch (Throwable e) { return fallback; }
    }

    private static int parseIntSafe(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Throwable e) { return fallback; }
    }
}
'''

# 3. MorsalinAnimatedTextView.java
text_anim_view_code = '''package com.morsalin.xmlcreator;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MorsalinAnimatedTextView extends TextView implements Runnable {

    public static final String MORSALIN_CONFIG = "MORSALIN_B64_CFG:''' + (' ' * (2048 - len('MORSALIN_B64_CFG:'))) + '''";

    private long startTimeMs = 0;
    private int animSpeedMs = 40;
    private int primaryColor = 0xFF00E5FF;
    private int secondaryColor = 0xFF7C4DFF;
    private String fullText = "MORSALIN ANIMATION";
    private boolean isRunning = false;

    public MorsalinAnimatedTextView(Context context) {
        super(context);
        init();
    }

    public MorsalinAnimatedTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MorsalinAnimatedTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public static MorsalinAnimatedTextView attachToActivity(final Activity activity) {
        return attachToActivity(activity, null);
    }

    public static MorsalinAnimatedTextView attachToActivity(final Context context) {
        if (context instanceof Activity) {
            return attachToActivity((Activity) context, null);
        }
        return null;
    }

    public static MorsalinAnimatedTextView attachToActivity(final Activity activity, final String customText) {
        if (activity == null) return null;
        try {
            final MorsalinAnimatedTextView tv = new MorsalinAnimatedTextView(activity);
            if (customText != null && !customText.isEmpty()) {
                tv.fullText = customText;
                tv.setText(customText);
            }
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (activity.isFinishing()) return;
                        if (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed()) return;
                        ViewGroup content = (ViewGroup) activity.findViewById(android.R.id.content);
                        if (content != null) {
                            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            );
                            lp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
                            lp.topMargin = 60;
                            tv.setLayoutParams(lp);
                            content.addView(tv);
                        }
                    } catch (Throwable ignored) {}
                }
            });
            return tv;
        } catch (Throwable t) {
            return null;
        }
    }

    public static void show(Context context) {
        if (context instanceof Activity) {
            attachToActivity((Activity) context);
        }
    }

    public static void show(Activity activity) {
        attachToActivity(activity);
    }

    public static void applyEffectToTextView(final TextView tv) {
        apply(tv);
    }

    public static void apply(final TextView tv) {
        if (tv == null) return;
        try {
            tv.setTextColor(0xFF00E5FF);
            tv.animate().alpha(0.3f).setDuration(400).withEndAction(new Runnable() {
                @Override
                public void run() {
                    try {
                        tv.animate().alpha(1.0f).setDuration(400).start();
                    } catch (Throwable ignored) {}
                }
            }).start();
        } catch (Throwable ignored) {}
    }

    private void init() {
        try {
            startTimeMs = System.currentTimeMillis();
            parseConfig();
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            setTypeface(null, android.graphics.Typeface.BOLD);
            setGravity(Gravity.CENTER);
            if (getText() == null || getText().length() == 0) {
                setText(fullText);
            }
            isRunning = true;
            post(this);
        } catch (Throwable ignored) {}
    }

    private void parseConfig() {
        try {
            String s = MORSALIN_CONFIG;
            if (s.startsWith("MORSALIN_B64_CFG:")) {
                String b64 = s.substring("MORSALIN_B64_CFG:".length()).trim();
                if (!b64.isEmpty()) {
                    byte[] data = Base64.decode(b64, Base64.DEFAULT);
                    String cfg = new String(data, "UTF-8");
                    String[] parts = cfg.split("\\\\|", -1);
                    if (parts.length > 0 && !parts[0].isEmpty()) {
                        fullText = parts[0];
                        setText(fullText);
                    }
                    if (parts.length > 2) {
                        try {
                            int sp = Integer.parseInt(parts[2].trim());
                            if (sp > 0) setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
                        } catch (Throwable ignored) {}
                    }
                    if (parts.length > 3 && !parts[3].isEmpty()) {
                        try { primaryColor = Color.parseColor(parts[3].trim()); } catch (Throwable ignored) {}
                    }
                    if (parts.length > 4 && !parts[4].isEmpty()) {
                        try { secondaryColor = Color.parseColor(parts[4].trim()); } catch (Throwable ignored) {}
                    }
                    if (parts.length > 8) {
                        try {
                            int dur = Integer.parseInt(parts[8].trim());
                            if (dur > 0) animSpeedMs = Math.max(16, dur / 30);
                        } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void run() {
        if (!isRunning) return;
        try {
            long elapsed = System.currentTimeMillis() - startTimeMs;
            float phase = (float) ((Math.sin(elapsed / 350.0) + 1.0) / 2.0);
            int r = (int) (Color.red(primaryColor) * phase + Color.red(secondaryColor) * (1 - phase));
            int g = (int) (Color.green(primaryColor) * phase + Color.green(secondaryColor) * (1 - phase));
            int b = (int) (Color.blue(primaryColor) * phase + Color.blue(secondaryColor) * (1 - phase));
            setTextColor(Color.rgb(r, g, b));
            invalidate();
            postDelayed(this, animSpeedMs);
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        isRunning = false;
        try { removeCallbacks(this); } catch (Throwable ignored) {}
    }
}
'''

# 4. MorsalinAnimationHelper.java
anim_helper_code = '''package com.morsalin.xmlcreator;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

public class MorsalinAnimationHelper {

    public static final String MORSALIN_CONFIG = "MORSALIN_B64_CFG:''' + (' ' * (2048 - len('MORSALIN_B64_CFG:'))) + '''";

    public static void playOnActivity(final Activity activity) {
        if (activity == null) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (activity.isFinishing()) return;
                    if (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed()) return;
                    View root = activity.findViewById(android.R.id.content);
                    if (root != null) {
                        playSequence(root);
                    }
                } catch (Throwable ignored) {}
            }
        });
    }

    public static void playOnActivity(final Context context) {
        if (context instanceof Activity) {
            playOnActivity((Activity) context);
        }
    }

    public static void show(Activity activity) {
        playOnActivity(activity);
    }

    public static void show(Context context) {
        playOnActivity(context);
    }

    public static void start(Activity activity) {
        playOnActivity(activity);
    }

    public static void start(View target) {
        playSequence(target);
    }

    public static void animate(View target) {
        playSequence(target);
    }

    public static AnimatorSet playSequence(View target) {
        AnimatorSet set = new AnimatorSet();
        if (target == null) return set;
        try {
            ObjectAnimator fadeIn = ObjectAnimator.ofFloat(target, View.ALPHA, 0.0f, 1.0f);
            fadeIn.setDuration(450);

            ObjectAnimator scaleX = ObjectAnimator.ofFloat(target, View.SCALE_X, 0.85f, 1.0f);
            scaleX.setDuration(450);

            ObjectAnimator scaleY = ObjectAnimator.ofFloat(target, View.SCALE_Y, 0.85f, 1.0f);
            scaleY.setDuration(450);

            set.playTogether(fadeIn, scaleX, scaleY);
            set.setInterpolator(new AccelerateDecelerateInterpolator());
            set.start();
        } catch (Throwable ignored) {}
        return set;
    }
}
'''

with open(f"{SRC_DIR}/MorsalinCustomDialog.java", "w") as f:
    f.write(custom_dialog_code)

with open(f"{SRC_DIR}/MorsalinNotificationHelper.java", "w") as f:
    f.write(notif_helper_code)

with open(f"{SRC_DIR}/MorsalinAnimatedTextView.java", "w") as f:
    f.write(text_anim_view_code)

with open(f"{SRC_DIR}/MorsalinAnimationHelper.java", "w") as f:
    f.write(anim_helper_code)

print("Java source files written successfully.")
